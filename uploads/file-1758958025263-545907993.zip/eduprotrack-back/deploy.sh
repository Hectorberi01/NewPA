#!/bin/bash

# Script de déploiement du backend EduProTrack sur GCP Cloud Run
# Usage: ./deploy.sh [PROJECT_ID] [PLAGIARISM_SERVICE_URL] [DATABASE_URL] [JWT_SECRET]

set -e

# Configuration
PROJECT_ID=${1:-"eduprotrack-project"}
PLAGIARISM_SERVICE_URL=${2:-"https://plagiarism-service.run.app"}
SERVICE_NAME="eduprotrack-backend"
REGION="europe-west1"

# Couleurs pour les logs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${GREEN}🚀 Déploiement du backend EduProTrack${NC}"
echo -e "${YELLOW}Project ID: ${PROJECT_ID}${NC}"
echo -e "${YELLOW}Plagiarism Service: ${PLAGIARISM_SERVICE_URL}${NC}"
echo -e "${YELLOW}Region: ${REGION}${NC}"

# Vérifier que gcloud est installé et configuré
if ! command -v gcloud &> /dev/null; then
    echo -e "${RED}❌ gcloud CLI n'est pas installé${NC}"
    exit 1
fi

# Vérifier l'authentification
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
    echo -e "${RED}❌ Non authentifié avec gcloud${NC}"
    echo "Exécutez: gcloud auth login"
    exit 1
fi

# Configurer le projet
echo -e "${YELLOW}📋 Configuration du projet...${NC}"
gcloud config set project $PROJECT_ID

# Activer les APIs nécessaires
echo -e "${YELLOW}🔧 Activation des APIs...${NC}"
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com
gcloud services enable containerregistry.googleapis.com
gcloud services enable secretmanager.googleapis.com

# Vérifier si les secrets existent
echo -e "${YELLOW}🔐 Vérification des secrets...${NC}"

# Fonction pour créer un secret s'il n'existe pas
create_secret_if_not_exists() {
    local secret_name=$1
    local secret_value=$2
    
    if ! gcloud secrets describe $secret_name &> /dev/null; then
        echo -e "${BLUE}📝 Création du secret $secret_name...${NC}"
        echo -n "$secret_value" | gcloud secrets create $secret_name --data-file=-
    else
        echo -e "${GREEN}✅ Secret $secret_name existe déjà${NC}"
    fi
}

# Demander les secrets s'ils ne sont pas fournis
if [ -z "$3" ]; then
    echo -e "${YELLOW}🔑 Veuillez entrer l'URL de la base de données:${NC}"
    read -s DATABASE_URL
else
    DATABASE_URL=$3
fi

if [ -z "$4" ]; then
    echo -e "${YELLOW}🔑 Veuillez entrer le JWT secret:${NC}"
    read -s JWT_SECRET
else
    JWT_SECRET=$4
fi

# Créer les secrets
create_secret_if_not_exists "database-url" "$DATABASE_URL"
create_secret_if_not_exists "jwt-secret" "$JWT_SECRET"

echo -e "${YELLOW}🏗️  Démarrage du build et déploiement...${NC}"

# Build et déploiement avec Cloud Build
gcloud builds submit \
  --config cloudbuild.yaml \
  --substitutions _PLAGIARISM_SERVICE_URL="$PLAGIARISM_SERVICE_URL" \
  .

# Vérifier le déploiement
echo -e "${YELLOW}🔍 Vérification du déploiement...${NC}"
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format="value(status.url)")

if [ -n "$SERVICE_URL" ]; then
    echo -e "${GREEN}✅ Backend déployé avec succès !${NC}"
    echo -e "${GREEN}🌐 URL du backend: $SERVICE_URL${NC}"
    echo -e "${GREEN}📚 API Documentation: $SERVICE_URL/api${NC}"
    
    # Test de santé
    echo -e "${YELLOW}🏥 Test de santé du service...${NC}"
    if curl -f "$SERVICE_URL/health" > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Backend opérationnel${NC}"
    else
        echo -e "${RED}⚠️  Le backend semble avoir des problèmes${NC}"
    fi
    
    echo ""
    echo -e "${GREEN}🎉 Déploiement terminé !${NC}"
    echo -e "${YELLOW}📝 Variables d'environnement pour le frontend:${NC}"
    echo "NEXT_PUBLIC_API_URL=$SERVICE_URL"
    
    echo -e "${YELLOW}📝 URL à mettre à jour dans le service de plagiat:${NC}"
    echo "BACKEND_HOST=$(echo $SERVICE_URL | sed 's|https\?://||')"
    
else
    echo -e "${RED}❌ Échec du déploiement${NC}"
    exit 1
fi