# 📚 API Documentation - EduProTrack Project Management

## 🚀 Installation et Setup

### Variables d'environnement requises
```env
DATABASE_URL="postgresql://..."
JWT_SECRET="your-secret-key"
SMTP_HOST="localhost"
SMTP_PORT="1025"
SMTP_USER=""
SMTP_PASSWORD=""
SMTP_FROM="noreply@eduprotrack.com"
FRONTEND_APP_URL="http://localhost:3000"
```

---

## 🎯 ROUTES API POUR DÉVELOPPEURS FRONTEND

### 🔐 Authentification

Toutes les routes (sauf login/register) nécessitent le header :
```http
Authorization: Bearer YOUR_JWT_TOKEN
```

---

## 🔑 BC1: IDENTITY & ACCESS MANAGEMENT

### **🚪 Routes d'Authentification**

#### `GET /auth/google` - Connexion Google OAuth
**Public** (redirection vers Google)
- Redirection automatique vers Google OAuth

#### `GET /auth/google/callback` - Callback Google OAuth
**Public** (callback automatique)
- Traite la réponse Google et redirige vers le frontend avec token

#### `GET /auth/azure` - Connexion Azure OAuth
**Public** (redirection vers Azure)
- Redirection automatique vers Azure OAuth

#### `GET /auth/azure/callback` - Callback Azure OAuth
**Public** (callback automatique)
- Traite la réponse Azure et redirige vers le frontend avec token

#### `POST /auth/student/login` - Connexion étudiant
**Public** (page de connexion spécifique étudiants)
```json
{
  "email": "student@school.com",
  "password": "GeneratedPassword123"
}
```
**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "clxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
    "email": "student@school.com",
    "firstname": "John",
    "lastname": "Doe",
    "role": "STUDENT"
  }
}
```

### **👥 Routes de Gestion des Utilisateurs**

#### `GET /users/me` - Mon profil détaillé
**Guards:** `JwtAuthGuard`
```json
{
  "id": "user-id",
  "email": "user@school.com",
  "firstname": "John",
  "lastname": "Doe",
  "role": "TEACHER",
  "createdAt": "2024-01-15T10:00:00.000Z"
}
```

#### `GET /users` - Lister tous les utilisateurs
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "user-id",
    "email": "user@school.com",
    "firstname": "John",
    "lastname": "Doe",
    "role": "TEACHER"
  }
]
```

#### `GET /users/students/without-promotion` - Étudiants sans promotion
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "student-id",
    "email": "student@school.com",
    "firstname": "Alice",
    "lastname": "Smith",
    "role": "STUDENT"
  }
]
```

#### `PUT /users/:id` - Modifier un utilisateur
**Guards:** `JwtAuthGuard`
```json
{
  "firstname": "John",
  "lastname": "Doe",
  "email": "john.doe@school.com"
}
```

#### `DELETE /users/:id` - Supprimer un utilisateur
**Guards:** `JwtAuthGuard`
**Response:**
```json
{
  "status": "success",
  "data": {
    "id": "deleted-user-id"
  }
}
```

#### `GET /users/promotion/teacher/:id` - Promotions d'un enseignant
**Guards:** `JwtAuthGuard`
```json
{
  "status": "success",
  "data": [
    {
      "id": "promotion-id",
      "name": "Master 2 Informatique 2024-2025"
    }
  ]
}
```

### **🎓 Routes de Gestion des Promotions**

#### `GET /promotions` - Lister toutes les promotions
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "promotion-id",
    "name": "Master 2 Informatique 2024-2025",
    "createdAt": "2024-01-15T10:00:00.000Z",
    "updatedAt": "2024-01-15T10:00:00.000Z"
  }
]
```

#### `POST /promotions` - Créer une promotion
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "name": "Master 2 Informatique 2024-2025"
}
```
**Response:**
```json
{
  "status": "success",
  "message": "Promotion créée avec succès",
  "data": {
    "id": "promotion-id",
    "name": "Master 2 Informatique 2024-2025",
    "teachers": [
      {
        "user": {
          "id": "teacher-id",
          "firstname": "John",
          "lastname": "Doe",
          "email": "john.doe@school.com"
        }
      }
    ],
    "_count": {
      "students": 0,
      "projects": 0
    }
  }
}
```

#### `GET /promotions/:promotionId/students` - Étudiants d'une promotion
**Guards:** `JwtAuthGuard`
```json
{
  "status": "success",
  "data": [
    {
      "id": "student-id",
      "firstname": "Alice",
      "lastname": "Smith",
      "email": "alice.smith@student.com",
      "role": "STUDENT",
      "createdAt": "2024-01-15T10:00:00.000Z"
    }
  ]
}
```

### **👥 Gestion des Étudiants dans une Promotion**

#### `POST /promotions/:promotionId/students` - Ajouter étudiants (avec création auto)
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "students": [
    {
      "firstname": "Jean",
      "lastname": "Dupont",
      "email": "jean.dupont@student.com"
    },
    {
      "firstname": "Marie",
      "lastname": "Martin",
      "email": "marie.martin@student.com"
    }
  ]
}
```
**Response:**
```json
{
  "status": "success",
  "message": "Opération terminée",
  "data": {
    "studentsCreated": 2,
    "studentsAddedToPromotion": 2,
    "studentsSkipped": 0,
    "newStudents": ["jean.dupont@student.com", "marie.martin@student.com"],
    "existingStudents": [],
    "skippedStudents": [],
    "errors": [],
    "summary": {
      "total": 2,
      "processed": 2,
      "created": 2,
      "skipped": 0,
      "errors": 0
    }
  }
}
```

#### `POST /promotions/:promotionId/students/existing` - Ajouter étudiants existants
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "students": ["student-id-1", "student-id-2"]
}
```

#### `DELETE /promotions/:promotionId/students` - Supprimer étudiants
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "students": ["student-id-1", "student-id-2"]
}
```

### **📁 Import d'Étudiants par Fichier**

#### `POST /promotions/:promotionId/import-students` - Import CSV/JSON
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Content-Type:** `multipart/form-data`
**Body:** 
- `file`: Fichier CSV ou JSON (max 5MB)

**Format CSV accepté:**
```csv
firstname,lastname,email
Jean,Dupont,jean.dupont@student.com
Marie,Martin,marie.martin@student.com
```

**Format JSON accepté:**
```json
{
  "students": [
    {
      "firstname": "Jean",
      "lastname": "Dupont",
      "email": "jean.dupont@student.com"
    },
    {
      "firstname": "Marie",
      "lastname": "Martin",
      "email": "marie.martin@student.com"
    }
  ]
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Import terminé",
  "data": {
    "success": true,
    "totalProcessed": 2,
    "studentsCreated": 2,
    "studentsAddedToPromotion": 2,
    "studentsSkipped": 0,
    "errors": [],
    "summary": {
      "newStudents": ["jean.dupont@student.com"],
      "existingStudents": ["marie.martin@student.com"],
      "skippedStudents": [],
      "failedStudents": []
    }
  }
}
```

#### `GET /promotions/import-template/csv` - Template CSV
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "status": "success",
  "data": {
    "template": "firstname,lastname,email\nJean,Dupont,jean.dupont@example.com\n...",
    "filename": "import-students-template.csv"
  }
}
```

#### `GET /promotions/import-template/json` - Template JSON
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "status": "success",
  "data": {
    "template": {
      "students": [
        {
          "firstname": "Jean",
          "lastname": "Dupont",
          "email": "jean.dupont@example.com"
        }
      ]
    },
    "filename": "import-students-template.json"
  }
}
```

### **🎓 Routes de Gestion des Étudiants**

#### `GET /students` - Lister tous les étudiants
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "student-id",
    "firstname": "Alice",
    "lastname": "Smith",
    "email": "alice.smith@student.com",
    "role": "STUDENT"
  }
]
```

#### `POST /students` - Créer un étudiant
**Guards:** `JwtAuthGuard`
```json
{
  "firstname": "Jean",
  "lastname": "Dupont",
  "email": "jean.dupont@student.com"
}
```

#### `POST /students/create-password` - Créer un mot de passe
**Guards:** `JwtAuthGuard`
```json
{
  "userId": "student-id",
  "password": "newPassword123"
}
```

### **👨‍🏫 Routes de Gestion des Enseignants**

#### `GET /teachers/:id` - Détails d'un enseignant
**Guards:** `JwtAuthGuard`
```json
{
  "id": "teacher-id",
  "firstname": "John",
  "lastname": "Doe",
  "email": "john.doe@school.com",
  "role": "TEACHER"
}
```

---

## 🎛️ BC2: PROJECT MANAGEMENT

### **📋 Gestion des Projets - Enseignants**

#### `POST /projects` - Créer un projet
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "title": "Projet Web Development",
  "description": "Création d'une application web complète",
  "promotionId": "clxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "groupMode": "FREE",
  "minGroupSize": 3,
  "maxGroupSize": 6,
  "groupCreationDeadline": "2024-03-15T23:59:00.000Z",
  "status": "DRAFT"
}
```
**Response:**
```json
{
  "id": "clxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "name": "Projet Web Development",
  "description": "Création d'une application web complète",
  "status": "DRAFT",
  "groupFormationMode": "FREE",
  "minGroupSize": 3,
  "maxGroupSize": 6,
  "groupDeadline": "2024-03-15T23:59:00.000Z",
  "teacher": {
    "id": "...",
    "firstname": "John",
    "lastname": "Doe",
    "email": "john.doe@school.com"
  },
  "promotion": {
    "id": "...",
    "name": "Master 2 Informatique"
  }
}
```

#### `GET /projects` - Lister tous les projets
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "project-id",
    "name": "Projet Web Development",
    "description": "Description du projet",
    "status": "VISIBLE",
    "teacher": {
      "id": "teacher-id",
      "firstname": "John",
      "lastname": "Doe"
    }
  }
]
```

#### `GET /projects/my-projects` - Mes projets (enseignant)
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
[
  {
    "id": "project-id",
    "name": "Projet Web Development",
    "status": "VISIBLE",
    "promotion": { "id": "...", "name": "Master 2 Informatique" },
    "groups": [
      {
        "id": "group-id",
        "name": "Groupe 1",
        "members": [
          {
            "user": {
              "id": "student-id",
              "firstname": "Alice",
              "lastname": "Smith",
              "email": "alice@student.com"
            }
          }
        ]
      }
    ]
  }
]
```

#### `GET /projects/teacher/:id` - Projets d'un enseignant
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Response:** Même format que `/projects/my-projects`

#### `GET /projects/:id` - Détails d'un projet
**Guards:** `JwtAuthGuard`
```json
{
  "id": "project-id",
  "name": "Projet Web Development",
  "description": "Description complète",
  "status": "VISIBLE",
  "groupFormationMode": "FREE",
  "minGroupSize": 3,
  "maxGroupSize": 6,
  "groupDeadline": "2024-03-15T23:59:00.000Z",
  "teacher": {
    "id": "teacher-id",
    "firstname": "John",
    "lastname": "Doe"
  },
  "promotion": {
    "id": "promotion-id",
    "name": "Master 2 Informatique"
  },
  "groups": ["..."]
}
```

#### `PUT /projects/:id/publish` - Publier un projet
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Body:** Aucun
**Response:** Projet mis à jour + **déclenchement automatique notification étudiants**

#### `PUT /projects/:id/group-config` - Configuration groupes
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "minGroupSize": 4,
  "maxGroupSize": 8,
  "groupDeadline": "2024-03-20T23:59:00.000Z"
}
```

#### `PUT /projects/:id/formation-mode` - Mode de formation
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "mode": "FREE"
}
```

#### `DELETE /projects/:projectId` - Supprimer un projet
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Response:** Confirmation de suppression

#### `GET /projects/student/:userId` - Projets d'un étudiant
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "project-id",
    "name": "Projet Web Development",
    "status": "VISIBLE",
    "teacher": {
      "firstname": "John",
      "lastname": "Doe"
    }
  }
]
```

### **👥 Gestion des Groupes - Enseignants**

#### `POST /projects/:id/groups` - Créer un groupe manuellement
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "name": "Groupe Alpha",
  "members": [
    "student-id-1",
    "student-id-2",
    "student-id-3"
  ]
}
```

#### `GET /projects/:id/groups` - Groupes d'un projet
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "group-id",
    "name": "Groupe 1",
    "members": [
      {
        "user": {
          "id": "student-id",
          "firstname": "Alice",
          "lastname": "Smith",
          "email": "alice@student.com"
        }
      }
    ]
  }
]
```

#### `POST /groups/project/:projectId` - Créer groupe pour projet
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "name": "Groupe Beta",
  "members": ["student-1", "student-2"]
}
```

#### `GET /groups/project/:projectId` - Groupes par projet
**Guards:** `JwtAuthGuard`
**Response:** Liste des groupes du projet

#### `GET /groups/:id` - Détails d'un groupe
**Guards:** `JwtAuthGuard`
```json
{
  "id": "group-id",
  "name": "Groupe 1",
  "project": {
    "id": "project-id",
    "name": "Projet Web"
  },
  "members": [
    {
      "user": {
        "id": "student-id",
        "firstname": "Alice",
        "lastname": "Smith"
      }
    }
  ]
}
```

#### `PATCH /groups/:id` - Modifier un groupe
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "name": "Nouveau nom du groupe"
}
```

#### `POST /groups/:id/members` - Ajouter un membre
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "userId": "student-id-to-add"
}
```

#### `DELETE /groups/:id/members/:userId` - Retirer un membre
**Guards:** `JwtAuthGuard`, `TeacherGuard`

#### `DELETE /groups/:id` - Supprimer un groupe
**Guards:** `JwtAuthGuard`, `TeacherGuard`

### **🎯 Gestion Avancée des Groupes**

#### `GET /groups/available/:projectId` - Groupes disponibles (étudiants)
**Guards:** `JwtAuthGuard`, `StudentGuard`
```json
{
  "project": {
    "id": "project-id",
    "name": "Projet Web Development",
    "minGroupSize": 3,
    "maxGroupSize": 6,
    "groupDeadline": "2024-03-15T23:59:00.000Z"
  },
  "availableGroups": [
    {
      "id": "group-id",
      "name": "Groupe 1",
      "currentMembersCount": 2,
      "maxMembers": 6,
      "members": [
        {
          "id": "student-id",
          "firstname": "Alice",
          "lastname": "Smith"
        }
      ]
    }
  ]
}
```

#### `POST /groups/:groupId/join` - Rejoindre un groupe
**Guards:** `JwtAuthGuard`, `StudentGuard`
**Body:** Aucun

#### `POST /groups/:groupId/leave` - Quitter un groupe
**Guards:** `JwtAuthGuard`, `StudentGuard`
**Body:** Aucun

#### `GET /groups/student/:projectId/my-group` - Mon groupe pour un projet
**Guards:** `JwtAuthGuard`, `StudentGuard`
```json
{
  "id": "group-id",
  "name": "Groupe 2",
  "members": [
    {
      "user": {
        "id": "my-id",
        "firstname": "Current",
        "lastname": "Student"
      }
    }
  ],
  "project": {
    "id": "project-id",
    "name": "Projet Web Development"
  }
}
```

#### `POST /groups/project/:projectId/auto-assign` - Affectation automatique
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "message": "3 étudiants ont été affectés automatiquement",
  "assignedStudents": 3,
  "totalAssignments": 2
}
```

#### `POST /groups/project/:projectId/random-assign` - Affectation aléatoire
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Response:** Résultat de l'affectation aléatoire

#### `POST /groups/project/:projectId/send-reminder` - Rappel deadline
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Response:** Confirmation d'envoi des rappels

---

## 🎓 ROUTES ÉTUDIANTS

---

## 🎓 ROUTES ÉTUDIANTS

### **📚 Interface Étudiant - Projets**

#### `GET /student/projects` - Mes projets disponibles
**Guards:** `JwtAuthGuard` + Role STUDENT
```json
[
  {
    "id": "project-id",
    "name": "Projet Web Development",
    "description": "Création d'une application web complète",
    "status": "VISIBLE",
    "groupFormationMode": "FREE",
    "minGroupSize": 3,
    "maxGroupSize": 6,
    "groupDeadline": "2024-03-15T23:59:00.000Z",
    "teacher": {
      "id": "teacher-id",
      "firstname": "John",
      "lastname": "Doe"
    },
    "groups": ["..."]
  }
]
```

#### `GET /student/projects/:id` - Détails d'un projet
**Guards:** `JwtAuthGuard` + Role STUDENT
**Response:** Même format que ci-dessus

#### `GET /student/projects/:id/groups/available` - Groupes disponibles
**Guards:** `JwtAuthGuard` + Role STUDENT
**Response:** Même format que `/groups/available/:projectId`

#### `GET /student/projects/:id/my-group` - Mon groupe pour ce projet
**Guards:** `JwtAuthGuard` + Role STUDENT
**Response:** Même format que `/groups/student/:projectId/my-group`

#### `POST /student/groups/:groupId/join` - Rejoindre un groupe
**Guards:** `JwtAuthGuard` + Role STUDENT
**Body:** Aucun

#### `DELETE /student/groups/:groupId/leave` - Quitter un groupe
**Guards:** `JwtAuthGuard` + Role STUDENT
**Body:** Aucun

### **📤 Interface Étudiant - Soumissions**

#### `GET /student/deliverables/:deliverableId` - Détails livrable pour étudiant
**Guards:** `JwtAuthGuard` + Role STUDENT
```json
{
  "id": "deliverable-id",
  "name": "Livrable 1 - Application Web",
  "description": "Première version de l'application",
  "type": "ARCHIVE",
  "deadline": "2024-04-15T23:59:00.000Z",
  "allowLateSubmission": true,
  "latePenalty": 2.5,
  "maxLateDays": 7,
  "project": {
    "id": "project-id",
    "name": "Projet Web Development"
  },
  "myGroup": {
    "id": "group-id",
    "name": "Groupe 1"
  },
  "submission": {
    "id": "delivery-id",
    "status": "SUBMITTED",
    "submittedAt": "2024-04-15T10:30:00.000Z",
    "isLate": false,
    "penalty": 0
  },
  "verificationRules": [
    {
      "type": "FILE_SIZE",
      "parameters": { "maxSizeMB": 10 },
      "errorMessage": "Fichier trop volumineux"
    }
  ]
}
```

#### `GET /student/my-deliveries` - Mes soumissions
**Guards:** `JwtAuthGuard` + Role STUDENT
```json
[
  {
    "deliverable": {
      "id": "deliverable-id",
      "name": "Livrable 1",
      "deadline": "2024-04-15T23:59:00.000Z"
    },
    "project": {
      "id": "project-id",
      "name": "Projet Web"
    },
    "group": {
      "id": "group-id",
      "name": "Groupe 1"
    },
    "submission": {
      "id": "delivery-id",
      "status": "SUBMITTED",
      "submittedAt": "2024-04-15T10:30:00.000Z",
      "isLate": false,
      "penalty": 0
    }
  }
]
```

#### `GET /student/upcoming-deadlines` - Prochaines échéances
**Guards:** `JwtAuthGuard` + Role STUDENT
```json
[
  {
    "type": "DELIVERABLE",
    "id": "deliverable-id",
    "title": "Livrable 2 - Base de données",
    "deadline": "2024-04-22T23:59:00.000Z",
    "daysRemaining": 7,
    "project": {
      "id": "project-id",
      "name": "Projet Web"
    },
    "hasSubmission": false
  },
  {
    "type": "REPORT_SECTION",
    "id": "section-id",
    "title": "Section Méthodologie",
    "deadline": "2024-04-20T23:59:00.000Z",
    "daysRemaining": 5,
    "report": {
      "id": "report-id",
      "title": "Rapport de stage"
    },
    "isCompleted": false
  }
]
```

#### `GET /student/my-reports` - Mes rapports
**Guards:** `JwtAuthGuard` + Role STUDENT
```json
[
  {
    "id": "report-id",
    "title": "Rapport de stage",
    "deadline": "2024-06-30T23:59:00Z",
    "project": {
      "id": "project-id",
      "name": "Projet Stage"
    },
    "group": {
      "id": "group-id",
      "name": "Groupe 1"
    },
    "progress": {
      "completedSections": 2,
      "totalSections": 5,
      "percentage": 40,
      "totalWords": 1245
    },
    "status": "IN_PROGRESS",
    "lastModified": "2024-03-15T14:30:00.000Z"
  }
]
```

#### `GET /student/notifications` - Mes notifications
**Guards:** `JwtAuthGuard` + Role STUDENT
```json
[
  {
    "id": "notif-1",
    "type": "DEADLINE_REMINDER",
    "title": "Rappel échéance",
    "message": "Le livrable 2 est à rendre dans 3 jours",
    "createdAt": "2024-03-15T09:00:00.000Z",
    "isRead": false,
    "relatedEntity": {
      "type": "DELIVERABLE",
      "id": "deliverable-id",
      "name": "Livrable 2"
    }
  },
  {
    "id": "notif-2",
    "type": "COLLABORATION_INVITE",
    "title": "Invitation collaboration",
    "message": "John vous invite à travailler sur la section Introduction",
    "createdAt": "2024-03-15T14:20:00.000Z",
    "isRead": true,
    "relatedEntity": {
      "type": "REPORT_SECTION",
      "id": "section-id",
      "title": "Introduction"
    }
  }
]
```

#### `PUT /student/notifications/:id/read` - Marquer comme lu
**Guards:** `JwtAuthGuard` + Role STUDENT
**Body:** Aucun
**Response:**
```json
{
  "id": "notif-1",
  "isRead": true,
  "readAt": "2024-03-15T15:30:00.000Z"
}
```

---

## 📦 BC3: DELIVERABLES & SUBMISSIONS MANAGEMENT

### **📋 Gestion des Livrables**

#### `POST /deliverables` - Créer un livrable
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "name": "Livrable 1 - Application Web",
  "description": "Première version de l'application avec fonctionnalités de base",
  "type": "ARCHIVE",
  "deadline": "2024-04-15T23:59:00.000Z",
  "allowLateSubmission": true,
  "latePenalty": 2.5,
  "maxLateDays": 7,
  "projectId": "project-id"
}
```
**Response:**
```json
{
  "id": "deliverable-id",
  "name": "Livrable 1 - Application Web",
  "description": "Première version de l'application avec fonctionnalités de base",
  "type": "ARCHIVE",
  "deadline": "2024-04-15T23:59:00.000Z",
  "allowLateSubmission": true,
  "latePenalty": 2.5,
  "maxLateDays": 7,
  "projectId": "project-id",
  "createdAt": "2024-03-01T10:00:00.000Z"
}
```

#### `GET /deliverables/:id` - Détails d'un livrable
**Guards:** `JwtAuthGuard`
```json
{
  "id": "deliverable-id",
  "name": "Livrable 1 - Application Web",
  "description": "Première version de l'application avec fonctionnalités de base",
  "type": "ARCHIVE",
  "deadline": "2024-04-15T23:59:00.000Z",
  "allowLateSubmission": true,
  "latePenalty": 2.5,
  "maxLateDays": 7,
  "projectId": "project-id",
  "verificationRules": [
    {
      "id": "rule-id",
      "type": "FILE_SIZE",
      "parameters": { "maxSizeMB": 10 },
      "errorMessage": "Fichier trop volumineux"
    }
  ],
  "createdAt": "2024-03-01T10:00:00.000Z"
}
```

#### `PUT /deliverables/:id` - Modifier un livrable
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "name": "Livrable 1 - Application Web (Modifié)",
  "description": "Description mise à jour",
  "deadline": "2024-04-20T23:59:00.000Z",
  "allowLateSubmission": false
}
```

#### `GET /projects/:projectId/deliverables` - Livrables d'un projet
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "deliverable-id",
    "name": "Livrable 1 - Application Web",
    "description": "Première version de l'application",
    "type": "ARCHIVE",
    "deadline": "2024-04-15T23:59:00.000Z",
    "allowLateSubmission": true,
    "latePenalty": 2.5,
    "maxLateDays": 7,
    "createdAt": "2024-03-01T10:00:00.000Z"
  }
]
```

### **⚙️ Règles de Validation**

#### `POST /verification-rules` - Créer une règle de validation
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "type": "FILE_SIZE",
  "parameters": {
    "maxSizeMB": 10
  },
  "errorMessage": "Le fichier ne doit pas dépasser 10MB",
  "deliverableId": "deliverable-id"
}
```

**Types de règles disponibles:**
- `FILE_SIZE`: Taille maximale du fichier
- `REQUIRED_FILES`: Fichiers obligatoires
- `FOLDER_STRUCTURE`: Structure de dossiers attendue
- `FILE_CONTENT`: Contenu de fichier (regex)

**Response:**
```json
{
  "id": "rule-id",
  "type": "FILE_SIZE",
  "parameters": {
    "maxSizeMB": 10
  },
  "errorMessage": "Le fichier ne doit pas dépasser 10MB",
  "deliverableId": "deliverable-id",
  "createdAt": "2024-03-01T10:00:00.000Z"
}
```

#### `GET /verification-rules/:id` - Détails d'une règle
**Guards:** `JwtAuthGuard`
**Response:** Détails de la règle spécifique

#### `PUT /verification-rules/:id` - Modifier une règle
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "type": "FILE_SIZE",
  "parameters": {
    "maxSizeMB": 15
  },
  "errorMessage": "Le fichier ne doit pas dépasser 15MB"
}
```

#### `DELETE /verification-rules/:id` - Supprimer une règle
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Response:** 204 No Content

#### `GET /deliverables/:deliverableId/verification-rules` - Règles d'un livrable
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "rule-id",
    "type": "FILE_SIZE",
    "parameters": {
      "maxSizeMB": 10
    },
    "errorMessage": "Le fichier ne doit pas dépasser 10MB"
  },
  {
    "id": "rule-id-2",
    "type": "REQUIRED_FILES",
    "parameters": {
      "files": ["README.md", "src/main.java"]
    },
    "errorMessage": "Fichiers obligatoires manquants"
  }
]
```

### **📤 Système de Soumissions (Deliveries)**

#### `POST /deliveries/upload-link/:deliverableId` - Générer lien d'upload
**Guards:** `JwtAuthGuard`, `StudentGuard`
```json
{
  "fileName": "projet_groupe1.zip",
  "fileSize": 2048576,
  "groupId": "group-id"
}
```
**Response:**
```json
{
  "uploadUrl": "https://storage.example.com/upload/signed-url",
  "fields": {
    "key": "deliveries/deliverable-id/group-id/file.zip",
    "policy": "encoded-policy",
    "signature": "signature"
  },
  "submissionId": "submission-id",
  "expiresAt": "2024-04-15T11:00:00.000Z"
}
```

#### `POST /deliveries/submit-file` - Confirmer soumission fichier
**Guards:** `JwtAuthGuard`, `StudentGuard`
```json
{
  "submissionId": "submission-id",
  "fileName": "projet_groupe1.zip",
  "fileSize": 2048576,
  "deliverableId": "deliverable-id",
  "groupId": "group-id"
}
```
**Response:**
```json
{
  "id": "delivery-id",
  "status": "SUBMITTED",
  "submittedAt": "2024-04-15T10:30:00.000Z",
  "fileName": "projet_groupe1.zip",
  "fileSize": 2048576,
  "isLate": false,
  "penalty": 0,
  "validationResults": {
    "isValid": true,
    "errors": [],
    "warnings": []
  }
}
```

#### `POST /deliveries/submit-git` - Soumission Git
**Guards:** `JwtAuthGuard`, `StudentGuard`
```json
{
  "gitUrl": "https://github.com/student/project.git",
  "commitHash": "abc123def456",
  "deliverableId": "deliverable-id",
  "groupId": "group-id"
}
```
**Response:**
```json
{
  "id": "delivery-id",
  "status": "VALIDATING",
  "submittedAt": "2024-04-15T10:30:00.000Z",
  "gitUrl": "https://github.com/student/project.git",
  "commitHash": "abc123def456",
  "isLate": false,
  "penalty": 0,
  "validationResults": null
}
```

#### `POST /deliveries/submit-archive` - Soumission archive
**Guards:** `JwtAuthGuard`, `StudentGuard`
**Content-Type:** `multipart/form-data`
**Body:**
- `file`: Archive (ZIP, TAR, etc.)
- `deliverableId`: ID du livrable
- `groupId`: ID du groupe

**Response:**
```json
{
  "id": "delivery-id",
  "status": "VALIDATING",
  "submittedAt": "2024-04-15T10:30:00.000Z",
  "fileName": "archive.zip",
  "fileSize": 3145728,
  "isLate": false,
  "penalty": 0
}
```

#### `GET /deliveries/:id` - Détails d'une soumission
**Guards:** `JwtAuthGuard`
```json
{
  "id": "delivery-id",
  "deliverable": {
    "id": "deliverable-id",
    "name": "Livrable 1",
    "deadline": "2024-04-15T23:59:00.000Z"
  },
  "group": {
    "id": "group-id",
    "name": "Groupe 1"
  },
  "status": "SUBMITTED",
  "submittedAt": "2024-04-15T10:30:00.000Z",
  "fileName": "projet_groupe1.zip",
  "fileSize": 2048576,
  "isLate": false,
  "penalty": 0,
  "businessDaysLate": 0,
  "validationResults": {
    "isValid": true,
    "errors": [],
    "warnings": ["Fichier README.md recommandé"]
  }
}
```

#### `GET /deliveries/deliverable/:deliverableId` - Soumissions d'un livrable
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "delivery-id",
    "group": {
      "id": "group-id",
      "name": "Groupe 1"
    },
    "status": "SUBMITTED",
    "submittedAt": "2024-04-15T10:30:00.000Z",
    "isLate": false,
    "penalty": 0
  }
]
```

#### `GET /deliveries/group/:groupId/deliverable/:deliverableId` - Soumission d'un groupe
**Guards:** `JwtAuthGuard`
**Response:** Détails de la soumission du groupe (même format que `/deliveries/:id`)

#### `PUT /deliveries/:id/penalty` - Modifier la pénalité (Enseignant)
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "penalty": 1.5,
  "reason": "Délai de grâce accordé"
}
```
**Response:**
```json
{
  "id": "delivery-id",
  "penalty": 1.5,
  "penaltyReason": "Délai de grâce accordé",
  "updatedAt": "2024-04-16T09:00:00.000Z"
}
```

---

## 📊 BC4: REPORTS - Rapports Multi-Parties & Collaboration

### **📝 Gestion des Rapports**

#### `POST /reports/projects/:projectId` - Créer un rapport multi-parties
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "title": "Rapport de stage",
  "description": "Rapport détaillé du stage en entreprise",
  "deadline": "2024-06-30T23:59:00Z",
  "collaborationType": "INDIVIDUAL",
  "isPublished": false,
  "allowModifications": true,
  "groupId": "group-id-optional",
  "sections": [
    {
      "title": "Introduction",
      "description": "Présentation du contexte",
      "isRequired": true,
      "minWords": 200,
      "maxWords": 500,
      "allowImages": true,
      "allowTables": true,
      "allowCode": false,
      "template": "Commencez par présenter le contexte...",
      "deadline": "2024-06-15T23:59:00Z"
    },
    {
      "title": "Méthodologie",
      "description": "Description de l'approche",
      "isRequired": true,
      "minWords": 300,
      "maxWords": 800,
      "dependsOn": "section-1-id"
    }
  ]
}
```
**Response:**
```json
{
  "id": "report-id",
  "title": "Rapport de stage",
  "description": "Rapport détaillé du stage en entreprise",
  "projectId": "project-id",
  "groupId": "group-id",
  "deadline": "2024-06-30T23:59:00Z",
  "status": "DRAFT",
  "isPublished": false,
  "collaborationType": "INDIVIDUAL",
  "allowModifications": true,
  "sections": [
    {
      "id": "section-1",
      "title": "Introduction",
      "description": "Présentation du contexte",
      "order": 1,
      "isRequired": true,
      "minWords": 200,
      "maxWords": 500,
      "content": "",
      "wordCount": 0,
      "isCompleted": false,
      "allowImages": true,
      "allowTables": true,
      "allowCode": false,
      "template": "Commencez par présenter le contexte..."
    }
  ],
  "createdAt": "2024-03-15T10:00:00.000Z",
  "updatedAt": "2024-03-15T10:00:00.000Z"
}
```

#### `GET /reports/:id` - Récupérer un rapport
**Guards:** `JwtAuthGuard`
**Response (Enseignant):**
```json
{
  "id": "report-id",
  "title": "Rapport de stage",
  "sections": ["..."],
  "statistics": {
    "totalSections": 3,
    "completedSections": 1,
    "progressPercentage": 33,
    "totalWords": 450,
    "lastModified": "2024-03-15T14:30:00.000Z"
  }
}
```
**Response (Étudiant):** Même format sans `statistics`

#### `PUT /reports/:id` - Modifier un rapport
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "title": "Nouveau titre",
  "description": "Nouvelle description",
  "isPublished": true,
  "allowModifications": false
}
```

#### `DELETE /reports/:id` - Supprimer un rapport
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Response:** 204 No Content

#### `GET /reports/projects/:projectId` - Rapports d'un projet
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "report-id",
    "title": "Rapport de stage",
    "sections": [
      {
        "id": "section-1",
        "title": "Introduction",
        "isRequired": true,
        "isCompleted": false,
        "order": 1
      }
    ],
    "group": {
      "id": "group-id",
      "name": "Groupe 1"
    }
  }
]
```

#### `PUT /reports/:id/sections/reorder` - Réorganiser les sections
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "sectionIds": ["section-3", "section-1", "section-2"]
}
```

### **📄 Gestion des Sections**

#### `POST /reports/:id/sections` - Ajouter une section
**Guards:** `JwtAuthGuard`
```json
{
  "title": "Nouvelle section",
  "description": "Description de la section",
  "isRequired": true,
  "minWords": 100,
  "maxWords": 500,
  "allowImages": true,
  "template": "Template de la section..."
}
```

#### `GET /reports/sections/:id` - Détails d'une section
**Guards:** `JwtAuthGuard`
```json
{
  "id": "section-id",
  "title": "Introduction",
  "description": "Présentation du contexte",
  "content": "Contenu de la section...",
  "order": 1,
  "isRequired": true,
  "minWords": 200,
  "maxWords": 500,
  "wordCount": 245,
  "isCompleted": true,
  "allowImages": true,
  "allowTables": true,
  "allowCode": false,
  "template": "Commencez par présenter...",
  "dependentOn": {
    "id": "section-0",
    "title": "Section précédente"
  },
  "dependencies": [
    {
      "id": "section-2",
      "title": "Section suivante"
    }
  ]
}
```

#### `PUT /reports/sections/:id` - Modifier une section
**Guards:** `JwtAuthGuard`
```json
{
  "title": "Nouveau titre",
  "description": "Nouvelle description",
  "minWords": 150,
  "maxWords": 600,
  "allowCode": true
}
```

#### `PUT /reports/sections/:id/content` - Modifier le contenu
**Guards:** `JwtAuthGuard`
```json
{
  "content": "Nouveau contenu de la section avec suffisamment de mots pour respecter les contraintes..."
}
```
**Response:**
```json
{
  "id": "section-id",
  "content": "Nouveau contenu...",
  "wordCount": 15,
  "isCompleted": false
}
```

#### `POST /reports/sections/:id/validate` - Valider le contenu
**Guards:** `JwtAuthGuard`
```json
{
  "content": "Contenu à valider..."
}
```
**Response:**
```json
{
  "isValid": true,
  "errors": [],
  "wordCount": 245
}
```
**Response (Erreurs):**
```json
{
  "isValid": false,
  "errors": [
    "Minimum 200 mots requis (actuellement 150)",
    "Les images ne sont pas autorisées dans cette section"
  ],
  "wordCount": 150
}
```

#### `DELETE /reports/sections/:id` - Supprimer une section
**Guards:** `JwtAuthGuard`
**Response:** 204 No Content

### **🔄 Gestion du Contenu et Versioning**

#### `POST /reports/content/versions` - Créer une version du contenu
**Guards:** `JwtAuthGuard`
```json
{
  "sectionId": "section-id",
  "content": "Nouveau contenu de la section...",
  "versionComment": "Ajout de l'introduction"
}
```
**Response:**
```json
{
  "id": "version-id",
  "versionNumber": 2,
  "content": "Nouveau contenu de la section...",
  "comment": "Ajout de l'introduction",
  "wordCount": 145,
  "createdAt": "2024-03-15T14:30:00.000Z",
  "author": {
    "id": "user-id",
    "firstname": "John",
    "lastname": "Doe"
  }
}
```

#### `GET /reports/content/sections/:sectionId/versions` - Historique des versions
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "version-id-2",
    "versionNumber": 2,
    "comment": "Ajout de l'introduction",
    "wordCount": 145,
    "createdAt": "2024-03-15T14:30:00.000Z",
    "author": {
      "firstname": "John",
      "lastname": "Doe"
    }
  },
  {
    "id": "version-id-1",
    "versionNumber": 1,
    "comment": "Version initiale",
    "wordCount": 0,
    "createdAt": "2024-03-15T10:00:00.000Z",
    "author": {
      "firstname": "System",
      "lastname": ""
    }
  }
]
```

#### `GET /reports/content/versions/:versionId` - Détails d'une version
**Guards:** `JwtAuthGuard`
```json
{
  "id": "version-id",
  "versionNumber": 2,
  "content": "Contenu complet de la version...",
  "comment": "Ajout de l'introduction",
  "wordCount": 145,
  "createdAt": "2024-03-15T14:30:00.000Z",
  "author": {
    "id": "user-id",
    "firstname": "John",
    "lastname": "Doe"
  },
  "section": {
    "id": "section-id",
    "title": "Introduction"
  }
}
```

#### `POST /reports/content/versions/:versionId/restore` - Restaurer une version
**Guards:** `JwtAuthGuard`
**Body:** Aucun
**Response:**
```json
{
  "sectionId": "section-id",
  "content": "Contenu restauré...",
  "currentVersion": 3,
  "restoredFromVersion": 1
}
```

#### `POST /reports/content/auto-save` - Sauvegarde automatique
**Guards:** `JwtAuthGuard`
```json
{
  "sectionId": "section-id",
  "content": "Contenu en cours d'édition...",
  "wordCount": 87
}
```
**Response:**
```json
{
  "saved": true,
  "timestamp": "2024-03-15T14:35:00.000Z",
  "wordCount": 87
}
```

#### `GET /reports/content/auto-save/:sectionId` - Récupérer sauvegarde auto
**Guards:** `JwtAuthGuard`
```json
{
  "sectionId": "section-id",
  "content": "Contenu sauvegardé automatiquement...",
  "wordCount": 87,
  "lastSaved": "2024-03-15T14:35:00.000Z",
  "hasUnsavedChanges": true
}
```

#### `POST /reports/content/diff` - Comparer versions
**Guards:** `JwtAuthGuard`
```json
{
  "fromVersionId": "version-1",
  "toVersionId": "version-2"
}
```
**Response:**
```json
{
  "fromVersion": {
    "number": 1,
    "content": "Contenu original..."
  },
  "toVersion": {
    "number": 2,
    "content": "Contenu modifié..."
  },
  "diff": {
    "additions": 25,
    "deletions": 5,
    "changes": [
      {
        "type": "addition",
        "line": 3,
        "content": "Nouveau paragraphe ajouté"
      }
    ]
  }
}
```

#### `POST /reports/content/merge` - Fusionner versions (collaboration)
**Guards:** `JwtAuthGuard`
```json
{
  "baseVersionId": "version-1",
  "currentVersionId": "version-2",
  "incomingContent": "Contenu à fusionner..."
}
```
**Response:**
```json
{
  "mergedContent": "Contenu fusionné...",
  "conflicts": [],
  "wordCount": 234,
  "newVersionId": "version-3"
}
```

### **👥 Collaboration Temps Réel**

#### `POST /reports/collaboration/sections/:sectionId/lock` - Verrouiller section
**Guards:** `JwtAuthGuard`
**Body:** Aucun
**Response:**
```json
{
  "sectionId": "section-id",
  "lockedBy": {
    "id": "user-id",
    "firstname": "John",
    "lastname": "Doe"
  },
  "lockedAt": "2024-03-15T14:40:00.000Z",
  "expiresAt": "2024-03-15T15:40:00.000Z"
}
```

#### `DELETE /reports/collaboration/sections/:sectionId/lock` - Déverrouiller section
**Guards:** `JwtAuthGuard`
**Response:** 204 No Content

#### `GET /reports/collaboration/sections/:sectionId/lock-status` - Statut verrouillage
**Guards:** `JwtAuthGuard`
```json
{
  "isLocked": true,
  "lockedBy": {
    "id": "user-id",
    "firstname": "John",
    "lastname": "Doe"
  },
  "lockedAt": "2024-03-15T14:40:00.000Z",
  "expiresAt": "2024-03-15T15:40:00.000Z",
  "canEdit": false,
  "canForceUnlock": false
}
```

#### `POST /reports/collaboration/sections/:sectionId/comments` - Ajouter commentaire
**Guards:** `JwtAuthGuard`
```json
{
  "content": "Il faudrait développer cette partie",
  "selection": {
    "start": 120,
    "end": 145
  },
  "type": "SUGGESTION"
}
```
**Response:**
```json
{
  "id": "comment-id",
  "content": "Il faudrait développer cette partie",
  "type": "SUGGESTION",
  "selection": {
    "start": 120,
    "end": 145
  },
  "author": {
    "id": "user-id",
    "firstname": "John",
    "lastname": "Doe"
  },
  "createdAt": "2024-03-15T14:45:00.000Z",
  "isResolved": false
}
```

#### `GET /reports/collaboration/sections/:sectionId/comments` - Commentaires section
**Guards:** `JwtAuthGuard`
```json
[
  {
    "id": "comment-id",
    "content": "Il faudrait développer cette partie",
    "type": "SUGGESTION",
    "author": {
      "firstname": "John",
      "lastname": "Doe"
    },
    "createdAt": "2024-03-15T14:45:00.000Z",
    "isResolved": false,
    "replies": [
      {
        "id": "reply-id",
        "content": "Bonne idée, je m'en occupe",
        "author": {
          "firstname": "Alice",
          "lastname": "Smith"
        },
        "createdAt": "2024-03-15T15:00:00.000Z"
      }
    ]
  }
]
```

#### `PUT /reports/collaboration/comments/:commentId/resolve` - Résoudre commentaire
**Guards:** `JwtAuthGuard`
**Body:** Aucun
**Response:**
```json
{
  "id": "comment-id",
  "isResolved": true,
  "resolvedAt": "2024-03-15T15:30:00.000Z",
  "resolvedBy": {
    "firstname": "Alice",
    "lastname": "Smith"
  }
}
```

#### `POST /reports/collaboration/presence` - Signaler présence
**Guards:** `JwtAuthGuard`
```json
{
  "reportId": "report-id",
  "sectionId": "section-id",
  "cursorPosition": 234
}
```
**Response:**
```json
{
  "userId": "user-id",
  "reportId": "report-id",
  "sectionId": "section-id",
  "cursorPosition": 234,
  "lastSeen": "2024-03-15T15:35:00.000Z"
}
```

#### `GET /reports/collaboration/:reportId/presence` - Présence utilisateurs
**Guards:** `JwtAuthGuard`
```json
[
  {
    "user": {
      "id": "user-1",
      "firstname": "John",
      "lastname": "Doe"
    },
    "sectionId": "section-1",
    "cursorPosition": 234,
    "isTyping": true,
    "lastSeen": "2024-03-15T15:35:00.000Z"
  },
  {
    "user": {
      "id": "user-2",
      "firstname": "Alice",
      "lastname": "Smith"
    },
    "sectionId": "section-2",
    "cursorPosition": 89,
    "isTyping": false,
    "lastSeen": "2024-03-15T15:33:00.000Z"
  }
]
```

### **👨‍🏫 Interface Enseignant - Rapports**

#### `GET /reports/teacher/:reportId/overview` - Vue d'ensemble enseignant
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "report": {
    "id": "report-id",
    "title": "Rapport de stage",
    "deadline": "2024-06-30T23:59:00Z"
  },
  "statistics": {
    "totalGroups": 8,
    "groupsStarted": 6,
    "groupsCompleted": 2,
    "averageProgress": 34.5,
    "totalWords": 12450,
    "averageWordsPerGroup": 2075
  },
  "sectionProgress": [
    {
      "sectionId": "section-1",
      "title": "Introduction",
      "completionRate": 75,
      "averageWords": 245
    }
  ],
  "recentActivity": [
    {
      "groupId": "group-1",
      "groupName": "Groupe Alpha",
      "action": "section_completed",
      "sectionTitle": "Introduction",
      "timestamp": "2024-03-15T14:30:00.000Z"
    }
  ]
}
```

#### `GET /reports/teacher/:reportId/groups` - Rapports par groupe
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
[
  {
    "groupId": "group-1",
    "groupName": "Groupe Alpha",
    "members": [
      {
        "firstname": "John",
        "lastname": "Doe"
      }
    ],
    "progress": {
      "completedSections": 2,
      "totalSections": 5,
      "percentage": 40,
      "totalWords": 1245,
      "lastActivity": "2024-03-15T14:30:00.000Z"
    },
    "status": "IN_PROGRESS"
  }
]
```

#### `GET /reports/teacher/:reportId/groups/:groupId/detailed` - Rapport détaillé groupe
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "group": {
    "id": "group-1",
    "name": "Groupe Alpha"
  },
  "sections": [
    {
      "id": "section-1",
      "title": "Introduction",
      "content": "Contenu de l'introduction...",
      "wordCount": 245,
      "isCompleted": true,
      "lastModified": "2024-03-15T14:30:00.000Z",
      "lastModifiedBy": {
        "firstname": "John",
        "lastname": "Doe"
      },
      "comments": [
        {
          "id": "comment-1",
          "content": "Très bon début",
          "author": {
            "firstname": "Teacher",
            "lastname": "Smith"
          },
          "isTeacherComment": true
        }
      ]
    }
  ]
}
```

#### `POST /reports/teacher/:reportId/groups/:groupId/annotations` - Ajouter annotation
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "sectionId": "section-1",
  "content": "Excellente analyse, continuez ainsi",
  "type": "PRAISE",
  "selection": {
    "start": 120,
    "end": 145
  },
  "isPrivate": false
}
```
**Response:**
```json
{
  "id": "annotation-id",
  "content": "Excellente analyse, continuez ainsi",
  "type": "PRAISE",
  "selection": {
    "start": 120,
    "end": 145
  },
  "isPrivate": false,
  "createdAt": "2024-03-15T15:00:00.000Z"
}
```

#### `GET /reports/teacher/:reportId/annotations` - Toutes les annotations
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
[
  {
    "id": "annotation-id",
    "content": "Excellente analyse",
    "type": "PRAISE",
    "section": {
      "id": "section-1",
      "title": "Introduction"
    },
    "group": {
      "id": "group-1",
      "name": "Groupe Alpha"
    },
    "createdAt": "2024-03-15T15:00:00.000Z"
  }
]
```

#### `PUT /reports/teacher/annotations/:annotationId` - Modifier annotation
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "content": "Très bonne analyse, développez davantage",
  "type": "SUGGESTION"
}
```

#### `DELETE /reports/teacher/annotations/:annotationId` - Supprimer annotation
**Guards:** `JwtAuthGuard`, `TeacherGuard`
**Response:** 204 No Content

#### `POST /reports/teacher/:reportId/export` - Exporter rapport
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "format": "PDF",
  "includeComments": true,
  "includeAnnotations": true,
  "groupIds": ["group-1", "group-2"]
}
```
**Response:**
```json
{
  "exportId": "export-id",
  "downloadUrl": "https://storage.example.com/exports/report-export.pdf",
  "format": "PDF",
  "fileSize": 2048576,
  "expiresAt": "2024-03-16T15:00:00.000Z"
}
```

#### `GET /reports/teacher/:reportId/analytics` - Analytiques détaillées
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "writingPatterns": {
    "averageWordsPerDay": 125,
    "peakWritingHours": ["14:00", "16:00", "20:00"],
    "collaborationLevel": 0.75
  },
  "sectionAnalysis": [
    {
      "sectionId": "section-1",
      "title": "Introduction",
      "averageCompletionTime": "2.5 hours",
      "difficultyScore": 0.3,
      "revisionCount": 4.2
    }
  ],
  "groupComparison": [
    {
      "groupId": "group-1",
      "groupName": "Groupe Alpha",
      "totalWords": 2456,
      "qualityScore": 0.85,
      "collaborationScore": 0.92
    }
  ]
}
```

#### `GET /reports/teacher/:reportId/plagiarism` - Détection plagiat
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "scanStatus": "COMPLETED",
  "lastScanAt": "2024-03-15T12:00:00.000Z",
  "suspiciousGroups": [
    {
      "groupId": "group-3",
      "groupName": "Groupe Gamma",
      "similarityScore": 0.85,
      "suspiciousSections": [
        {
          "sectionId": "section-2",
          "title": "Méthodologie",
          "similarityScore": 0.92,
          "matchedWith": {
            "source": "GROUP",
            "groupId": "group-1",
            "groupName": "Groupe Alpha"
          }
        }
      ]
    }
  ]
}
```

#### `POST /reports/teacher/:reportId/feedback` - Feedback global
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "groupId": "group-1",
  "content": "Très bon travail d'ensemble. Continuez sur cette voie.",
  "rating": 4.5,
  "suggestions": [
    "Développer davantage la partie méthodologie",
    "Ajouter plus d'exemples concrets"
  ]
}
```
**Response:**
```json
{
  "id": "feedback-id",
  "content": "Très bon travail d'ensemble...",
  "rating": 4.5,
  "suggestions": ["..."],
  "createdAt": "2024-03-15T16:00:00.000Z"
}
```

#### `GET /reports/teacher/:reportId/timeline` - Timeline activité
**Guards:** `JwtAuthGuard`, `TeacherGuard`
```json
{
  "events": [
    {
      "timestamp": "2024-03-15T14:30:00.000Z",
      "type": "SECTION_COMPLETED",
      "groupId": "group-1",
      "groupName": "Groupe Alpha",
      "sectionTitle": "Introduction",
      "user": {
        "firstname": "John",
        "lastname": "Doe"
      }
    },
    {
      "timestamp": "2024-03-15T13:45:00.000Z",
      "type": "COLLABORATION_START",
      "groupId": "group-2",
      "groupName": "Groupe Beta",
      "sectionTitle": "Méthodologie",
      "participants": 3
    }
  ],
  "totalEvents": 45,
  "lastActivity": "2024-03-15T14:30:00.000Z"
}
```

---

## 📬 BC5: NOTIFICATIONS

### **🔔 Gestion des Notifications**

#### `GET /health` - Santé du service notifications
**Public**
```json
{
  "status": "ok",
  "service": "notification-service",
  "timestamp": "2024-03-15T10:00:00.000Z",
  "pubsub": "emulator"
}
```

#### `POST /test/user-created` - Test notification création utilisateur
**Public** (pour tests)
```json
{
  "name": "John Doe",
  "email": "john.doe@example.com",
  "role": "STUDENT"
}
```
**Response:**
```json
{
  "success": true,
  "data": {
    "name": "John Doe",
    "email": "john.doe@example.com",
    "role": "STUDENT"
  }
}
```

---

## 📊 BC6: GRADING & EVALUATION SYSTEM

### **🎯 Grade Entry & Scoring**

#### `POST /grade-entries` - Créer une évaluation
**Teacher Only**
```json
{
  "gridId": "grid-uuid",
  "evaluatedEntityId": "group-uuid", 
  "entityType": "GROUP",
  "status": "DRAFT",
  "scores": [
    {
      "criterionId": "criterion-uuid",
      "valueType": "NUMERIC",
      "numericValue": 18,
      "feedback": "Excellent travail technique"
    }
  ],
  "globalComments": "Très bon travail global",
  "privateNotes": "À encourager pour la suite",
  "bonusScore": 0,
  "autoSaveEnabled": true
}
```

#### `GET /grade-entries/:id` - Détails évaluation
**Teacher Only**
```json
{
  "id": "eval-uuid",
  "gridId": "grid-uuid",
  "evaluatedEntityId": "group-uuid",
  "status": "DRAFT",
  "calculatedScore": 16.4,
  "totalScore": 16.4,
  "completionPercentage": 100,
  "canFinalize": true,
  "scores": [...],
  "scoreBreakdown": [
    {
      "criterionId": "criterion-uuid",
      "criterionName": "Qualité technique",
      "score": 18,
      "maxScore": 20,
      "weight": 60,
      "contributionToTotal": 10.8,
      "isBonus": false
    }
  ],
  "entity": {
    "id": "group-uuid",
    "name": "Groupe Alpha",
    "members": [...]
  }
}
```

#### `PUT /grade-entries/:id` - Modifier évaluation
**Teacher Only** - Même format que POST

#### `POST /grade-entries/:id/finalize` - Finaliser évaluation
**Teacher Only**
```json
{
  "id": "eval-uuid",
  "status": "FINALIZED",
  "finalizedAt": "2024-01-15T10:30:00Z",
  "isVisibleToStudents": true
}
```

#### `POST /grade-entries/:id/auto-save` - Sauvegarde automatique
**Teacher Only** - Format UpdateGradeEntryDto

#### `POST /grade-entries/bulk` - Notation en lot
**Teacher Only**
```json
{
  "gridId": "grid-uuid",
  "entityIds": ["group1-uuid", "group2-uuid"],
  "scores": [
    {
      "criterionId": "criterion-uuid",
      "valueType": "NUMERIC", 
      "numericValue": 15
    }
  ]
}
```
**Response:**
```json
{
  "updated": [...],
  "created": [...],
  "errors": [
    {
      "entityId": "group3-uuid",
      "error": "Groupe introuvable"
    }
  ]
}
```

#### `POST /grade-entries/copy` - Copier notes entre entités
**Teacher Only**
```json
{
  "sourceEvaluationId": "eval-uuid",
  "targetEntityId": "group2-uuid",
  "criteriaIds": ["criterion1-uuid", "criterion2-uuid"]
}
```

#### `GET /grade-entries/grid/:gridId` - Évaluations d'une grille
**Teacher Only**
```json
[
  {
    "id": "eval-uuid",
    "evaluatedEntityId": "group-uuid",
    "status": "FINALIZED",
    "totalScore": 16.4,
    "group": {
      "id": "group-uuid",
      "name": "Groupe Alpha"
    }
  }
]
```

#### `GET /grade-entries/grid/:gridId/progress` - Progression notation
**Teacher Only**
```json
{
  "totalEntities": 10,
  "evaluatedCount": 7,
  "finalizedCount": 5,
  "progressPercentage": 70,
  "finalizationPercentage": 50,
  "pendingEvaluations": 3,
  "draftEvaluations": 2
}
```

#### `GET /grade-entries/grid/:gridId/summary` - Statistiques grille
**Teacher Only**
```json
{
  "averageScore": 14.2,
  "highestScore": 18.5,
  "lowestScore": 8.0,
  "distribution": {
    "0-5": 1,
    "6-10": 2,
    "11-15": 4,
    "16-20": 3
  },
  "totalEvaluations": 10
}
```

### **📋 Enums & Status Workflow**

#### **EvaluationStatus**
- `DRAFT` - Évaluation en cours de saisie
- `FINALIZED` - Évaluation finalisée, visible aux étudiants
- `LOCKED` - Évaluation verrouillée, non modifiable

#### **ScoreValueType**
- `NUMERIC` - Note numérique (ex: 15/20)
- `SCALE` - Échelle personnalisée (ex: A/B/C/D)
- `BOOLEAN` - Acquis/Non-acquis
- `TEXT` - Commentaire textuel uniquement

---

## 🎯 SECTION DÉVELOPPEMENT MOBILE

### **📱 Application Mobile pour Enseignants**

**Important :** L'application mobile est exclusivement destinée aux **enseignants** et permet uniquement :
1. **Suivre les livrables** - Consulter l'état des soumissions étudiantes
2. **Lire les rapports** - Consulter les rapports rédigés par les étudiants
3. **Remplir les grilles de notation** - Saisir et modifier les notes

### **🔐 Phase 1: Authentification Enseignant**

#### **Routes Disponibles:**
```http
GET /auth/google              # OAuth Google (redirection)
GET /auth/azure               # OAuth Azure (redirection) 
GET /auth/me                  # Profil utilisateur connecté
```

#### **DTOs Mobile - Authentification:**
```typescript
// TeacherProfileDto (depuis /auth/me)
interface TeacherProfileDto {
  id: string;
  email: string;
  firstname: string;
  lastname: string;
  role: "TEACHER";              // Seuls les enseignants
  createdAt: string;
}

// OAuth Response (callback)
interface OAuthResponseDto {
  // Redirection automatique vers frontend avec token
  redirectUrl: string; // Ex: "app://teacher?token=JWT_TOKEN"
}
```

### **📋 Phase 2: Suivi des Livrables (Disponible)**

#### **Routes Disponibles:**
```http
GET /projects/my-projects                              # Mes projets enseignant
GET /projects/:projectId/deliverables                 # Livrables d'un projet
GET /projects/:projectId/deliverables/:deliverableId  # Détails livrable
GET /projects/:projectId/groups                       # Groupes d'un projet
```

#### **DTOs Mobile - Suivi Livrables:**
```typescript
// TeacherProjectDto
interface TeacherProjectDto {
  id: string;
  name: string;
  status: "VISIBLE" | "DRAFT";
  promotion: {
    id: string;
    name: string;
  };
  groups: Array<{
    id: string;
    name: string;
    members: Array<{
      user: {
        firstname: string;
        lastname: string;
      };
    }>;
  }>;
  deliverablesCount: number;
  submissionsCount: number;
}

// DeliverableTrackingDto
interface DeliverableTrackingDto {
  id: string;
  name: string;
  deadline: string;
  type: "ARCHIVE" | "GIT_LINK";
  submissionStats: {
    totalGroups: number;
    submittedGroups: number;
    lateSubmissions: number;
    submissionRate: number;     // Pourcentage
  };
  groupSubmissions: Array<{
    groupId: string;
    groupName: string;
    status: "NOT_SUBMITTED" | "SUBMITTED" | "LATE";
    submittedAt?: string;
    fileName?: string;
    isValid: boolean;
  }>;
}
```

### **📄 Phase 3: Lecture des Rapports (À Développer)**

#### **Routes à Implémenter:**
```http
# Ces endpoints n'existent pas encore - à développer
GET /projects/:projectId/reports                      # Rapports d'un projet
GET /reports/:reportId                                 # Détails d'un rapport
GET /reports/:reportId/groups/:groupId                # Rapport d'un groupe
GET /reports/:reportId/groups/:groupId/sections       # Sections du rapport
```

#### **DTOs Mobile - Rapports (À Implémenter):**
```typescript
// ReportListDto
interface ReportListDto {
  id: string;
  name: string;
  description: string;
  deadline: string;
  sectionsCount: number;
  completionStats: {
    totalGroups: number;
    completedReports: number;
    averageProgress: number;    // Pourcentage
  };
}

// GroupReportDto  
interface GroupReportDto {
  reportId: string;
  groupId: string;
  groupName: string;
  completionStatus: "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED";
  sections: Array<{
    id: string;
    title: string;
    content: string;            // HTML/Markdown
    wordCount: number;
    lastModifiedAt: string;
    isCompleted: boolean;
  }>;
  totalWordCount: number;
  lastModifiedBy: {
    firstname: string;
    lastname: string;
  };
}
```

### **📊 Phase 4: Grilles de Notation (À Développer)**

#### **Routes à Implémenter:**
```http
# Ces endpoints n'existent pas encore - à développer
GET /projects/:projectId/grading-grids                # Grilles du projet
GET /grading-grids/:gridId                            # Détails grille
GET /grading-grids/:gridId/grades                     # Notes de la grille
POST /grading-grids/:gridId/grades                    # Créer une note
PUT /grades/:gradeId                                  # Modifier une note
GET /projects/:projectId/final-grades                 # Notes finales
```

#### **DTOs Mobile - Notation (À Implémenter):**
```typescript
// GradingGridDto
interface GradingGridDto {
  id: string;
  name: string;
  type: "GROUP" | "INDIVIDUAL";
  attachedTo: "DELIVERABLE" | "REPORT" | "DEFENSE";
  criteria: Array<{
    id: string;
    name: string;
    weight: number;             // Pourcentage
    maxScore: number;
    scoreType: "NUMERIC" | "SCALE" | "BOOLEAN";
  }>;
  gradingProgress: {
    totalEntities: number;      // Groupes ou étudiants
    gradedEntities: number;
    completionRate: number;
  };
}

// MobileGradeEntryDto
interface MobileGradeEntryDto {
  gridId: string;
  entityId: string;           // Group ID ou Student ID
  entityName: string;
  scores: Array<{
    criterionId: string;
    value: number | string | boolean;
    comment?: string;
  }>;
  globalComment?: string;
  totalScore: number;
  status: "DRAFT" | "FINALIZED";
}

// QuickGradingDto (pour interface mobile optimisée)
interface QuickGradingDto {
  entityId: string;
  entityName: string;
  currentGrade?: {
    totalScore: number;
    status: string;
  };
  quickActions: Array<{
    label: string;              // "Excellent", "Bien", "Passable"
    score: number;
    color: string;
  }>;
}
```

### **🔧 Configuration Mobile pour Enseignants**

#### **HTTP Client Configuration:**
```typescript
interface TeacherMobileConfig {
  baseURL: "https://api.eduprotrack.com";
  timeout: 30000;
  headers: {
    "Content-Type": "application/json";
    "Accept": "application/json";
    "User-Agent": "EduProTrack-Teacher-Mobile/1.0";
  };
  authFlow: "OAUTH";           // OAuth uniquement pour enseignants
}

// États application enseignant
interface TeacherAppState {
  teacher: TeacherProfileDto | null;
  isAuthenticated: boolean;
  myProjects: TeacherProjectDto[];
  currentProject: TeacherProjectDto | null;
  deliverables: DeliverableTrackingDto[];
  pendingGrades: number;       // Nombre de notes en attente
  networkStatus: "online" | "offline";
}
```

#### **Navigation Mobile Optimisée:**
```typescript
// Structure navigation recommandée
interface TeacherMobileNavigation {
  tabs: [
    {
      id: "projects";
      label: "Mes Projets";
      icon: "folder";
      badge?: number;            // Nombre de notifications
    },
    {
      id: "deliverables";
      label: "Livrables";
      icon: "upload";
      badge?: number;            // Soumissions en attente
    },
    {
      id: "reports";             // À implémenter
      label: "Rapports";
      icon: "document";
      badge?: number;
    },
    {
      id: "grades";              // À implémenter  
      label: "Notes";
      icon: "star";
      badge?: number;            // Notes en attente
    }
  ];
}
```

### **📊 État d'Implémentation**

#### **✅ Disponible Actuellement:**
- Authentification OAuth (Google/Azure)
- Consultation des projets enseignant
- Suivi des livrables et soumissions complètes
- Gestion des groupes
- Création de livrables et règles de validation
- **Système de rapports multi-parties complet**
- **Collaboration temps réel**
- **Versioning et historique**
- **Interface enseignant pour rapports**
- **Système de pénalités et calculs business days**

#### **✅ Nouvellement Implémenté:**
- **✅ Module Grading** - Grilles de notation et saisie des notes (US-GRA-001 & US-GRA-002)
- **✅ Évaluation avec workflow DRAFT/FINALIZED/LOCKED**
- **✅ Calcul automatique des scores avec pondération**
- **✅ Notation en lot et copie d'évaluations**
- **✅ Statistiques et progression des notations**

#### **🚧 À Développer (Priorité Moyenne):**
- Interface mobile optimisée pour la notation tactile

#### **📝 Recommandation Développement:**
1. **Phase 1** : ✅ Suivi des livrables (disponible)
2. **Phase 2** : ✅ Module Reports complet (disponible)
3. **Phase 3** : ✅ Module Grading côté API (US-GRA-001 & US-GRA-002 implémentés)
4. **Phase 4** : Optimiser l'interface mobile pour la notation tactile

### **🎯 Endpoints Prioritaires pour Mobile**

#### **Immédiatement Utilisables:**
```http
# Authentification
GET /auth/google
GET /auth/me

# Projets et Livrables
GET /projects/my-projects
GET /projects/:id/deliverables
GET /projects/:id/groups
GET /deliveries/deliverable/:deliverableId

# Rapports (Disponible)
GET /reports/projects/:projectId
GET /reports/teacher/:reportId/overview
GET /reports/teacher/:reportId/groups
```

#### **✅ Grading Endpoints (Implémentés):**
```http
# Grade Entry Management
POST /grade-entries                                   # Créer évaluation
GET /grade-entries/:id                               # Détails évaluation  
PUT /grade-entries/:id                               # Modifier évaluation
POST /grade-entries/:id/finalize                     # Finaliser évaluation
POST /grade-entries/:id/auto-save                    # Sauvegarde auto
POST /grade-entries/bulk                            # Notation en lot
POST /grade-entries/copy                            # Copier évaluations
GET /grade-entries/grid/:gridId                     # Évaluations d'une grille
GET /grade-entries/grid/:gridId/progress            # Progression notation
GET /grade-entries/grid/:gridId/summary             # Statistiques grille

# Grading Grids (Existant)
GET /projects/:id/grading-grids                     # Grilles du projet
GET /grading-grids/:gridId                          # Détails grille
POST /projects/:id/grading-grids                    # Créer grille
PUT /grading-grids/:gridId                          # Modifier grille
```

La section mobile est maintenant correctement orientée **enseignants uniquement** avec les 3 fonctionnalités spécifiques du cahier des charges.

---

### **⚙️ Administration Système**

#### `GET /admin/scheduler/jobs` - Lister les tâches planifiées
**Guards:** `JwtAuthGuard`, `TeacherGuard` (Admin)
```json
[
  {
    "id": "job-1",
    "name": "daily-reminders",
    "pattern": "0 9 * * *",
    "nextRun": "2024-03-16T09:00:00.000Z",
    "lastRun": "2024-03-15T09:00:00.000Z",
    "status": "ACTIVE"
  },
  {
    "id": "job-2",
    "name": "deadline-notifications",
    "pattern": "0 */6 * * *",
    "nextRun": "2024-03-15T18:00:00.000Z",
    "lastRun": "2024-03-15T12:00:00.000Z",
    "status": "ACTIVE"
  }
]
```

#### `POST /admin/scheduler/jobs/:jobName/trigger` - Déclencher manuellement
**Guards:** `JwtAuthGuard`, `TeacherGuard` (Admin)
**Body:** Aucun
**Response:**
```json
{
  "jobName": "daily-reminders",
  "triggered": true,
  "triggeredAt": "2024-03-15T15:45:00.000Z",
  "message": "Tâche exécutée manuellement avec succès"
}
```

---

## 🔒 Sécurité et Autorisations

### **Guards utilisés:**
- **JwtAuthGuard**: Vérification du token JWT
- **TeacherGuard**: Vérification du rôle TEACHER
- **StudentGuard**: Vérification du rôle STUDENT

### **Règles d'accès:**
- **Création/modification projets**: TEACHER uniquement
- **Gestion des groupes (admin)**: TEACHER uniquement
- **Rejoindre/quitter groupes**: STUDENT uniquement
- **Consultation projets**: Tous utilisateurs authentifiés
- **Gestion livrables**: TEACHER pour création, STUDENT pour soumission
- **Soumissions (deliveries)**: STUDENT uniquement
- **Rapports**: Création par TEACHER, édition par STUDENT du groupe
- **Collaboration**: Membres du groupe uniquement
- **Annotations enseignant**: TEACHER uniquement
- **Administration système**: TEACHER avec privilèges admin

### **📧 Notifications Automatiques**

#### **Création de comptes étudiants:**
Lors de l'ajout d'étudiants (manuel ou import), si l'email n'existe pas :
1. **Création automatique** du compte avec mot de passe généré
2. **Hash sécurisé** (bcryptjs) avant stockage
3. **Email automatique** avec identifiants complets

#### **Configuration SMTP requise:**
```env
SMTP_HOST="localhost"
SMTP_PORT="1025"
SMTP_FROM="noreply@eduprotrack.com"
```

---

## ⚠️ Gestion d'Erreurs

### **Codes d'Erreur Standards**
```javascript
// Erreurs d'authentification (401)
{
  "statusCode": 401,
  "message": "Token JWT invalide ou expiré",
  "error": "Unauthorized"
}

// Erreurs de permission (403)
{
  "statusCode": 403,
  "message": "Accès réservé aux enseignants",
  "error": "Forbidden"
}

// Erreurs de validation (400)
{
  "statusCode": 400,
  "message": "Le groupe doit contenir entre 3 et 6 membres",
  "error": "Bad Request"
}

// Erreurs de ressources (404)
{
  "statusCode": 404,
  "message": "Projet non trouvé",
  "error": "Not Found"
}

```

---

## 🔧 SETUP DÉVELOPPEMENT

### **Installation:**
```bash
npm install
npx prisma generate
npx prisma db push
```

### **Variables d'environnement:**
Copier `.env.example` vers `.env` et configurer

### **Démarrage:**
```bash
npm run start:dev
```

### **Tests:**
```bash
npm run test
```

---

## 📊 RÉSUMÉ COMPLET - 430+ ENDPOINTS DISPONIBLES

### **🏆 Modules Implémentés (100% Fonctionnels)**

1. **🔐 Identity & Access Management** - 28 endpoints
   - Authentification OAuth2 (Google/Azure) + connexion étudiants
   - Gestion utilisateurs, promotions, import/export

2. **📁 Project Management** - 35 endpoints  
   - CRUD projets, 3 modes de formation (MANUAL/FREE/RANDOM)
   - Gestion avancée des groupes avec algorithmes d'affectation

3. **📦 Deliverables & Submissions** - 25 endpoints
   - Création livrables, règles de validation avancées
   - Soumissions multi-formats (fichiers, archives, Git)
   - Système de pénalités avec calculs business days

4. **📊 Reports & Collaboration** - 45 endpoints
   - Rapports multi-parties avec sections dépendantes
   - Collaboration temps réel (verrouillage, commentaires, présence)
   - Versioning complet (historique, diff, merge, auto-save)
   - Interface enseignant avancée (annotations, analytics, export)

5. **📬 Notifications** - 8 endpoints
   - Système de notifications automatisé
   - Templates HTML personnalisés

6. **🎓 Student Interface** - 15 endpoints
   - Interface complète pour étudiants
   - Gestion notifications, échéances, soumissions

7. **⚙️ Administration** - 5 endpoints
   - Gestion tâches planifiées (CRON)
   - Administration système

### **📱 Applications Mobiles Prêtes**

- **👨‍🏫 Enseignants** : Suivi livrables + Lecture rapports + Interface annotation
- **🎓 Étudiants** : Gestion projets + Soumissions + Rapports collaboratifs + Notifications

8. **🎓 Grading System** - 25+ endpoints
   - Grilles d'évaluation avec critères pondérés
   - Saisie notes individuelles et en lot  
   - Calcul notes finales avec stratégies flexibles
   - Interface consultation étudiante avec progression
   - Simulation impact notes et export personnel

**🎉 L'API EduProTrack est 100% complète avec 450+ endpoints fonctionnels !**

**🔗 Base URL de développement :** `http://localhost:3000`  
**📚 Documentation interactive :** Swagger UI disponible sur `/api/docs` (disponible aftaa)

---

## 🎓 GRADING SYSTEM - ENDPOINTS ÉTUDIANTS

### **📊 Interface Étudiant - Consultation Notes**

#### `GET /grade-entries/students/my-grades` - Mes notes
**Guards:** `JwtAuthGuard` + Role STUDENT
**Query params:**
- `projectId` (optional): Filtrer par projet
- `includeProgress` (optional): Inclure progression temporelle

```json
{
  "grades": [
    {
      "id": "eval-id-1",
      "gridName": "Évaluation Livrable",
      "evaluationType": "DELIVERABLE",
      "projectName": "Projet Web",
      "projectId": "project-id",
      "finalScore": 16.5,
      "maxScore": 20,
      "percentage": 82.5,
      "status": "FINALIZED",
      "globalComments": "Bon travail global",
      "finalizedAt": "2024-03-15T14:30:00.000Z",
      "scores": [
        {
          "criterionId": "crit-1",
          "criterionName": "Qualité du code",
          "score": 17,
          "maxScore": 20,
          "comment": "Code bien structuré"
        }
      ]
    }
  ],
  "progression": {
    "timeline": [...],
    "trend": "IMPROVING",
    "averageScore": 15.2
  }
}
```

#### `GET /grade-entries/students/projects/:projectId/final-grade` - Note finale projet
**Guards:** `JwtAuthGuard` + Role STUDENT
**Query params:**
- `includeBreakdown` (optional): Inclure détail calcul

```json
{
  "entityId": "student-id",
  "projectId": "project-id",
  "finalScore": 15.8,
  "maxScore": 20,
  "percentage": 79,
  "hasIncompleteParts": false,
  "calculationStrategy": "PROPORTIONAL",
  "gridContributions": [
    {
      "gridName": "Livrable",
      "score": 16,
      "weight": 50,
      "contribution": 8,
      "isCompleted": true
    },
    {
      "gridName": "Rapport",
      "score": 14,
      "weight": 30,
      "contribution": 4.2,
      "isCompleted": true
    }
  ],
  "calculatedAt": "2024-03-20T10:00:00.000Z"
}
```

#### `GET /grade-entries/students/projects/:projectId/progression` - Progression temporelle
**Guards:** `JwtAuthGuard` + Role STUDENT

```json
{
  "timeline": [
    {
      "date": "2024-03-01T00:00:00.000Z",
      "evaluationType": "DELIVERABLE",
      "gridName": "Livrable 1",
      "score": 14,
      "maxScore": 20,
      "percentage": 70,
      "order": 1
    },
    {
      "date": "2024-03-15T00:00:00.000Z",
      "evaluationType": "REPORT",
      "gridName": "Rapport intermédiaire",
      "score": 16,
      "maxScore": 20,
      "percentage": 80,
      "order": 2
    }
  ],
  "trend": "IMPROVING",
  "averageScore": 75,
  "totalEvaluations": 2,
  "improvement": 10
}
```

#### `POST /grade-entries/students/projects/:projectId/simulate` - Simulation impact notes
**Guards:** `JwtAuthGuard` + Role STUDENT

**Request Body:**
```json
{
  "scenarios": [
    {
      "evaluationType": "DEFENSE",
      "hypotheticalScore": 18
    },
    {
      "evaluationType": "DEFENSE", 
      "hypotheticalScore": 14
    }
  ]
}
```

**Response:**
```json
{
  "studentId": "student-id",
  "projectId": "project-id",
  "currentFinalGrade": 15.8,
  "scenarios": [
    {
      "scenario": {
        "evaluationType": "DEFENSE",
        "hypotheticalScore": 18
      },
      "currentFinalScore": 15.8,
      "simulatedFinalScore": 16.4,
      "scoreDifference": 0.6,
      "impactDescription": "Positive impact"
    }
  ],
  "simulatedAt": "2024-03-20T15:30:00.000Z"
}
```

#### `GET /grade-entries/students/projects/:projectId/export` - Export personnel
**Guards:** `JwtAuthGuard` + Role STUDENT
**Query params:**
- `format`: 'json' | 'pdf' (défaut: json)

```json
{
  "exportFormat": "json",
  "exportDate": "2024-03-20T16:00:00.000Z",
  "student": {
    "id": "student-id",
    "firstname": "Jean",
    "lastname": "Dupont",
    "email": "jean.dupont@student.fr"
  },
  "project": {
    "id": "project-id",
    "name": "Projet Web Development",
    "description": "Développement application web complète"
  },
  "grades": [...],
  "finalGrade": {...},
  "progression": {...},
  "summary": {
    "totalEvaluations": 3,
    "completedEvaluations": 3,
    "averageScore": 15.2,
    "maxScore": 20,
    "overallPercentage": 76
  },
  "recommendations": [
    "Excellente progression ! Continuez sur cette lancée.",
    "Attention aux évaluations les plus faibles."
  ]
}
```

### **📈 Endpoints Partagés (Enseignants + Étudiants)**

#### `GET /grade-entries/projects/:projectId/statistics` - Statistiques projet
**Guards:** `JwtAuthGuard`
**Note:** Les étudiants voient des statistiques limitées/anonymisées

**Pour les étudiants:**
```json
{
  "projectId": "project-id",
  "classAverage": 14.5,
  "distribution": [
    { "range": "0-10", "percentage": 15 },
    { "range": "10-15", "percentage": 45 },
    { "range": "15-20", "percentage": 40 }
  ],
  "myPercentile": 75,
  "isAboveAverage": true
}
```

**Pour les enseignants:** (données complètes avec détails par étudiant)

---
