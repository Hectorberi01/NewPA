# 🎓 EduProTrack - Project Management API

## 📋 Vue d'Ensemble

API complète de gestion des projets étudiants avec système de groupes avancé, notifications automatiques et affectation intelligente.

### ✨ Fonctionnalités Principales
- 📚 **Gestion complète des projets** (création, publication, configuration)
- 👥 **Système de groupes intelligent** (modes manuel, libre, aléatoire)
- 📧 **Notifications automatiques** (email templates professionnels)
- 🎲 **Affectation automatique** (algorithme équilibré après deadline)
- ⏰ **Scheduler automatisé** (rappels, affectations, nettoyage)
- 🔐 **Sécurité robuste** (JWT, guards, validation des rôles)
- 🌐 **API RESTful complète** (18+ endpoints documentés)

## 🚀 Démarrage Rapide

```bash
# 1. Installation dépendance
npm install @nestjs/schedule

# 2. Configuration environnement
cp .env.example .env
# Éditer .env avec vos paramètres

# 3. Base de données
npx prisma generate
npx ts-node prisma/seed.ts

# 4. Démarrage
npm run start:dev
```

**➡️ Voir [`QUICK_START.md`](./QUICK_START.md) pour un guide détaillé**

## 📖 Documentation

| Fichier | Description |
|---------|-------------|
| [`API_DOCUMENTATION.md`](./API_DOCUMENTATION.md) | 📘 **Guide complet développeur frontend** - Toutes les routes, DTOs, exemples |
| [`TESTING_GUIDE.md`](./TESTING_GUIDE.md) | 🧪 **Guide de test step-by-step** - Workflows, cas de test, validation |
| [`QUICK_START.md`](./QUICK_START.md) | ⚡ **Setup en 3 minutes** - Tests rapides avec curl et Postman |
| [`INSTALLATION.md`](./INSTALLATION.md) | 🔧 **Installation complète** - Setup production, troubleshooting |
| [`IMPLEMENTATION_SUMMARY.md`](./IMPLEMENTATION_SUMMARY.md) | 📊 **Résumé technique** - Architecture, composants, user stories |

## 🎯 User Stories Implémentées

### 📋 Projets (US-P1 à US-P4)
- ✅ **US-P1** : Création projets avec validation complète
- ✅ **US-P2** : Attachement promotions avec vérification permissions  
- ✅ **US-P3** : Notifications automatiques lors publication
- ✅ **US-P4** : Interface consultation étudiants (projets VISIBLE)

### 👥 Groupes (US-G1 à US-G5)
- ✅ **US-G1** : Configuration tailles groupes + deadline
- ✅ **US-G2** : Modes formation (MANUAL/FREE/RANDOM)
- ✅ **US-G3** : Gestion manuelle par enseignants
- ✅ **US-G4** : Gestion libre étudiants + groupes vides auto-créés
- ✅ **US-G5** : Affectation automatique après deadline

## 🏗️ Architecture

### 📁 Structure du Code
```
src/
├── projects/
│   ├── project.service.ts          # Logique métier projets
│   ├── project.controller.ts       # Endpoints enseignants
│   └── dto/                        # DTOs et validation
├── groups/
│   ├── groups.service.ts           # CRUD groupes
│   ├── group-management.service.ts # Logique mode FREE
│   └── groups.controller.ts        # Endpoints gestion groupes
├── students/
│   └── student-project.controller.ts # Interface étudiants
├── utils/
│   ├── scheduler.service.ts        # Tâches automatiques
│   └── scheduler.controller.ts     # Admin scheduler
└── notifications/
    ├── email.service.ts            # Service email
    └── template.service.ts         # Templates HTML
```

### 🔄 Workflows Automatiques
1. **Publication Projet** → Notification étudiants + Création groupes vides (si FREE)
2. **Rappel J-1** → Email aux non-groupés (CRON daily 10h00)
3. **Affectation Auto** → Algorithme équilibré + Notifications (CRON hourly)

## 🧪 Tests et Validation

### 📦 Collection Postman
Import [`EduProTrack_API_Tests.postman_collection.json`](./EduProTrack_API_Tests.postman_collection.json)
- 30+ requêtes organisées par workflows
- Tests automatiques intégrés
- Variables d'environnement configurées

### 🌱 Données de Test
```bash
# Générer 55 utilisateurs + 5 projets test
npx ts-node prisma/seed.ts
```
- 3 enseignants, 3 promotions, 55 étudiants
- Projets dans différents modes (FREE, MANUAL, RANDOM)
- Groupes pré-existants pour tests complets

### 🎯 Comptes de Test
```
👨‍🏫 Enseignants:
- john.doe@school.com / password123
- jane.smith@school.com / password123

🎓 Étudiants:
- alice.johnson@student.com / password123 (Master 2)
- antoine.dubois@student.com / password123 (Licence 3)
```

## 🎨 Interface Frontend

### 🔗 Endpoints Principaux

**Enseignants :**
```http
POST   /projects                    # Créer projet
PUT    /projects/:id/publish        # Publier → notifications
PUT    /projects/:id/group-config   # Configurer groupes
PUT    /projects/:id/formation-mode # Mode FREE/MANUAL/RANDOM
POST   /projects/:id/groups         # Créer groupe manuel
```

**Étudiants :**
```http
GET    /student/projects                      # Mes projets VISIBLE
GET    /student/projects/:id/groups/available # Groupes disponibles
POST   /student/groups/:id/join               # Rejoindre groupe
DELETE /student/groups/:id/leave              # Quitter groupe
```

### 📱 États UI Recommandés
```javascript
const projectStates = {
  NO_GROUP: "Aucun groupe",           // myGroup === null
  IN_GROUP: "Dans un groupe",         // myGroup !== null  
  DEADLINE_PASSED: "Deadline dépassée", // new Date() > deadline
  NOT_FREE_MODE: "Mode non libre"     // mode !== "FREE"
};
```

## 🔧 Configuration

### 📧 Variables d'Environnement
```env
DATABASE_URL="postgresql://..."
JWT_SECRET="your-secret-key"
SMTP_HOST="localhost"
SMTP_PORT="1025"
SMTP_FROM="noreply@eduprotrack.com"
```

### 📮 Setup Email (Développement)
```bash
# Option 1: MailHog (recommandé)
# Windows: télécharger depuis GitHub
# macOS: brew install mailhog

# Option 2: Configuration SMTP réelle
# Modifier .env avec vos paramètres SMTP
```

## 🎯 Points Clés

### 🧮 Algorithme Groupes Vides (US-G4)
```javascript
// Pour 25 étudiants, groupes min 3
nbGroupes = Math.ceil(25 / 3) = 9 groupes vides créés
// Garantit suffisamment de places pour tous
```

### 📧 Notifications Automatiques
- **Projet publié** : Tous les étudiants de la promotion
- **Rappel J-1** : Étudiants non-groupés uniquement  
- **Affectation auto** : Étudiants affectés avec détails du groupe

### 🔐 Sécurité
- JWT requis pour toutes les routes
- `TeacherGuard` pour routes enseignants
- Validation rôle étudiant dans interface dédiée
- Vérification permissions promotion/enseignant

## 🚨 Troubleshooting

### Problème courant : Module introuvable
```bash
npm install @nestjs/schedule
```

### Problème : Pas de notifications
```bash
# Vérifier configuration .env
# Installer MailHog pour développement
# Checker logs serveur pour erreurs SMTP
```

### Problème : Groupes non créés
```bash
# Les groupes vides ne sont créés qu'à la publication
# En mode FREE uniquement
# Vérifier statut VISIBLE du projet
```

## 📊 Métriques

- ✅ **18+ endpoints** REST
- ✅ **6 services** métier  
- ✅ **4 workflows** automatiques
- ✅ **3 templates** email
- ✅ **55 utilisateurs** de test
- ✅ **5 projets** test différents modes
- ✅ **100% User Stories** implémentées

## 🎉 Prêt pour la Production

L'API EduProTrack est **complètement fonctionnelle** avec :
- Architecture robuste et modulaire
- Sécurité et validation complètes  
- Workflows automatisés fiables
- Documentation exhaustive
- Tests complets validés

**🚀 Prêt pour l'intégration frontend et le déploiement !**

---

## 📞 Support

- 📘 **Documentation API** : [`API_DOCUMENTATION.md`](./API_DOCUMENTATION.md)
- 🧪 **Guide de test** : [`TESTING_GUIDE.md`](./TESTING_GUIDE.md)  
- ⚡ **Démarrage rapide** : [`QUICK_START.md`](./QUICK_START.md)
- 🔧 **Installation** : [`INSTALLATION.md`](./INSTALLATION.md)

**Développé avec ❤️ pour EduProTrack**
