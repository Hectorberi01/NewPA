import { config } from 'dotenv';

// Charger les variables d'environnement de test
config({ path: '.env.test' });

// Configuration par défaut pour les tests
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test-jwt-secret-key-for-testing-only';
process.env.DATABASE_URL =
  'postgresql://test:test@localhost:5432/eduprotrack_test';
process.env.SMTP_HOST = 'localhost';
process.env.SMTP_PORT = '1025';
process.env.SMTP_USER = '';
process.env.SMTP_PASSWORD = '';
process.env.SMTP_FROM = 'test@eduprotrack.com';
process.env.SMTP_SECURE = 'false';

// Désactiver les logs pendant les tests
process.env.LOG_LEVEL = 'error';

// Configuration pour les tests
global.beforeEach(() => {
  jest.clearAllMocks();
});

// Timeout global pour les tests
jest.setTimeout(30000);

// Mock global pour les modules externes problématiques
// Note: bcryptjs is mocked individually in test files for better control

jest.mock('jsonwebtoken', () => ({
  sign: jest.fn().mockReturnValue('mock-jwt-token'),
  verify: jest.fn().mockReturnValue({
    sub: 'user-id',
    email: 'test@example.com',
    role: 'STUDENT',
  }),
}));

// Supprimer les warnings de dépréciation pendant les tests
process.env.NODE_NO_WARNINGS = '1';

export {};
