import {
  Role,
  Project,
  Group,
  Deliverable,
  DeliverableType,
  ProjectStatus,
  GroupFormationMode,
} from '@prisma/client';
import type { ValidatedUser } from '../auth/types/auth.types';
import type { Request, Response } from 'express';

export class TestHelpers {
  static createMockUser(
    role: Role,
    overrides?: Partial<ValidatedUser>,
  ): ValidatedUser {
    const baseUser = {
      id: `${role.toLowerCase()}-test-id`,
      email: `${role.toLowerCase()}@test.com`,
      firstname: 'Test',
      lastname: 'User',
      role,
    };

    return { ...baseUser, ...overrides };
  }

  static createMockStudent(overrides?: Partial<ValidatedUser>): ValidatedUser {
    return this.createMockUser(Role.STUDENT, overrides);
  }

  static createMockTeacher(overrides?: Partial<ValidatedUser>): ValidatedUser {
    return this.createMockUser(Role.TEACHER, overrides);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  static createMockPrismaService(): Record<string, any> {
    return {
      user: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      project: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      group: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      groupMember: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        createMany: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        deleteMany: jest.fn(),
        count: jest.fn(),
      },
      deliverable: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      deliverableSubmission: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      penaltyAdjustment: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      delivery: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      report: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      reportSection: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      promotion: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        count: jest.fn(),
      },
      studentPromotion: {
        findMany: jest.fn(),
        findUnique: jest.fn(),
        findFirst: jest.fn(),
        create: jest.fn(),
        createMany: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        deleteMany: jest.fn(),
        count: jest.fn(),
      },
      $transaction: jest.fn(),
      $disconnect: jest.fn(),
    };
  }

  static createMockRequest(user?: ValidatedUser): Partial<Request> {
    return {
      user: user || this.createMockStudent(),
      headers: {
        'content-type': 'application/json',
      },
      body: {},
      query: {},
      params: {},
    };
  }

  static createMockResponse(): Partial<Response> {
    return {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      send: jest.fn().mockReturnThis(),
      cookie: jest.fn().mockReturnThis(),
      clearCookie: jest.fn().mockReturnThis(),
    };
  }

  static createMockJwtPayload(user: ValidatedUser): {
    sub: string;
    email: string;
    role: Role;
    iat: number;
    exp: number;
  } {
    return {
      sub: user.id,
      email: user.email,
      role: user.role,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 3600, // 1 hour
    };
  }

  static createSuccessResponse<T>(data: T): { success: true; data: T } {
    return {
      success: true,
      data,
    };
  }

  static createErrorResponse(
    message: string,
    code = 500,
  ): { success: false; error: { message: string; code: number } } {
    return {
      success: false,
      error: {
        message,
        code,
      },
    };
  }

  static createMockDate(dateString?: string): Date {
    return new Date(dateString || '2024-01-01T00:00:00.000Z');
  }

  /*static createMockProject(overrides?: Partial<Project>): Project {
    return {
      id: 'project-1',
      name: 'Test Project',
      description: 'Test project description',
      status: ProjectStatus.DRAFT,
      promotionId: 'promotion-1',
      userId: 'teacher-1',
      groupFormationMode: GroupFormationMode.FREE,
      minGroupSize: 3,
      maxGroupSize: 5,
      groupDeadline: null,
      createdAt: this.createMockDate(),
      updatedAt: this.createMockDate(),
      ...overrides,
    };
  }*/

  static createMockGroup(overrides?: Partial<Group>): Group {
    return {
      id: 'group-1',
      name: 'Test Group',
      projectId: 'project-1',
      createdAt: this.createMockDate(),
      updatedAt: this.createMockDate(),
      ...overrides,
    };
  }

  static createMockDeliverable(overrides?: Partial<Deliverable>): Deliverable {
    return {
      id: 'deliverable-1',
      name: 'Test Deliverable',
      description: 'Test deliverable description',
      projectId: 'project-1',
      deadline: this.createMockDate('2024-06-30T23:59:59.999Z'),
      type: DeliverableType.ARCHIVE,
      allowLateSubmission: false,
      latePenalty: null,
      maxLateDays: null,
      maxPenalty: null,
      maxFileSize: null,
      allowedExtensions: [],
      requiredFiles: [],
      evaluationGridId: null,
      createdAt: this.createMockDate(),
      updatedAt: this.createMockDate(),
      ...overrides,
    };
  }

  // TODO: Ajouter les méthodes createMockProjectReport, createMockReportSection, createMockGroupReportContent
  // pour les nouveaux modèles de rapports simplifiés

  static resetAllMocks(mockObject: Record<string, unknown>): void {
    Object.keys(mockObject).forEach((key) => {
      const value = mockObject[key];
      if (typeof value === 'object' && value !== null) {
        this.resetAllMocks(value as Record<string, unknown>);
      } else if (jest.isMockFunction(value)) {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-call, @typescript-eslint/no-explicit-any
        (value as any).mockReset();
      }
    });
  }
}
