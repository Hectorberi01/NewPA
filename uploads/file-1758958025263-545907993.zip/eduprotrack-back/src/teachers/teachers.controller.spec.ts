import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { TeachersController } from './teachers.controller';
import { TeachersService } from './teachers.service';
import { PrismaService } from '../prisma/prisma.service';
import { Role } from '@prisma/client';

describe('TeachersController', () => {
  let controller: TeachersController;
  let service: TeachersService;

  const mockPrismaService = {
    user: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
    },
  };

  const mockTeachersService = {
    getById: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TeachersController],
      providers: [
        {
          provide: TeachersService,
          useValue: mockTeachersService,
        },
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
      ],
    }).compile();

    controller = module.get<TeachersController>(TeachersController);
    service = module.get<TeachersService>(TeachersService);

    // Reset all mocks
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('getById', () => {
    it('should return teacher by id', async () => {
      const teacherId = 'teacher-1';
      const mockTeacher = {
        id: teacherId,
        email: 'teacher@test.com',
        firstname: 'John',
        lastname: 'Teacher',
        role: Role.TEACHER,
      };

      mockTeachersService.getById.mockResolvedValue({
        status: 'success',
        message: 'Opération réussie',
        data: mockTeacher,
      });

      const result = await controller.getById(teacherId);

      expect(result).toEqual({
        status: 'success',
        message: 'Opération réussie',
        data: mockTeacher,
      });
      expect(mockTeachersService.getById).toHaveBeenCalledWith(teacherId);
    });

    it('should handle errors when teacher not found', async () => {
      const teacherId = 'non-existent-teacher';
      const error = new Error('Teacher not found');
      mockTeachersService.getById.mockRejectedValue(error);

      await expect(controller.getById(teacherId)).rejects.toThrow(
        'Teacher not found',
      );
      expect(mockTeachersService.getById).toHaveBeenCalledWith(teacherId);
    });
  });
});
