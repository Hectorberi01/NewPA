export class Teacher {}
