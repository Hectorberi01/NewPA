import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
} from '@nestjs/swagger';
import { TeachersService } from './teachers.service';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Teachers')
@Controller('teachers')
export class TeachersController {
  constructor(private readonly teachersService: TeachersService) {}

  @Get('/:id')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Récupérer un enseignant par son ID' })
  @ApiParam({ name: 'id', description: "ID de l'enseignant" })
  @ApiResponse({ status: 200, description: 'Enseignant récupéré avec succès' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Enseignant non trouvé' })
  async getById(@Param('id') id: string) {
    return await this.teachersService.getById(id);
  }
}
