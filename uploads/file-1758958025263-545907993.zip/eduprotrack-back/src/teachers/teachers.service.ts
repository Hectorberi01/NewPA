import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class TeachersService {
  constructor(private readonly prisma: PrismaService) {}

  async getById(id: string) {
    const foundedTeacher = await this.prisma.user.findUnique({
      where: { id: id },
    });

    if (!foundedTeacher) {
      throw new NotFoundException(`Aucun enseignant avec l'id ${id}`);
    }

    return foundedTeacher;
  }
}
