import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { TeachersService } from './teachers.service';
import { PrismaService } from '../prisma/prisma.service';
import { Role } from '@prisma/client';
import { NotFoundException } from '@nestjs/common';

describe('TeachersService', () => {
  let service: TeachersService;
  let prismaService: PrismaService;

  const mockPrismaService = {
    user: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TeachersService,
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
      ],
    }).compile();

    service = module.get<TeachersService>(TeachersService);
    prismaService = module.get<PrismaService>(PrismaService);

    // Reset all mocks
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getById', () => {
    it('should return teacher by id successfully', async () => {
      const teacherId = 'teacher-1';
      const mockTeacher = {
        id: teacherId,
        email: 'teacher@test.com',
        firstname: 'John',
        lastname: 'Teacher',
        role: Role.TEACHER,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      mockPrismaService.user.findUnique.mockResolvedValue(mockTeacher);

      const result = await service.getById(teacherId);

      expect(result).toEqual(mockTeacher);
      expect(mockPrismaService.user.findUnique).toHaveBeenCalledWith({
        where: {
          id: teacherId,
        },
      });
    });

    it('should handle teacher not found', async () => {
      const teacherId = 'non-existent-teacher';
      mockPrismaService.user.findUnique.mockResolvedValue(null);

      await expect(service.getById(teacherId)).rejects.toThrow(
        NotFoundException,
      );
      await expect(service.getById(teacherId)).rejects.toThrow(
        `Aucun enseignant avec l'id ${teacherId}`,
      );

      expect(mockPrismaService.user.findUnique).toHaveBeenCalledWith({
        where: {
          id: teacherId,
        },
      });
    });

    it('should handle database errors', async () => {
      const teacherId = 'teacher-1';
      const error = new Error('Database connection failed');
      mockPrismaService.user.findUnique.mockRejectedValue(error);

      await expect(service.getById(teacherId)).rejects.toThrow(
        "Erreur lors de la récupération de l'enseignant",
      );
      expect(mockPrismaService.user.findUnique).toHaveBeenCalledWith({
        where: {
          id: teacherId,
        },
      });
    });
  });
});
