import { IsString } from 'class-validator';

export interface CreatePromotionDto {
  name: string;
}

export class CreatePromotionDtoValidation implements CreatePromotionDto {
  @IsString()
  name!: string;
}
