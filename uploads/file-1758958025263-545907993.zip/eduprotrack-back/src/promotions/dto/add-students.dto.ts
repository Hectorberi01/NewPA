import { IsArray, IsEmail, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

export interface StudentToAddDto {
  firstname: string;
  lastname: string;
  email: string;
  avatar?: string;
}

export class StudentToAddDtoValidation implements StudentToAddDto {
  @IsString()
  firstname!: string;

  @IsString()
  lastname!: string;

  @IsEmail()
  email!: string;

  avatar?: string;
}

export interface AddStudentsDto {
  students: StudentToAddDto[];
}

export class AddStudentsDtoValidation implements AddStudentsDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => StudentToAddDtoValidation)
  students!: StudentToAddDto[];
}

export interface AddExistingStudentsDto {
  students: string[];
}

export class AddExistingStudentsDtoValidation
  implements AddExistingStudentsDto
{
  @IsArray()
  @IsString({ each: true })
  students!: string[];
}
