import { PartialType } from '@nestjs/mapped-types';
import { CreatePromotionDtoValidation } from './create-promotion.dto';

export class UpdatePromotionDto extends PartialType(
  CreatePromotionDtoValidation,
) {}
