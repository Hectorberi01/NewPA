import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Request,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
  ApiConsumes,
} from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { PromotionService } from './promotions.service';
import { CreatePromotionDtoValidation } from './dto/create-promotion.dto';
import {
  AddExistingStudentsDtoValidation,
  AddStudentsDtoValidation,
} from './dto/add-students.dto';
import { JWTAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { TeacherGuard } from 'src/auth/guards/teacher.guard';
import { ImportStudentsService } from '../students/import-students.service';
import type { AuthenticatedRequest } from 'src/auth/types/auth.types';

@ApiTags('Promotions')
@Controller('promotions')
export class PromotionController {
  constructor(
    private readonly promotionService: PromotionService,
    private readonly importStudentsService: ImportStudentsService,
  ) {}

  @Post()
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Créer une nouvelle promotion',
    description: 'Permet aux enseignants de créer une nouvelle promotion',
  })
  @ApiResponse({
    status: 201,
    description: 'Promotion créée avec succès',
  })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 403, description: 'Accès refusé' })
  @ApiBody({ type: CreatePromotionDtoValidation })
  async createPromotion(
    @Body() createPromotionDto: CreatePromotionDtoValidation,
    @Request() req: AuthenticatedRequest,
  ) {
    return await this.promotionService.create(createPromotionDto, req.user.id);
  }

  @Get()
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Récupérer toutes les promotions',
    description:
      "Permet de récupérer la liste de toutes les promotions de l'enseignant connecté",
  })
  @ApiResponse({
    status: 200,
    description: 'Liste des promotions récupérée avec succès',
  })
  async getAllPromotions(@Request() req: AuthenticatedRequest) {
    return await this.promotionService.findAllByTeacher(req.user.id);
  }

  @Get(':id')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Récupérer une promotion par son ID',
    description: "Permet de récupérer les détails d'une promotion spécifique",
  })
  @ApiParam({
    name: 'id',
    description: 'Identifiant unique de la promotion',
    type: String,
  })
  @ApiResponse({
    status: 200,
    description: 'Promotion récupérée avec succès',
  })
  @ApiResponse({ status: 404, description: 'Promotion non trouvée' })
  async getPromotionById(
    @Param('id') id: string,
    @Request() req: AuthenticatedRequest,
  ) {
    return await this.promotionService.findOneByTeacher(id, req.user.id);
  }

  @Delete(':id')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Supprimer une promotion',
    description: 'Permet de supprimer une promotion existante',
  })
  @ApiParam({
    name: 'id',
    description: 'Identifiant unique de la promotion à supprimer',
    type: String,
  })
  @ApiResponse({
    status: 200,
    description: 'Promotion supprimée avec succès',
  })
  @ApiResponse({ status: 404, description: 'Promotion non trouvée' })
  @ApiResponse({ status: 403, description: 'Accès refusé' })
  async deletePromotion(
    @Param('id') id: string,
    @Request() req: AuthenticatedRequest,
  ) {
    await this.promotionService.delete(id, req.user.id);
  }

  @Post(':id/students/existing')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Ajouter des étudiants existants à une promotion',
    description:
      "Permet d'ajouter des étudiants déjà enregistrés dans le système à une promotion",
  })
  @ApiParam({
    name: 'id',
    description: 'Identifiant unique de la promotion',
    type: String,
  })
  @ApiBody({ type: AddExistingStudentsDtoValidation })
  @ApiResponse({
    status: 201,
    description: 'Étudiants ajoutés avec succès',
  })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 404, description: 'Promotion ou étudiant non trouvé' })
  async addExistingStudentsToPromotion(
    @Param('id') promotionId: string,
    @Body() addStudentsDto: AddExistingStudentsDtoValidation,
    @Request() req: AuthenticatedRequest,
  ) {
    return await this.promotionService.addExistingStudents(
      promotionId,
      addStudentsDto.students,
      req.user.id,
    );
  }

  @Post(':id/students/import')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @UseInterceptors(FileInterceptor('file'))
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Importer des étudiants via fichier CSV',
    description:
      "Permet d'importer des étudiants dans une promotion via un fichier CSV",
  })
  @ApiConsumes('multipart/form-data')
  @ApiParam({
    name: 'id',
    description: 'Identifiant unique de la promotion',
    type: String,
  })
  @ApiResponse({
    status: 201,
    description: 'Étudiants importés avec succès',
  })
  @ApiResponse({
    status: 400,
    description: 'Fichier invalide ou données incorretes',
  })
  @ApiResponse({ status: 404, description: 'Promotion non trouvée' })
  async importStudentsFromCSV(
    @Param('id') promotionId: string,
    @UploadedFile() file: Express.Multer.File,
  ) {
    if (!file) {
      throw new BadRequestException('Aucun fichier fourni');
    }

    return await this.importStudentsService.importStudentsToPromotion(
      file,
      promotionId,
    );
  }
  /**
   * Récupérer tous les étudiants d'une promotion qui n'ont pas de groupe pour un projet donné
   */
  @Get(':promotionId/students/ungrouped/:projectId')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  async getUngroupedStudents(
    @Param('projectId') projectId: string,
    @Param('promotionId') promotionId: string,
  ) {
    return await this.promotionService.getUngroupedStudents(
      projectId,
      promotionId,
    );
  }

  @Post(':id/students/new')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Créer et ajouter de nouveaux étudiants',
    description:
      'Permet de créer de nouveaux étudiants et de les ajouter directement à une promotion',
  })
  @ApiParam({
    name: 'id',
    description: 'Identifiant unique de la promotion',
    type: String,
  })
  @ApiBody({ type: AddStudentsDtoValidation })
  @ApiResponse({
    status: 201,
    description: 'Nouveaux étudiants créés et ajoutés avec succès',
  })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 404, description: 'Promotion non trouvée' })
  async addNewStudentsToPromotion(
    @Param('id') promotionId: string,
    @Body() addStudentsDto: AddStudentsDtoValidation,
    @Request() req: AuthenticatedRequest,
  ) {
    return await this.promotionService.addNewStudents(
      promotionId,
      addStudentsDto.students,
      req.user.id,
    );
  }

  @Get(':promotionId/students')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: "Récupérer les étudiants d'une promotion",
    description:
      "Permet de récupérer la liste des étudiants d'une promotion spécifique",
  })
  @ApiParam({
    name: 'promotionId',
    description: 'Identifiant unique de la promotion',
    type: String,
  })
  @ApiResponse({
    status: 200,
    description: 'Liste des étudiants récupérée avec succès',
  })
  @ApiResponse({ status: 404, description: 'Promotion non trouvée' })
  async getPromotionStudents(@Param('promotionId') promotionId: string) {
    return await this.promotionService.getPromotionStudents(promotionId);
  }

  @Delete(':promotionId/students')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: "Supprimer des étudiants d'une promotion",
    description: "Permet de supprimer des étudiants d'une promotion spécifique",
  })
  @ApiParam({
    name: 'promotionId',
    description: 'Identifiant unique de la promotion',
    type: String,
  })
  @ApiBody({ type: AddExistingStudentsDtoValidation })
  @ApiResponse({
    status: 200,
    description: 'Étudiants supprimés avec succès',
  })
  @ApiResponse({ status: 404, description: 'Promotion ou étudiant non trouvé' })
  async removeStudentsFromPromotion(
    @Param('promotionId') promotionId: string,
    @Body() removeStudentsDto: AddExistingStudentsDtoValidation,
    @Request() req: AuthenticatedRequest,
  ) {
    return await this.promotionService.removeStudentsFromPromotion(
      promotionId,
      removeStudentsDto.students,
      req.user.id,
    );
  }

  @Get('import-template/csv')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Télécharger template CSV pour import',
    description:
      "Permet de télécharger un template CSV pour l'import d'étudiants",
  })
  @ApiResponse({
    status: 200,
    description: 'Template CSV récupéré avec succès',
  })
  getImportTemplate() {
    const csvTemplate = `firstname,lastname,email
Jean,Dupont,jean.dupont@example.com
Marie,Martin,marie.martin@example.com
Pierre,Durand,pierre.durand@example.com`;

    return {
      template: csvTemplate,
      filename: 'import-students-template.csv',
    };
  }

  @Get('import-template/json')
  @UseGuards(JWTAuthGuard, TeacherGuard)
  @ApiBearerAuth()
  @ApiOperation({
    summary: 'Télécharger template JSON pour import',
    description:
      "Permet de télécharger un template JSON pour l'import d'étudiants",
  })
  @ApiResponse({
    status: 200,
    description: 'Template JSON récupéré avec succès',
  })
  getImportTemplateJson() {
    const jsonTemplate = {
      students: [
        {
          firstname: 'Jean',
          lastname: 'Dupont',
          email: 'jean.dupont@example.com',
        },
        {
          firstname: 'Marie',
          lastname: 'Martin',
          email: 'marie.martin@example.com',
        },
        {
          firstname: 'Pierre',
          lastname: 'Durand',
          email: 'pierre.durand@example.com',
        },
      ],
    };

    return {
      template: jsonTemplate,
      filename: 'import-students-template.json',
    };
  }
}
