import { HttpException, NotFoundException, Injectable } from '@nestjs/common';
import type { CreatePromotionDto } from './dto/create-promotion.dto';
import type { StudentToAddDto } from './dto/add-students.dto';
import { PrismaService } from 'src/prisma/prisma.service';
import { Role } from '@prisma/client';
import { UserHandler } from '../notifications/handlers/user.handler';
import { PasswordUtils } from '../utils/password.utils';
import { getErrorMessage } from '../utils/type-guards';
import * as bcrypt from 'bcryptjs';

@Injectable()
export class PromotionService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly userHandler: UserHandler,
  ) {}

  async findAllByTeacher(teacherId: string) {
    try {
      return await this.prisma.promotion.findMany({
        where: {
          teachers: {
            some: {
              userId: teacherId,
            },
          },
        },
        select: {
          id: true,
          name: true,
          teachers: {
            select: {
              user: {
                select: {
                  id: true,
                  firstname: true,
                  lastname: true,
                  email: true,
                },
              },
            },
          },
          _count: {
            select: {
              students: true,
              projects: true,
            },
          },
        },
      });
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  async findOneByTeacher(teacherId: string, promotionId: string) {
    try {
      const promotion = await this.prisma.promotion.findUnique({
        where: { id: promotionId },
        include: {
          teachers: {
            include: {
              user: {
                select: {
                  id: true,
                  firstname: true,
                  lastname: true,
                  email: true,
                },
              },
            },
          },
          _count: {
            select: {
              students: true,
              projects: true,
            },
          },
        },
      });

      if (!promotion) {
        throw new NotFoundException('Promotion not found');
      }

      // Vérifier si le professeur est associé à la promotion
      const isTeacherAssociated = promotion.teachers.some(
        (teacher) => teacher.user.id === teacherId,
      );

      if (!isTeacherAssociated) {
        throw new HttpException(
          'Teacher not associated with this promotion',
          403,
        );
      }

      return promotion;
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  async getPromotionsTeacher(teacherId: string) {
    try {
      return await this.prisma.promotion.findMany({
        where: {
          teachers: {
            some: {
              userId: teacherId,
            },
          },
        },
        include: {
          teachers: {},
        },
      });
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  async create(createPromotionDto: CreatePromotionDto, teacherId: string) {
    try {
      // Création de la promotion et de la relation TeacherPromotion en transaction
      const result = await this.prisma.$transaction(async (tx) => {
        // 1. Créer la promotion
        const promotion = await tx.promotion.create({
          data: {
            name: createPromotionDto.name,
          },
        });

        // 2. Créer automatiquement la relation TeacherPromotion
        await tx.teacherPromotion.create({
          data: {
            userId: teacherId,
            promotionId: promotion.id,
          },
        });

        // 3. Retourner la promotion avec les relations
        return tx.promotion.findUnique({
          where: { id: promotion.id },
          include: {
            teachers: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                    email: true,
                  },
                },
              },
            },
            _count: {
              select: {
                students: true,
                projects: true,
              },
            },
          },
        });
      });
      return result;
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  async addStudentToPromotion(promotionId: string, studentId: string) {
    try {
      const promotion = await this.prisma.studentPromotion.create({
        data: {
          promotionId,
          userId: studentId,
        },
      });

      return promotion;
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  async removeToPromotion(promotionId: string, studentId: string) {
    try {
      const promotion = await this.prisma.studentPromotion.delete({
        where: {
          userId_promotionId: {
            userId: studentId,
            promotionId: promotionId,
          },
        },
      });

      return promotion;
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  async getPromotionStudents(promotionId: string) {
    try {
      const students = await this.prisma.user.findMany({
        where: {
          role: Role.STUDENT,
          studentPromotions: {
            some: {
              promotionId: promotionId,
            },
          },
        },
        select: {
          id: true,
          firstname: true,
          lastname: true,
          email: true,
        },
      });

      if (!students) {
        throw new NotFoundException('Promotion not found');
      }

      return students;
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  /**
   * Ajouter des étudiants à une promotion avec création automatique des comptes
   */
  async addStudentsWithCreation(
    promotionId: string,
    studentsData: StudentToAddDto[],
  ) {
    try {
      // Vérification de l'existence de la promotion
      const promotion = await this.prisma.promotion.findUnique({
        where: { id: promotionId },
      });

      if (!promotion) {
        throw new NotFoundException('Promotion not found');
      }

      const result = {
        studentsCreated: 0,
        studentsAddedToPromotion: 0,
        studentsSkipped: 0,
        newStudents: [] as string[],
        existingStudents: [] as string[],
        skippedStudents: [] as string[],
        errors: [] as Array<{ email: string; message: string }>,
      };

      for (const studentData of studentsData) {
        try {
          await this.prisma.$transaction(async (tx) => {
            // Vérifier si l'étudiant existe
            const existingUser = await tx.user.findUnique({
              where: { email: studentData.email },
            });

            let userId: string;

            if (existingUser) {
              userId = existingUser.id;
              result.existingStudents.push(studentData.email);

              // Vérifier si déjà dans la promotion
              const existingPromotion = await tx.studentPromotion.findUnique({
                where: {
                  userId_promotionId: {
                    userId: userId,
                    promotionId: promotionId,
                  },
                },
              });

              if (existingPromotion) {
                result.studentsSkipped++;
                result.skippedStudents.push(studentData.email);
                return;
              }
            } else {
              // Générer un mot de passe aléatoire
              const plainPassword = PasswordUtils.generateSimplePassword(10);
              const hashedPassword = await bcrypt.hash(plainPassword, 10);

              // Créer nouvel étudiant
              const newUser = await tx.user.create({
                data: {
                  firstname: studentData.firstname,
                  lastname: studentData.lastname,
                  email: studentData.email,
                  password: hashedPassword,
                  role: Role.STUDENT,
                },
              });

              userId = newUser.id;
              result.studentsCreated++;
              result.newStudents.push(studentData.email);

              // Déclencher la notification avec les identifiants
              const studentCredentials = {
                firstname: newUser.firstname ?? '',
                lastname: newUser.lastname ?? '',
                email: newUser.email,
                password: plainPassword,
                loginUrl: `${process.env.FRONTEND_APP_URL}/auth/student/login`,
              };

              // Notification asynchrone
              setImmediate(() => {
                this.userHandler
                  .handleStudentCreated(studentCredentials)
                  .catch((error) => {
                    console.error('Erreur envoi notification:', error);
                  });
              });
            }

            // Ajouter à la promotion
            await tx.studentPromotion.create({
              data: {
                userId: userId,
                promotionId: promotionId,
              },
            });

            result.studentsAddedToPromotion++;
          });
        } catch (error) {
          result.errors.push({
            email: studentData.email,
            message: `Erreur de traitement: ${getErrorMessage(error)}`,
          });
        }
      }

      return {
        ...result,
        summary: {
          total: studentsData.length,
          processed: result.studentsAddedToPromotion,
          created: result.studentsCreated,
          skipped: result.studentsSkipped,
          errors: result.errors.length,
        },
      };
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  async delete(promotionId: string, teacherId?: string) {
    try {
      // If teacherId is provided, verify the teacher has access to this promotion
      if (teacherId) {
        const promotion = await this.prisma.promotion.findUnique({
          where: { id: promotionId },
          include: {
            teachers: {
              where: { userId: teacherId },
            },
          },
        });

        if (!promotion) {
          throw new NotFoundException('Promotion not found');
        }

        if (promotion.teachers.length === 0) {
          throw new HttpException(
            'Teacher not associated with this promotion',
            403,
          );
        }
      }

      const promotion = await this.prisma.promotion.delete({
        where: { id: promotionId },
      });

      return promotion;
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  /**
   * Add existing students to a promotion
   */
  async addExistingStudents(
    promotionId: string,
    studentIds: string[],
    teacherId: string,
  ) {
    try {
      // Verify teacher has access to this promotion
      const promotion = await this.prisma.promotion.findUnique({
        where: { id: promotionId },
        include: {
          teachers: {
            where: { userId: teacherId },
          },
        },
      });

      if (!promotion) {
        throw new NotFoundException('Promotion not found');
      }

      if (promotion.teachers.length === 0) {
        throw new HttpException(
          'Teacher not associated with this promotion',
          403,
        );
      }

      // Verify all students exist
      const existingStudents = await this.prisma.user.findMany({
        where: {
          id: { in: studentIds },
          role: Role.STUDENT,
        },
      });

      if (existingStudents.length !== studentIds.length) {
        throw new HttpException('Some students not found', 404);
      }

      // Add students to promotion (skip if already exists)
      const results = await this.prisma.$transaction(async (tx) => {
        const addedStudents = [];
        const alreadyInPromotion = [];

        for (const studentId of studentIds) {
          try {
            await tx.studentPromotion.create({
              data: {
                userId: studentId,
                promotionId: promotionId,
              },
            });
            addedStudents.push(studentId);
          } catch {
            // Student already in promotion
            alreadyInPromotion.push(studentId);
          }
        }

        return { addedStudents, alreadyInPromotion };
      });

      return results;
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  /**
   * Add new students to a promotion (create them first)
   */
  async addNewStudents(
    promotionId: string,
    students: StudentToAddDto[],
    teacherId: string,
  ) {
    try {
      // Verify teacher has access to this promotion
      const promotion = await this.prisma.promotion.findUnique({
        where: { id: promotionId },
        include: {
          teachers: {
            where: { userId: teacherId },
          },
        },
      });

      if (!promotion) {
        throw new NotFoundException('Promotion not found');
      }

      if (promotion.teachers.length === 0) {
        throw new HttpException(
          'Teacher not associated with this promotion',
          403,
        );
      }

      // Use the existing method for adding students with creation
      return await this.addStudentsWithCreation(promotionId, students);
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  /**
   * Remove students from a promotion
   */
  async removeStudentsFromPromotion(
    promotionId: string,
    studentIds: string[],
    teacherId: string,
  ) {
    try {
      // Verify teacher has access to this promotion
      const promotion = await this.prisma.promotion.findUnique({
        where: { id: promotionId },
        include: {
          teachers: {
            where: { userId: teacherId },
          },
        },
      });

      if (!promotion) {
        throw new NotFoundException('Promotion not found');
      }

      if (promotion.teachers.length === 0) {
        throw new HttpException(
          'Teacher not associated with this promotion',
          403,
        );
      }

      // Remove students from promotion
      const result = await this.prisma.studentPromotion.deleteMany({
        where: {
          promotionId: promotionId,
          userId: { in: studentIds },
        },
      });

      return { removedCount: result.count };
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }

  /**
   * Récupérer tous les étudiants d'une promotion qui n'ont pas de groupe pour un projet donné
   */
  async getUngroupedStudents(projectId: string, promotionId: string) {
    try {
      const s = await this.prisma.user.findMany({
        where: {
          role: 'STUDENT',
          studentPromotions: {
            some: {
              promotionId: promotionId,
            },
          },
          groupMemberships: {
            none: {
              group: {
                projectId: projectId,
              },
            },
          },
        },
        select: {
          id: true,
          email: true,
          firstname: true,
          lastname: true,
          role: true,
          createdAt: true,
        },
      });
      console.log(s);
      return s;
    } catch (err) {
      console.error(err);
      const errorMessage = getErrorMessage(err);
      throw new HttpException(errorMessage, 500);
    }
  }
}
