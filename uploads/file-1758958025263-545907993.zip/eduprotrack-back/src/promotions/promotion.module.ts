import { Module } from '@nestjs/common';
import { PromotionService } from './promotions.service';
import { PromotionController } from './promotions.controller';
import { PrismaService } from 'src/prisma/prisma.service';
import { ImportStudentsService } from '../students/import-students.service';
import { UserHandler } from '../notifications/handlers/user.handler';
import { EmailService } from '../notifications/email.service';
import { TemplateService } from '../notifications/template.service';

@Module({
  controllers: [PromotionController],
  providers: [
    PromotionService,
    PrismaService,
    ImportStudentsService,
    UserHandler,
    EmailService,
    TemplateService,
  ],
})
export class PromotionModule {}
