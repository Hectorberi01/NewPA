import {
  Controller,
  Get,
  Post,
  Delete,
  Param,
  UseGuards,
  Request,
  BadRequestException,
  Body,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
  ApiConsumes,
} from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { ProjectService } from '../projects/project.service';
import { GroupManagementService } from '../groups/group-management.service';
import { DeliverableService } from '../deliverables/deliverable.service';
import { DefensesService } from '../defenses/defenses.service';
import { GroupReportContentService } from '../reports/services/group-report-content.service';
import { DeliveriesService } from '../deliveries/deliveries.service';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Role } from '@prisma/client';
import type { AuthenticatedRequest } from '../auth/types/auth.types';

@ApiTags('Student Projects')
@Controller('student')
@UseGuards(JWTAuthGuard)
@ApiBearerAuth('JWT-auth')
export class StudentProjectController {
  constructor(
    private readonly projectService: ProjectService,
    private readonly groupManagementService: GroupManagementService,
    private readonly deliverableService: DeliverableService,
    private readonly defensesService: DefensesService,
    private readonly groupReportContentService: GroupReportContentService,
    private readonly deliveriesService: DeliveriesService,
  ) {}

  /**
   * Guard pour vérifier que l'utilisateur est un étudiant
   */
  private ensureStudentRole(user: { role: Role; id: string }): void {
    if (user.role !== Role.STUDENT) {
      throw new BadRequestException('Accès réservé aux étudiants');
    }
  }

  @Get('projects')
  @ApiOperation({ summary: "Récupérer les projets de l'étudiant connecté" })
  @ApiResponse({ status: 200, description: "Liste des projets de l'étudiant" })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getMyProjects(@Request() req: AuthenticatedRequest) {
    this.ensureStudentRole(req.user);
    return this.projectService.findByStudent(req.user.id);
  }

  @Get('projects/:id')
  @ApiOperation({ summary: "Récupérer les détails d'un projet" })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiResponse({ status: 200, description: 'Détails du projet' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Projet non visible ou mauvaise promotion' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  async getProject(
    @Param('id') projectId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.projectService.findByIdForStudent(projectId, req.user.id);
  }

  @Get('projects/:id/groups/available')
  @ApiOperation({ summary: 'Récupérer les groupes disponibles pour un projet' })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiResponse({ status: 200, description: 'Liste des groupes disponibles' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getAvailableGroups(
    @Param('id') projectId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.groupManagementService.getAvailableGroups(projectId);
  }

  @Get('projects/:id/my-group')
  @ApiOperation({ summary: "Récupérer le groupe de l'étudiant pour un projet" })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiResponse({ status: 200, description: "Groupe de l'étudiant" })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Groupe non trouvé' })
  async getMyGroup(
    @Param('id') projectId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.groupManagementService.getStudentGroup(req.user.id, projectId);
  }

  @Post('groups/:groupId/join')
  @ApiOperation({ summary: 'Rejoindre un groupe' })
  @ApiParam({ name: 'groupId', description: 'ID du groupe' })
  @ApiResponse({ status: 201, description: 'Groupe rejoint avec succès' })
  @ApiResponse({
    status: 400,
    description: 'Erreur lors de la jointure au groupe',
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Groupe non trouvé' })
  async joinGroup(
    @Param('groupId') groupId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.groupManagementService.joinGroup(req.user.id, groupId);
  }

  @Delete('groups/:groupId/leave')
  @ApiOperation({ summary: 'Quitter un groupe' })
  @ApiParam({ name: 'groupId', description: 'ID du groupe' })
  @ApiResponse({ status: 200, description: 'Groupe quitté avec succès' })
  @ApiResponse({
    status: 400,
    description: 'Erreur lors de la sortie du groupe',
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Groupe non trouvé' })
  async leaveGroup(
    @Param('groupId') groupId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.groupManagementService.leaveGroup(req.user.id, groupId);
  }

  // ==================== ROUTES LIVRABLES ====================

  @Get('deliverables')
  @ApiOperation({ summary: 'Récupérer tous mes livrables' })
  @ApiResponse({ status: 200, description: 'Liste de tous les livrables accessibles à l\'étudiant' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getMyDeliverables(@Request() req: AuthenticatedRequest) {
    this.ensureStudentRole(req.user);
    return this.deliverableService.findByStudent(req.user.id);
  }

  @Get('deliverables/:deliverableId')
  @ApiOperation({ summary: 'Récupérer les détails d\'un livrable' })
  @ApiParam({ name: 'deliverableId', description: 'ID du livrable' })
  @ApiResponse({ status: 200, description: 'Détails du livrable' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès refusé au livrable' })
  @ApiResponse({ status: 404, description: 'Livrable non trouvé' })
  async getDeliverable(
    @Param('deliverableId') deliverableId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.deliverableService.findByIdForStudent(deliverableId, req.user.id);
  }

  @Post('deliverables/:deliverableId/submit')
  @UseInterceptors(FileInterceptor('file'))
  @ApiOperation({ summary: 'Soumettre un fichier pour un livrable' })
  @ApiConsumes('multipart/form-data')
  @ApiParam({ name: 'deliverableId', description: 'ID du livrable' })
  @ApiBody({
    description: 'Fichier à soumettre',
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiResponse({ status: 201, description: 'Fichier soumis avec succès' })
  @ApiResponse({ status: 400, description: 'Erreur de validation du fichier' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès refusé' })
  @ApiResponse({ status: 404, description: 'Livrable non trouvé' })
  async submitFile(
    @Param('deliverableId') deliverableId: string,
    @UploadedFile() file: Express.Multer.File,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.deliveriesService.submitDeliverable(deliverableId, null, req.user.id, { file });
  }

  @Post('deliverables/:deliverableId/submit-git')
  @ApiOperation({ summary: 'Soumettre un lien Git pour un livrable' })
  @ApiParam({ name: 'deliverableId', description: 'ID du livrable' })
  @ApiBody({
    description: 'Informations du dépôt Git',
    schema: {
      type: 'object',
      properties: {
        gitUrl: { type: 'string', example: 'https://github.com/user/repo.git' },
        branch: { type: 'string', example: 'main', default: 'main' },
      },
      required: ['gitUrl'],
    },
  })
  @ApiResponse({ status: 201, description: 'Lien Git soumis avec succès' })
  @ApiResponse({ status: 400, description: 'URL Git invalide' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès refusé' })
  @ApiResponse({ status: 404, description: 'Livrable non trouvé' })
  async submitGit(
    @Param('deliverableId') deliverableId: string,
    @Body() gitData: { gitUrl: string; branch?: string },
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.deliveriesService.submitDeliverable(deliverableId, null, req.user.id, { 
      gitUrl: gitData.gitUrl,
      branch: gitData.branch || 'main'
    });
  }

  // ==================== ROUTES SOUTENANCES ====================

  @Get('defenses')
  @ApiOperation({ summary: 'Récupérer mes soutenances planifiées' })
  @ApiResponse({ status: 200, description: 'Liste des soutenances de l\'étudiant' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getMyDefenses(@Request() req: AuthenticatedRequest) {
    this.ensureStudentRole(req.user);
    return this.defensesService.findByStudent(req.user.id);
  }

  @Get('defenses/:defenseId')
  @ApiOperation({ summary: 'Récupérer les détails d\'une soutenance' })
  @ApiParam({ name: 'defenseId', description: 'ID de la soutenance' })
  @ApiResponse({ status: 200, description: 'Détails de la soutenance' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès refusé à cette soutenance' })
  @ApiResponse({ status: 404, description: 'Soutenance non trouvée' })
  async getDefense(
    @Param('defenseId') defenseId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.defensesService.findByIdForStudent(defenseId, req.user.id);
  }

  // ==================== ROUTES RAPPORTS ====================

  @Get('reports')
  @ApiOperation({ summary: 'Récupérer tous mes rapports de groupe' })
  @ApiResponse({ status: 200, description: 'Liste des rapports accessibles à l\'étudiant' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getMyReports(@Request() req: AuthenticatedRequest) {
    this.ensureStudentRole(req.user);
    return this.groupReportContentService.getStudentReports(req.user.id);
  }

  @Get('reports/:reportId')
  @ApiOperation({ summary: 'Récupérer les détails d\'un rapport' })
  @ApiParam({ name: 'reportId', description: 'ID du rapport' })
  @ApiResponse({ status: 200, description: 'Détails du rapport' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès refusé à ce rapport' })
  @ApiResponse({ status: 404, description: 'Rapport non trouvé' })
  async getReport(
    @Param('reportId') reportId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    this.ensureStudentRole(req.user);
    return this.groupReportContentService.getReportForStudent(reportId, req.user.id);
  }

  // ==================== ROUTES DASHBOARD ====================

  @Get('dashboard')
  @ApiOperation({ summary: 'Tableau de bord étudiant avec toutes les informations' })
  @ApiResponse({ status: 200, description: 'Dashboard complet de l\'étudiant' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getDashboard(@Request() req: AuthenticatedRequest) {
    this.ensureStudentRole(req.user);
    
    const [projects, deliverables, defenses, reports] = await Promise.all([
      this.projectService.findByStudent(req.user.id),
      this.deliverableService.findByStudent(req.user.id),
      this.defensesService.findByStudent(req.user.id),
      this.groupReportContentService.getStudentReports(req.user.id),
    ]);

    return {
      projects,
      deliverables,
      defenses,
      reports,
      summary: {
        totalProjects: projects.length,
        totalDeliverables: deliverables.length,
        totalDefenses: defenses.length,
        totalReports: reports.length,
      },
    };
  }

  @Get('my-submissions')
  @ApiOperation({ summary: 'Récupérer toutes mes soumissions' })
  @ApiResponse({ status: 200, description: 'Liste de toutes les soumissions de l\'étudiant' })
  @ApiResponse({ status: 400, description: 'Accès réservé aux étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getMySubmissions(@Request() req: AuthenticatedRequest) {
    this.ensureStudentRole(req.user);
    return this.deliveriesService.findByStudent(req.user.id);
  }
}
