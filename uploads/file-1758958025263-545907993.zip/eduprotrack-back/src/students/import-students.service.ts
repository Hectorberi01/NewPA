import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { validate } from 'class-validator';
import * as csv from 'csv-parser';
import { Readable } from 'stream';
import type {
  ImportStudentDto,
  ImportResult,
  ImportError,
  ParsedStudent,
} from './dto/import-students.dto';
import { ImportStudentDtoValidation } from './dto/import-students.dto';
import { Role } from '@prisma/client';
import { UserHandler } from '../notifications/handlers/user.handler';
import { PasswordUtils } from '../utils/password.utils';
import { getErrorMessage } from '../utils/type-guards';

import * as bcrypt from 'bcryptjs';

@Injectable()
export class ImportStudentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly userHandler: UserHandler,
  ) {}

  /**
   * Point d'entrée principal pour l'import
   */
  async importStudentsToPromotion(
    file: Express.Multer.File,
    promotionId: string,
  ): Promise<ImportResult> {
    try {
      // 1. Validation du fichier
      this.validateFile(file);

      // 2. Vérification de l'existence de la promotion
      await this.validatePromotion(promotionId);

      // 3. Parsing du fichier
      const parsedStudents = await this.parseFile(file);

      // 4. Validation des données
      const { validStudents, errors } =
        await this.validateStudents(parsedStudents);

      // 5. Traitement des étudiants
      const processingResult = await this.processStudents(
        validStudents,
        promotionId,
      );

      // 6. Compilation du résultat final
      return this.compileResult(validStudents, processingResult, errors);
    } catch (error) {
      throw new BadRequestException(
        `Erreur lors de l'import: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Validation du fichier uploadé
   */
  private validateFile(file: Express.Multer.File): void {
    if (!file) {
      throw new BadRequestException('Aucun fichier fourni');
    }

    // Taille maximum 5MB
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      throw new BadRequestException('Le fichier ne peut pas dépasser 5MB');
    }

    // Types MIME acceptés
    const allowedMimeTypes = [
      'text/csv',
      'application/csv',
      'application/json',
      'text/plain',
    ];

    if (!allowedMimeTypes.includes(file.mimetype)) {
      throw new BadRequestException(
        'Format de fichier non supporté. Utilisez CSV ou JSON.',
      );
    }
  }

  /**
   * Vérification de l'existence de la promotion
   */
  private async validatePromotion(promotionId: string): Promise<void> {
    const promotion = await this.prisma.promotion.findUnique({
      where: { id: promotionId },
    });

    if (!promotion) {
      throw new BadRequestException(
        `Promotion avec l'ID ${promotionId} non trouvée`,
      );
    }
  }

  /**
   * Parsing du fichier selon son type
   */
  private async parseFile(file: Express.Multer.File): Promise<ParsedStudent[]> {
    const content = file.buffer.toString('utf-8');

    if (file.mimetype.includes('json')) {
      return this.parseJsonFile(content);
    } else {
      return this.parseCsvFile(file.buffer);
    }
  }

  /**
   * Parsing du fichier JSON
   */
  private parseJsonFile(content: string): ParsedStudent[] {
    try {
      const data: unknown = JSON.parse(content);

      if (!data || typeof data !== 'object' || !('students' in data)) {
        throw new BadRequestException(
          'Format JSON invalide. Utilisez: {"students": [...]}',
        );
      }

      const students = (data as { students: unknown }).students;
      if (!Array.isArray(students)) {
        throw new BadRequestException(
          'Format JSON invalide. "students" doit être un tableau',
        );
      }

      if (students.length > 500) {
        throw new BadRequestException('Maximum 500 étudiants par import');
      }

      return students.map((student: unknown, index: number) => ({
        ...(student as ImportStudentDto),
        rowIndex: index + 1,
      }));
    } catch (error) {
      if (error instanceof BadRequestException) {
        throw error;
      }
      throw new BadRequestException(
        `Erreur de parsing JSON: ${getErrorMessage(error)}`,
      );
    }
  }

  /**
   * Parsing du fichier CSV
   */
  private async parseCsvFile(buffer: Buffer): Promise<ParsedStudent[]> {
    return new Promise((resolve, reject) => {
      const students: ParsedStudent[] = [];
      const stream = Readable.from(buffer);

      stream
        .pipe(csv())
        .on('data', (data: Record<string, string>) => {
          students.push({
            firstname: data.firstname,
            lastname: data.lastname,
            email: data.email,
            avatar: data.avatar,
            rowIndex: students.length + 2, // +2 car ligne 1 = headers
          });
        })
        .on('end', () => {
          if (students.length > 500) {
            reject(new BadRequestException('Maximum 500 étudiants par import'));
          } else {
            resolve(students);
          }
        })
        .on('error', (error) => {
          reject(
            new BadRequestException(
              `Erreur de parsing CSV: ${getErrorMessage(error)}`,
            ),
          );
        });
    });
  }

  /**
   * Validation des données des étudiants
   */
  private async validateStudents(
    parsedStudents: ParsedStudent[],
  ): Promise<{ validStudents: ParsedStudent[]; errors: ImportError[] }> {
    const validStudents: ParsedStudent[] = [];
    const errors: ImportError[] = [];
    const seenEmails = new Set<string>();

    for (const student of parsedStudents) {
      // Vérification des doublons dans le fichier
      if (seenEmails.has(student.email)) {
        errors.push({
          row: student.rowIndex,
          email: student.email,
          message: 'Email dupliqué dans le fichier',
          type: 'duplicate',
        });
        continue;
      }
      seenEmails.add(student.email);

      // Validation avec class-validator
      const dto = Object.assign(new ImportStudentDtoValidation(), student);
      const validationErrors = await validate(dto);

      if (validationErrors.length > 0) {
        validationErrors.forEach((error) => {
          Object.values(error.constraints || {}).forEach((message) => {
            errors.push({
              row: student.rowIndex,
              email: student.email,
              field: error.property,
              message,
              type: 'validation',
            });
          });
        });
      } else {
        validStudents.push(student);
      }
    }

    return { validStudents, errors };
  }

  /**
   * Traitement des étudiants validés
   */
  private async processStudents(
    validStudents: ParsedStudent[],
    promotionId: string,
  ) {
    const result = {
      studentsCreated: 0,
      studentsAddedToPromotion: 0,
      studentsSkipped: 0,
      newStudents: [] as string[],
      existingStudents: [] as string[],
      skippedStudents: [] as string[],
      failedStudents: [] as string[],
      errors: [] as ImportError[],
    };

    for (const studentData of validStudents) {
      try {
        await this.prisma.$transaction(async (tx) => {
          // Vérifier si l'étudiant existe
          const existingUser = await tx.user.findUnique({
            where: { email: studentData.email },
          });

          let userId: string;

          if (existingUser) {
            userId = existingUser.id;
            result.existingStudents.push(studentData.email);

            // Vérifier si déjà dans la promotion
            const existingPromotion = await tx.studentPromotion.findUnique({
              where: {
                userId_promotionId: {
                  userId: userId,
                  promotionId: promotionId,
                },
              },
            });

            if (existingPromotion) {
              result.studentsSkipped++;
              result.skippedStudents.push(studentData.email);
              return;
            }
          } else {
            // Générer un mot de passe aléatoire
            const plainPassword = PasswordUtils.generateSimplePassword(10);
            const hashedPassword = await bcrypt.hash(plainPassword, 10);

            // Créer nouvel étudiant
            const newUser = await tx.user.create({
              data: {
                firstname: studentData.firstname,
                lastname: studentData.lastname,
                email: studentData.email,
                password: hashedPassword,
                role: Role.STUDENT,
              },
            });

            userId = newUser.id;
            result.studentsCreated++;
            result.newStudents.push(studentData.email);

            // Déclencher la notification avec les identifiants
            const studentCredentials = {
              firstname: newUser.firstname ?? '',
              lastname: newUser.lastname ?? '',
              email: newUser.email,
              password: plainPassword,
              loginUrl: `${process.env.FRONTEND_APP_URL}/auth/student/login`,
            };

            // Notification asynchrone pour ne pas bloquer la transaction
            setImmediate(() => {
              this.userHandler
                .handleStudentCreated(studentCredentials)
                .catch((error) => {
                  console.error('Erreur envoi notification:', error);
                });
            });
          }

          // Ajouter à la promotion
          await tx.studentPromotion.create({
            data: {
              userId: userId,
              promotionId: promotionId,
            },
          });

          result.studentsAddedToPromotion++;
        });
      } catch (error) {
        result.errors.push({
          row: studentData.rowIndex,
          email: studentData.email,
          message: `Erreur de traitement: ${getErrorMessage(error)}`,
          type: 'database',
        });
        result.failedStudents.push(studentData.email);
      }
    }

    return result;
  }

  /**
   * Compilation du résultat final
   */
  private compileResult(
    validStudents: ParsedStudent[],
    processingResult: {
      studentsCreated: number;
      studentsAddedToPromotion: number;
      studentsSkipped: number;
      newStudents: string[];
      existingStudents: string[];
      skippedStudents: string[];
      failedStudents: string[];
      errors: ImportError[];
    },
    validationErrors: ImportError[],
  ): ImportResult {
    const allErrors = [...validationErrors, ...processingResult.errors];

    return {
      success: allErrors.length === 0,
      totalProcessed: validStudents.length,
      studentsCreated: processingResult.studentsCreated,
      studentsAddedToPromotion: processingResult.studentsAddedToPromotion,
      studentsSkipped: processingResult.studentsSkipped,
      errors: allErrors,
      summary: {
        newStudents: processingResult.newStudents,
        existingStudents: processingResult.existingStudents,
        skippedStudents: processingResult.skippedStudents,
        failedStudents: processingResult.failedStudents,
      },
    } as ImportResult;
  }
}
