// Mock bcryptjs BEFORE any imports
jest.mock('bcryptjs', () => ({
  hash: jest.fn().mockResolvedValue('hashed-password'),
  compare: jest.fn().mockResolvedValue(true),
}));

import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { StudentsService } from './students.service';
import { PrismaService } from '../prisma/prisma.service';
import { Role } from '@prisma/client';
import { BadRequestException, ConflictException } from '@nestjs/common';
import { hash } from 'bcryptjs';

describe('StudentsService', () => {
  let service: StudentsService;
  let prismaService: PrismaService;

  const mockPrismaService = {
    user: {
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        StudentsService,
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
      ],
    }).compile();

    service = module.get<StudentsService>(StudentsService);
    prismaService = module.get<PrismaService>(PrismaService);

    // Reset all mocks
    jest.clearAllMocks();

    // Ensure bcryptjs mock is properly configured
    (hash as jest.Mock).mockResolvedValue('hashed-password');
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getAll', () => {
    it('should return all students successfully', async () => {
      const mockStudents = [
        {
          id: '1',
          email: 'student1@test.com',
          firstname: 'John',
          lastname: 'Doe',
          role: Role.STUDENT,
        },
        {
          id: '2',
          email: 'student2@test.com',
          firstname: 'Jane',
          lastname: 'Smith',
          role: Role.STUDENT,
        },
      ];

      mockPrismaService.user.findMany.mockResolvedValue(mockStudents);

      const result = await service.getAll();

      expect(result).toEqual(mockStudents);
      expect(mockPrismaService.user.findMany).toHaveBeenCalledWith({
        where: {
          role: 'STUDENT',
        },
      });
    });

    it('should handle database errors', async () => {
      const error = new Error('Database connection failed');
      mockPrismaService.user.findMany.mockRejectedValue(error);

      await expect(service.getAll()).rejects.toThrow(BadRequestException);
      expect(mockPrismaService.user.findMany).toHaveBeenCalledWith({
        where: {
          role: 'STUDENT',
        },
      });
    });
  });

  describe('getExcludeStudentFromPromotion', () => {
    it('should return students excluding those from specified promotion', async () => {
      const promotionId = 'promotion-1';
      const mockStudents = [
        {
          id: '3',
          email: 'student3@test.com',
          firstname: 'Bob',
          lastname: 'Wilson',
          role: Role.STUDENT,
        },
      ];

      mockPrismaService.user.findMany.mockResolvedValue(mockStudents);

      const result = await service.getExcludeStudentFromPromotion(promotionId);

      expect(result).toEqual(mockStudents);
      expect(mockPrismaService.user.findMany).toHaveBeenCalledWith({
        where: {
          role: Role.STUDENT,
          studentPromotions: {
            some: {
              promotionId: promotionId,
            },
          },
        },
      });
    });

    it('should handle database errors for promotion exclusion', async () => {
      const promotionId = 'promotion-1';
      const error = new Error('Database error');
      mockPrismaService.user.findMany.mockRejectedValue(error);

      await expect(
        service.getExcludeStudentFromPromotion(promotionId),
      ).rejects.toThrow(BadRequestException);
      expect(mockPrismaService.user.findMany).toHaveBeenCalledWith({
        where: {
          role: Role.STUDENT,
          studentPromotions: {
            some: {
              promotionId: promotionId,
            },
          },
        },
      });
    });
  });

  describe('create', () => {
    it('should create a new student successfully', async () => {
      const createStudentDto = {
        email: 'newstudent@test.com',
        firstname: 'Alice',
        lastname: 'Johnson',
      };

      const mockCreatedStudent = {
        id: '4',
        ...createStudentDto,
        role: Role.STUDENT,
        password: 'hashed-password',
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      // Mock pour vérifier qu'un étudiant avec cet email n'existe pas
      mockPrismaService.user.findUnique.mockResolvedValue(null);
      mockPrismaService.user.create.mockResolvedValue(mockCreatedStudent);

      const result = await service.create(createStudentDto);

      expect(result).toEqual(mockCreatedStudent);
      expect(mockPrismaService.user.findUnique).toHaveBeenCalledWith({
        where: { email: createStudentDto.email },
      });
      expect(mockPrismaService.user.create).toHaveBeenCalledWith({
        data: {
          ...createStudentDto,
          role: Role.STUDENT,
          password: 'hashed-password',
        },
      });
    });

    it('should handle creation errors', async () => {
      const createStudentDto = {
        email: 'newstudent@test.com',
        firstname: 'Alice',
        lastname: 'Johnson',
      };

      // Mock pour vérifier qu'un étudiant avec cet email n'existe pas
      mockPrismaService.user.findUnique.mockResolvedValue(null);
      const error = new Error('Database connection failed');
      mockPrismaService.user.create.mockRejectedValue(error);

      await expect(service.create(createStudentDto)).rejects.toThrow(
        BadRequestException,
      );
      expect(mockPrismaService.user.findUnique).toHaveBeenCalledWith({
        where: { email: createStudentDto.email },
      });
    });

    it('should handle duplicate email', async () => {
      const createStudentDto = {
        email: 'existing@test.com',
        firstname: 'Alice',
        lastname: 'Johnson',
      };

      const existingStudent = {
        id: '1',
        email: 'existing@test.com',
        firstname: 'Existing',
        lastname: 'Student',
        role: Role.STUDENT,
      };

      mockPrismaService.user.findUnique.mockResolvedValue(existingStudent);

      await expect(service.create(createStudentDto)).rejects.toThrow(
        ConflictException,
      );
      await expect(service.create(createStudentDto)).rejects.toThrow(
        'Un étudiant avec cet email existe déjà',
      );
      expect(mockPrismaService.user.findUnique).toHaveBeenCalledWith({
        where: { email: createStudentDto.email },
      });
      expect(mockPrismaService.user.create).not.toHaveBeenCalled();
    });
  });
});
