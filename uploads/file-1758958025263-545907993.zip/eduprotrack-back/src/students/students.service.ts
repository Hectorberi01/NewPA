import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import type { CreateStudentDto } from './dto/create-student.dto';
import type { CreatePasswordDto } from './dto/create-password-dto';
import { PrismaService } from '../prisma/prisma.service';
import type { Prisma } from '@prisma/client';
import { Role } from '@prisma/client';
import { randomBytes } from 'crypto';
import { hash } from 'bcryptjs';
import { sign } from 'jsonwebtoken';
import { UpdateStudentDto } from './dto/update-student.dto';

@Injectable()
export class StudentsService {
  constructor(private prisma: PrismaService) {}

  async getAll() {
    return this.prisma.user.findMany({
      where: {
        role: 'STUDENT' as Role,
      },
      select: {
        id: true,
        firstname: true,
        lastname: true,
        email: true,
      },
    });
  }

  async getExcludeStudentFromPromotion(id: string) {
    return this.prisma.user.findMany({
      where: {
        role: Role.STUDENT,
        studentPromotions: {
          some: {
            promotionId: id,
          },
        },
      },
      select: {
        id: true,
        firstname: true,
        lastname: true,
        email: true,
      },
    });
  }

  private async generateRandomHashedPassword(): Promise<string | null> {
    const rawPassword = randomBytes(6).toString('base64').slice(0, 10);

    // TODO à virer
    console.log('Password:', rawPassword);
    try {
      return await hash(rawPassword, 10);
    } catch (err) {
      console.error('Erreur génération password:', err);
      return null;
    }
  }

  async create(createStudentDto: CreateStudentDto) {
    const hashedPassword = await this.generateRandomHashedPassword();

    if (!hashedPassword) {
      throw new BadRequestException(
        'Erreur lors de la génération du mot de passe',
      );
    }

    // Vérifier si l'étudiant n'existe pas déjà
    const foundedStudent = await this.prisma.user.findUnique({
      where: { email: createStudentDto.email },
    });

    if (foundedStudent) {
      throw new ConflictException('Un étudiant avec cet email existe déjà');
    }

    const userData: Prisma.UserCreateInput = {
      firstname: createStudentDto.firstname,
      lastname: createStudentDto.lastname,
      email: createStudentDto.email,
      role: Role.STUDENT,
      password: hashedPassword,
    };

    return this.prisma.user.create({
      data: userData,
    });
  }

  async createPassword(body: CreatePasswordDto) {
    const { email, password } = body;

    // Vérifier si l'étudiant existe
    const student = await this.prisma.user.findUnique({
      where: { email },
    });

    if (!student) {
      throw new NotFoundException('Aucun étudiant trouvé avec cet email');
    }

    // Mettre à jour le mot de passe de l'étudiant
    const hashedPassword = await hash(password, 10);
    await this.prisma.user.update({
      where: { id: student.id },
      data: { password: hashedPassword },
    });

    // Générer le token de connexion
    const payload = {
      id: student.id,
      email: student.email,
      role: student.role,
    };

    const token = sign(payload, process.env.JWT_SECRET);

    return {
      id: student.id,
      email: student.email,
      firstname: student.firstname,
      lastname: student.lastname,
      role: student.role,
      token,
    };
  }

  async updateStudent(id: string, data: UpdateStudentDto) {
    const student = await this.prisma.user.findUnique({
      where: { id },
    });

    if (!student) {
      throw new NotFoundException(`Aucun élève avec l'id ${id}`);
    }

    return await this.prisma.user.update({
      where: { id },
      data: {
        firstname: data.firstname,
        lastname: data.lastname,
      },
    });
  }
}
