import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { StudentsController } from './students.controller';
import { StudentsService } from './students.service';
import { PrismaService } from '../prisma/prisma.service';
import { ImportStudentsService } from './import-students.service';
import { Role } from '@prisma/client';

describe('StudentsController', () => {
  let controller: StudentsController;
  let studentsService: StudentsService;
  let importStudentsService: ImportStudentsService;

  const mockPrismaService = {
    user: {
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
    },
  };

  const mockStudentsService = {
    getAll: jest.fn(),
    getExcludeStudentFromPromotion: jest.fn(),
    create: jest.fn(),
    createPassword: jest.fn(),
  };

  const mockImportStudentsService = {
    importStudents: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [StudentsController],
      providers: [
        {
          provide: StudentsService,
          useValue: mockStudentsService,
        },
        {
          provide: ImportStudentsService,
          useValue: mockImportStudentsService,
        },
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
      ],
    }).compile();

    controller = module.get<StudentsController>(StudentsController);
    studentsService = module.get<StudentsService>(StudentsService);
    importStudentsService = module.get<ImportStudentsService>(
      ImportStudentsService,
    );

    // Reset all mocks
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('getAll', () => {
    it('should return all students', async () => {
      const mockStudents = [
        { id: '1', email: 'student1@test.com', role: Role.STUDENT },
        { id: '2', email: 'student2@test.com', role: Role.STUDENT },
      ];
      mockStudentsService.getAll.mockResolvedValue({
        status: 'success',
        message: 'Opération réussie',
        data: mockStudents,
      });

      const result = await controller.getAll();

      expect(result).toEqual({
        status: 'success',
        message: 'Opération réussie',
        data: mockStudents,
      });
      expect(mockStudentsService.getAll).toHaveBeenCalledTimes(1);
    });

    it('should handle service errors', async () => {
      const error = new Error('Database error');
      mockStudentsService.getAll.mockRejectedValue(error);

      await expect(controller.getAll()).rejects.toThrow('Database error');
      expect(mockStudentsService.getAll).toHaveBeenCalledTimes(1);
    });
  });

  describe('getStudentNotInPromotion', () => {
    it('should return students not in promotion', async () => {
      const promotionId = 'promotion-1';
      const mockStudents = [
        { id: '3', email: 'student3@test.com', role: Role.STUDENT },
      ];
      mockStudentsService.getExcludeStudentFromPromotion.mockResolvedValue({
        status: 'success',
        message: 'Opération réussie',
        data: mockStudents,
      });

      const result = await controller.getStudentNotInPromotion(promotionId);

      expect(result).toEqual({
        status: 'success',
        message: 'Opération réussie',
        data: mockStudents,
      });
      expect(
        mockStudentsService.getExcludeStudentFromPromotion,
      ).toHaveBeenCalledWith(promotionId);
    });
  });

  describe('create', () => {
    it('should create a new student', async () => {
      const createStudentDto = {
        email: 'newstudent@test.com',
        firstname: 'John',
        lastname: 'Doe',
      };
      const mockCreatedStudent = {
        id: '4',
        ...createStudentDto,
        role: Role.STUDENT,
      };
      mockStudentsService.create.mockResolvedValue({
        status: 'success',
        message: 'Opération réussie',
        data: mockCreatedStudent,
      });

      const result = await controller.create(createStudentDto);

      expect(result).toEqual({
        status: 'success',
        message: 'Opération réussie',
        data: mockCreatedStudent,
      });
      expect(mockStudentsService.create).toHaveBeenCalledWith(createStudentDto);
    });
  });

  describe('createPassword', () => {
    it('should create password for student', async () => {
      const createPasswordDto = {
        email: 'student@test.com',
        password: 'newPassword123',
      };
      const mockResponse = {
        status: 'success',
        message: 'Password created successfully',
        data: null,
      };
      mockStudentsService.createPassword.mockResolvedValue(mockResponse);

      const result = await controller.createPassword(createPasswordDto);

      expect(result).toEqual(mockResponse);
      expect(mockStudentsService.createPassword).toHaveBeenCalledWith(
        createPasswordDto,
      );
    });
  });
});
