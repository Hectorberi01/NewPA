import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  UseGuards,
  Put,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';
import { StudentsService } from './students.service';
import { CreateStudentDtoValidation } from './dto/create-student.dto';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreatePasswordDtoValidation } from './dto/create-password-dto';
import { UpdateStudentDto } from './dto/update-student.dto';

@ApiTags('Students')
@Controller('students')
export class StudentsController {
  constructor(private readonly studentsService: StudentsService) {}

  @Get()
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Récupérer tous les étudiants' })
  @ApiResponse({ status: 200, description: 'Liste de tous les étudiants' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  getAll() {
    return this.studentsService.getAll();
  }

  @Get('excluded/:excludedPromotionId')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({
    summary: 'Récupérer les étudiants non inclus dans une promotion',
  })
  @ApiParam({
    name: 'excludedPromotionId',
    description: 'ID de la promotion à exclure',
  })
  @ApiResponse({
    status: 200,
    description: 'Liste des étudiants non inclus dans la promotion spécifiée',
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  getStudentNotInPromotion(@Param('excludedPromotionId') promotionId: string) {
    return this.studentsService.getExcludeStudentFromPromotion(promotionId);
  }

  @Post()
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Créer un nouvel étudiant' })
  @ApiBody({ type: CreateStudentDtoValidation })
  @ApiResponse({ status: 201, description: 'Étudiant créé avec succès' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  create(@Body() createStudentDto: CreateStudentDtoValidation) {
    return this.studentsService.create(createStudentDto);
  }

  @Post('/create-password')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Créer un mot de passe pour un étudiant' })
  @ApiBody({ type: CreatePasswordDtoValidation })
  @ApiResponse({ status: 201, description: 'Mot de passe créé avec succès' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async createPassword(@Body() body: CreatePasswordDtoValidation) {
    return await this.studentsService.createPassword(body);
  }

  @Put('/:id')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Mettre à jour le prénom et nom d’un élève' })
  @ApiParam({ name: 'id', description: "ID de l'élève à modifier" })
  @ApiResponse({ status: 200, description: 'Élève mis à jour avec succès' })
  @ApiResponse({ status: 404, description: 'Élève non trouvé' })
  async updateStudent(
    @Param('id') id: string,
    @Body() updateDto: UpdateStudentDto,
  ) {
    return await this.studentsService.updateStudent(id, updateDto);
  }
}
