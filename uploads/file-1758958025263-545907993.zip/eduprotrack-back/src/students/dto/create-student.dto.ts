import { IsEmail, IsString } from 'class-validator';

export interface CreateStudentDto {
  email: string;
  firstname: string;
  lastname: string;
}

export class CreateStudentDtoValidation implements CreateStudentDto {
  @IsEmail()
  email!: string;

  @IsString()
  firstname!: string;

  @IsString()
  lastname!: string;
}
