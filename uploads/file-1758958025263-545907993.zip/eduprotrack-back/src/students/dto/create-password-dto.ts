import { IsEmail, IsString } from 'class-validator';

export interface CreatePasswordDto {
  email: string;
  password: string;
}

export class CreatePasswordDtoValidation implements CreatePasswordDto {
  @IsEmail()
  email!: string;

  @IsString()
  password!: string;
}
