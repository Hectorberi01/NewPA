export enum StudenApiError {
  AlreadyExist = 'Un étudiant avec cet email existe déjà',
}
