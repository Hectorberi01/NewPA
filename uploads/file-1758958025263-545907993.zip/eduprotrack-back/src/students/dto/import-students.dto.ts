import { IsEmail, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { Transform } from 'class-transformer';

export interface ImportStudentDto {
  firstname: string;
  lastname: string;
  email: string;
  avatar?: string;
}

export class ImportStudentDtoValidation implements ImportStudentDto {
  @IsString()
  @IsNotEmpty()
  @Transform(({ value }: { value: unknown }) =>
    typeof value === 'string' ? value.trim() : value,
  )
  firstname!: string;

  @IsString()
  @IsNotEmpty()
  @Transform(({ value }: { value: unknown }) =>
    typeof value === 'string' ? value.trim() : value,
  )
  lastname!: string;

  @IsEmail()
  @Transform(({ value }: { value: unknown }) =>
    typeof value === 'string' ? value.toLowerCase().trim() : value,
  )
  email!: string;

  @IsOptional()
  @IsString()
  avatar?: string;
}

export interface ImportResult {
  success: boolean;
  totalProcessed: number;
  studentsCreated: number;
  studentsAddedToPromotion: number;
  studentsSkipped: number;
  errors: ImportError[];
  summary: {
    newStudents: string[];
    existingStudents: string[];
    skippedStudents: string[];
    failedStudents: string[];
  };
}

export interface ImportError {
  row: number;
  email?: string;
  field?: string;
  message: string;
  type: 'validation' | 'database' | 'duplicate' | 'system';
}

export interface ParsedStudent extends ImportStudentDto {
  rowIndex: number;
}
