import { PartialType } from '@nestjs/mapped-types';
import { CreateStudentDtoValidation } from './create-student.dto';

export class UpdateStudentDto extends PartialType(CreateStudentDtoValidation) {}
