import { Module } from '@nestjs/common';
import { StudentsService } from './students.service';
import { StudentsController } from './students.controller';
import { StudentProjectController } from './student-project.controller';
import { ProjectModule } from '../projects/project.module';
import { GroupsModule } from '../groups/groups.module';
import { DeliverableModule } from '../deliverables/deliverable.module';
import { DefensesModule } from '../defenses/defenses.module';
import { ReportsModule } from '../reports/reports.module';
import { DeliveriesModule } from '../deliveries/deliveries.module';
import { PrismaService } from '../prisma/prisma.service';

@Module({
  controllers: [StudentsController, StudentProjectController],
  providers: [StudentsService, PrismaService],
  imports: [
    ProjectModule, 
    GroupsModule, 
    DeliverableModule, 
    DefensesModule, 
    ReportsModule,
    DeliveriesModule
  ],
})
export class StudentsModule {}
