import * as crypto from 'crypto';

export class PasswordUtils {
  /**
   * Génère un mot de passe aléatoire sécurisé
   * @param length - Longueur du mot de passe (défaut: 12)
   * @returns Le mot de passe généré
   */
  static generateRandomPassword(length: number = 12): string {
    const upperCaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowerCaseLetters = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const specialChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    const allChars =
      upperCaseLetters + lowerCaseLetters + numbers + specialChars;

    let password = '';

    // Assurer qu'il y a au moins un caractère de chaque type
    password += upperCaseLetters[crypto.randomInt(0, upperCaseLetters.length)];
    password += lowerCaseLetters[crypto.randomInt(0, lowerCaseLetters.length)];
    password += numbers[crypto.randomInt(0, numbers.length)];
    password += specialChars[crypto.randomInt(0, specialChars.length)];

    // Compléter avec des caractères aléatoires
    for (let i = password.length; i < length; i++) {
      password += allChars[crypto.randomInt(0, allChars.length)];
    }

    // Mélanger les caractères
    return password
      .split('')
      .sort(() => crypto.randomInt(0, 2) - 0.5)
      .join('');
  }

  /**
   * Génère un mot de passe plus simple et lisible
   * @param length - Longueur du mot de passe (défaut: 10)
   * @returns Le mot de passe généré
   */
  static generateSimplePassword(length: number = 10): string {
    const upperCaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowerCaseLetters = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';

    const allChars = upperCaseLetters + lowerCaseLetters + numbers;

    let password = '';

    // Assurer qu'il y a au moins une majuscule, une minuscule et un chiffre
    password += upperCaseLetters[crypto.randomInt(0, upperCaseLetters.length)];
    password += lowerCaseLetters[crypto.randomInt(0, lowerCaseLetters.length)];
    password += numbers[crypto.randomInt(0, numbers.length)];

    // Compléter avec des caractères aléatoires
    for (let i = password.length; i < length; i++) {
      password += allChars[crypto.randomInt(0, allChars.length)];
    }

    // Mélanger les caractères
    return password
      .split('')
      .sort(() => crypto.randomInt(0, 2) - 0.5)
      .join('');
  }
}
