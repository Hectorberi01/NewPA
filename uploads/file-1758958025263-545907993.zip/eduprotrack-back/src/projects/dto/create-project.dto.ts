import {
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Min,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { GroupFormationMode, ProjectStatus } from '@prisma/client';

export interface CreateProjectDto {
  title: string;
  description?: string;
  promotionId: string;
  teacherId?: string;
  groupMode?: GroupFormationMode;
  groupCreationDeadline?: string; // Correspond à groupDeadline dans Prisma
  status?: ProjectStatus;
  minGroupSize?: number;
  maxGroupSize?: number;
}

export class CreateProjectDtoValidation implements CreateProjectDto {
  @ApiProperty({
    description: 'Titre du projet',
    example: "Projet de fin d'année - Application web",
  })
  @IsString()
  @IsNotEmpty()
  title!: string;

  @ApiPropertyOptional({
    description: 'Description détaillée du projet',
    example:
      "Développement d'une application web full-stack avec authentification et gestion des utilisateurs",
  })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({
    description: 'ID de la promotion concernée',
    example: 'clm1234567890abcdef123456',
  })
  @IsString()
  @IsOptional()
  promotionId!: string;

  @ApiPropertyOptional({
    description: "ID de l'enseignant responsable",
    example: 'clm0987654321fedcba098765',
  })
  @IsString()
  @IsOptional()
  teacherId?: string;

  @ApiPropertyOptional({
    description: 'Mode de formation des groupes',
    enum: GroupFormationMode,
    example: GroupFormationMode.FREE,
  })
  @IsEnum(GroupFormationMode)
  @IsOptional()
  groupMode?: GroupFormationMode;

  @ApiPropertyOptional({
    description: 'Date limite pour la création des groupes (ISO 8601)',
    example: '2024-12-31T23:59:59.000Z',
  })
  @IsDateString()
  @IsOptional()
  groupCreationDeadline?: string;

  @ApiPropertyOptional({
    description: 'Statut du projet',
    enum: ProjectStatus,
    example: ProjectStatus.VISIBLE,
  })
  @IsEnum(ProjectStatus)
  @IsOptional()
  status?: ProjectStatus;

  @ApiPropertyOptional({
    description: "Taille minimale d'un groupe",
    minimum: 1,
    example: 2,
  })
  @IsInt()
  @Min(1)
  @IsOptional()
  minGroupSize?: number;

  @ApiPropertyOptional({
    description: "Taille maximale d'un groupe",
    minimum: 1,
    example: 4,
  })
  @IsInt()
  @Min(1)
  @IsOptional()
  maxGroupSize?: number;
}
