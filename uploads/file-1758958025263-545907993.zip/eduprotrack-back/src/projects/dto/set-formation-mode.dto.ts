import { IsEnum } from 'class-validator';
import { GroupFormationMode } from '@prisma/client';

export interface SetFormationModeDto {
  mode: GroupFormationMode;
}

export class SetFormationModeDtoValidation implements SetFormationModeDto {
  @IsEnum(GroupFormationMode)
  mode!: GroupFormationMode;
}
