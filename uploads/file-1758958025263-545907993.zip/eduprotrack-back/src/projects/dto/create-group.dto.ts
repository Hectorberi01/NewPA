import { IsArray, IsString } from 'class-validator';

export interface CreateGroupDto {
  members: string[];
}

export class CreateGroupDtoValidation implements CreateGroupDto {
  @IsArray()
  @IsString({ each: true })
  members!: string[];
}
