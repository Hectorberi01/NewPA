import { IsOptional, IsInt, IsDateString, Min } from 'class-validator';

export class UpdateGroupConfigDto {
  @IsOptional()
  @IsInt()
  @Min(1)
  minGroupSize?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  maxGroupSize?: number;

  @IsOptional()
  @IsDateString()
  groupDeadline?: string;
}
