// project.controller.ts
import {
  Body,
  Controller,
  Post,
  Get,
  Param,
  Put,
  UseGuards,
  Request,
  Delete,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';
import { CreateGroupDtoValidation } from './dto/create-group.dto';
import { CreateProjectDtoValidation } from './dto/create-project.dto';
import { UpdateGroupConfigDto } from './dto/update-group-config.dto';
import { SetFormationModeDtoValidation } from './dto/set-formation-mode.dto';
import { ProjectService } from './project.service';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../auth/guards/teacher.guard';
import { EvaluationGridService } from '../grading/services/evaluation-grid.service';
import {
  CreateEvaluationGridDto,
  EvaluationGridResponseDto,
} from '../grading/dto';

interface AuthenticatedRequest extends Request {
  user: {
    id: string;
    email: string;
    role: string;
  };
}

@ApiTags('Projects')
@Controller('projects')
@UseGuards(JWTAuthGuard)
@ApiBearerAuth('JWT-auth')
export class ProjectController {
  constructor(
    private readonly projectService: ProjectService,
    private readonly evaluationGridService: EvaluationGridService,
  ) {}

  @Post()
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Créer un nouveau projet' })
  @ApiBody({ type: CreateProjectDtoValidation })
  @ApiResponse({ status: 201, description: 'Projet créé avec succès' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  create(
    @Body() dto: CreateProjectDtoValidation,
    @Request() req: AuthenticatedRequest,
  ) {
    dto.teacherId = req.user.id;
    return this.projectService.create(dto);
  }

  @Get()
  @ApiOperation({ summary: 'Récupérer tous les projets' })
  @ApiResponse({ status: 200, description: 'Liste de tous les projets' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  findAll() {
    return this.projectService.findAll();
  }

  @Get('teacher/:id')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: "Récupérer les projets d'un enseignant" })
  @ApiParam({ name: 'id', description: "ID de l'enseignant" })
  @ApiResponse({
    status: 200,
    description: "Liste des projets de l'enseignant",
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  findByTeacher(@Param('id') teacherId: string) {
    return this.projectService.findByTeacher(teacherId);
  }

  @Get('my-projects')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Récupérer mes projets (enseignant connecté)' })
  @ApiResponse({
    status: 200,
    description: "Liste des projets de l'enseignant connecté",
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  findMyProjects(@Request() req: AuthenticatedRequest) {
    return this.projectService.findByTeacher(req.user.id);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Récupérer un projet par son ID' })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiResponse({ status: 200, description: 'Projet récupéré avec succès' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  findById(@Param('id') id: string) {
    return this.projectService.findById(id);
  }

  /**
   * Publication d'un projet (DRAFT → VISIBLE)
   */
  @Put(':id/publish')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Publier un projet (DRAFT → VISIBLE)' })
  @ApiParam({ name: 'id', description: 'ID du projet à publier' })
  @ApiResponse({ status: 200, description: 'Projet publié avec succès' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  publishProject(
    @Param('id') projectId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    return this.projectService.publishProject(projectId, req.user.id);
  }

  /**
   * Configuration des groupes (tailles, deadline)
   */
  @Put(':id/group-config')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Configurer les groupes (tailles, deadline)' })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiBody({ type: UpdateGroupConfigDto })
  @ApiResponse({
    status: 200,
    description: 'Configuration des groupes mise à jour avec succès',
  })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  updateGroupConfig(
    @Param('id') projectId: string,
    @Body() dto: UpdateGroupConfigDto,
    @Request() req: AuthenticatedRequest,
  ) {
    return this.projectService.updateGroupConfig(projectId, req.user.id, dto);
  }

  /**
   * Définition du mode de formation des groupes
   */
  @Put(':id/formation-mode')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Définir le mode de formation des groupes' })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiBody({ type: SetFormationModeDtoValidation })
  @ApiResponse({
    status: 200,
    description: 'Mode de formation défini avec succès',
  })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  setFormationMode(
    @Param('id') projectId: string,
    @Body() dto: SetFormationModeDtoValidation,
    @Request() req: AuthenticatedRequest,
  ) {
    return this.projectService.setFormationMode(
      projectId,
      req.user.id,
      dto.mode,
    );
  }

  /**
   * Création manuelle d'un groupe (mode MANUAL)
   */
  @Post(':id/groups')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Créer un groupe manuellement (mode MANUAL)' })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiBody({ type: CreateGroupDtoValidation })
  @ApiResponse({ status: 201, description: 'Groupe créé avec succès' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  createGroup(@Param('id') id: string, @Body() dto: CreateGroupDtoValidation) {
    return this.projectService.createGroup(id, dto);
  }

  /**
   * Récupération des groupes d'un projet
   */
  @Get(':id/groups')
  @ApiOperation({ summary: "Récupérer les groupes d'un projet" })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiResponse({ status: 200, description: 'Liste des groupes du projet' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  getProjectGroups(@Param('id') id: string) {
    return this.projectService.getGroups(id);
  }

  /**
   * Récupération des projets pour un étudiant
   */
  @Get('student/:userId')
  @ApiOperation({ summary: "Récupérer les projets d'un étudiant" })
  @ApiParam({ name: 'userId', description: "ID de l'utilisateur étudiant" })
  @ApiResponse({
    status: 200,
    description: "Liste des projets de l'\u00e9tudiant",
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Étudiant non trouvé' })
  findByStudent(@Param('userId') userId: string) {
    return this.projectService.findByStudent(userId);
  }

  /**
   * Supprimer un projet
   */
  @Delete(':projectId')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Supprimer un projet' })
  @ApiParam({ name: ':projectId', description: 'ID du projet à supprimer' })
  @ApiResponse({ status: 200, description: 'Projet supprimé avec succès' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  deleteProject(
    @Param('projectId') id: string,
    @Request() req: AuthenticatedRequest,
  ) {
    return this.projectService.deleteProject(id, req.user.id);
  }

  /**
   * Mettre à jour un projet
   */
  @Put(':projectId')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Mettre à jour un projet' })
  @ApiBody({ type: CreateProjectDtoValidation })
  @ApiResponse({ status: 200, description: 'Projet mis à jour avec succès' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  updateProject(
    @Param('projectId') projectId: string,
    @Body() dto: Partial<CreateProjectDtoValidation>,
    @Request() req: AuthenticatedRequest,
  ) {
    dto.teacherId = req.user.id;
    return this.projectService.updateProject(projectId, dto);
  }

  /**
   * Récupération des grilles d'évaluation d'un projet
   */
  @Get(':id/evaluation-grids')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: "Récupérer les grilles d'évaluation d'un projet" })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiResponse({
    status: 200,
    description: "Liste des grilles d'évaluation du projet",
    type: [EvaluationGridResponseDto],
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  getProjectEvaluationGrids(
    @Param('id') projectId: string,
    @Request() req: AuthenticatedRequest,
  ): Promise<EvaluationGridResponseDto[]> {
    return this.evaluationGridService.getProjectGrids(projectId, req.user.id);
  }

  /**
   * Création d'une grille d'évaluation pour un projet
   */
  @Post(':id/evaluation-grids')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: "Créer une grille d'évaluation pour un projet" })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiBody({ type: CreateEvaluationGridDto })
  @ApiResponse({
    status: 201,
    description: "Grille d'évaluation créée avec succès",
    type: EvaluationGridResponseDto,
  })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  createProjectEvaluationGrid(
    @Param('id') projectId: string,
    @Body() dto: CreateEvaluationGridDto,
    @Request() req: AuthenticatedRequest,
  ): Promise<EvaluationGridResponseDto> {
    return this.evaluationGridService.createProjectGrid(
      projectId,
      dto,
      req.user.id,
    );
  }

  /**
   * Résumé des évaluations d'un projet
   */
  @Get(':id/evaluation-summary')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: "Récupérer le résumé des évaluations d'un projet" })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiResponse({
    status: 200,
    description: 'Résumé des évaluations du projet',
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  getProjectEvaluationSummary(
    @Param('id') projectId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    return this.projectService.getEvaluationSummary(projectId, req.user.id);
  }
}
