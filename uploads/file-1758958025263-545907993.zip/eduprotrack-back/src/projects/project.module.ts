import { Module } from '@nestjs/common';
import { ProjectController } from './project.controller';
import { ProjectService } from './project.service';
import { PrismaService } from '../prisma/prisma.service';
import { EmailService } from '../notifications/email.service';
import { TemplateService } from '../notifications/template.service';
import { EvaluationGridService } from '../grading/services/evaluation-grid.service';
import { GroupManagementService } from '../groups/group-management.service';

@Module({
  controllers: [ProjectController],
  providers: [
    ProjectService,
    PrismaService,
    EmailService,
    TemplateService,
    EvaluationGridService,
    GroupManagementService,
  ],
  exports: [ProjectService],
})
export class ProjectModule {}
