import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import type { CreateGroupDto } from './dto/create-group.dto';
import type { CreateProjectDto } from './dto/create-project.dto';
import { GroupFormationMode, ProjectStatus } from '@prisma/client';
import { EmailService } from '../notifications/email.service';
import {
  ProjectTemplate,
  TemplateService,
} from '../notifications/template.service';
import type { Prisma } from '@prisma/client';
import { GroupManagementService } from '../groups/group-management.service';

@Injectable()
export class ProjectService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly emailService: EmailService,
    private readonly templateService: TemplateService,
    private readonly groupManagementService: GroupManagementService,
  ) {}

  async create(dto: CreateProjectDto) {
    // Filtrer les valeurs undefined pour Prisma
    const teacherId = dto.teacherId;
    if (!teacherId) {
      throw new BadRequestException("L'enseignant est requis");
    }

    // Validation : l'enseignant doit appartenir à la promotion
    const teacherPromotion = await this.prisma.teacherPromotion.findFirst({
      where: {
        promotionId: dto.promotionId,
        userId: teacherId,
      },
    });

    if (!teacherPromotion) {
      throw new BadRequestException(
        "L'enseignant n'appartient pas à cette promotion",
      );
    }

    // Validation : nom unique par enseignant
    const existingProject = await this.prisma.project.findFirst({
      where: {
        name: dto.title,
        userId: teacherId,
      },
    });

    if (existingProject) {
      throw new BadRequestException(
        'Un projet avec ce nom existe déjà pour cet enseignant',
      );
    }

    // Valeurs par défaut pour les tailles de groupes
    const minGroupSize = dto.minGroupSize ?? 1;
    const maxGroupSize = dto.maxGroupSize ?? 6;

    // Validation : tailles de groupes cohérentes
    if (minGroupSize > maxGroupSize) {
      throw new BadRequestException(
        'La taille minimale ne peut pas être supérieure à la taille maximale',
      );
    }

    // ✅ Préparer les données avec le bon type Prisma
    const createData: Prisma.ProjectCreateInput = {
      name: dto.title,
      description: dto.description ?? null,
      promotion: {
        connect: { id: dto.promotionId },
      },
      teacher: {
        connect: { id: teacherId },
      },
      groupFormationMode: dto.groupMode ?? GroupFormationMode.MANUAL,
      minGroupSize: minGroupSize,
      maxGroupSize: maxGroupSize,
      status: dto.status ?? ProjectStatus.DRAFT,
      groupDeadline: dto.groupCreationDeadline
        ? new Date(dto.groupCreationDeadline)
        : null,
    };

    return this.prisma.project.create({
      data: createData,
      include: {
        teacher: {
          select: { id: true, firstname: true, lastname: true, email: true },
        },
        promotion: {
          select: { id: true, name: true },
        },
      },
    });
  }

  /**
   * Publication d'un projet (DRAFT → VISIBLE)
   * Déclenche la notification à tous les étudiants de la promotion
   */
  async publishProject(projectId: string, teacherId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        teacher: true,
        promotion: {
          include: {
            students: {
              include: {
                user: true,
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException(`Projet non trouvé`);
    }

    if (project.userId !== teacherId) {
      throw new ForbiddenException(
        'Vous ne pouvez modifier que vos propres projets',
      );
    }

    if (project.status === ProjectStatus.VISIBLE) {
      throw new BadRequestException('Le projet est déjà visible');
    }

    // Validation : données requises pour publication
    if (!project.promotionId) {
      throw new BadRequestException(
        'Une promotion doit être attachée avant publication',
      );
    }

    // Mise à jour du statut
    const updatedProject = await this.prisma.project.update({
      where: { id: projectId },
      data: { status: ProjectStatus.VISIBLE },
      include: {
        teacher: true,
        promotion: true,
      },
    });

    // Notification aux étudiants de la promotion
    const students = project.promotion.students.map((sp) => sp.user);
    await this.notifyProjectVisible(updatedProject, students);

    // Céer les groupes vides
    if (project.groupFormationMode !== GroupFormationMode.RANDOM) {
      await this.createEmptyGroupsForFreeMode(projectId);
    } else {
      await this.groupManagementService.performRandomAssignment(projectId);
    }

    return updatedProject;
  }

  /**
   * Mise à jour de la configuration des groupes
   */
  async updateGroupConfig(
    projectId: string,
    teacherId: string,
    config: {
      minGroupSize?: number;
      maxGroupSize?: number;
      groupDeadline?: string;
    },
  ) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new NotFoundException(`Projet non trouvé`);
    }

    if (project.userId !== teacherId) {
      throw new ForbiddenException(
        'Vous ne pouvez modifier que vos propres projets',
      );
    }

    // Validations
    const minSize = config.minGroupSize ?? project.minGroupSize;
    const maxSize = config.maxGroupSize ?? project.maxGroupSize;

    if (minSize > maxSize) {
      throw new BadRequestException(
        'La taille minimale ne peut pas être supérieure à la taille maximale',
      );
    }

    // ✅ Préparer les données avec le bon type Prisma
    const updateData: Prisma.ProjectUpdateInput = {};

    if (config.minGroupSize !== undefined) {
      updateData.minGroupSize = config.minGroupSize;
    }
    if (config.maxGroupSize !== undefined) {
      updateData.maxGroupSize = config.maxGroupSize;
    }
    if (config.groupDeadline !== undefined) {
      updateData.groupDeadline = new Date(config.groupDeadline);
    }

    return this.prisma.project.update({
      where: { id: projectId },
      data: updateData,
    });
  }

  /**
   * Changement du mode de formation des groupes
   */
  async setFormationMode(
    projectId: string,
    teacherId: string,
    mode: GroupFormationMode,
  ) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: { groups: true },
    });

    if (!project) {
      throw new NotFoundException(`Projet non trouvé`);
    }

    if (project.userId !== teacherId) {
      throw new ForbiddenException(
        'Vous ne pouvez modifier que vos propres projets',
      );
    }

    const updatedProject = await this.prisma.project.update({
      where: { id: projectId },
      data: { groupFormationMode: mode },
    });

    // Actions spécifiques selon le mode
    switch (mode) {
      case GroupFormationMode.FREE:
        if (project.status === ProjectStatus.VISIBLE) {
          await this.createEmptyGroupsForFreeMode(projectId);
        }
        break;
      case GroupFormationMode.RANDOM:
        if (project.status === ProjectStatus.VISIBLE) {
          // Import du service ici pour éviter la dépendance circulaire
          const { GroupManagementService } = await import(
            '../groups/group-management.service'
          );
          const groupManagementService = new GroupManagementService(
            this.prisma,
            this.emailService,
            this.templateService,
          );
          await groupManagementService.performRandomAssignment(projectId);
        }
        break;
    }

    return updatedProject;
  }

  /**
   * Création des groupes vides pour le mode FREE
   */
  async createEmptyGroupsForFreeMode(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        promotion: {
          include: {
            students: true,
          },
        },
        groups: true,
      },
    });

    if (!project) {
      throw new NotFoundException(`Projet non trouvé`);
    }

    const nbStudents = project.promotion.students.length;
    const nbGroupsNeeded = Math.ceil(nbStudents / project.minGroupSize);

    console.log(`🧮 Calcul groupes vides:`);
    console.log(`   👥 Étudiants: ${nbStudents}`);
    console.log(`   📏 Taille min: ${project.minGroupSize}`);
    console.log(
      `   📊 Groupes nécessaires: ceil(${nbStudents}/${project.minGroupSize}) = ${nbGroupsNeeded}`,
    );
    console.log(`   📋 Groupes existants: ${project.groups.length}`);

    // Supprimer seulement les groupes vides existants pour ce projet
    const deletedGroups = await this.prisma.group.deleteMany({
      where: {
        projectId,
        members: { none: {} }, // Groupes sans membres
      },
    });

    console.log(`🗑️ Groupes vides supprimés: ${deletedGroups.count}`);

    // Créer les nouveaux groupes vides
    const groupsData = Array.from({ length: nbGroupsNeeded }, (_, i) => ({
      name: `Groupe ${i + 1}`,
      projectId,
    }));

    const result = await this.prisma.group.createMany({
      data: groupsData,
    });

    console.log(
      `✅ ${result.count} groupes vides créés pour projet ${project.name}`,
    );

    return {
      created: result.count,
      expected: nbGroupsNeeded,
      algorithm: `ceil(${nbStudents}/${project.minGroupSize}) = ${nbGroupsNeeded}`,
    };
  }

  /**
   * Notification projet visible
   */
  private async notifyProjectVisible(
    project: { name: string; description?: string | null },
    students: Array<{ email: string; firstname: string; lastname: string }>,
  ) {
    const template = this.templateService.getProjectVisibleTemplate(
      project as ProjectTemplate,
    );

    for (const student of students) {
      if (student.email) {
        await this.emailService.sendEmail(
          student.email,
          template.subject,
          template.html,
        );
      }
    }
  }

  async findAll() {
    return await this.prisma.project.findMany({
      include: {
        teacher: {
          select: { id: true, firstname: true, lastname: true, email: true },
        },
        promotion: {
          select: { id: true, name: true },
        },
        groups: {
          include: {
            members: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                    email: true,
                  },
                },
              },
            },
          },
        },
      },
    });
  }

  async findById(id: string) {
    const project = await this.prisma.project.findUnique({
      where: { id },
      include: {
        teacher: {
          select: { id: true, firstname: true, lastname: true, email: true },
        },
        promotion: {
          select: { id: true, name: true },
        },
        groups: {
          include: {
            members: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                    email: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException(`Project with id ${id} not found`);
    }

    return project;
  }

  /**
   * Récupère un projet par ID avec vérifications d'accès étudiant
   * Vérifie que l'étudiant appartient à la promotion du projet
   * et que le projet est visible (statut VISIBLE)
   */
  async findByIdForStudent(projectId: string, studentId: string) {
    console.log(`[DEBUG] findByIdForStudent - studentId: ${studentId}, projectId: ${projectId}`);
    
    // Vérifier que l'étudiant appartient à une promotion
    const studentPromotion = await this.prisma.studentPromotion.findFirst({
      where: { userId: studentId },
      include: { promotion: true },
    });

    if (!studentPromotion) {
      console.log(`[DEBUG] Aucune promotion trouvée pour l'étudiant ${studentId}`);
      throw new NotFoundException(
        `Vous devez être assigné à une promotion pour accéder aux projets`,
      );
    }
    
    console.log(`[DEBUG] Étudiant dans la promotion: ${studentPromotion.promotion.name} (${studentPromotion.promotionId})`);

    // Récupérer le projet avec toutes les informations nécessaires
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        teacher: {
          select: { id: true, firstname: true, lastname: true, email: true },
        },
        promotion: {
          select: { id: true, name: true },
        },
        groups: {
          include: {
            members: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                    email: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    // IMPORTANT: Si le projet n'existe pas, retourner 404
    if (!project) {
      console.log(`[DEBUG] Projet non trouvé: ${projectId}`);
      throw new NotFoundException(`Le projet demandé n'existe pas`);
    }
    
    console.log(`[DEBUG] Projet trouvé: ${project.name}, statut: ${project.status}, promotion: ${project.promotion.name} (${project.promotionId})`);

    // Vérifier que l'étudiant appartient à la promotion du projet
    if (project.promotionId !== studentPromotion.promotionId) {
      console.log(`[DEBUG] Promotion différente - Étudiant: ${studentPromotion.promotionId}, Projet: ${project.promotionId}`);
      throw new ForbiddenException(
        "Vous n'avez pas accès à ce projet car il n'appartient pas à votre promotion",
      );
    }

    // Vérifier que le projet est visible pour les étudiants
    if (project.status !== ProjectStatus.VISIBLE) {
      console.log(`[DEBUG] Projet non visible - statut: ${project.status}`);
      throw new ForbiddenException(
        'Ce projet n\'est pas encore visible pour les étudiants',
      );
    }

    console.log(`[DEBUG] Accès autorisé au projet ${project.name}`);
    return project;
  }

  async createGroup(projectId: string, dto: CreateGroupDto) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new NotFoundException(`Project with id ${projectId} not found`);
    }

    // Validation des contraintes de taille
    if (
      dto.members.length < project.minGroupSize ||
      dto.members.length > project.maxGroupSize
    ) {
      throw new BadRequestException(
        `Le groupe doit contenir entre ${project.minGroupSize} et ${project.maxGroupSize} membres`,
      );
    }

    // Vérifier qu'aucun membre n'est déjà dans un groupe pour ce projet
    const existingMemberships = await this.prisma.groupMember.findMany({
      where: {
        userId: { in: dto.members },
        group: { projectId },
      },
    });

    if (existingMemberships.length > 0) {
      throw new BadRequestException(
        'Certains étudiants sont déjà dans un groupe pour ce projet',
      );
    }

    // Générer un nom automatique pour le groupe
    const existingGroupsCount = await this.prisma.group.count({
      where: { projectId },
    });

    const groupName = `Groupe ${existingGroupsCount + 1}`;

    // Créer le groupe puis ajouter les membres
    const group = await this.prisma.group.create({
      data: {
        name: groupName,
        projectId: projectId,
      },
    });

    // Ajouter les membres au groupe
    if (dto.members && dto.members.length > 0) {
      await this.prisma.groupMember.createMany({
        data: dto.members.map((userId) => ({
          groupId: group.id,
          userId: userId,
        })),
      });
    }

    return this.prisma.group.findUnique({
      where: { id: group.id },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
      },
    });
  }

  async findByTeacher(teacherId: string) {
    return await this.prisma.project.findMany({
      where: {
        userId: teacherId,
      },
      include: {
        promotion: {
          select: { id: true, name: true },
        },
        groups: {
          include: {
            members: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                    email: true,
                  },
                },
              },
            },
          },
        },
      },
    });
  }

  async getGroupsByProjectId(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new NotFoundException(`Project with id ${projectId} not found`);
    }

    return this.prisma.group.findMany({
      where: { projectId },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
      },
    });
  }

  async updateProject(projectId: string, dto: Partial<CreateProjectDto>) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });
    if (!project) {
      throw new NotFoundException(`Project with id ${projectId} not found`);
    }
    if (dto.teacherId && project.userId !== dto.teacherId) {
      throw new ForbiddenException(
        'Vous ne pouvez modifier que vos propres projets',
      );
    }
    // Filtrer les valeurs undefined pour Prisma
    const updateData: Prisma.ProjectUpdateInput = {};
    if (dto.title !== undefined) {
      updateData.name = dto.title;
    }
    if (dto.description !== undefined) {
      updateData.description = dto.description;
    }
    if (dto.groupMode !== undefined) {
      updateData.groupFormationMode = dto.groupMode;
    }
    if (dto.groupCreationDeadline !== undefined) {
      updateData.groupDeadline = new Date(dto.groupCreationDeadline);
    }
    if (dto.status !== undefined) {
      updateData.status = dto.status;
    }
    if (dto.minGroupSize !== undefined) {
      updateData.minGroupSize = dto.minGroupSize;
    }
    if (dto.maxGroupSize !== undefined) {
      updateData.maxGroupSize = dto.maxGroupSize;
    }
    return this.prisma.project.update({
      where: { id: projectId },
      data: updateData,
    });
  }

  async findByStudent(userId: string) {
    // Récupération directe via Prisma sans appel HTTP
    const studentPromotion = await this.prisma.studentPromotion.findFirst({
      where: { userId },
      include: { promotion: true },
    });

    if (!studentPromotion) {
      throw new NotFoundException(
        `Aucune promotion trouvée pour l'utilisateur ${userId}`,
      );
    }

    // Retourner uniquement les projets VISIBLE pour les étudiants
    return this.prisma.project.findMany({
      where: {
        promotionId: studentPromotion.promotionId,
        status: ProjectStatus.VISIBLE, // Seulement les projets visibles
      },
      include: {
        teacher: {
          select: { id: true, firstname: true, lastname: true, email: true },
        },
        promotion: {
          select: { id: true, name: true },
        },
        groups: {
          include: {
            members: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                    email: true,
                  },
                },
              },
            },
          },
        },
      },
    });
  }

  async getGroups(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new NotFoundException(`Project with id ${projectId} not found`);
    }

    return this.prisma.group.findMany({
      where: { projectId },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
      },
    });
  }

  async deleteProject(projectId: string, teacherId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new NotFoundException(`Project with id ${projectId} not found`);
    }

    if (project.userId !== teacherId) {
      throw new ForbiddenException(
        'Vous ne pouvez modifier que vos propres projets',
      );
    }
    await this.prisma.group.deleteMany({
      where: { projectId },
    });

    return this.prisma.project.delete({
      where: { id: projectId },
    });
  }

  async getEvaluationSummary(projectId: string, teacherId: string) {
    // Verify teacher has access to project
    const project = await this.prisma.project.findFirst({
      where: {
        id: projectId,
        userId: teacherId,
      },
      include: {
        deliverables: {
          select: {
            id: true,
            name: true,
            type: true,
          },
        },
        report: {
          select: {
            id: true,
            title: true,
          },
        },
        defenseSessions: {
          select: {
            id: true,
            startTime: true,
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException('Project not found or access denied');
    }

    // Get evaluation grids for this project
    const evaluationGrids = await this.prisma.evaluationGrid.findMany({
      where: {
        projectId,
        isTemplate: false,
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
        _count: {
          select: {
            evaluations: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Calculate weight distribution
    const totalWeight = evaluationGrids.reduce(
      (sum, grid) => sum + grid.weight,
      0,
    );
    const hasCompleteWeights = Math.abs(totalWeight - 1) < 0.01; // Should sum to 1 (100%)

    // Group grids by type
    const gridsByType = {
      DELIVERABLE: evaluationGrids.filter(
        (grid) => grid.type === 'DELIVERABLE',
      ),
      REPORT: evaluationGrids.filter((grid) => grid.type === 'REPORT'),
      DEFENSE: evaluationGrids.filter((grid) => grid.type === 'DEFENSE'),
    };

    // Check configuration status
    const hasDeliverables = project.deliverables.length > 0;
    const hasReports = Boolean(project.report);
    const hasDefenses = project.defenseSessions.length > 0;

    const configurationStatus = {
      deliverables: {
        configured: hasDeliverables,
        count: project.deliverables.length,
        hasEvaluationGrids: gridsByType.DELIVERABLE.length > 0,
        evaluationGridCount: gridsByType.DELIVERABLE.length,
      },
      reports: {
        configured: hasReports,
        count: hasReports ? 1 : 0,
        hasEvaluationGrids: gridsByType.REPORT.length > 0,
        evaluationGridCount: gridsByType.REPORT.length,
      },
      defenses: {
        configured: hasDefenses,
        count: project.defenseSessions.length,
        hasEvaluationGrids: gridsByType.DEFENSE.length > 0,
        evaluationGridCount: gridsByType.DEFENSE.length,
      },
    };

    return {
      project: {
        id: project.id,
        name: project.name,
        description: project.description,
      },
      evaluationGrids: evaluationGrids.map((grid) => ({
        id: grid.id,
        name: grid.name,
        type: grid.type,
        weight: grid.weight,
        criteriaCount: grid.criteria.length,
        evaluationCount: grid._count.evaluations,
        criteriaWeightValid:
          Math.abs(
            grid.criteria.reduce(
              (sum, criterion) => sum + criterion.weight,
              0,
            ) - 100,
          ) < 0.01,
      })),
      weightDistribution: {
        total: totalWeight,
        isComplete: hasCompleteWeights,
        byType: {
          DELIVERABLE: gridsByType.DELIVERABLE.reduce(
            (sum, grid) => sum + grid.weight,
            0,
          ),
          REPORT: gridsByType.REPORT.reduce(
            (sum, grid) => sum + grid.weight,
            0,
          ),
          DEFENSE: gridsByType.DEFENSE.reduce(
            (sum, grid) => sum + grid.weight,
            0,
          ),
        },
      },
      configurationStatus,
      recommendations: this.generateEvaluationRecommendations(
        configurationStatus,
        hasCompleteWeights,
        gridsByType,
      ),
    };
  }

  private generateEvaluationRecommendations(
    configurationStatus: {
      deliverables: {
        configured: boolean;
        hasEvaluationGrids: boolean;
      };
      reports: {
        configured: boolean;
        hasEvaluationGrids: boolean;
      };
      defenses: {
        configured: boolean;
        hasEvaluationGrids: boolean;
      };
    },
    hasCompleteWeights: boolean,
    gridsByType: Record<string, Array<{ criteria: unknown[] }>>,
  ): string[] {
    const recommendations: string[] = [];

    // Check for missing evaluation grids
    if (
      configurationStatus.deliverables.configured &&
      !configurationStatus.deliverables.hasEvaluationGrids
    ) {
      recommendations.push(
        "Créer des grilles d'évaluation pour les livrables configurés",
      );
    }
    if (
      configurationStatus.reports.configured &&
      !configurationStatus.reports.hasEvaluationGrids
    ) {
      recommendations.push(
        "Créer des grilles d'évaluation pour les rapports configurés",
      );
    }
    if (
      configurationStatus.defenses.configured &&
      !configurationStatus.defenses.hasEvaluationGrids
    ) {
      recommendations.push(
        "Créer des grilles d'évaluation pour les soutenances configurées",
      );
    }

    // Check weight distribution
    if (!hasCompleteWeights) {
      recommendations.push('Ajuster les poids des grilles pour atteindre 100%');
    }

    // Check for empty grids
    const gridsWithoutCriteria = Object.values(gridsByType)
      .flat()
      .filter((grid) => grid.criteria.length === 0);

    if (gridsWithoutCriteria.length > 0) {
      recommendations.push('Ajouter des critères aux grilles vides');
    }

    if (recommendations.length === 0) {
      recommendations.push("Configuration d'évaluation complète");
    }

    return recommendations;
  }
}
