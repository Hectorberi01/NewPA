// 🎯 TYPES GLOBAUX EDUPROTRACK
// Interfaces TypeScript pour tous les modules

import type { Role } from '@prisma/client';

// =====================================================
// 🌐 COMMON RESPONSE TYPES
// =====================================================

export interface ApiResponse<T = unknown> {
  status: 'success' | 'fail' | 'error';
  code?: number;
  data?: T;
  message?: string;
  errors?: string[];
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

// =====================================================
// 📧 EMAIL & NOTIFICATION TYPES
// =====================================================

export interface EmailConfig {
  to: string | string[];
  subject: string;
  html: string;
  from?: string;
}

export interface NotificationTemplate {
  subject: string;
  content: string;
  variables: Record<string, unknown>;
}

export interface EmailServiceConfig {
  host: string;
  port: number;
  secure: boolean;
  auth: {
    user: string;
    pass: string;
  };
}

// =====================================================
// 👥 GROUP MANAGEMENT TYPES
// =====================================================

export interface GroupMember {
  id: string;
  userId: string;
  user: {
    id: string;
    email: string;
    firstname: string;
    lastname: string;
    role: Role;
  };
  joinedAt: Date;
}

export interface GroupWithMembers {
  id: string;
  name: string;
  description?: string;
  maxMembers: number;
  projectId: string;
  members: GroupMember[];
  createdAt: Date;
  updatedAt: Date;
}

export interface GroupAssignment {
  groupId: string;
  studentIds: string[];
}

export interface AutoAssignmentResult {
  assignedGroups: GroupAssignment[];
  unassignedStudents: string[];
  summary: {
    totalStudents: number;
    assignedStudents: number;
    unassignedStudents: number;
    groupsUsed: number;
  };
}

// =====================================================
// 📚 PROJECT MANAGEMENT TYPES
// =====================================================

export interface ProjectStudent {
  id: string;
  email: string;
  firstname: string;
  lastname: string;
}

export interface ProjectNotificationData {
  name: string;
  description: string;
  teacher: {
    firstname: string;
    lastname: string;
  };
  promotion: {
    name: string;
  };
  groupFormationMode: string;
  minGroupSize: number;
  maxGroupSize: number;
  groupDeadline?: Date;
}

// =====================================================
// 🎓 STUDENT IMPORT TYPES
// =====================================================

export interface StudentImportRow {
  firstname: string;
  lastname: string;
  email: string;
  avatar?: string;
}

export interface ImportValidationError {
  row: number;
  field: string;
  value: unknown;
  message: string;
}

export interface ProcessedImportResult {
  studentsCreated: number;
  studentsAddedToPromotion: number;
  studentsSkipped: number;
  errors: ImportValidationError[];
  newStudents: string[];
  existingStudents: string[];
  skippedStudents: string[];
  failedStudents: string[];
}

// =====================================================
// 🔒 REQUEST TYPES WITH USER
// =====================================================

export interface RequestWithAuthUser {
  user: {
    id: string;
    email: string;
    role: Role;
    firstname: string;
    lastname: string;
  };
}

// =====================================================
// 📊 UTILITY TYPES
// =====================================================

export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

export type OptionalFields<T, K extends keyof T> = Omit<T, K> &
  Partial<Pick<T, K>>;

// =====================================================
// 🛡️ ERROR HANDLING TYPES
// =====================================================

export interface DatabaseError {
  code: string;
  message: string;
  meta?: Record<string, unknown>;
}

export interface ValidationErrorDetail {
  field: string;
  value: unknown;
  constraints: Record<string, string>;
}

export interface CustomError extends Error {
  status?: number;
  code?: string;
  details?: unknown;
}

// =====================================================
// 📅 SCHEDULING TYPES
// =====================================================

export interface ScheduleConfig {
  timezone: string;
  dateFormat: string;
  timeFormat: string;
}

export interface TaskExecution {
  id: string;
  name: string;
  scheduledFor: Date;
  executedAt?: Date;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: unknown;
  error?: string;
}
