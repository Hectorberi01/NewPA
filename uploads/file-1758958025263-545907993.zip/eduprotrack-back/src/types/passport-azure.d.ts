// 🔧 DÉCLARATIONS DE TYPES MANQUANTES - EduProTrack

declare module 'passport-azure-ad-oauth2' {
  import { Strategy as PassportStrategy } from 'passport';

  export interface AzureStrategyOptions {
    clientID: string;
    clientSecret: string;
    callbackURL: string;
    tenant: string;
    resource: string;
  }

  export interface AzureProfile {
    id: string;
    displayName: string;
    name: {
      familyName: string;
      givenName: string;
    };
    emails: Array<{
      value: string;
    }>;
    provider: string;
    _raw: string;
    _json: Record<string, unknown>;
  }

  export type AzureVerifyCallback = (
    accessToken: string,
    refreshToken: string,
    params: { id_token: string },
    profile: AzureProfile,
    done: (error: unknown, user?: unknown) => void,
  ) => void;

  export class Strategy extends PassportStrategy {
    constructor(options: AzureStrategyOptions, verify: AzureVerifyCallback);
  }
}
