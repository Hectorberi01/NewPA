import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { UserModule } from './users/user.module';
import { AuthModule } from './auth/auth.module';
import { TeachersModule } from './teachers/teachers.module';
import { ConfigModule } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { PromotionModule } from './promotions/promotion.module';
import { StudentsModule } from './students/students.module';
import { ProjectModule } from './projects/project.module';
import { GroupsModule } from './groups/groups.module';
import { SchedulerModule } from './scheduler/scheduler.module';
import { DeliverableModule } from './deliverables/deliverable.module';
import { DeliveriesModule } from './deliveries/deliveries.module';
import { ReportsModule } from './reports/reports.module';
import { GradingModule } from './grading/grading.module';
import { DefensesModule } from './defenses/defenses.module';
import { PlagiarismModule } from './plagiarism/plagiarism.module';

@Module({
  controllers: [],
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    JwtModule.register({
      global: true,
      secret: process.env.JWT_SECRET,
      signOptions: { expiresIn: '24h' },
    }),
    PrismaModule,
    UserModule,
    AuthModule,
    PromotionModule,
    StudentsModule,
    TeachersModule,
    ProjectModule,
    GroupsModule,
    SchedulerModule,
    DeliveriesModule,
    DeliverableModule,
    ReportsModule,
    GradingModule,
    DefensesModule,
    PlagiarismModule,
  ],
})
export class AppModule {}
