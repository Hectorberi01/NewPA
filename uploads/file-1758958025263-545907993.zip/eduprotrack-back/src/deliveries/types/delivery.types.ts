/**
 * Types for deliveries module
 */

export interface BulkDownloadSubmissionDto {
  id: string;
  groupName: string;
  fileName: string | null;
  fileSize: number | null;
  gitUrl: string | null;
  submittedBy: string;
  submittedAt: Date;
  pathInArchive: string;
}

export interface DownloadCacheItem {
  archivePath: string;
  archiveName: string;
  totalSize: number;
  expiresAt: Date;
  includedSubmissions: BulkDownloadSubmissionDto[];
}
