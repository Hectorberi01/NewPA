import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsUrl,
  Matches,
} from 'class-validator';

/**
 * DTO pour la soumission d'un lien Git
 */
export class SubmitGitLinkDto {
  @IsString()
  @IsNotEmpty({ message: 'URL Git obligatoire' })
  @IsUrl(
    {
      protocols: ['http', 'https'],
      require_protocol: true,
    },
    { message: 'URL Git invalide, doit être une URL valide' },
  )
  @Matches(
    /^https?:\/\/(www\.)?github\.com\/[\w-]+\/[\w.-]+(\/?|\/(tree|blob)\/[\w.-]+\/?)$/,
    { message: 'URL Git invalide, doit être une URL GitHub valide' },
  )
  gitUrl: string;

  @IsString()
  @IsOptional()
  comment?: string;
}
