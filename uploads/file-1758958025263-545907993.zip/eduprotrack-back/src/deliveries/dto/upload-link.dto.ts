import { IsString, IsUrl, IsOptional } from 'class-validator';

export class UploadLinkDto {
  @IsString()
  @IsUrl(
    {},
    {
      message: 'Le lien doit être une URL valide',
    },
  )
  link: string;

  @IsOptional()
  @IsString()
  projectId?: string;

  @IsOptional()
  @IsString()
  description?: string;
}
