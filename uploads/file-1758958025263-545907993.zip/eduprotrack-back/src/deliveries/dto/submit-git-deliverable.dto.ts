import {
  IsString,
  IsOptional,
  IsUrl,
  IsUUID,
  IsNotEmpty,
  Matches,
} from 'class-validator';

/**
 * DTO pour la soumission d'un livrable de type Git
 */
export class SubmitGitDeliverableDto {
  @IsString()
  @IsNotEmpty({
    message: "L'URL du dépôt Git est obligatoire",
  })
  @IsUrl({
    protocols: ['http', 'https'],
    require_protocol: true,
  })
  @Matches(/^https?:\/\/(github\.com|gitlab\.com|bitbucket\.org)\/.*$/i, {
    message: 'Seuls les dépôts GitHub, GitLab et Bitbucket sont autorisés',
  })
  gitUrl: string;

  @IsString()
  @IsOptional()
  @IsUUID()
  groupId?: string;

  @IsString()
  @IsOptional()
  comment?: string;
}
