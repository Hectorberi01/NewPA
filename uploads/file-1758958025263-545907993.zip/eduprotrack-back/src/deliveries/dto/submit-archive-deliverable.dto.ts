import { IsString, IsOptional, IsUUID } from 'class-validator';

/**
 * DTO pour la soumission d'un livrable de type Archive
 * Le fichier est envoyé via multipart/form-data
 * et n'est donc pas inclus dans ce DTO
 */
export class SubmitArchiveDeliverableDto {
  @IsString()
  @IsOptional()
  @IsUUID()
  groupId?: string;

  @IsString()
  @IsOptional()
  comment?: string;
}
