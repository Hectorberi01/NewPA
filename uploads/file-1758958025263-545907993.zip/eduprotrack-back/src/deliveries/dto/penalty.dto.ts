import {
  IsNumber,
  IsString,
  IsNotEmpty,
  Min,
  Max,
  IsOptional,
} from 'class-validator';

/**
 * DTO pour l'ajustement d'un malus par un enseignant
 */
export class AdjustPenaltyDto {
  @IsNumber()
  @Min(0, { message: 'Le malus ne peut pas être négatif' })
  @Max(100, { message: 'Le malus ne peut pas dépasser 100 points' })
  newPenalty: number;

  @IsString()
  @IsNotEmpty({ message: "La raison de l'ajustement est obligatoire" })
  reason: string;

  @IsString()
  @IsOptional()
  additionalComments?: string;
}

/**
 * Historique d'ajustement des malus
 */
export class PenaltyAdjustmentHistoryDto {
  id: string;
  submissionId: string;
  teacherId: string;
  teacherName: string;
  originalPenalty: number;
  newPenalty: number;
  reason: string;
  additionalComments?: string;
  adjustedAt: Date;
}

/**
 * Synthèse des malus pour un livrable
 */
export class PenaltySummaryDto {
  deliverableId: string;
  deliverableName: string;
  totalSubmissions: number;
  lateSubmissions: number;
  averagePenalty: number;
  submissions: PenaltySubmissionDto[];
}

/**
 * Informations sur les soumissions avec malus
 */
export class PenaltySubmissionDto {
  submissionId: string;
  groupId: string;
  groupName: string;
  studentName: string;
  submissionDate: Date;
  isLate: boolean;
  lateDays: number;
  penalty: number;
  hasAdjustment: boolean;
  adjustmentHistory?: PenaltyAdjustmentHistoryDto[];
}
