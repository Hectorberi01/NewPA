import { DeliverableType } from '@prisma/client';

/**
 * DTO pour la réponse des soumissions
 */
export class SubmissionResponseDto {
  id: string;
  deliverableId: string;
  deliverableName: string;
  type: DeliverableType;
  studentId: string;
  studentName: string;
  groupId: string;
  groupName: string;
  submissionDate: Date;
  fileName?: string;
  fileSize?: number;
  gitUrl?: string;
  isLate: boolean;
  lateDays: number;
  penalty: number;
  status: 'PENDING' | 'VALIDATED' | 'REJECTED';
  validationResults?: {
    isValid: boolean;
    errors: string[];
    warnings: string[];
    details: {
      ruleType: string;
      ruleName: string;
      passed: boolean;
      message?: string;
    }[];
  };
  version: number;
  comment?: string;
}

/**
 * DTO pour la réponse des soumissions d'un groupe
 */
export class GroupSubmissionsResponseDto {
  groupId: string;
  groupName: string;
  deliverableId: string;
  deliverableName: string;
  hasSubmitted: boolean;
  lastSubmissionDate?: Date;
  lastSubmissionBy?: string;
  submissions: SubmissionResponseDto[];
}

/**
 * DTO pour la réponse de prévision de malus
 */
export class PenaltyPreviewDto {
  isLate: boolean;
  lateDays: number;
  penalty: number;
  isCapped: boolean;
  maxPenalty?: number;
  deadline: Date;
  currentTime: Date;
}
