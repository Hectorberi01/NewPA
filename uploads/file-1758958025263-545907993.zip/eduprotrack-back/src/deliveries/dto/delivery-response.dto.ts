import { DeliverableType, SubmissionStatus } from '@prisma/client';
import { ValidationResultDto } from '../../deliverables/dto/verification-rule.dto';

/**
 * DTO de réponse pour une soumission
 */
export class SubmissionResponseDto {
  id: string;
  deliverableId: string;
  groupId: string;
  studentId: string;
  status: SubmissionStatus;
  submittedAt: Date;
  fileUrl?: string;
  fileName?: string;
  fileSize?: number;
  gitUrl?: string;
  isLate: boolean;
  lateDays: number;
  malus: number;
  comment?: string;
  validationResults: ValidationResultDto;
  version?: number;
}

/**
 * DTO pour la réponse contenant l'historique des soumissions
 */
export class SubmissionHistoryResponseDto {
  deliverableId: string;
  deliverableName: string;
  deliverableType: DeliverableType;
  deadline: Date;
  allowLateSubmission: boolean;
  latePenalty?: number;
  maxLateDays?: number;
  submissions: SubmissionResponseDto[];
}

/**
 * DTO pour la réponse de statut de soumission d'un groupe
 */
export class GroupSubmissionStatusDto {
  groupId: string;
  groupName: string;
  hasSubmitted: boolean;
  lastSubmissionDate?: Date;
  lastSubmittedBy?: {
    id: string;
    firstName: string;
    lastName: string;
  };
  isLate: boolean;
  lateDays: number;
  malus: number;
  status: SubmissionStatus;
}

/**
 * DTO pour la réponse de tableau de bord des soumissions
 */
export class SubmissionDashboardDto {
  totalGroups: number;
  submittedGroups: number;
  pendingGroups: number;
  lateSubmissions: number;
  onTimeSubmissions: number;
  submissionRate: number; // pourcentage
  averageLateDays: number;
  groups: GroupSubmissionStatusDto[];
}
