import { IsString, IsOptional } from 'class-validator';

/**
 * DTO pour la soumission d'un fichier
 */
export class SubmitFileDto {
  // Le fichier est géré par Multer et n'a pas besoin d'être validé ici

  @IsString()
  @IsOptional()
  comment?: string;
}
