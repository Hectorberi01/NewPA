import {
  IsOptional,
  IsString,
  IsArray,
  IsBoolean,
  IsNumber,
  IsDateString,
  IsIn,
} from 'class-validator';
import { Transform } from 'class-transformer';
import { SubmissionStatus } from '@prisma/client';

export class SubmissionFiltersDto {
  @IsOptional()
  @IsIn(['NOT_SUBMITTED', 'SUBMITTED', 'VALIDATION_FAILED', 'GRADED'])
  status?: SubmissionStatus;

  @IsOptional()
  @IsBoolean()
  @Transform(({ value }) => (value as string) === 'true')
  isLate?: boolean;

  @IsOptional()
  @IsBoolean()
  @Transform(({ value }) => (value as string) === 'true')
  isValid?: boolean;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  groupIds?: string[];

  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @IsNumber()
  @Transform(({ value }) => parseInt(value as string, 10))
  minLateDays?: number;

  @IsOptional()
  @IsNumber()
  @Transform(({ value }) => parseInt(value as string, 10))
  maxLateDays?: number;

  @IsOptional()
  @IsDateString()
  submittedAfter?: Date;

  @IsOptional()
  @IsDateString()
  submittedBefore?: Date;

  @IsOptional()
  @IsNumber()
  @Transform(({ value }) => parseInt(value as string, 10))
  page?: number;

  @IsOptional()
  @IsNumber()
  @Transform(({ value }) => parseInt(value as string, 10))
  limit?: number;

  @IsOptional()
  @IsString()
  sortBy?: 'submittedAt' | 'groupName' | 'status' | 'isLate' | 'daysLate';

  @IsOptional()
  @IsIn(['asc', 'desc'])
  sortOrder?: 'asc' | 'desc';
}

export interface FilteredSubmissionDto {
  id: string;
  groupId: string;
  groupName: string;
  submittedBy: {
    id: string;
    firstName: string;
    lastName: string;
  };
  status: SubmissionStatus;
  submittedAt: Date;
  fileName: string | null;
  fileSize: number | null;
  gitUrl: string | null;
  isLate: boolean;
  lateDays: number;
  penaltyApplied: number;
  isValid: boolean;
  validationErrors: string[];
  version: number;
}

export interface FilteredSubmissionsSummaryDto {
  totalSubmissions: number;
  validSubmissions: number;
  invalidSubmissions: number;
  lateSubmissions: number;
  onTimeSubmissions: number;
  averageLateDays: number;
  totalPenaltyApplied: number;
  groupsWithSubmissions: number;
  groupsWithoutSubmissions: number;
}

export interface FilteredSubmissionsResponseDto {
  totalCount: number;
  totalPages: number;
  currentPage: number;
  limit: number;
  submissions: FilteredSubmissionDto[];
  summary: FilteredSubmissionsSummaryDto;
}

export class TeacherSearchDto {
  @IsString()
  query: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  searchFields?: ('groupName' | 'studentName' | 'fileName' | 'gitUrl')[];

  @IsOptional()
  @IsNumber()
  @Transform(({ value }) => parseInt(value as string, 10))
  limit?: number;
}

export interface SearchResultDto {
  id: string;
  type: 'group' | 'student' | 'submission';
  title: string;
  description: string;
  groupId: string;
  submissionId?: string;
  studentId?: string;
  relevanceScore: number;
  matchedFields: string[];
}

export interface SearchResultsDto {
  query: string;
  results: SearchResultDto[];
  totalCount: number;
  searchFields: string[];
}

export class BulkDownloadDto {
  @IsArray()
  @IsString({ each: true })
  submissionIds: string[];

  @IsOptional()
  @IsString()
  format?: 'zip' | 'tar';

  @IsOptional()
  @IsBoolean()
  includeMetadata?: boolean;

  @IsOptional()
  @IsString()
  archiveName?: string;
}

export interface BulkDownloadResponseDto {
  downloadUrl: string;
  archiveName: string;
  totalFiles: number;
  totalSize: number;
  expiresAt: Date;
  includedSubmissions: Array<{
    id: string;
    groupName: string;
    fileName: string | null;
    fileSize: number | null;
    gitUrl: string | null;
    submittedBy: string;
    submittedAt: Date;
    pathInArchive: string;
  }>;
}
