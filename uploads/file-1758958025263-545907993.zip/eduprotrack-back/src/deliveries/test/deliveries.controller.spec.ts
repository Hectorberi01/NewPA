import { Test, TestingModule } from '@nestjs/testing';
import { DeliveriesController } from '../deliveries.controller';
import { DeliveriesService } from '../deliveries.service';
import { LatePenaltyService } from '../services/late-penalty.service';
import { PrismaService } from '../../prisma/prisma.service';
import { JWTAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../../auth/guards/teacher.guard';
import { ValidatedUser, AuthenticatedRequest } from '../../auth/types/auth.types';
import { Role } from '@prisma/client';

const mockDeliveryService = {
  submitFile: jest.fn(),
  submitGitLink: jest.fn(),
  getSubmissionHistory: jest.fn(),
  getGroupSubmissionStatus: jest.fn(),
  getSubmissionDashboard: jest.fn(),
};

const mockLatePenaltyService = {
  previewPenalty: jest.fn(),
  adjustPenalty: jest.fn(),
  getPenaltySummary: jest.fn(),
};

const mockPrismaService = {
  deliverable: {
    findUnique: jest.fn(),
  },
};

describe('DeliveriesController', () => {
  let controller: DeliveriesController;
  let deliveryService: jest.Mocked<DeliveriesService>;
  let latePenaltyService: jest.Mocked<LatePenaltyService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DeliveriesController],
      providers: [
        {
          provide: DeliveriesService,
          useValue: mockDeliveryService,
        },
        {
          provide: LatePenaltyService,
          useValue: mockLatePenaltyService,
        },
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
      ],
    })
      .overrideGuard(JWTAuthGuard)
      .useValue({ canActivate: () => true })
      .overrideGuard(TeacherGuard)
      .useValue({ canActivate: () => true })
      .compile();

    controller = module.get<DeliveriesController>(DeliveriesController);
    deliveryService = module.get(DeliveriesService);
    latePenaltyService = module.get(LatePenaltyService);

    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('Penalty Management Endpoints', () => {
    describe('GET /deliverables/:deliverableId/penalty-preview', () => {
      it('should return penalty preview', async () => {
        // GIVEN
        const deliverableId = 'deliverable-id';
        const expectedPreview = {
          isLate: true,
          lateDays: 2,
          penalty: 4.0,
          isCapped: false,
          deadline: new Date('2024-03-15T23:59:00'),
          currentTime: new Date('2024-03-19T10:00:00'),
        };

        latePenaltyService.previewPenalty.mockResolvedValue(expectedPreview);

        // WHEN
        const result = await controller.previewPenalty(deliverableId);

        // THEN
        expect(result).toEqual(expectedPreview);
        expect(latePenaltyService.previewPenalty).toHaveBeenCalledWith(
          deliverableId,
        );
      });
    });

    describe('PUT /submissions/:submissionId/penalty', () => {
      it('should allow teacher to adjust penalty', async () => {
        // GIVEN
        const submissionId = 'submission-id';
        const teacherId = 'teacher-id';
        const user: ValidatedUser = {
          id: teacherId,
          role: Role.TEACHER,
          email: 'teacher@example.com',
          firstname: 'John',
          lastname: 'Teacher',
        };
        const adjustmentData = {
          newPenalty: 1.0,
          reason: 'Circonstances exceptionnelles',
        };
        const expectedResult = {
          id: submissionId,
          deliverableId: 'deliverable-id',
          groupId: 'group-id',
          submittedById: 'student-id',
          fileUrl: null,
          gitUrl: null,
          fileName: null,
          fileSize: null,
          status: 'SUBMITTED' as const,
          submittedAt: new Date(),
          isLate: false,
          daysLate: null,
          penaltyApplied: 1.0,
          isValid: true,
          validationErrors: [],
          similarityScore: null,
          suspiciousGroups: [],
          plagiarismChecked: false,
          createdAt: new Date(),
          updatedAt: new Date(),
        };

        latePenaltyService.adjustPenalty.mockResolvedValue(expectedResult);

        // WHEN
        const result = await controller.adjustPenalty(
          submissionId,
          { user } as AuthenticatedRequest,
          adjustmentData,
        );

        // THEN
        expect(result).toEqual(expectedResult);
        expect(latePenaltyService.adjustPenalty).toHaveBeenCalledWith(
          submissionId,
          teacherId,
          adjustmentData,
        );
      });
    });

    describe('GET /deliverables/:deliverableId/penalties', () => {
      it('should return penalty summary for teacher', async () => {
        // GIVEN
        const deliverableId = 'deliverable-id';
        const expectedSummary = {
          deliverableId,
          deliverableName: 'Test Deliverable',
          totalSubmissions: 10,
          lateSubmissions: 3,
          averagePenalty: 2.5,
          submissions: [],
        };

        latePenaltyService.getPenaltySummary.mockResolvedValue(expectedSummary);

        // WHEN
        const result = await controller.getPenaltySummary(deliverableId);

        // THEN
        expect(result).toEqual(expectedSummary);
        expect(latePenaltyService.getPenaltySummary).toHaveBeenCalledWith(
          deliverableId,
        );
      });
    });
  });

  describe('Validation Tests', () => {
    it('should require reason for penalty adjustment', async () => {
      // GIVEN
      const submissionId = 'submission-id';
      const user: ValidatedUser = {
        id: 'teacher-id',
        role: Role.TEACHER,
        email: 'teacher@example.com',
        firstname: 'John',
        lastname: 'Teacher',
      };
      const invalidAdjustment = {
        newPenalty: 0,
        // reason manquant
      };

      // WHEN & THEN
      // Note: Dans un vrai test d'intégration avec des pipes de validation,
      // ceci devrait lever une erreur 400
      // Ici on teste seulement que le service est appelé avec les bons paramètres
      latePenaltyService.adjustPenalty.mockRejectedValue(
        new Error("La raison de l'ajustement est obligatoire"),
      );

      await expect(
        controller.adjustPenalty(submissionId, { user } as AuthenticatedRequest, invalidAdjustment as any),
      ).rejects.toThrow("La raison de l'ajustement est obligatoire");
    });

    it('should validate penalty bounds', async () => {
      // GIVEN
      const submissionId = 'submission-id';
      const user: ValidatedUser = {
        id: 'teacher-id',
        role: Role.TEACHER,
        email: 'teacher@example.com',
        firstname: 'John',
        lastname: 'Teacher',
      };
      const invalidAdjustment = {
        newPenalty: -5, // Négatif non autorisé
        reason: 'Test',
      };

      // WHEN & THEN
      latePenaltyService.adjustPenalty.mockRejectedValue(
        new Error('Le malus ne peut pas être négatif'),
      );

      await expect(
        controller.adjustPenalty(submissionId, { user } as AuthenticatedRequest, invalidAdjustment),
      ).rejects.toThrow('Le malus ne peut pas être négatif');
    });
  });

  describe('Authorization Tests', () => {
    it('should require teacher role for penalty adjustment', () => {
      // GIVEN - Le TeacherGuard est mocké pour retourner true
      // Dans un vrai test, on vérifierait que le guard est bien appliqué

      // WHEN & THEN
      const metadata = Reflect.getMetadata(
        '__guards__',
        controller.adjustPenalty,
      );
      expect(metadata).toBeDefined();
      // En vrai test, on vérifierait que TeacherGuard est dans la liste
    });

    it('should require teacher role for penalty summary', () => {
      // GIVEN - Le TeacherGuard est mocké pour retourner true

      // WHEN & THEN
      const metadata = Reflect.getMetadata(
        '__guards__',
        controller.getPenaltySummary,
      );
      expect(metadata).toBeDefined();
    });

    it('should allow any authenticated user for penalty preview', () => {
      // GIVEN - Seul JWTAuthGuard requis pour la prévisualisation

      // WHEN & THEN
      const metadata = Reflect.getMetadata(
        '__guards__',
        controller.previewPenalty,
      );
      // La prévisualisation ne nécessite que l'authentification, pas le rôle enseignant
      // Absence de guards spécifiques signifie que seule l'auth de base est requise
      expect(metadata).toBeUndefined();
    });
  });
});
