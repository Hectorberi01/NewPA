import { Test, TestingModule } from '@nestjs/testing';
import { LatePenaltyService } from '../services/late-penalty.service';
import { BusinessDayService } from '../services/business-day.service';
import { PrismaService } from '../../prisma/prisma.service';

const mockPrismaService = {
  deliverable: {
    findUnique: jest.fn().mockResolvedValue(null),
  },
  deliverableSubmission: {
    findUnique: jest.fn().mockResolvedValue(null),
    findMany: jest.fn().mockResolvedValue([]),
    update: jest.fn().mockResolvedValue(null),
  },
  penaltyAdjustment: {
    create: jest.fn().mockResolvedValue(null),
  },
  user: {
    findUnique: jest.fn().mockResolvedValue(null),
  },
};

const mockBusinessDayService = {
  calculateBusinessDays: jest.fn(),
};

describe('LatePenaltyService', () => {
  let service: LatePenaltyService;
  let prismaService: any;
  let businessDayService: jest.Mocked<BusinessDayService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        LatePenaltyService,
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
        {
          provide: BusinessDayService,
          useValue: mockBusinessDayService,
        },
      ],
    }).compile();

    service = module.get<LatePenaltyService>(LatePenaltyService);
    prismaService = module.get(PrismaService);
    businessDayService = module.get(BusinessDayService);

    // Reset mocks
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('calculatePenalty', () => {
    it('should calculate penalty for 1 business day late', () => {
      // GIVEN
      const deadline = new Date('2024-03-15T23:59:00'); // Vendredi
      const submissionDate = new Date('2024-03-18T10:00:00'); // Lundi
      const penaltyPerDay = 2.5;

      businessDayService.calculateBusinessDays.mockReturnValue(1);

      // WHEN
      const penalty = service.calculatePenalty(
        deadline,
        submissionDate,
        penaltyPerDay,
      );

      // THEN
      expect(penalty.lateDays).toBe(1); // Weekend non compté
      expect(penalty.penalty).toBe(2.5);
      expect(penalty.isLate).toBe(true);
      expect(penalty.isCapped).toBe(false);
    });

    it('should not count weekends in penalty calculation', () => {
      // GIVEN
      const deadline = new Date('2024-03-15T23:59:00'); // Vendredi
      const submissionDate = new Date('2024-03-19T09:00:00'); // Mardi
      const penaltyPerDay = 1.0;

      businessDayService.calculateBusinessDays.mockReturnValue(2);

      // WHEN
      const penalty = service.calculatePenalty(
        deadline,
        submissionDate,
        penaltyPerDay,
      );

      // THEN
      expect(penalty.lateDays).toBe(2); // Lundi + Mardi
      expect(penalty.penalty).toBe(2.0);
    });

    it('should respect maximum penalty limit', () => {
      // GIVEN
      const deadline = new Date('2024-03-01T23:59:00');
      const submissionDate = new Date('2024-03-15T10:00:00'); // 10 jours ouvrés
      const penaltyPerDay = 3.0;
      const maxPenalty = 20.0;

      businessDayService.calculateBusinessDays.mockReturnValue(10);

      // WHEN
      const penalty = service.calculatePenalty(
        deadline,
        submissionDate,
        penaltyPerDay,
        maxPenalty,
      );

      // THEN
      expect(penalty.penalty).toBe(20.0); // Plafonné
      expect(penalty.isCapped).toBe(true);
    });

    it('should handle French holidays correctly', () => {
      // GIVEN - 1er mai (férié) entre deadline et soumission
      const deadline = new Date('2024-04-30T23:59:00'); // Mardi
      const submissionDate = new Date('2024-05-02T10:00:00'); // Jeudi
      const penaltyPerDay = 1.0;

      businessDayService.calculateBusinessDays.mockReturnValue(1); // Mercredi seulement

      // WHEN
      const penalty = service.calculatePenalty(
        deadline,
        submissionDate,
        penaltyPerDay,
      );

      // THEN
      expect(penalty.lateDays).toBe(1); // Mercredi seulement (1er mai férié)
    });

    it('should return zero penalty for on-time submission', () => {
      // GIVEN
      const deadline = new Date('2024-03-15T23:59:00');
      const submissionDate = new Date('2024-03-15T22:30:00');

      // WHEN
      const penalty = service.calculatePenalty(deadline, submissionDate, 2.0);

      // THEN
      expect(penalty.penalty).toBe(0);
      expect(penalty.isLate).toBe(false);
      expect(penalty.lateDays).toBe(0);
    });

    it('should throw error when max late days exceeded', () => {
      // GIVEN
      const deadline = new Date('2024-03-01T23:59:00');
      const submissionDate = new Date('2024-03-15T10:00:00');
      const penaltyPerDay = 1.0;
      const maxLateDays = 5;

      businessDayService.calculateBusinessDays.mockReturnValue(10); // Plus que le max

      // WHEN & THEN
      expect(() => {
        service.calculatePenalty(
          deadline,
          submissionDate,
          penaltyPerDay,
          undefined,
          maxLateDays,
        );
      }).toThrow(
        'La soumission dépasse le délai maximum autorisé de 5 jours ouvrés',
      );
    });
  });

  describe('previewPenalty', () => {
    it('should preview penalty for a deliverable', async () => {
      // GIVEN
      const deliverableId = 'deliverable-id';
      const deliverable = {
        id: deliverableId,
        allowLateSubmission: true,
        deadline: new Date('2024-03-15T23:59:00'),
        latePenalty: 2.0,
        maxPenalty: 10.0,
        maxLateDays: 5,
      };

      prismaService.deliverable.findUnique.mockResolvedValue(deliverable);
      businessDayService.calculateBusinessDays.mockReturnValue(2);

      // WHEN
      const preview = await service.previewPenalty(
        deliverableId,
        new Date('2024-03-19T10:00:00'),
      );

      // THEN
      expect(preview.isLate).toBe(true);
      expect(preview.lateDays).toBe(2);
      expect(preview.penalty).toBe(4.0);
    });

    it('should throw error for non-existent deliverable', async () => {
      // GIVEN
      prismaService.deliverable.findUnique.mockResolvedValue(null);

      // WHEN & THEN
      await expect(service.previewPenalty('non-existent')).rejects.toThrow(
        "Livrable avec l'ID non-existent non trouvé",
      );
    });

    it('should throw error when late submissions not allowed', async () => {
      // GIVEN
      const deliverable = {
        id: 'deliverable-id',
        allowLateSubmission: false,
        deadline: new Date('2024-03-15T23:59:00'),
      };

      prismaService.deliverable.findUnique.mockResolvedValue(deliverable);

      // WHEN & THEN
      await expect(
        service.previewPenalty(
          'deliverable-id',
          new Date('2024-03-19T10:00:00'),
        ),
      ).rejects.toThrow(
        'Les soumissions tardives ne sont pas autorisées pour ce livrable',
      );
    });
  });

  describe('adjustPenalty', () => {
    it('should allow teacher to cancel penalty', async () => {
      // GIVEN
      const submissionId = 'submission-id';
      const teacherId = 'teacher-id';
      const submission = {
        id: submissionId,
        penaltyApplied: 5.0,
        penaltyAdjustments: [],
        submittedBy: { id: 'student-id' },
      };
      const teacher = { id: teacherId, firstname: 'John', lastname: 'Doe' };
      const adjustment = { newPenalty: 0, reason: 'Problème technique' };

      prismaService.deliverableSubmission.findUnique.mockResolvedValue(
        submission,
      );
      prismaService.user.findUnique.mockResolvedValue(teacher);
      prismaService.penaltyAdjustment.create.mockResolvedValue({
        id: 'adjustment-id',
        submissionId,
        adjustedById: teacherId,
        originalPenalty: 5.0,
        newPenalty: 0,
        reason: 'Problème technique',
        adjustedAt: new Date(),
      });

      const updatedSubmission = {
        ...submission,
        penaltyApplied: 0,
        penaltyAdjustments: [],
        submittedBy: { id: 'student-id' },
        deliverable: { id: 'deliverable-id' },
      };
      prismaService.deliverableSubmission.update.mockResolvedValue(
        updatedSubmission,
      );

      // WHEN
      const result = await service.adjustPenalty(
        submissionId,
        teacherId,
        adjustment,
      );

      // THEN
      expect(result.penaltyApplied).toBe(0);
      expect(prismaService.penaltyAdjustment.create).toHaveBeenCalledWith({
        data: {
          submissionId,
          adjustedById: teacherId,
          originalPenalty: 5.0,
          newPenalty: 0,
          reason: 'Problème technique',
        },
      });
    });

    it('should throw error for non-existent submission', async () => {
      // GIVEN
      prismaService.deliverableSubmission.findUnique.mockResolvedValue(null);

      // WHEN & THEN
      await expect(
        service.adjustPenalty('non-existent', 'teacher-id', {
          newPenalty: 0,
          reason: 'Test',
        }),
      ).rejects.toThrow("Soumission avec l'ID non-existent non trouvée");
    });

    it('should throw error for non-existent teacher', async () => {
      // GIVEN
      const submission = { id: 'submission-id', penaltyApplied: 5.0 };
      prismaService.deliverableSubmission.findUnique.mockResolvedValue(
        submission,
      );
      prismaService.user.findUnique.mockResolvedValue(null);

      // WHEN & THEN
      await expect(
        service.adjustPenalty('submission-id', 'non-existent', {
          newPenalty: 0,
          reason: 'Test',
        }),
      ).rejects.toThrow("Enseignant avec l'ID non-existent non trouvé");
    });
  });

  describe('getPenaltySummary', () => {
    it('should return penalty summary for deliverable', async () => {
      // GIVEN
      const deliverableId = 'deliverable-id';
      const deliverable = { id: deliverableId, name: 'Test Deliverable' };
      const submissions = [
        {
          id: 'submission-1',
          groupId: 'group-1',
          isLate: true,
          daysLate: 2,
          penaltyApplied: 4.0,
          createdAt: new Date(),
          submittedBy: { firstname: 'John', lastname: 'Doe' },
          group: { name: 'Group 1' },
          penaltyAdjustments: [],
        },
        {
          id: 'submission-2',
          groupId: 'group-2',
          isLate: false,
          daysLate: 0,
          penaltyApplied: 0,
          createdAt: new Date(),
          submittedBy: { firstname: 'Jane', lastname: 'Smith' },
          group: { name: 'Group 2' },
          penaltyAdjustments: [],
        },
      ];

      prismaService.deliverable.findUnique.mockResolvedValue(deliverable);
      prismaService.deliverableSubmission.findMany.mockResolvedValue(
        submissions,
      );

      // WHEN
      const summary = await service.getPenaltySummary(deliverableId);

      // THEN
      expect(summary.deliverableId).toBe(deliverableId);
      expect(summary.deliverableName).toBe('Test Deliverable');
      expect(summary.totalSubmissions).toBe(2);
      expect(summary.lateSubmissions).toBe(1);
      expect(summary.averagePenalty).toBe(4.0);
      expect(summary.submissions).toHaveLength(2);
    });
  });
});
