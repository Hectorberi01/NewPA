import { Test, TestingModule } from '@nestjs/testing';
import { BusinessDayService } from '../services/business-day.service';

describe('BusinessDayService', () => {
  let service: BusinessDayService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [BusinessDayService],
    }).compile();

    service = module.get<BusinessDayService>(BusinessDayService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('calculateBusinessDays', () => {
    it('should calculate business days correctly', () => {
      // GIVEN - Deadline vendredi soir, soumission mardi matin
      const deadline = new Date('2024-03-15'); // Vendredi
      const submission = new Date('2024-03-19'); // Mardi

      // WHEN
      const days = service.calculateBusinessDays(deadline, submission);

      // THEN - Lundi (18) est le seul jour ouvré entre vendredi et mardi
      expect(days).toBe(1); // Lundi seulement
    });

    it('should exclude French holidays', () => {
      // GIVEN - Du mardi 30 avril au vendredi 3 mai (1er mai férié = mercredi)
      const start = new Date('2024-04-30'); // Mardi
      const end = new Date('2024-05-03'); // Vendredi

      // WHEN
      const days = service.calculateBusinessDays(start, end);

      // THEN - Jeudi 2 mai seulement (mercredi 1er mai est férié)
      expect(days).toBe(1); // Jeudi seulement
    });

    it('should handle same-day correctly', () => {
      // GIVEN
      const date = new Date('2024-03-15T10:00:00');
      const sameDateLater = new Date('2024-03-15T15:00:00');

      // WHEN
      const days = service.calculateBusinessDays(date, sameDateLater);

      // THEN
      expect(days).toBe(0);
    });

    it('should return 0 for reversed dates', () => {
      // GIVEN
      const start = new Date('2024-03-19');
      const end = new Date('2024-03-15');

      // WHEN
      const days = service.calculateBusinessDays(start, end);

      // THEN
      expect(days).toBe(0);
    });

    it('should count business days over a longer period', () => {
      // GIVEN - Une semaine complète
      const start = new Date('2024-03-11'); // Lundi
      const end = new Date('2024-03-17'); // Dimanche

      // WHEN
      const days = service.calculateBusinessDays(start, end);

      // THEN - Mardi, Mercredi, Jeudi, Vendredi, Samedi (exclu weekend)
      expect(days).toBe(4); // Mardi à Vendredi
    });
  });

  describe('isFrenchHoliday', () => {
    it('should recognize fixed holidays', () => {
      expect(service.isFrenchHoliday(new Date('2024-01-01'))).toBe(true); // Nouvel An
      expect(service.isFrenchHoliday(new Date('2024-05-01'))).toBe(true); // Fête du Travail
      expect(service.isFrenchHoliday(new Date('2024-07-14'))).toBe(true); // Fête Nationale
      expect(service.isFrenchHoliday(new Date('2024-12-25'))).toBe(true); // Noël
    });

    it('should recognize variable holidays', () => {
      expect(service.isFrenchHoliday(new Date('2024-04-01'))).toBe(true); // Lundi de Pâques 2024
      expect(service.isFrenchHoliday(new Date('2024-05-09'))).toBe(true); // Ascension 2024
      expect(service.isFrenchHoliday(new Date('2024-05-20'))).toBe(true); // Lundi de Pentecôte 2024
    });

    it('should return false for regular days', () => {
      expect(service.isFrenchHoliday(new Date('2024-03-15'))).toBe(false);
    });

    it('should handle years not in the pre-calculated list', () => {
      // GIVEN - Une année non pré-calculée
      const futureDate = new Date('2030-01-02'); // Non férié

      // WHEN & THEN
      expect(service.isFrenchHoliday(futureDate)).toBe(false);
    });
  });

  describe('isBusinessDay', () => {
    it('should return true for weekdays that are not holidays', () => {
      // GIVEN - Un mardi normal
      const tuesday = new Date('2024-03-12');

      // WHEN & THEN
      expect(service.isBusinessDay(tuesday)).toBe(true);
    });

    it('should return false for weekends', () => {
      // GIVEN
      const saturday = new Date('2024-03-16');
      const sunday = new Date('2024-03-17');

      // WHEN & THEN
      expect(service.isBusinessDay(saturday)).toBe(false);
      expect(service.isBusinessDay(sunday)).toBe(false);
    });

    it('should return false for holidays even on weekdays', () => {
      // GIVEN - 1er mai 2024 (mercredi)
      const laborDay = new Date('2024-05-01');

      // WHEN & THEN
      expect(service.isBusinessDay(laborDay)).toBe(false);
    });
  });
});
