import { Test, TestingModule } from '@nestjs/testing';
import { DeliveriesService } from '../deliveries.service';
import { PrismaService } from '../../prisma/prisma.service';
import { ValidationService } from '../services/validation.service';
import { EmailService } from '../../notifications/email.service';
import { LatePenaltyService } from '../services/late-penalty.service';
import { DeliverableType, SubmissionStatus } from '@prisma/client';
import { SubmitFileDto } from '../dto/submit-file.dto';
import { SubmitGitLinkDto } from '../dto/submit-git-link.dto';
import { ForbiddenException, NotFoundException } from '@nestjs/common';

describe('DeliveryService', () => {
  let service: DeliveriesService;
  let prismaService: PrismaService;
  let validationService: ValidationService;
  let storageService: any;
  let emailService: EmailService;
  let latePenaltyService: LatePenaltyService;

  const mockStorageService = {
    save: jest.fn().mockResolvedValue('path/to/file'),
    saveLink: jest.fn().mockResolvedValue('link-id'),
    checkZipBomb: jest.fn().mockResolvedValue(false),
    scanWithClamAV: jest.fn().mockResolvedValue(true),
  };

  const mockEmailService = {
    sendEmail: jest.fn().mockResolvedValue(true),
  };

  const mockLatePenaltyService = {
    calculatePenalty: jest.fn().mockReturnValue({
      isLate: false,
      lateDays: 0,
      penalty: 0,
    }),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DeliveriesService,
        {
          provide: PrismaService,
          useValue: {
            deliverable: {
              findUnique: jest.fn(),
            },
            deliverableSubmission: {
              create: jest.fn(),
              count: jest.fn(),
              findMany: jest.fn(),
              findFirst: jest.fn(),
            },
            groupMember: {
              findFirst: jest.fn(),
              findMany: jest.fn(),
            },
            group: {
              findUnique: jest.fn(),
            },
            user: {
              findUnique: jest.fn(),
            },
          },
        },
        {
          provide: ValidationService,
          useValue: {
            validateFileSubmission: jest.fn(),
            validateGitSubmission: jest.fn(),
          },
        },
        {
          provide: 'STORAGE_SERVICE',
          useValue: mockStorageService,
        },
        {
          provide: EmailService,
          useValue: mockEmailService,
        },
        {
          provide: LatePenaltyService,
          useValue: mockLatePenaltyService,
        },
      ],
    }).compile();

    service = module.get<DeliveriesService>(DeliveriesService);
    prismaService = module.get<PrismaService>(PrismaService);
    validationService = module.get<ValidationService>(ValidationService);
    storageService = module.get('STORAGE_SERVICE');
    emailService = module.get<EmailService>(EmailService);
    latePenaltyService = module.get<LatePenaltyService>(LatePenaltyService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('submitFile', () => {
    it('should successfully submit a file', async () => {
      // Mock data
      const deliverableId = 'deliverable-id';
      const groupId = 'group-id';
      const studentId = 'student-id';
      const file = {
        originalname: 'test.zip',
        size: 1024,
        buffer: Buffer.from('test'),
      } as Express.Multer.File;
      const submitFileDto: SubmitFileDto = { comment: 'Test comment' };

      // Mock service responses
      jest.spyOn(service as any, 'isStudentInGroup').mockResolvedValue(true);
      jest
        .spyOn(service as any, 'checkLateSubmissionAllowed')
        .mockResolvedValue(true);
      jest.spyOn(prismaService.deliverable, 'findUnique').mockResolvedValue({
        id: deliverableId,
        type: DeliverableType.ARCHIVE,
        deadline: new Date(Date.now() + 86400000), // Tomorrow
        allowLateSubmission: true,
        latePenalty: 2,
        maxLateDays: 5,
        name: 'Test Deliverable',
      } as any);

      jest
        .spyOn(validationService, 'validateFileSubmission')
        .mockResolvedValue({
          isValid: true,
          errors: [],
          warnings: [],
          details: [],
        });

      jest
        .spyOn(prismaService.deliverableSubmission, 'count')
        .mockResolvedValue(0);

      jest
        .spyOn(prismaService.deliverableSubmission, 'create')
        .mockResolvedValue({
          id: 'submission-id',
          deliverableId,
          groupId,
          studentId,
          fileName: file.originalname,
          fileSize: file.size,
          filePath: 'path/to/file',
          status: SubmissionStatus.SUBMITTED,
          isLate: false,
          lateDays: 0,
          malus: 0,
          comment: submitFileDto.comment,
          validationResults: { isValid: true },
          version: 1,
          createdAt: new Date(),
        } as any);

      jest
        .spyOn(service as any, 'notifyGroupMembers')
        .mockResolvedValue(undefined);

      // Execute
      const result = await service.submitFile(
        deliverableId,
        groupId,
        studentId,
        file,
        submitFileDto,
      );

      // Assert
      expect(result).toBeDefined();
      expect(result.status).toBe(SubmissionStatus.SUBMITTED);
      expect(result.isLate).toBe(false);
      expect(result.fileName).toBe(file.originalname);
      expect(storageService.save).toHaveBeenCalledWith(file, studentId);
      expect(prismaService.deliverableSubmission.create).toHaveBeenCalled();
    });

    it('should throw error if student is not in group', async () => {
      // Mock data
      const deliverableId = 'deliverable-id';
      const groupId = 'group-id';
      const studentId = 'student-id';
      const file = {} as Express.Multer.File;
      const submitFileDto = {} as SubmitFileDto;

      // Mock service response
      jest.spyOn(service as any, 'isStudentInGroup').mockResolvedValue(false);

      // Execute & Assert
      await expect(
        service.submitFile(
          deliverableId,
          groupId,
          studentId,
          file,
          submitFileDto,
        ),
      ).rejects.toThrow(ForbiddenException);
    });

    it('should throw error if late submission is not allowed', async () => {
      // Mock data
      const deliverableId = 'deliverable-id';
      const groupId = 'group-id';
      const studentId = 'student-id';
      const file = {} as Express.Multer.File;
      const submitFileDto = {} as SubmitFileDto;

      // Mock service responses
      jest.spyOn(service as any, 'isStudentInGroup').mockResolvedValue(true);
      jest
        .spyOn(service as any, 'checkLateSubmissionAllowed')
        .mockResolvedValue(false);

      // Execute & Assert
      await expect(
        service.submitFile(
          deliverableId,
          groupId,
          studentId,
          file,
          submitFileDto,
        ),
      ).rejects.toThrow(ForbiddenException);
    });
  });

  describe('submitGitLink', () => {
    it('should successfully submit a git link', async () => {
      // Mock data
      const deliverableId = 'deliverable-id';
      const groupId = 'group-id';
      const studentId = 'student-id';
      const submitGitLinkDto: SubmitGitLinkDto = {
        gitUrl: 'https://github.com/user/repo',
        comment: 'Test comment',
      };

      // Mock service responses
      jest.spyOn(service as any, 'isStudentInGroup').mockResolvedValue(true);
      jest
        .spyOn(service as any, 'checkLateSubmissionAllowed')
        .mockResolvedValue(true);
      jest.spyOn(prismaService.deliverable, 'findUnique').mockResolvedValue({
        id: deliverableId,
        type: DeliverableType.GIT_LINK,
        deadline: new Date(Date.now() + 86400000), // Tomorrow
        allowLateSubmission: true,
        latePenalty: 2,
        maxLateDays: 5,
        name: 'Test Deliverable',
      } as any);

      jest.spyOn(validationService, 'validateGitSubmission').mockResolvedValue({
        isValid: true,
        errors: [],
        warnings: [],
        details: [],
      });

      jest
        .spyOn(prismaService.deliverableSubmission, 'count')
        .mockResolvedValue(0);

      jest
        .spyOn(prismaService.deliverableSubmission, 'create')
        .mockResolvedValue({
          id: 'submission-id',
          deliverableId,
          groupId,
          studentId,
          gitUrl: submitGitLinkDto.gitUrl,
          status: SubmissionStatus.SUBMITTED,
          isLate: false,
          lateDays: 0,
          malus: 0,
          comment: submitGitLinkDto.comment,
          validationResults: { isValid: true },
          version: 1,
          createdAt: new Date(),
        } as any);

      jest
        .spyOn(service as any, 'notifyGroupMembers')
        .mockResolvedValue(undefined);

      // Execute
      const result = await service.submitGitLink(
        deliverableId,
        groupId,
        studentId,
        submitGitLinkDto,
      );

      // Assert
      expect(result).toBeDefined();
      expect(result.status).toBe(SubmissionStatus.SUBMITTED);
      expect(result.isLate).toBe(false);
      expect(result.gitUrl).toBe(submitGitLinkDto.gitUrl);
      expect(storageService.saveLink).toHaveBeenCalledWith(
        submitGitLinkDto.gitUrl,
        studentId,
      );
      expect(prismaService.deliverableSubmission.create).toHaveBeenCalled();
    });
  });

  describe('getSubmissionHistory', () => {
    it('should return submission history for a group', async () => {
      // Mock data
      const deliverableId = 'deliverable-id';
      const groupId = 'group-id';

      // Mock service responses
      jest.spyOn(prismaService.deliverable, 'findUnique').mockResolvedValue({
        id: deliverableId,
        name: 'Test Deliverable',
        type: DeliverableType.ARCHIVE,
        deadline: new Date(),
        allowLateSubmission: true,
        latePenalty: 2,
        maxLateDays: 5,
      } as any);

      jest
        .spyOn(prismaService.deliverableSubmission, 'findMany')
        .mockResolvedValue([
          {
            id: 'submission-1',
            deliverableId,
            groupId,
            studentId: 'student-1',
            fileName: 'test1.zip',
            fileSize: 1024,
            filePath: 'path/to/file1',
            status: SubmissionStatus.SUBMITTED,
            isLate: false,
            lateDays: 0,
            malus: 0,
            comment: 'Comment 1',
            validationResults: { isValid: true },
            version: 1,
            createdAt: new Date(),
            student: {
              firstName: 'John',
              lastName: 'Doe',
            },
          },
          {
            id: 'submission-2',
            deliverableId,
            groupId,
            studentId: 'student-2',
            fileName: 'test2.zip',
            fileSize: 2048,
            filePath: 'path/to/file2',
            status: SubmissionStatus.SUBMITTED,
            isLate: true,
            lateDays: 1,
            malus: 2,
            comment: 'Comment 2',
            validationResults: { isValid: true },
            version: 2,
            createdAt: new Date(),
            student: {
              firstName: 'Jane',
              lastName: 'Smith',
            },
          },
        ] as any);

      // Execute
      const result = await service.getSubmissionHistory(deliverableId, groupId);

      // Assert
      expect(result).toBeDefined();
      expect(result.deliverableId).toBe(deliverableId);
      expect(result.submissions).toHaveLength(2);
      expect(result.submissions[0].version).toBe(2);
      expect(result.submissions[1].version).toBe(1);
    });

    it('should throw error if deliverable not found', async () => {
      // Mock data
      const deliverableId = 'deliverable-id';
      const groupId = 'group-id';

      // Mock service response
      jest
        .spyOn(prismaService.deliverable, 'findUnique')
        .mockResolvedValue(null);

      // Execute & Assert
      await expect(
        service.getSubmissionHistory(deliverableId, groupId),
      ).rejects.toThrow(NotFoundException);
    });
  });

  // Add more tests for other methods...
});
