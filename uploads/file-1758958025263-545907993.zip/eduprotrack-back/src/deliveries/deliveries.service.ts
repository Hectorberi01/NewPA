import {
  Injectable,
  Inject,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ValidationService } from './services/validation.service';
import { IStorageService } from './interfaces/storage-service.interface';
import { SubmitFileDto } from './dto/submit-file.dto';
import { SubmitGitLinkDto } from './dto/submit-git-link.dto';
import {
  SubmissionResponseDto,
  SubmissionHistoryResponseDto,
  GroupSubmissionStatusDto,
  SubmissionDashboardDto,
} from './dto/delivery-response.dto';
import {
  SubmissionFiltersDto,
  FilteredSubmissionsResponseDto,
  FilteredSubmissionDto,
  FilteredSubmissionsSummaryDto,
  TeacherSearchDto,
  SearchResultsDto,
  SearchResultDto,
  BulkDownloadDto,
  BulkDownloadResponseDto,
} from './dto/teacher-dashboard.dto';
import { DeliverableType, SubmissionStatus } from '@prisma/client';
import { EmailService } from '../notifications/email.service';
import { LatePenaltyService } from './services/late-penalty.service';
import { StreamableFile } from '@nestjs/common';
import { createReadStream } from 'fs';
import { join } from 'path';
import * as archiver from 'archiver';
import { Readable } from 'stream';
import { v4 as uuidv4 } from 'uuid';
import {
  DownloadCacheItem,
  BulkDownloadSubmissionDto,
} from './types/delivery.types';
import { Response } from 'express';

@Injectable()
export class DeliveriesService {
  private readonly downloadCache = new Map<string, DownloadCacheItem>();
  private readonly downloadPath = process.env.DOWNLOAD_PATH || '/tmp/downloads';

  constructor(
    private readonly prisma: PrismaService,
    private readonly validationService: ValidationService,
    @Inject('STORAGE_SERVICE')
    private readonly storageService: IStorageService,
    private readonly emailService: EmailService,
    private readonly latePenaltyService: LatePenaltyService,
  ) {}

  /**
   * Vérifie si un étudiant appartient à un groupe
   * @param studentId - ID de l'étudiant
   * @param groupId - ID du groupe
   * @returns true si l'étudiant appartient au groupe
   */
  private async isStudentInGroup(
    studentId: string,
    groupId: string,
  ): Promise<boolean> {
    const membership = await this.prisma.groupMember.findFirst({
      where: {
        userId: studentId,
        groupId,
      },
    });
    return !!membership;
  }

  /**
   * Calcule le nombre de jours ouvrés de retard et le malus associé
   * @param deadline - Date limite
   * @param latePenalty - Pénalité par jour de retard
   * @param maxLateDays - Nombre maximum de jours de retard autorisés
   * @param maxPenalty - Pénalité maximale (optionnel)
   * @returns Informations sur le retard
   */
  private calculateLatePenalty(
    deadline: Date,
    latePenalty?: number,
    maxLateDays?: number,
    maxPenalty?: number,
  ): { isLate: boolean; lateDays: number; malus: number } {
    const now = new Date();

    try {
      const penaltyInfo = this.latePenaltyService.calculatePenalty(
        deadline,
        now,
        latePenalty || 0,
        maxPenalty,
        maxLateDays,
      );

      return {
        isLate: penaltyInfo.isLate,
        lateDays: penaltyInfo.lateDays,
        malus: penaltyInfo.penalty,
      };
    } catch (error) {
      // Si le délai maximum est dépassé, retourner -1 pour indiquer le rejet
      if (error instanceof Error && error.message.includes('délai maximum')) {
        throw new Error(error.message);
      }
      return { isLate: false, lateDays: 0, malus: 0 };
    }
  }

  /**
   * Vérifie si une soumission tardive est autorisée
   * @param deliverableId - ID du livrable
   * @returns true si les soumissions tardives sont autorisées
   */
  private async checkLateSubmissionAllowed(
    deliverableId: string,
  ): Promise<boolean> {
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      select: { allowLateSubmission: true, deadline: true },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    const now = new Date();
    const isLate = now > deliverable.deadline;

    // Si en retard et non autorisé
    if (isLate && !deliverable.allowLateSubmission) {
      return false;
    }

    return true;
  }

  /**
   * Soumet un fichier pour un livrable
   * @param deliverableId - ID du livrable
   * @param groupId - ID du groupe
   * @param studentId - ID de l'étudiant
   * @param file - Fichier soumis
   * @param submitFileDto - Données supplémentaires (commentaire)
   * @returns Informations sur la soumission
   */
  async submitFile(
    deliverableId: string,
    groupId: string,
    studentId: string,
    file: Express.Multer.File,
    _submitFileDto: SubmitFileDto,
  ): Promise<SubmissionResponseDto> {
    // Vérifier que l'étudiant appartient au groupe
    const isInGroup = await this.isStudentInGroup(studentId, groupId);
    if (!isInGroup) {
      throw new ForbiddenException(
        `L'étudiant n'appartient pas au groupe spécifié`,
      );
    }

    // Vérifier que les soumissions tardives sont autorisées si nécessaire
    const isSubmissionAllowed =
      await this.checkLateSubmissionAllowed(deliverableId);
    if (!isSubmissionAllowed) {
      throw new ForbiddenException(
        `La deadline est passée et les soumissions tardives ne sont pas autorisées`,
      );
    }

    // Récupérer le livrable
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    // Vérifier le type de livrable
    if (deliverable.type !== DeliverableType.ARCHIVE) {
      throw new BadRequestException(
        `Ce livrable attend un lien Git, pas un fichier`,
      );
    }

    // Valider le fichier par rapport aux règles
    const validationResults =
      await this.validationService.validateFileSubmission(deliverableId, file);

    // Sauvegarder le fichier
    const filePath = await this.storageService.save(file, studentId);

    // Calculer le retard et le malus
    const { isLate, lateDays, malus } = this.calculateLatePenalty(
      deliverable.deadline,
      deliverable.latePenalty,
      deliverable.maxLateDays,
      deliverable.maxPenalty,
    );

    // Vérifier si le délai maximum est dépassé
    if (malus === -1) {
      throw new ForbiddenException(
        `Le délai maximum de soumission (${deliverable.maxLateDays} jours ouvrés) est dépassé`,
      );
    }

    // Déterminer le statut de la soumission
    let status: SubmissionStatus = SubmissionStatus.SUBMITTED;
    if (!validationResults.isValid) {
      status = SubmissionStatus.VALIDATION_FAILED;
    }

    // Compter les soumissions précédentes pour la version
    const previousSubmissions = await this.prisma.deliverableSubmission.count({
      where: { deliverableId, groupId },
    });
    // Version information available for future use
    const version = previousSubmissions + 1;

    // Créer la soumission en base de données
    const submission = await this.prisma.deliverableSubmission.upsert({
      where: {
        deliverableId_groupId: {
          deliverableId,
          groupId,
        },
      },
      update: {
        submittedById: studentId,
        fileName: file.originalname,
        fileSize: file.size,
        fileUrl: filePath,
        status,
        isLate,
        daysLate: lateDays,
        penaltyApplied: malus,
        validationErrors: validationResults
          ? [JSON.stringify(validationResults)]
          : [],
        isValid: validationResults ? validationResults.isValid : null,
        createdAt: new Date(), // Pour forcer la date de soumission
      },
      create: {
        deliverableId,
        groupId,
        submittedById: studentId,
        fileName: file.originalname,
        fileSize: file.size,
        fileUrl: filePath,
        status,
        isLate,
        daysLate: lateDays,
        penaltyApplied: malus,
        validationErrors: validationResults
          ? [JSON.stringify(validationResults)]
          : [],
        isValid: validationResults ? validationResults.isValid : null,
      },
    });

    // Notifier les autres membres du groupe
    await this.notifyGroupMembers(groupId, studentId, deliverableId);

    return {
      id: submission.id,
      deliverableId: submission.deliverableId,
      groupId: submission.groupId,
      studentId: submission.submittedById,
      status: submission.status,
      submittedAt: submission.createdAt,
      fileUrl: submission.fileUrl, // Ou générer une URL d'accès
      fileName: submission.fileName,
      fileSize: submission.fileSize,
      isLate: submission.isLate,
      lateDays: submission.daysLate,
      malus: submission.penaltyApplied,
      validationResults: validationResults,
      version: version,
    };
  }

  /**
   * Soumet un lien Git pour un livrable
   * @param deliverableId - ID du livrable
   * @param groupId - ID du groupe
   * @param studentId - ID de l'étudiant
   * @param submitGitLinkDto - Données de soumission Git
   * @returns Informations sur la soumission
   */
  async submitGitLink(
    deliverableId: string,
    groupId: string,
    studentId: string,
    submitGitLinkDto: SubmitGitLinkDto,
  ): Promise<SubmissionResponseDto> {
    // Vérifier que l'étudiant appartient au groupe
    const isInGroup = await this.isStudentInGroup(studentId, groupId);
    if (!isInGroup) {
      throw new ForbiddenException(
        `L'étudiant n'appartient pas au groupe spécifié`,
      );
    }

    // Vérifier que les soumissions tardives sont autorisées si nécessaire
    const isSubmissionAllowed =
      await this.checkLateSubmissionAllowed(deliverableId);
    if (!isSubmissionAllowed) {
      throw new ForbiddenException(
        `La deadline est passée et les soumissions tardives ne sont pas autorisées`,
      );
    }

    // Récupérer le livrable
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    // Vérifier le type de livrable
    if (deliverable.type !== DeliverableType.GIT_LINK) {
      throw new BadRequestException(
        `Ce livrable attend un fichier, pas un lien Git`,
      );
    }

    // Valider le lien Git par rapport aux règles
    const validationResults =
      await this.validationService.validateGitSubmission(
        deliverableId,
        submitGitLinkDto.gitUrl,
      );

    // Sauvegarder le lien
    const linkId = await this.storageService.saveLink(
      submitGitLinkDto.gitUrl,
      studentId,
    );

    // Le linkId pourrait être utilisé pour tracer les liens sauvegardés
    console.log(`Lien sauvegardé avec ID: ${linkId}`);

    // Calculer le retard et le malus
    const { isLate, lateDays, malus } = this.calculateLatePenalty(
      deliverable.deadline,
      deliverable.latePenalty,
      deliverable.maxLateDays,
      deliverable.maxPenalty,
    );

    // Vérifier si le délai maximum est dépassé
    if (malus === -1) {
      throw new ForbiddenException(
        `Le délai maximum de soumission (${deliverable.maxLateDays} jours ouvrés) est dépassé`,
      );
    }

    // Déterminer le statut de la soumission
    let status: SubmissionStatus = SubmissionStatus.SUBMITTED;
    if (!validationResults.isValid) {
      status = SubmissionStatus.VALIDATION_FAILED;
    }

    // Compter les soumissions précédentes pour la version
    const previousSubmissions = await this.prisma.deliverableSubmission.count({
      where: { deliverableId, groupId },
    });
    // Version information available for future use
    const version = previousSubmissions + 1;

    // Créer la soumission en base de données
    const submission = await this.prisma.deliverableSubmission.upsert({
      where: {
        deliverableId_groupId: {
          deliverableId,
          groupId,
        },
      },
      update: {
        submittedById: studentId,
        gitUrl: submitGitLinkDto.gitUrl,
        status,
        isLate,
        daysLate: lateDays,
        penaltyApplied: malus,
        validationErrors: validationResults
          ? [JSON.stringify(validationResults)]
          : [],
        isValid: validationResults ? validationResults.isValid : null,
        createdAt: new Date(),
      },
      create: {
        deliverableId,
        groupId,
        submittedById: studentId,
        gitUrl: submitGitLinkDto.gitUrl,
        status,
        isLate,
        daysLate: lateDays,
        penaltyApplied: malus,
        validationErrors: validationResults
          ? [JSON.stringify(validationResults)]
          : [],
        isValid: validationResults ? validationResults.isValid : null,
      },
    });

    // Notifier les autres membres du groupe
    await this.notifyGroupMembers(groupId, studentId, deliverableId);

    return {
      id: submission.id,
      deliverableId: submission.deliverableId,
      groupId: submission.groupId,
      studentId: submission.submittedById,
      status: submission.status,
      submittedAt: submission.createdAt,
      gitUrl: submission.gitUrl,
      isLate: submission.isLate,
      lateDays: submission.daysLate,
      malus: submission.penaltyApplied,
      validationResults: validationResults,
      version: version,
    };
  }

  /**
   * Notifie les autres membres du groupe d'une nouvelle soumission
   * @param groupId - ID du groupe
   * @param submitterId - ID de l'étudiant qui a soumis
   * @param deliverableId - ID du livrable
   */
  private async notifyGroupMembers(
    groupId: string,
    submitterId: string,
    deliverableId: string,
  ): Promise<void> {
    // Récupérer les membres du groupe
    const groupMembers = await this.prisma.groupMember.findMany({
      where: {
        groupId,
        userId: { not: submitterId }, // Exclure l'étudiant qui a soumis
      },
      include: {
        user: true,
      },
    });

    // Récupérer le livrable et l'étudiant qui a soumis
    const [deliverable, submitter] = await Promise.all([
      this.prisma.deliverable.findUnique({
        where: { id: deliverableId },
        select: {
          id: true,
          name: true,
        },
      }),
      this.prisma.user.findUnique({
        where: { id: submitterId },
        select: {
          id: true,
          firstname: true,
          lastname: true,
        },
      }),
    ]);

    // Envoyer une notification à chaque membre
    for (const member of groupMembers) {
      const htmlContent = `
        <h2>Nouvelle soumission pour le livrable ${deliverable?.name}</h2>
        <p>Bonjour ${member.user.firstname} ${member.user.lastname},</p>
        <p>Une nouvelle soumission a été effectuée par ${submitter?.firstname} ${submitter?.lastname} pour le livrable "${deliverable?.name}".</p>
        <p>Date de soumission: ${new Date().toLocaleString('fr-FR')}</p>
        <p>Cordialement,<br>L'équipe EduProTrack</p>
      `;

      await this.emailService.sendEmail(
        member.user.email,
        `Nouvelle soumission pour le livrable ${deliverable?.name}`,
        htmlContent,
      );
    }
  }

  /**
   * Récupère l'historique des soumissions d'un groupe pour un livrable
   * @param deliverableId - ID du livrable
   * @param groupId - ID du groupe
   * @returns Historique des soumissions
   */
  async getSubmissionHistory(
    deliverableId: string,
    groupId: string,
  ): Promise<SubmissionHistoryResponseDto> {
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      select: {
        id: true,
        name: true,
        type: true,
        deadline: true,
        allowLateSubmission: true,
        latePenalty: true,
        maxLateDays: true,
      },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    const submissions = await this.prisma.deliverableSubmission.findMany({
      where: {
        deliverableId,
        groupId,
      },
      orderBy: {
        createdAt: 'desc',
      },
      include: {
        submittedBy: {
          select: {
            firstname: true,
            lastname: true,
          },
        },
      },
    });

    return {
      deliverableId: deliverable.id,
      deliverableName: deliverable.name,
      deliverableType: deliverable.type,
      deadline: deliverable.deadline,
      allowLateSubmission: deliverable.allowLateSubmission,
      latePenalty: deliverable.latePenalty,
      maxLateDays: deliverable.maxLateDays,
      submissions: submissions.map((sub, index) => ({
        id: sub.id,
        deliverableId: sub.deliverableId,
        groupId: sub.groupId,
        studentId: sub.submittedById,
        status: sub.status,
        submittedAt: sub.createdAt,
        fileUrl: sub.fileUrl,
        fileName: sub.fileName,
        fileSize: sub.fileSize,
        gitUrl: sub.gitUrl,
        isLate: sub.isLate,
        lateDays: sub.daysLate,
        malus: sub.penaltyApplied,
        validationResults: {
          isValid: sub.isValid ?? true,
          errors: sub.validationErrors,
          warnings: [],
          details: [],
        },
        version: submissions.length - index, // Version dans l'ordre inverse (la plus récente a la version la plus élevée)
      })),
    };
  }

  /**
   * Récupère le statut de soumission d'un groupe pour un livrable
   * @param deliverableId - ID du livrable
   * @param groupId - ID du groupe
   * @returns Statut de soumission du groupe
   */
  async getGroupSubmissionStatus(
    deliverableId: string,
    groupId: string,
  ): Promise<GroupSubmissionStatusDto> {
    const group = await this.prisma.group.findUnique({
      where: { id: groupId },
      select: {
        id: true,
        name: true,
      },
    });

    if (!group) {
      throw new NotFoundException(`Groupe avec l'ID ${groupId} non trouvé`);
    }

    // Récupérer la dernière soumission du groupe
    const lastSubmission = await this.prisma.deliverableSubmission.findFirst({
      where: {
        deliverableId,
        groupId,
      },
      orderBy: {
        createdAt: 'desc',
      },
      include: {
        submittedBy: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
    });

    if (!lastSubmission) {
      return {
        groupId: group.id,
        groupName: group.name,
        hasSubmitted: false,
        isLate: false,
        lateDays: 0,
        malus: 0,
        status: SubmissionStatus.NOT_SUBMITTED,
      };
    }

    return {
      groupId: group.id,
      groupName: group.name,
      hasSubmitted: true,
      lastSubmissionDate: lastSubmission.createdAt,
      lastSubmittedBy: {
        id: lastSubmission.submittedBy.id,
        firstName: lastSubmission.submittedBy.firstname,
        lastName: lastSubmission.submittedBy.lastname,
      },
      isLate: lastSubmission.isLate,
      lateDays: lastSubmission.daysLate,
      malus: lastSubmission.penaltyApplied,
      status: lastSubmission.status,
    };
  }

  /**
   * Génère un tableau de bord des soumissions pour un livrable (vue enseignant)
   * @param deliverableId - ID du livrable
   * @returns Tableau de bord des soumissions
   */
  async getSubmissionDashboard(
    deliverableId: string,
  ): Promise<SubmissionDashboardDto> {
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      include: {
        project: {
          include: {
            groups: true,
          },
        },
      },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    const groups = deliverable.project.groups;
    const groupIds = groups.map((g) => g.id);

    // Récupérer les dernières soumissions pour chaque groupe
    const lastSubmissions = await Promise.all(
      groupIds.map((groupId) =>
        this.prisma.deliverableSubmission.findFirst({
          where: {
            deliverableId,
            groupId,
          },
          orderBy: {
            createdAt: 'desc',
          },
          include: {
            submittedBy: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
              },
            },
          },
        }),
      ),
    );

    // Calculer les métriques
    const totalGroups = groups.length;
    const submittedGroups = lastSubmissions.filter((s) => s !== null).length;
    const pendingGroups = totalGroups - submittedGroups;

    const validSubmissions = lastSubmissions.filter(
      (s) => s !== null && s.status === SubmissionStatus.SUBMITTED,
    );

    const lateSubmissions = validSubmissions.filter((s) => s.isLate).length;
    const onTimeSubmissions = validSubmissions.length - lateSubmissions;

    const submissionRate =
      totalGroups > 0 ? (submittedGroups / totalGroups) * 100 : 0;

    const totalLateDays = validSubmissions.reduce(
      (sum, s) => sum + (s.daysLate || 0),
      0,
    );
    const averageLateDays =
      validSubmissions.length > 0 ? totalLateDays / validSubmissions.length : 0;

    // Préparer les données de groupe
    const groupsData = groups.map((group, index) => {
      const submission = lastSubmissions[index];

      if (!submission) {
        return {
          groupId: group.id,
          groupName: group.name,
          hasSubmitted: false,
          isLate: false,
          lateDays: 0,
          malus: 0,
          status: SubmissionStatus.NOT_SUBMITTED,
        };
      }

      return {
        groupId: group.id,
        groupName: group.name,
        hasSubmitted: true,
        lastSubmissionDate: submission.createdAt,
        lastSubmittedBy: {
          id: submission.submittedBy.id,
          firstName: submission.submittedBy.firstname,
          lastName: submission.submittedBy.lastname,
        },
        isLate: submission.isLate,
        lateDays: submission.daysLate,
        malus: submission.penaltyApplied,
        status: submission.status,
      };
    });

    return {
      totalGroups,
      submittedGroups,
      pendingGroups,
      lateSubmissions,
      onTimeSubmissions,
      submissionRate,
      averageLateDays,
      groups: groupsData,
    };
  }

  /**
   * Récupère les soumissions avec filtrage avancé
   * @param deliverableId - ID du livrable
   * @param filters - Filtres de recherche
   * @returns Soumissions filtrées avec pagination
   */
  async getFilteredSubmissions(
    deliverableId: string,
    filters: SubmissionFiltersDto,
  ): Promise<FilteredSubmissionsResponseDto> {
    const status = filters.status;
    const isLate = filters.isLate;
    const isValid = filters.isValid;
    const groupIds = filters.groupIds;
    const search = filters.search;
    const minLateDays = filters.minLateDays;
    const maxLateDays = filters.maxLateDays;
    const submittedAfter = filters.submittedAfter;
    const submittedBefore = filters.submittedBefore;
    const page = filters.page ?? 1;
    const limit = filters.limit ?? 20;
    const sortBy = filters.sortBy ?? 'submittedAt';
    const sortOrder = filters.sortOrder ?? 'desc';

    // Construire les conditions WHERE
    const whereConditions: {
      deliverableId: string;
      status?: SubmissionStatus;
      isLate?: boolean;
      isValid?: boolean;
      groupId?: { in: string[] };
      daysLate?: { gte?: number; lte?: number };
      createdAt?: { gte?: Date; lte?: Date };
      OR?: Array<{
        fileName?: { contains: string; mode: 'insensitive' };
        gitUrl?: { contains: string; mode: 'insensitive' };
        group?: { name: { contains: string; mode: 'insensitive' } };
        submittedBy?: {
          OR: Array<{
            firstname?: { contains: string; mode: 'insensitive' };
            lastname?: { contains: string; mode: 'insensitive' };
          }>;
        };
      }>;
    } = {
      deliverableId,
    };

    if (status) {
      whereConditions.status = status;
    }

    if (isLate !== undefined) {
      whereConditions.isLate = isLate;
    }

    if (isValid !== undefined) {
      whereConditions.isValid = isValid;
    }

    if (groupIds && groupIds.length > 0) {
      whereConditions.groupId = { in: groupIds };
    }

    if (minLateDays !== undefined) {
      whereConditions.daysLate = { gte: minLateDays };
    }

    if (maxLateDays !== undefined) {
      whereConditions.daysLate = {
        ...whereConditions.daysLate,
        lte: maxLateDays,
      };
    }

    if (submittedAfter) {
      whereConditions.createdAt = { gte: submittedAfter };
    }

    if (submittedBefore) {
      whereConditions.createdAt = {
        ...whereConditions.createdAt,
        lte: submittedBefore,
      };
    }

    // Recherche textuelle
    if (search) {
      whereConditions.OR = [
        { fileName: { contains: search, mode: 'insensitive' } },
        { gitUrl: { contains: search, mode: 'insensitive' } },
        { group: { name: { contains: search, mode: 'insensitive' } } },
        {
          submittedBy: {
            OR: [
              { firstname: { contains: search, mode: 'insensitive' } },
              { lastname: { contains: search, mode: 'insensitive' } },
            ],
          },
        },
      ];
    }

    // Construire les options de tri
    const orderByOptions: {
      group?: { name: 'asc' | 'desc' };
      createdAt?: 'asc' | 'desc';
      status?: 'asc' | 'desc';
      isLate?: 'asc' | 'desc';
      daysLate?: 'asc' | 'desc';
    } = {};
    if (sortBy === 'groupName') {
      orderByOptions.group = { name: sortOrder };
    } else if (sortBy === 'submittedAt') {
      orderByOptions.createdAt = sortOrder;
    } else {
      orderByOptions[sortBy] = sortOrder;
    }

    // Calculer la pagination
    const skip = (page - 1) * limit;

    // Récupérer les soumissions
    const [submissions, totalCount] = await Promise.all([
      this.prisma.deliverableSubmission.findMany({
        where: whereConditions,
        include: {
          group: { select: { id: true, name: true } },
          submittedBy: {
            select: { id: true, firstname: true, lastname: true },
          },
        },
        orderBy: orderByOptions,
        skip,
        take: limit,
      }),
      this.prisma.deliverableSubmission.count({
        where: whereConditions,
      }),
    ]);

    // Calculer les statistiques de résumé
    const allSubmissions = await this.prisma.deliverableSubmission.findMany({
      where: whereConditions,
      select: {
        isLate: true,
        daysLate: true,
        penaltyApplied: true,
        isValid: true,
        groupId: true,
      },
    });

    const summary: FilteredSubmissionsSummaryDto = {
      totalSubmissions: allSubmissions.length,
      validSubmissions: allSubmissions.filter((s) => s.isValid).length,
      invalidSubmissions: allSubmissions.filter((s) => !s.isValid).length,
      lateSubmissions: allSubmissions.filter((s) => s.isLate).length,
      onTimeSubmissions: allSubmissions.filter((s) => !s.isLate).length,
      averageLateDays:
        allSubmissions.length > 0
          ? allSubmissions.reduce((sum, s) => sum + s.daysLate, 0) /
            allSubmissions.length
          : 0,
      totalPenaltyApplied: allSubmissions.reduce(
        (sum, s) => sum + s.penaltyApplied,
        0,
      ),
      groupsWithSubmissions: new Set(allSubmissions.map((s) => s.groupId)).size,
      groupsWithoutSubmissions: 0, // Calculé après
    };

    // Calculer les groupes sans soumissions
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      include: { project: { include: { groups: true } } },
    });

    if (deliverable) {
      const allGroupIds = deliverable.project.groups.map((g) => g.id);
      const submittedGroupIds = new Set(allSubmissions.map((s) => s.groupId));
      summary.groupsWithoutSubmissions =
        allGroupIds.length - submittedGroupIds.size;
    }

    // Transformer les données
    const transformedSubmissions: FilteredSubmissionDto[] = submissions.map(
      (submission, index) => ({
        id: submission.id,
        groupId: submission.groupId,
        groupName: submission.group.name,
        submittedBy: {
          id: submission.submittedBy.id,
          firstName: submission.submittedBy.firstname,
          lastName: submission.submittedBy.lastname,
        },
        status: submission.status,
        submittedAt: submission.createdAt,
        fileName: submission.fileName,
        fileSize: submission.fileSize,
        gitUrl: submission.gitUrl,
        isLate: submission.isLate,
        lateDays: submission.daysLate,
        penaltyApplied: submission.penaltyApplied,
        isValid: submission.isValid ?? true,
        validationErrors: submission.validationErrors,
        version: skip + index + 1,
      }),
    );

    const totalPages = Math.ceil(totalCount / limit);

    return {
      totalCount,
      totalPages,
      currentPage: page,
      limit,
      submissions: transformedSubmissions,
      summary,
    };
  }

  /**
   * Effectue une recherche dans les soumissions
   * @param deliverableId - ID du livrable
   * @param searchParams - Paramètres de recherche
   * @returns Résultats de recherche
   */
  async searchSubmissions(
    deliverableId: string,
    searchParams: TeacherSearchDto,
  ): Promise<SearchResultsDto> {
    const {
      query,
      searchFields = ['groupName', 'studentName'],
      limit = 10,
    } = searchParams;

    const results: SearchResultDto[] = [];

    // Recherche dans les groupes
    if (searchFields.includes('groupName')) {
      const groups = await this.prisma.group.findMany({
        where: {
          name: { contains: query, mode: 'insensitive' },
          project: {
            deliverables: { some: { id: deliverableId } },
          },
        },
        select: {
          id: true,
          name: true,
          deliverableSubmissions: {
            where: { deliverableId },
            select: { id: true, status: true, createdAt: true },
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
        take: limit,
      });

      groups.forEach((group) => {
        const lastSubmission = group.deliverableSubmissions[0];
        results.push({
          id: group.id,
          type: 'group',
          title: group.name,
          description: `Groupe ${group.name}${
            lastSubmission
              ? ` - Dernière soumission: ${lastSubmission.createdAt.toLocaleDateString()}`
              : ' - Aucune soumission'
          }`,
          groupId: group.id,
          relevanceScore: this.calculateRelevanceScore(query, group.name),
          matchedFields: ['groupName'],
        });
      });
    }

    // Recherche dans les noms d'étudiants
    if (searchFields.includes('studentName')) {
      const students = await this.prisma.deliverableSubmission.findMany({
        where: {
          deliverableId,
          submittedBy: {
            OR: [
              { firstname: { contains: query, mode: 'insensitive' } },
              { lastname: { contains: query, mode: 'insensitive' } },
            ],
          },
        },
        include: {
          submittedBy: {
            select: { id: true, firstname: true, lastname: true },
          },
          group: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
      });

      students.forEach((submission) => {
        const fullName = `${submission.submittedBy.firstname} ${submission.submittedBy.lastname}`;
        results.push({
          id: submission.id,
          type: 'student',
          title: fullName,
          description: `${fullName} - Groupe ${submission.group.name} - Soumis le ${submission.createdAt.toLocaleDateString()}`,
          groupId: submission.groupId,
          submissionId: submission.id,
          studentId: submission.submittedBy.id,
          relevanceScore: this.calculateRelevanceScore(query, fullName),
          matchedFields: ['studentName'],
        });
      });
    }

    // Recherche dans les noms de fichiers
    if (searchFields.includes('fileName')) {
      const fileSubmissions = await this.prisma.deliverableSubmission.findMany({
        where: {
          deliverableId,
          fileName: { contains: query, mode: 'insensitive' },
        },
        include: {
          submittedBy: {
            select: { id: true, firstname: true, lastname: true },
          },
          group: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
      });

      fileSubmissions.forEach((submission) => {
        results.push({
          id: submission.id,
          type: 'submission',
          title: submission.fileName || 'Fichier sans nom',
          description: `Fichier soumis par ${submission.submittedBy.firstname} ${submission.submittedBy.lastname} - Groupe ${submission.group.name}`,
          groupId: submission.groupId,
          submissionId: submission.id,
          studentId: submission.submittedBy.id,
          relevanceScore: this.calculateRelevanceScore(
            query,
            submission.fileName || '',
          ),
          matchedFields: ['fileName'],
        });
      });
    }

    // Recherche dans les URLs Git
    if (searchFields.includes('gitUrl')) {
      const gitSubmissions = await this.prisma.deliverableSubmission.findMany({
        where: {
          deliverableId,
          gitUrl: { contains: query, mode: 'insensitive' },
        },
        include: {
          submittedBy: {
            select: { id: true, firstname: true, lastname: true },
          },
          group: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
      });

      gitSubmissions.forEach((submission) => {
        results.push({
          id: submission.id,
          type: 'submission',
          title: submission.gitUrl || 'URL Git',
          description: `URL Git soumise par ${submission.submittedBy.firstname} ${submission.submittedBy.lastname} - Groupe ${submission.group.name}`,
          groupId: submission.groupId,
          submissionId: submission.id,
          studentId: submission.submittedBy.id,
          relevanceScore: this.calculateRelevanceScore(
            query,
            submission.gitUrl || '',
          ),
          matchedFields: ['gitUrl'],
        });
      });
    }

    // Trier par score de pertinence et limiter
    const sortedResults = results
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, limit);

    return {
      query,
      results: sortedResults,
      totalCount: sortedResults.length,
      searchFields,
    };
  }

  /**
   * Calcule un score de pertinence pour la recherche
   * @param query - Requête de recherche
   * @param text - Texte à comparer
   * @returns Score de pertinence entre 0 et 1
   */
  private calculateRelevanceScore(query: string, text: string): number {
    if (!text) return 0;

    const queryLower = query.toLowerCase();
    const textLower = text.toLowerCase();

    // Score exact match
    if (textLower === queryLower) return 1.0;

    // Score starts with
    if (textLower.startsWith(queryLower)) return 0.8;

    // Score contains
    if (textLower.includes(queryLower)) return 0.6;

    // Score fuzzy match (nombre de caractères communs)
    const commonChars = queryLower
      .split('')
      .filter((char) => textLower.includes(char)).length;
    return (commonChars / Math.max(queryLower.length, textLower.length)) * 0.4;
  }

  /**
   * Prépare un téléchargement groupé de soumissions
   * @param deliverableId - ID du livrable
   * @param bulkDownload - Paramètres du téléchargement
   * @returns Informations sur le téléchargement préparé
   */
  async prepareBulkDownload(
    deliverableId: string,
    bulkDownload: BulkDownloadDto,
  ): Promise<BulkDownloadResponseDto> {
    const {
      submissionIds,
      format = 'zip',
      includeMetadata = true,
      archiveName,
    } = bulkDownload;

    // Récupérer les soumissions
    const submissions = await this.prisma.deliverableSubmission.findMany({
      where: {
        id: { in: submissionIds },
        deliverableId,
      },
      include: {
        group: { select: { name: true } },
        submittedBy: {
          select: { firstname: true, lastname: true },
        },
      },
    });

    if (submissions.length === 0) {
      throw new NotFoundException('Aucune soumission trouvée');
    }

    const downloadId = uuidv4();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const finalArchiveName =
      archiveName || `submissions-${deliverableId}-${timestamp}.${format}`;
    const archivePath = join(this.downloadPath, `${downloadId}.${format}`);

    // Créer le répertoire si nécessaire
    await this.ensureDirectoryExists(this.downloadPath);

    // Préparer les informations sur les soumissions
    const includedSubmissions: BulkDownloadSubmissionDto[] = submissions.map(
      (sub) => ({
        id: sub.id,
        groupName: sub.group.name,
        fileName: sub.fileName,
        fileSize: sub.fileSize,
        gitUrl: sub.gitUrl,
        submittedBy: `${sub.submittedBy.firstname} ${sub.submittedBy.lastname}`,
        submittedAt: sub.createdAt,
        pathInArchive: this.generateArchivePath(sub),
      }),
    );

    // Calculer la taille totale
    const totalSize = submissions.reduce(
      (sum, sub) => sum + (sub.fileSize || 0),
      0,
    );

    // Créer l'archive
    await this.createArchive(archivePath, submissions, includeMetadata, format);

    // Stocker les informations dans le cache
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 heures
    const downloadInfo = {
      archivePath,
      archiveName: finalArchiveName,
      totalSize,
      expiresAt,
      includedSubmissions,
    };

    this.downloadCache.set(downloadId, downloadInfo);

    // Nettoyer le cache après expiration
    setTimeout(
      () => {
        this.downloadCache.delete(downloadId);
      },
      24 * 60 * 60 * 1000,
    );

    return {
      downloadUrl: `/api/deliveries/downloads/${downloadId}`,
      archiveName: finalArchiveName,
      totalFiles: submissions.length,
      totalSize,
      expiresAt,
      includedSubmissions,
    };
  }

  /**
   * Récupère les informations d'un téléchargement groupé
   * @param downloadId - ID du téléchargement
   * @returns Informations sur le téléchargement
   */
  getBulkDownloadInfo(downloadId: string): DownloadCacheItem {
    const downloadInfo = this.downloadCache.get(downloadId);
    console.log(downloadId);
    if (!downloadInfo) {
      throw new NotFoundException('Téléchargement non trouvé ou expiré');
    }
    return downloadInfo;
  }

  /**
   * Streaming d'un téléchargement groupé
   * @param downloadId - ID du téléchargement
   * @returns Stream du fichier
   */
  streamBulkDownload(downloadId: string): StreamableFile {
    const downloadInfo = this.getBulkDownloadInfo(downloadId);
    const stream = createReadStream(downloadInfo.archivePath);
    return new StreamableFile(stream);
  }

  /**
   * Utilitaires privés
   */

  private async ensureDirectoryExists(dirPath: string): Promise<void> {
    const fs = await import('fs').then((fs) => fs.promises);
    try {
      await fs.access(dirPath);
    } catch {
      await fs.mkdir(dirPath, { recursive: true });
    }
  }

  private generateArchivePath(submission: {
    group: { name: string };
    createdAt: Date;
    fileName?: string | null;
  }): string {
    const groupName = submission.group.name.replace(/[^a-zA-Z0-9]/g, '_');
    const timestamp = submission.createdAt.toISOString().split('T')[0];

    if (submission.fileName) {
      return `${groupName}/${timestamp}_${submission.fileName}`;
    } else {
      return `${groupName}/${timestamp}_git_submission.txt`;
    }
  }

  private async createArchive(
    archivePath: string,
    submissions: Array<{
      group: { name: string };
      submittedBy: { firstname: string | null; lastname: string | null };
      createdAt: Date;
      id: string;
      fileName?: string | null;
      fileUrl?: string | null;
      gitUrl?: string | null;
      isLate: boolean;
      daysLate: number | null;
      penaltyApplied: number | null;
    }>,
    includeMetadata: boolean,
    format: string,
  ): Promise<void> {
    const fs = await import('fs');
    const output = fs.createWriteStream(archivePath);
    const archive = archiver(format === 'zip' ? 'zip' : 'tar', {
      zlib: { level: 9 },
    });

    archive.pipe(output);

    for (const submission of submissions) {
      const archivePath = this.generateArchivePath(submission);

      if (submission.fileUrl) {
        // Ajouter le fichier à l'archive
        try {
          const fileStream = await this.storageService.getFileStream(
            submission.fileUrl,
          );
          archive.append(fileStream as Readable, {
            name: archivePath,
          });
        } catch (error) {
          console.error(
            `Erreur lors de l'ajout du fichier ${submission.fileName}:`,
            error,
          );
        }
      } else if (submission.gitUrl) {
        // Ajouter un fichier texte avec l'URL Git
        archive.append(submission.gitUrl, { name: archivePath });
      }
    }

    if (includeMetadata) {
      const metadata = {
        generatedAt: new Date().toISOString(),
        totalSubmissions: submissions.length,
        submissions: submissions.map((s) => ({
          id: s.id,
          groupName: s.group.name,
          submittedBy: `${s.submittedBy.firstname} ${s.submittedBy.lastname}`,
          submittedAt: s.createdAt,
          fileName: s.fileName,
          gitUrl: s.gitUrl,
          isLate: s.isLate,
          lateDays: s.daysLate,
          penalty: s.penaltyApplied,
        })),
      };

      archive.append(JSON.stringify(metadata, null, 2), {
        name: 'metadata.json',
      });
    }

    await archive.finalize();
  }

  async downloadSubmissionFile(
    submissionId: string,
    res: Response,
  ): Promise<void> {
    const submission = await this.prisma.deliverableSubmission.findUnique({
      where: { id: submissionId },
      select: { fileUrl: true, fileName: true },
    });

    if (!submission || !submission.fileUrl || !submission.fileName) {
      throw new NotFoundException('Fichier non trouvé pour cette soumission');
    }

    const stream = (await this.storageService.getFileStream(
      submission.fileUrl,
    )) as Readable;

    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${submission.fileName}"`,
    );

    stream.pipe(res);
  }

  /**
   * Récupère toutes les soumissions d'un étudiant
   */
  async findByStudent(studentId: string) {
    console.log(`[DEBUG] findByStudent deliveries - studentId: ${studentId}`);
    
    // Vérifier que l'étudiant appartient à une promotion
    const studentPromotion = await this.prisma.studentPromotion.findFirst({
      where: { userId: studentId },
      include: { promotion: true },
    });

    if (!studentPromotion) {
      console.log(`[DEBUG] Aucune promotion trouvée pour l'étudiant ${studentId}`);
      throw new NotFoundException('Vous devez être assigné à une promotion pour voir vos soumissions');
    }

    // Récupérer toutes les soumissions de l'étudiant
    const submissions = await this.prisma.deliverableSubmission.findMany({
      where: {
        submittedBy: studentId,
        deliverable: {
          project: {
            promotionId: studentPromotion.promotionId,
            status: 'VISIBLE'
          }
        }
      },
      include: {
        deliverable: {
          include: {
            project: {
              include: {
                teacher: { select: { firstname: true, lastname: true } },
                promotion: { select: { name: true } }
              }
            }
          }
        },
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } }
              }
            }
          }
        }
      },
      orderBy: { submittedAt: 'desc' }
    });

    console.log(`[DEBUG] ${submissions.length} soumissions trouvées pour l'étudiant`);
    return submissions.map(submission => ({
      id: submission.id,
      deliverable: {
        id: submission.deliverable.id,
        name: submission.deliverable.name,
        type: submission.deliverable.type,
        deadline: submission.deliverable.deadline,
        project: {
          id: submission.deliverable.project.id,
          name: submission.deliverable.project.name,
          teacher: submission.deliverable.project.teacher,
          promotion: submission.deliverable.project.promotion
        }
      },
      group: submission.group ? {
        id: submission.group.id,
        name: submission.group.name,
        members: submission.group.members.map(m => ({
          firstname: m.user.firstname,
          lastname: m.user.lastname
        }))
      } : null,
      fileName: submission.fileName,
      fileSize: submission.fileSize,
      gitUrl: submission.gitUrl,
      gitBranch: submission.gitBranch,
      submittedAt: submission.submittedAt,
      status: submission.status,
      isLate: submission.submittedAt > submission.deliverable.deadline
    }));
  }
}
