import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { ValidationRuleService } from '../../deliverables/services/validation-rule.service';
import { FileAnalysisService } from '../../deliverables/services/file-analysis.service';
import { GitValidationService } from '../../deliverables/services/git-validation.service';
import { DeliverableType } from '@prisma/client';
import { ValidationResultDto } from '../../deliverables/dto/verification-rule.dto';

@Injectable()
export class ValidationService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly validationRuleService: ValidationRuleService,
    private readonly fileAnalysisService: FileAnalysisService,
    private readonly gitValidationService: GitValidationService,
  ) {}

  /**
   * Valide une soumission de fichier par rapport aux règles du livrable
   * @param deliverableId - ID du livrable
   * @param file - Fichier soumis
   * @returns Résultats de validation
   */
  async validateFileSubmission(
    deliverableId: string,
    file: Express.Multer.File,
  ): Promise<ValidationResultDto> {
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      include: { verificationRules: true },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    if (deliverable.type !== DeliverableType.ARCHIVE) {
      throw new BadRequestException(
        `Ce livrable attend un lien Git, pas un fichier`,
      );
    }

    // Validation de base: taille du fichier
    if (deliverable.maxFileSize && file.size > deliverable.maxFileSize) {
      return {
        isValid: false,
        errors: [
          `Le fichier dépasse la taille maximale autorisée (${Math.round(deliverable.maxFileSize / (1024 * 1024))} MB)`,
        ],
        warnings: [],
        details: [
          {
            ruleType: 'FILE_SIZE',
            ruleName: 'Taille du fichier',
            passed: false,
            message: `Taille actuelle: ${Math.round(file.size / (1024 * 1024))} MB`,
          },
        ],
      };
    }

    // Validation des extensions autorisées
    if (
      deliverable.allowedExtensions &&
      deliverable.allowedExtensions.length > 0
    ) {
      const fileExt = file.originalname.split('.').pop().toLowerCase();
      if (!deliverable.allowedExtensions.includes(`.${fileExt}`)) {
        return {
          isValid: false,
          errors: [
            `Extension de fichier non autorisée. Extensions acceptées: ${deliverable.allowedExtensions.join(', ')}`,
          ],
          warnings: [],
          details: [
            {
              ruleType: 'FILE_EXTENSION',
              ruleName: 'Extension de fichier',
              passed: false,
              message: `Extension actuelle: .${fileExt}`,
            },
          ],
        };
      }
    }

    // Validation des règles spécifiques
    if (deliverable.verificationRules.length > 0) {
      return this.validationRuleService.validateSubmission(deliverableId, {
        file,
        type: 'ARCHIVE',
      });
    }

    // Si aucune règle, la validation est réussie
    return {
      isValid: true,
      errors: [],
      warnings: [],
      details: [],
    };
  }

  /**
   * Valide une soumission de lien Git par rapport aux règles du livrable
   * @param deliverableId - ID du livrable
   * @param gitUrl - URL du dépôt Git
   * @returns Résultats de validation
   */
  async validateGitSubmission(
    deliverableId: string,
    gitUrl: string,
  ): Promise<ValidationResultDto> {
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      include: { verificationRules: true },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    if (deliverable.type !== DeliverableType.GIT_LINK) {
      throw new BadRequestException(
        `Ce livrable attend un fichier, pas un lien Git`,
      );
    }

    // Validation de base du format URL Git
    const gitUrlRegex =
      /^(https?:\/\/)?(www\.)?github\.com\/[\w-]+\/[\w.-]+(\/?|\/(tree|blob)\/[\w.-]+\/?)$/;
    if (!gitUrlRegex.test(gitUrl)) {
      return {
        isValid: false,
        errors: [
          'Format URL Git invalide. Exemple valide: https://github.com/utilisateur/repo',
        ],
        warnings: [],
        details: [
          {
            ruleType: 'GIT_URL_FORMAT',
            ruleName: 'Format URL Git',
            passed: false,
            message: 'URL Git mal formatée',
          },
        ],
      };
    }

    // Validation de l'accessibilité du dépôt
    const gitValidation =
      await this.gitValidationService.validateGitRepository(gitUrl);
    if (!gitValidation.isValid) {
      return {
        isValid: false,
        errors: gitValidation.errors,
        warnings: [],
        details: [
          {
            ruleType: 'GIT_ACCESSIBILITY',
            ruleName: 'Accessibilité du dépôt',
            passed: false,
            message: gitValidation.errors.join(', '),
          },
        ],
      };
    }

    // Si des règles spécifiques sont définies pour le dépôt Git
    if (deliverable.verificationRules.length > 0) {
      // Filtrer uniquement les règles applicables aux liens Git
      const gitRules = deliverable.verificationRules.filter(
        (rule) => rule.ruleType === 'GIT_VALIDATION',
      );

      if (gitRules.length > 0) {
        return this.validationRuleService.validateSubmission(deliverableId, {
          gitUrl,
          type: 'GIT_LINK',
        });
      }
    }

    // Si aucune règle, la validation est réussie
    return {
      isValid: true,
      errors: [],
      warnings: [],
      details: [],
    };
  }
}
