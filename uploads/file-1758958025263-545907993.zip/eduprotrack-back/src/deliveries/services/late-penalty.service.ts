import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { BusinessDayService } from './business-day.service';
import { AdjustPenaltyDto, PenaltySummaryDto } from '../dto/penalty.dto';
import { PenaltyPreviewDto } from '../dto/submission-response.dto';
import { DeliverableSubmission } from '@prisma/client';

/**
 * Service pour la gestion des pénalités de retard
 * Implémente l'US-DEL-004
 */
@Injectable()
export class LatePenaltyService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly businessDayService: BusinessDayService,
  ) {}

  /**
   * Calcule la pénalité de retard pour une soumission
   * @param deadline - Date limite de soumission
   * @param submissionDate - Date effective de soumission
   * @param penaltyPerDay - Pénalité par jour ouvré de retard
   * @param maxPenalty - Pénalité maximale (optionnel)
   * @param maxLateDays - Nombre maximum de jours de retard autorisés (optionnel)
   * @returns Informations sur la pénalité calculée
   */
  calculatePenalty(
    deadline: Date,
    submissionDate: Date,
    penaltyPerDay: number,
    maxPenalty?: number,
    maxLateDays?: number,
  ): PenaltyPreviewDto {
    // Si la soumission est dans les temps, pas de pénalité
    if (submissionDate <= deadline) {
      return {
        isLate: false,
        lateDays: 0,
        penalty: 0,
        isCapped: false,
        deadline,
        currentTime: submissionDate,
      };
    }

    // Calcul du nombre de jours ouvrés de retard
    const lateDays = this.businessDayService.calculateBusinessDays(
      deadline,
      submissionDate,
    );

    // Vérifier si le nombre de jours de retard dépasse le maximum autorisé
    if (maxLateDays !== undefined && lateDays > maxLateDays) {
      throw new Error(
        `La soumission dépasse le délai maximum autorisé de ${maxLateDays} jours ouvrés`,
      );
    }

    // Calcul de la pénalité sans plafond
    let penalty = lateDays * penaltyPerDay;
    let isCapped = false;

    // Application du plafond si défini
    if (maxPenalty !== undefined && penalty > maxPenalty) {
      penalty = maxPenalty;
      isCapped = true;
    }

    return {
      isLate: true,
      lateDays,
      penalty,
      isCapped,
      maxPenalty,
      deadline,
      currentTime: submissionDate,
    };
  }

  /**
   * Prévisualise la pénalité pour une soumission tardive
   * @param deliverableId - ID du livrable
   * @param submissionDate - Date de soumission estimée
   * @returns Prévision de la pénalité
   */
  async previewPenalty(
    deliverableId: string,
    submissionDate: Date = new Date(),
  ): Promise<PenaltyPreviewDto> {
    // Récupérer les informations du livrable
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
    });

    if (!deliverable) {
      throw new Error(`Livrable avec l'ID ${deliverableId} non trouvé`);
    }

    // Vérifier si les soumissions tardives sont autorisées
    if (!deliverable.allowLateSubmission) {
      throw new Error(
        'Les soumissions tardives ne sont pas autorisées pour ce livrable',
      );
    }

    // Convertir la deadline en Date
    const deadline = new Date(deliverable.deadline);

    // Calculer la pénalité
    return this.calculatePenalty(
      deadline,
      submissionDate,
      deliverable.latePenalty || 0,
      deliverable.maxPenalty,
      deliverable.maxLateDays,
    );
  }

  /**
   * Ajuste la pénalité d'une soumission (réservé aux enseignants)
   * @param submissionId - ID de la soumission
   * @param teacherId - ID de l'enseignant effectuant l'ajustement
   * @param adjustmentData - Données d'ajustement (nouvelle pénalité et raison)
   * @returns La soumission mise à jour
   */
  async adjustPenalty(
    submissionId: string,
    teacherId: string,
    adjustmentData: AdjustPenaltyDto,
  ): Promise<DeliverableSubmission> {
    // Récupérer la soumission existante
    const submission = await this.prisma.deliverableSubmission.findUnique({
      where: { id: submissionId },
      include: {
        penaltyAdjustments: true,
        submittedBy: true,
      },
    });

    if (!submission) {
      throw new Error(`Soumission avec l'ID ${submissionId} non trouvée`);
    }

    // Récupérer l'enseignant
    const teacher = await this.prisma.user.findUnique({
      where: { id: teacherId },
    });

    if (!teacher) {
      throw new Error(`Enseignant avec l'ID ${teacherId} non trouvé`);
    }

    // Créer l'historique d'ajustement
    const adjustment = await this.prisma.penaltyAdjustment.create({
      data: {
        submissionId: submission.id,
        adjustedById: teacherId,
        originalPenalty: submission.penaltyApplied || 0,
        newPenalty: adjustmentData.newPenalty,
        reason: adjustmentData.reason,
      },
    });

    // L'adjustment pourrait être utilisé pour des logs ou notifications
    console.log(`Ajustement créé avec ID: ${adjustment.id}`);

    // Mettre à jour la pénalité de la soumission
    const updatedSubmission = await this.prisma.deliverableSubmission.update({
      where: { id: submissionId },
      data: {
        penaltyApplied: adjustmentData.newPenalty,
      },
      include: {
        penaltyAdjustments: true,
        submittedBy: true,
        deliverable: true,
      },
    });

    // Envoyer une notification à l'étudiant
    // TODO: Implémenter la notification

    return updatedSubmission;
  }

  /**
   * Récupère la synthèse des pénalités pour un livrable
   * @param deliverableId - ID du livrable
   * @returns Synthèse des pénalités
   */
  async getPenaltySummary(deliverableId: string): Promise<PenaltySummaryDto> {
    // Récupérer le livrable
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
    });

    if (!deliverable) {
      throw new Error(`Livrable avec l'ID ${deliverableId} non trouvé`);
    }

    // Récupérer toutes les soumissions pour ce livrable
    const submissions = await this.prisma.deliverableSubmission.findMany({
      where: { deliverableId },
      include: {
        submittedBy: true,
        group: true,
        penaltyAdjustments: {
          include: {
            adjustedBy: true,
          },
          orderBy: {
            adjustedAt: 'desc',
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    // Préparer les données de synthèse
    const lateSubmissions = submissions.filter((sub) => sub.isLate);
    const totalPenalty = lateSubmissions.reduce(
      (sum, sub) => sum + (sub.penaltyApplied || 0),
      0,
    );
    const averagePenalty =
      lateSubmissions.length > 0 ? totalPenalty / lateSubmissions.length : 0;

    // Formater les données de soumission
    const submissionsData = submissions.map((sub) => ({
      submissionId: sub.id,
      groupId: sub.groupId,
      groupName: sub.group?.name || 'Groupe sans nom',
      studentName: `${sub.submittedBy.firstname} ${sub.submittedBy.lastname}`,
      submissionDate: sub.createdAt,
      isLate: sub.isLate,
      lateDays: sub.daysLate || 0,
      penalty: sub.penaltyApplied || 0,
      hasAdjustment: sub.penaltyAdjustments.length > 0,
      adjustmentHistory: sub.penaltyAdjustments.map((adj) => ({
        id: adj.id,
        submissionId: adj.submissionId,
        teacherId: adj.adjustedById,
        teacherName: `${adj.adjustedBy.firstname} ${adj.adjustedBy.lastname}`,
        originalPenalty: adj.originalPenalty,
        newPenalty: adj.newPenalty,
        reason: adj.reason,
        adjustedAt: adj.adjustedAt,
      })),
    }));

    return {
      deliverableId,
      deliverableName: deliverable.name,
      totalSubmissions: submissions.length,
      lateSubmissions: lateSubmissions.length,
      averagePenalty,
      submissions: submissionsData,
    };
  }
}
