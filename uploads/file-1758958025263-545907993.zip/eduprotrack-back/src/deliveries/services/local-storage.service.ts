import { Injectable, Logger } from '@nestjs/common';
import { writeFileSync, mkdirSync, existsSync, createReadStream } from 'fs';
import { join } from 'path';
import { IStorageService } from '../interfaces/storage-service.interface';

@Injectable()
export class LocalStorageService implements IStorageService {
  private readonly logger = new Logger(LocalStorageService.name);
  private readonly uploadPath = join(process.cwd(), 'uploads');

  constructor() {
    this.ensureUploadDirectory();
  }

  /**
   * Sauvegarde un fichier en local
   * @param file - Fichier à sauvegarder
   * @param userId - ID de l'utilisateur
   * @returns Chemin du fichier sauvegardé
   */
  async save(file: Express.Multer.File, userId: string): Promise<string> {
    try {
      // Vérification zip bomb
      await this.checkZipBomb(file);

      // Vérification antivirus
      await this.scanWithClamAV(file);

      const timestamp = Date.now();
      const fileName = `${userId}_${timestamp}_${file.originalname}`;
      const filePath = join(this.uploadPath, fileName);

      writeFileSync(filePath, file.buffer);

      this.logger.log(`Fichier sauvegardé localement: ${fileName}`);

      return filePath;
    } catch (error) {
      this.logger.error('Erreur lors de la sauvegarde locale', error);
      throw error;
    }
  }

  /**
   * Sauvegarde un lien en local
   * @param link - Lien à sauvegarder
   * @param userId - ID de l'utilisateur
   * @returns ID du lien sauvegardé
   */
  saveLink(link: string, userId: string): Promise<string> {
    return Promise.resolve().then(() => {
      try {
        const timestamp = Date.now();
        const linkId = `${userId}_${timestamp}_link`;
        const linkData = {
          link,
          userId,
          savedAt: new Date().toISOString(),
        };

        const linkPath = join(this.uploadPath, `${linkId}.json`);

        writeFileSync(linkPath, JSON.stringify(linkData, null, 2));

        this.logger.log(`Lien sauvegardé localement: ${linkId}`);

        return linkId;
      } catch (error) {
        this.logger.error('Erreur lors de la sauvegarde du lien', error);
        throw error;
      }
    });
  }

  /**
   * Vérifie si le fichier est une zip bomb
   * @param file - Fichier à vérifier
   * @returns true si le fichier est sûr
   */
  checkZipBomb(file: Express.Multer.File): Promise<boolean> {
    return Promise.resolve().then(() => {
      // Implémentation basique de détection de zip bomb
      const maxFileSize = 100 * 1024 * 1024; // 100MB
      const maxCompressionRatio = 100;

      if (file.size > maxFileSize) {
        throw new Error(`Fichier trop volumineux: ${file.size} bytes`);
      }

      // Vérification du ratio de compression pour les fichiers ZIP
      if (file.mimetype === 'application/zip') {
        const compressionRatio = file.buffer.length / file.size;
        if (compressionRatio > maxCompressionRatio) {
          throw new Error("Fichier suspecté d'être une zip bomb");
        }
      }

      return true;
    });
  }

  /**
   * Scan antivirus avec ClamAV
   * @param file - Fichier à scanner
   * @returns true si le fichier est propre
   */
  scanWithClamAV(file: Express.Multer.File): Promise<boolean> {
    return Promise.resolve().then(() => {
      try {
        // Note: Implémentation simulée
        // En production, intégrer avec ClamAV
        this.logger.log(`Scan antivirus simulé pour: ${file.originalname}`);

        // Simulation d'une vérification basique
        const suspiciousExtensions = ['.exe', '.bat', '.cmd', '.scr'];

        const fileExtension = file.originalname.toLowerCase().split('.').pop();

        if (suspiciousExtensions.includes(`.${fileExtension}`)) {
          throw new Error(`Type de fichier non autorisé: ${fileExtension}`);
        }

        return true;
      } catch (error) {
        this.logger.error('Erreur lors du scan antivirus', error);
        throw error;
      }
    });
  }

  /**
   * Récupère un stream de fichier
   * @param fileUrl - URL ou chemin du fichier
   * @returns Stream du fichier
   */
  getFileStream(fileUrl: string): Promise<NodeJS.ReadableStream> {
    try {
      // Pour le stockage local, fileUrl est le chemin du fichier
      if (!existsSync(fileUrl)) {
        throw new Error(`Fichier non trouvé: ${fileUrl}`);
      }

      const stream = createReadStream(fileUrl);
      this.logger.log(`Stream créé pour le fichier: ${fileUrl}`);

      return Promise.resolve(stream);
    } catch (error) {
      this.logger.error('Erreur lors de la création du stream', error);
      throw error;
    }
  }

  /**
   * Supprime un fichier du stockage local
   * @param fileUrl - URL ou chemin du fichier
   * @returns true si le fichier a été supprimé
   */
  async deleteFile(fileUrl: string): Promise<boolean> {
    try {
      const fs = await import('fs/promises');

      if (!existsSync(fileUrl)) {
        this.logger.warn(`Fichier non trouvé pour suppression: ${fileUrl}`);
        return false;
      }

      await fs.unlink(fileUrl);
      this.logger.log(`Fichier supprimé: ${fileUrl}`);

      return true;
    } catch (error) {
      this.logger.error('Erreur lors de la suppression du fichier', error);
      throw error;
    }
  }

  /**
   * Créer le répertoire d'upload s'il n'existe pas
   */
  private ensureUploadDirectory(): void {
    if (!existsSync(this.uploadPath)) {
      mkdirSync(this.uploadPath, { recursive: true });
      this.logger.log(`Répertoire d'upload créé: ${this.uploadPath}`);
    }
  }
}
