import { Injectable } from '@nestjs/common';

/**
 * Service pour la gestion des jours ouvrés en France
 * Utilisé pour calculer les jours de retard dans les soumissions
 */
@Injectable()
export class BusinessDayService {
  /**
   * Liste des jours fériés fixes en France (jour/mois)
   */
  private readonly fixedHolidays = [
    { day: 1, month: 1 }, // Nouvel An
    { day: 1, month: 5 }, // Fête du Travail
    { day: 8, month: 5 }, // Victoire 1945
    { day: 14, month: 7 }, // Fête Nationale
    { day: 15, month: 8 }, // Assomption
    { day: 1, month: 11 }, // Toussaint
    { day: 11, month: 11 }, // Armistice
    { day: 25, month: 12 }, // Noël
  ];

  /**
   * Liste des jours fériés variables en France pour les années à venir
   * Pré-calculés pour éviter des calculs complexes
   */
  private readonly variableHolidays = {
    // Année 2024
    2024: [
      new Date('2024-04-01'), // Lundi de Pâques
      new Date('2024-05-09'), // Ascension
      new Date('2024-05-20'), // Lundi de Pentecôte
    ],
    // Année 2025
    2025: [
      new Date('2025-04-21'), // Lundi de Pâques
      new Date('2025-05-29'), // Ascension
      new Date('2025-06-09'), // Lundi de Pentecôte
    ],
    // Année 2026
    2026: [
      new Date('2026-04-06'), // Lundi de Pâques
      new Date('2026-05-14'), // Ascension
      new Date('2026-05-25'), // Lundi de Pentecôte
    ],
  };

  /**
   * Vérifie si une date est un jour férié en France
   * @param date - Date à vérifier
   * @returns Vrai si c'est un jour férié
   */
  isFrenchHoliday(date: Date): boolean {
    const day = date.getDate();
    const month = date.getMonth() + 1; // getMonth() renvoie 0-11
    const year = date.getFullYear();

    // Vérification des jours fériés fixes
    const isFixedHoliday = this.fixedHolidays.some(
      (holiday) => holiday.day === day && holiday.month === month,
    );

    if (isFixedHoliday) {
      return true;
    }

    // Vérification des jours fériés variables
    const yearHolidays =
      this.variableHolidays[year as keyof typeof this.variableHolidays];
    if (yearHolidays) {
      return yearHolidays.some(
        (holiday: Date) =>
          holiday.getDate() === day &&
          holiday.getMonth() === date.getMonth() &&
          holiday.getFullYear() === year,
      );
    }

    return false;
  }

  /**
   * Vérifie si une date est un jour ouvré (lundi-vendredi, non férié)
   * @param date - Date à vérifier
   * @returns Vrai si c'est un jour ouvré
   */
  isBusinessDay(date: Date): boolean {
    const dayOfWeek = date.getDay(); // 0 = dimanche, 6 = samedi

    // Vérifier que ce n'est ni un week-end ni un jour férié
    return dayOfWeek !== 0 && dayOfWeek !== 6 && !this.isFrenchHoliday(date);
  }

  /**
   * Calcule le nombre de jours ouvrés entre deux dates
   * @param startDate - Date de début (exclue)
   * @param endDate - Date de fin (exclue)
   * @returns Nombre de jours ouvrés entre les deux dates
   */
  calculateBusinessDays(startDate: Date, endDate: Date): number {
    // Gérer le cas où les dates sont égales ou inversées
    if (startDate >= endDate) {
      return 0;
    }

    // Cloner les dates pour ne pas modifier les originales
    const start = new Date(startDate);
    const end = new Date(endDate);

    // Normaliser les dates pour ignorer les heures et commencer le jour suivant
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() + 1); // Commencer le jour suivant la date de début
    end.setHours(0, 0, 0, 0);

    let businessDays = 0;
    const currentDate = new Date(start);

    // Parcourir les jours et compter ceux qui sont ouvrés
    while (currentDate < end) {
      if (this.isBusinessDay(currentDate)) {
        businessDays++;
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return businessDays;
  }
}
