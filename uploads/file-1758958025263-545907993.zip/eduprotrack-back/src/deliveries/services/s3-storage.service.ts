import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
} from '@aws-sdk/client-s3';
import { Readable } from 'stream';
import { ReadableStream } from 'stream/web';
import { IStorageService } from '../interfaces/storage-service.interface';

@Injectable()
export class S3StorageService implements IStorageService {
  private readonly logger = new Logger(S3StorageService.name);
  private readonly s3Client: S3Client;
  private readonly bucketName: string;

  constructor(private readonly configService: ConfigService) {
    this.bucketName =
      this.configService?.get('AWS_S3_BUCKET') ||
      process.env.AWS_S3_BUCKET ||
      'eduprotrack-uploads';

    this.s3Client = new S3Client({
      region:
        this.configService?.get('AWS_REGION') ||
        process.env.AWS_REGION ||
        'eu-west-3',
      credentials: {
        accessKeyId:
          this.configService?.get('AWS_ACCESS_KEY_ID') ||
          process.env.AWS_ACCESS_KEY_ID ||
          '',
        secretAccessKey:
          this.configService?.get('AWS_SECRET_ACCESS_KEY') ||
          process.env.AWS_SECRET_ACCESS_KEY ||
          '',
      },
    });
  }

  /**
   * Sauvegarde un fichier sur S3
   * @param file - Fichier à sauvegarder
   * @param userId - ID de l'utilisateur
   * @returns URL S3 du fichier sauvegardé
   */
  async save(file: Express.Multer.File, userId: string): Promise<string> {
    try {
      // Vérifications de sécurité
      await this.checkZipBomb(file);
      await this.scanWithClamAV(file);

      const timestamp = Date.now();
      const fileName = `${userId}/${timestamp}_${file.originalname}`;

      const command = new PutObjectCommand({
        Bucket: this.bucketName,
        Key: fileName,
        Body: file.buffer,
        ContentType: file.mimetype,
        ServerSideEncryption: 'AES256',
        Metadata: {
          uploadedBy: userId,
          originalName: file.originalname,
          uploadedAt: new Date().toISOString(),
        },
      });

      await this.s3Client.send(command);

      const s3Url = `https://${this.bucketName}.s3.${process.env.AWS_REGION || 'eu-west-3'}.amazonaws.com/${fileName}`;

      this.logger.log(`Fichier uploadé vers S3: ${fileName}`);

      return s3Url;
    } catch (error) {
      this.logger.error("Erreur lors de l'upload S3", error);
      throw error;
    }
  }

  /**
   * Sauvegarde un lien sur S3
   * @param link - Lien à sauvegarder
   * @param userId - ID de l'utilisateur
   * @returns Clé S3 du lien sauvegardé
   */
  async saveLink(link: string, userId: string): Promise<string> {
    try {
      const timestamp = Date.now();
      const linkKey = `${userId}/links/${timestamp}_link.json`;

      const linkData = {
        link,
        userId,
        savedAt: new Date().toISOString(),
      };

      const command = new PutObjectCommand({
        Bucket: this.bucketName,
        Key: linkKey,
        Body: JSON.stringify(linkData, null, 2),
        ContentType: 'application/json',
        ServerSideEncryption: 'AES256',
        Metadata: {
          uploadedBy: userId,
          type: 'link',
          uploadedAt: new Date().toISOString(),
        },
      });

      await this.s3Client.send(command);

      this.logger.log(`Lien sauvegardé sur S3: ${linkKey}`);

      return linkKey;
    } catch (error) {
      this.logger.error('Erreur lors de la sauvegarde du lien sur S3', error);
      throw error;
    }
  }

  /**
   * Vérifie si le fichier est une zip bomb
   * @param file - Fichier à vérifier
   * @returns true si le fichier est sûr
   */
  checkZipBomb(file: Express.Multer.File): Promise<boolean> {
    return Promise.resolve().then(() => {
      const maxFileSize = 100 * 1024 * 1024; // 100MB
      const maxCompressionRatio = 100;

      if (file.size > maxFileSize) {
        throw new Error(`Fichier trop volumineux: ${file.size} bytes`);
      }

      if (file.mimetype === 'application/zip') {
        const compressionRatio = file.buffer.length / file.size;
        if (compressionRatio > maxCompressionRatio) {
          throw new Error("Fichier suspecté d'être une zip bomb");
        }
      }

      return true;
    });
  }

  /**
   * Scan antivirus avec ClamAV
   * @param file - Fichier à scanner
   * @returns true si le fichier est propre
   */
  scanWithClamAV(file: Express.Multer.File): Promise<boolean> {
    return Promise.resolve().then(() => {
      try {
        this.logger.log(`Scan antivirus pour S3: ${file.originalname}`);

        const suspiciousExtensions = ['.exe', '.bat', '.cmd', '.scr'];

        const fileExtension = file.originalname.toLowerCase().split('.').pop();

        if (suspiciousExtensions.includes(`.${fileExtension}`)) {
          throw new Error(`Type de fichier non autorisé: ${fileExtension}`);
        }

        return true;
      } catch (error) {
        this.logger.error('Erreur lors du scan antivirus S3', error);
        throw error;
      }
    });
  }

  /**
   * Récupère un stream de fichier depuis S3
   * @param fileUrl - URL S3 du fichier
   * @returns Stream du fichier
   */
  async getFileStream(fileUrl: string): Promise<NodeJS.ReadableStream> {
    try {
      // Extraire la clé du fichier depuis l'URL S3
      const key = this.extractKeyFromUrl(fileUrl);

      const command = new GetObjectCommand({
        Bucket: this.bucketName,
        Key: key,
      });

      const response = await this.s3Client.send(command);

      if (!response.Body) {
        throw new Error('Aucun contenu trouvé dans la réponse S3');
      }

      this.logger.log(`Stream créé pour le fichier S3: ${key}`);

      // Convert ReadableStream to NodeJS.ReadableStream
      if (response.Body instanceof Readable) {
        return response.Body;
      } else if (response.Body instanceof ReadableStream) {
        // Handle case where Body is a ReadableStream (web streams)
        return Readable.fromWeb(response.Body);
      } else {
        throw new Error('Unsupported stream type');
      }
    } catch (error) {
      this.logger.error('Erreur lors de la création du stream S3', error);
      throw error;
    }
  }

  /**
   * Extrait la clé du fichier depuis une URL S3
   * @param url - URL S3 complète
   * @returns Clé du fichier
   */
  private extractKeyFromUrl(url: string): string {
    try {
      // Format: https://bucket.s3.region.amazonaws.com/key
      const urlParts = url.split('/');
      const keyParts = urlParts.slice(3); // Enlever https:, '', bucket.s3.region.amazonaws.com
      return keyParts.join('/');
    } catch (error) {
      this.logger.error(`Erreur lors de l'extraction de la clé S3: ${error}`);
      throw new Error(`URL S3 invalide: ${url}`);
    }
  }
}
