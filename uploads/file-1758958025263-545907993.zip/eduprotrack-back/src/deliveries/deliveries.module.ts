import { Module } from '@nestjs/common';
import { DeliveriesController } from './deliveries.controller';
import { DeliveriesService } from './deliveries.service';
import { ValidationService } from './services/validation.service';
import { S3StorageService } from './services/s3-storage.service';
import { DeliverableModule } from '../deliverables/deliverable.module';
import { PrismaModule } from '../prisma/prisma.module';
import { LatePenaltyService } from './services/late-penalty.service';
import { BusinessDayService } from './services/business-day.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MulterModule } from '@nestjs/platform-express';
import { memoryStorage } from 'multer';
import { EmailService } from '../notifications/email.service';

@Module({
  imports: [
    PrismaModule,
    DeliverableModule,
    ConfigModule,
    MulterModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        storage: memoryStorage(),
        limits: {
          fileSize:
            configService.get<number>('MAX_FILE_SIZE') || 100 * 1024 * 1024, // 100MB
        },
        fileFilter: (req, file, cb) => {
          const allowedExtensions = ['.zip', '.tar', '.gz', '.rar'];
          const ext = file.originalname.split('.').pop()?.toLowerCase();

          if (ext && allowedExtensions.includes(`.${ext}`)) {
            cb(null, true);
          } else {
            cb(
              new Error(
                `Extension non autorisée. Formats acceptés: ${allowedExtensions.join(', ')},`,
              ),
              false,
            );
          }
        },
      }),
    }),
  ],
  controllers: [DeliveriesController],
  providers: [
    DeliveriesService,
    ValidationService,
    LatePenaltyService,
    BusinessDayService,
    EmailService,
    {
      provide: 'STORAGE_SERVICE',
      useClass: S3StorageService,
    },
  ],
  exports: [
    DeliveriesService,
    ValidationService,
    LatePenaltyService,
    BusinessDayService,
    'STORAGE_SERVICE',
  ],
})
export class DeliveriesModule {}
