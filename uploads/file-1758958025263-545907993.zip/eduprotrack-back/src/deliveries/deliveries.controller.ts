import {
  Controller,
  Post,
  Get,
  Put,
  Body,
  Param,
  UseGuards,
  UseInterceptors,
  UploadedFile,
  HttpCode,
  HttpStatus,
  BadRequestException,
  Query,
  Res,
  StreamableFile,
  Req,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { Response } from 'express';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../auth/guards/teacher.guard';
import { AuthenticatedRequest } from '../auth/types/auth.types';
import { DeliveriesService } from './deliveries.service';
import { LatePenaltyService } from './services/late-penalty.service';
import { SubmitFileDto } from './dto/submit-file.dto';
import { SubmitGitLinkDto } from './dto/submit-git-link.dto';
import {
  SubmissionResponseDto,
  SubmissionHistoryResponseDto,
  GroupSubmissionStatusDto,
  SubmissionDashboardDto,
} from './dto/delivery-response.dto';
import { AdjustPenaltyDto, PenaltySummaryDto } from './dto/penalty.dto';
import { PenaltyPreviewDto } from './dto/submission-response.dto';
import {
  SubmissionFiltersDto,
  FilteredSubmissionsResponseDto,
  TeacherSearchDto,
  SearchResultsDto,
  BulkDownloadDto,
  BulkDownloadResponseDto,
} from './dto/teacher-dashboard.dto';
import { DeliverableType, DeliverableSubmission } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Contrôleur pour la gestion des soumissions de livrables
 * Implémente l'US-DEL-003 pour la soumission par les étudiants
 */
@Controller('deliveries')
@UseGuards(JWTAuthGuard)
export class DeliveriesController {
  constructor(
    private readonly deliveryService: DeliveriesService,
    private readonly latePenaltyService: LatePenaltyService,
    private readonly prisma: PrismaService,
  ) {}

  /**
   * Soumet un fichier pour un livrable
   * @param deliverableId - ID du livrable
   * @param groupId - ID du groupe
   * @param user - Utilisateur courant
   * @param file - Fichier soumis
   * @param submitFileDto - Données supplémentaires
   * @returns Informations sur la soumission
   */
  @Post('deliverables/:deliverableId/groups/:groupId/submit-file')
  @UseInterceptors(FileInterceptor('file'))
  @HttpCode(HttpStatus.CREATED)
  async submitFile(
    @Param('deliverableId') deliverableId: string,
    @Param('groupId') groupId: string,
    @Req() req: AuthenticatedRequest,
    @UploadedFile() file: Express.Multer.File,
    @Body() submitFileDto: SubmitFileDto,
  ): Promise<SubmissionResponseDto> {
    if (!file) {
      throw new BadRequestException("Aucun fichier n'a été soumis");
    }

    // Vérifier le type de livrable
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      select: { type: true },
    });

    if (!deliverable) {
      throw new BadRequestException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    if (deliverable.type !== DeliverableType.ARCHIVE) {
      throw new BadRequestException(
        `Ce livrable attend un lien Git, pas un fichier`,
      );
    }

    return this.deliveryService.submitFile(
      deliverableId,
      groupId,
      req.user.id,
      file,
      submitFileDto,
    );
  }

  /**
   * Soumet un lien Git pour un livrable
   * @param deliverableId - ID du livrable
   * @param groupId - ID du groupe
   * @param user - Utilisateur courant
   * @param submitGitLinkDto - Données de soumission Git
   * @returns Informations sur la soumission
   */
  @Post('deliverables/:deliverableId/groups/:groupId/submit-git')
  @HttpCode(HttpStatus.CREATED)
  async submitGitLink(
    @Param('deliverableId') deliverableId: string,
    @Param('groupId') groupId: string,
    @Req() req: AuthenticatedRequest,
    @Body() submitGitLinkDto: SubmitGitLinkDto,
  ): Promise<SubmissionResponseDto> {
    // Vérifier le type de livrable
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      select: { type: true },
    });

    if (!deliverable) {
      throw new BadRequestException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    if (deliverable.type !== DeliverableType.GIT_LINK) {
      throw new BadRequestException(
        `Ce livrable attend un fichier, pas un lien Git`,
      );
    }

    return this.deliveryService.submitGitLink(
      deliverableId,
      groupId,
      req.user.id,
      submitGitLinkDto,
    );
  }

  /**
   * Récupère l'historique des soumissions d'un groupe pour un livrable
   * @param deliverableId - ID du livrable
   * @param groupId - ID du groupe
   * @returns Historique des soumissions
   */
  @Get('deliverables/:deliverableId/groups/:groupId/submissions')
  async getSubmissionHistory(
    @Param('deliverableId') deliverableId: string,
    @Param('groupId') groupId: string,
  ): Promise<SubmissionHistoryResponseDto> {
    return this.deliveryService.getSubmissionHistory(deliverableId, groupId);
  }

  /**
   * Récupère le statut de soumission d'un groupe pour un livrable
   * @param deliverableId - ID du livrable
   * @param groupId - ID du groupe
   * @returns Statut de soumission du groupe
   */
  @Get('deliverables/:deliverableId/groups/:groupId/status')
  async getGroupSubmissionStatus(
    @Param('deliverableId') deliverableId: string,
    @Param('groupId') groupId: string,
  ): Promise<GroupSubmissionStatusDto> {
    return this.deliveryService.getGroupSubmissionStatus(
      deliverableId,
      groupId,
    );
  }

  /**
   * Génère un tableau de bord des soumissions pour un livrable (vue enseignant)
   * @param deliverableId - ID du livrable
   * @returns Tableau de bord des soumissions
   */
  @Get('deliverables/:deliverableId/dashboard')
  @UseGuards(TeacherGuard)
  async getSubmissionDashboard(
    @Param('deliverableId') deliverableId: string,
  ): Promise<SubmissionDashboardDto> {
    return this.deliveryService.getSubmissionDashboard(deliverableId);
  }

  /**
   * Prévisualise la pénalité pour une soumission tardive
   * @param deliverableId - ID du livrable
   * @returns Prévision de la pénalité
   */
  @Get('deliverables/:deliverableId/penalty-preview')
  async previewPenalty(
    @Param('deliverableId') deliverableId: string,
  ): Promise<PenaltyPreviewDto> {
    return this.latePenaltyService.previewPenalty(deliverableId);
  }

  /**
   * Ajuste la pénalité d'une soumission (réservé aux enseignants)
   * @param submissionId - ID de la soumission
   * @param user - Utilisateur courant (enseignant)
   * @param adjustmentData - Données d'ajustement
   * @returns La soumission mise à jour
   */
  @Put('submissions/:submissionId/penalty')
  @UseGuards(TeacherGuard)
  @HttpCode(HttpStatus.OK)
  async adjustPenalty(
    @Param('submissionId') submissionId: string,
    @Req() req: AuthenticatedRequest,
    @Body() adjustmentData: AdjustPenaltyDto,
  ): Promise<DeliverableSubmission> {
    return this.latePenaltyService.adjustPenalty(
      submissionId,
      req.user.id,
      adjustmentData,
    );
  }

  /**
   * Récupère la synthèse des pénalités pour un livrable (vue enseignant)
   * @param deliverableId - ID du livrable
   * @returns Synthèse des pénalités
   */
  @Get('deliverables/:deliverableId/penalties')
  @UseGuards(TeacherGuard)
  async getPenaltySummary(
    @Param('deliverableId') deliverableId: string,
  ): Promise<PenaltySummaryDto> {
    return this.latePenaltyService.getPenaltySummary(deliverableId);
  }

  /**
   * Récupère les soumissions avec filtrage avancé pour les enseignants
   * @param deliverableId - ID du livrable
   * @param filters - Filtres de recherche
   * @returns Soumissions filtrées avec pagination
   */
  @Get('deliverables/:deliverableId/submissions/filtered')
  @UseGuards(TeacherGuard)
  async getFilteredSubmissions(
    @Param('deliverableId') deliverableId: string,
    @Query() filters: SubmissionFiltersDto,
  ): Promise<FilteredSubmissionsResponseDto> {
    return this.deliveryService.getFilteredSubmissions(deliverableId, filters);
  }

  /**
   * Effectue une recherche dans les soumissions pour les enseignants
   * @param deliverableId - ID du livrable
   * @param searchParams - Paramètres de recherche
   * @returns Résultats de recherche
   */
  @Get('deliverables/:deliverableId/search')
  @UseGuards(TeacherGuard)
  async searchSubmissions(
    @Param('deliverableId') deliverableId: string,
    @Query() searchParams: TeacherSearchDto,
  ): Promise<SearchResultsDto> {
    return this.deliveryService.searchSubmissions(deliverableId, searchParams);
  }

  /**
   * Télécharge un fichier zip contenant les soumissions sélectionnées
   * @param deliverableId - ID du livrable
   * @param bulkDownload - Données pour le téléchargement groupé
   * @returns Fichier zip des soumissions
   */
  @Post('deliverables/:deliverableId/bulk-download')
  @UseGuards(TeacherGuard)
  @HttpCode(HttpStatus.OK)
  async bulkDownloadSubmissions(
    @Param('deliverableId') deliverableId: string,
    @Body() bulkDownload: BulkDownloadDto,
  ): Promise<BulkDownloadResponseDto> {
    return this.deliveryService.prepareBulkDownload(
      deliverableId,
      bulkDownload,
    );
  }

  /**
   * Télécharge le fichier zip préparé
   * @param downloadId - ID du téléchargement
   * @param res - Response Express
   * @returns Fichier zip en streaming
   */
  @Get('downloads/:downloadId')
  downloadBulkFile(
    @Param('downloadId') downloadId: string,
    @Res({ passthrough: true }) res: Response,
  ): StreamableFile {
    const downloadInfo = this.deliveryService.getBulkDownloadInfo(downloadId);

    res.set({
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${downloadInfo.archiveName}"`,
      'Content-Length': downloadInfo.totalSize.toString(),
    });

    return this.deliveryService.streamBulkDownload(downloadId);
  }

  @Get('submissions/:submissionId/download')
  async downloadSubmission(
    @Param('submissionId') submissionId: string,
    @Res() res: Response,
  ) {
    return this.deliveryService.downloadSubmissionFile(submissionId, res);
  }
}
