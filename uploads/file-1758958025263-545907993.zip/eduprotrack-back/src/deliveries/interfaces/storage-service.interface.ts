export interface FileUploadResult {
  success: boolean;
  message: string;
  filePath?: string;
  url?: string;
}

export interface LinkSaveResult {
  success: boolean;
  message: string;
  linkId?: string;
}

export interface IStorageService {
  save(file: Express.Multer.File, userId: string): Promise<string>;

  saveLink(link: string, userId: string): Promise<string>;

  checkZipBomb(file: Express.Multer.File): Promise<boolean>;

  scanWithClamAV(file: Express.Multer.File): Promise<boolean>;

  getFileStream(fileUrl: string): Promise<NodeJS.ReadableStream>;
}
