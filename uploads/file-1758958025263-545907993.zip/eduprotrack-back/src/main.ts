import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import 'dotenv/config';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.enableCors({
    origin: ['http://localhost:3000', 'http://192.168.1.52:3000'],
    methods: ['GET', 'POST', 'PUT', 'PATH', 'DELETE', 'OPTIONS'],
    credentials: true,
  });

  app.enableCors({
    origin: [
      'https://preview-eduprotrack-auth-interface-kzmjpk401ma6cdb0wvv8.vusercontent.net/',
    ],
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    credentials: true,
  });

  app.enableShutdownHooks();

  app.useGlobalPipes(new ValidationPipe());

  // Configuration Swagger
  const config = new DocumentBuilder()
    .setTitle('EduProTrack API')
    .setDescription(
      'API de gestion de projets éducatifs avec authentification, gestion des utilisateurs, projets, groupes et livrables. ' +
        'Cette API permet la gestion complète des projets étudiants, des livrables, des soutenances et de la notation.',
    )
    .setVersion('1.0')
    .addServer('http://localhost:4000', 'Serveur de développement')
    .addBearerAuth(
      {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        name: 'JWT',
        description: 'Entrez votre token JWT (obtenu via /auth/login)',
        in: 'header',
      },
      'JWT-auth',
    )
    .addTag(
      'Auth',
      'Authentification et autorisation - Connexion, déconnexion, refresh tokens',
    )
    .addTag('Users', 'Gestion des utilisateurs - CRUD utilisateurs, profils')
    .addTag(
      'Students',
      'Gestion des étudiants - Étudiants, promotions, imports',
    )
    .addTag('Teachers', 'Gestion des enseignants - Enseignants, matières')
    .addTag('Projects', 'Gestion des projets - Création, suivi, livrables')
    .addTag(
      'Promotions',
      "Gestion des promotions - Classes, groupes d'étudiants",
    )
    .addTag('Groups', 'Gestion des groupes - Équipes projet, compositions')
    .addTag(
      'Deliverables',
      'Gestion des livrables - Définition, règles de validation',
    )
    .addTag('Deliveries', 'Gestion des livraisons - Soumissions, corrections')
    .addTag('Reports', 'Gestion des rapports - Suivis, analyses, statistiques')
    .addTag('Notifications', 'Système de notifications - Alertes, rappels')
    .addTag('Scheduler', 'Tâches programmées - Jobs automatiques')
    .addTag(
      'Defenses',
      'Gestion des soutenances - Planification, sessions, exports',
    )
    .addTag(
      'Grading',
      'Gestion de la notation - Saisie notes, calculs moyennes',
    )
    .addTag(
      'Evaluation Grids',
      "Grilles d'évaluation - Création, gestion, application",
    )
    .build();

  const document = SwaggerModule.createDocument(app, config, {
    operationIdFactory: (controllerKey: string, methodKey: string) => methodKey,
    deepScanRoutes: true,
    ignoreGlobalPrefix: false,
    extraModels: [],
  });

  SwaggerModule.setup('api/docs', app, document, {
    swaggerOptions: {
      persistAuthorization: true,
      displayRequestDuration: true,
      docExpansion: 'none',
      filter: true,
      showExtensions: true,
      showCommonExtensions: true,
      tryItOutEnabled: true,
      defaultModelsExpandDepth: 2,
      defaultModelExpandDepth: 2,
      displayOperationId: false,
      maxDisplayedTags: 50,
      showMutatedRequest: true,
      supportedSubmitMethods: ['get', 'post', 'put', 'delete', 'patch'],
      validatorUrl: null,
      withCredentials: true,
      requestInterceptor: (req: Record<string, unknown>) => {
        // Ajouter des headers par défaut si nécessaire
        (req.headers as Record<string, string>)['Content-Type'] =
          'application/json';
        return req;
      },
      responseInterceptor: (res: Record<string, unknown>) => {
        // Log des réponses pour debug en mode développement
        if (process.env.NODE_ENV === 'development') {
          console.log('Swagger Response:', res.status, res.url);
        }
        return res;
      },
    },
    customSiteTitle: 'EduProTrack API Documentation',
    customfavIcon: '/favicon.ico',
    customCss: `
      .swagger-ui .topbar { display: none }
      .swagger-ui .info { margin: 20px 0 }
      .swagger-ui .scheme-container { background: #fafafa; padding: 15px; margin: 15px 0; border-radius: 4px }
      .swagger-ui .models { margin-top: 20px }
      .swagger-ui .model-box { background: #f9f9f9; border: 1px solid #e0e0e0; border-radius: 4px }
      .swagger-ui .parameters-col_description { word-break: break-word }
      .swagger-ui .response-col_description { word-break: break-word }
      .swagger-ui .opblock-summary-description { word-break: break-word }
      .swagger-ui .btn.try-out__btn { background: #4CAF50; color: white; border: none }
      .swagger-ui .btn.execute { background: #2196F3; color: white; border: none }
    `,
    customCssUrl: undefined,
  });

  const port = process.env.PORT;
  await app.listen(+port, '0.0.0.0');

  console.log(`🚀 Application EduProTrack démarrée sur le port ${port}`);
}

// 🚀 Démarrage de l'application avec gestion d'erreur
bootstrap().catch((error) => {
  console.error("❌ Erreur lors du démarrage de l'application:", error);
  process.exit(1);
});
