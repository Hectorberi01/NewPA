import { Test, TestingModule } from '@nestjs/testing';
import { GradeEntryService } from '../services/grade-entry.service';
import { PrismaService } from '../../prisma/prisma.service';
import { NotFoundException } from '@nestjs/common';
import { EvaluationType, EvaluationStatus } from '@prisma/client';

describe('GradeEntryService - Final Grade Calculation (US-GRA-003)', () => {
  let service: GradeEntryService;
  let prisma: PrismaService;

  const mockPrismaService = {
    evaluationGrid: {
      findMany: jest.fn(),
    },
    group: {
      findUnique: jest.fn(),
    },
    user: {
      findUnique: jest.fn(),
    },
    project: {
      findUnique: jest.fn(),
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GradeEntryService,
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
      ],
    }).compile();

    service = module.get<GradeEntryService>(GradeEntryService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('calculateProjectFinalGrade', () => {
    const projectId = 'project-1';
    const entityId = 'group-1';

    it('should calculate weighted average correctly', async () => {
      // GIVEN
      const mockGrids = [
        {
          id: 'grid-1',
          name: 'Livrable',
          type: EvaluationType.DELIVERABLE,
          weight: 50,
          criteria: [{ id: 'crit-1', maxPoints: 20 }],
          evaluations: [
            {
              totalScore: 16,
              finalizedAt: new Date(),
              grid: {
                id: 'grid-1',
                criteria: [{ id: 'crit-1', maxPoints: 20 }],
              },
            },
          ],
        },
        {
          id: 'grid-2',
          name: 'Rapport',
          type: EvaluationType.REPORT,
          weight: 30,
          criteria: [{ id: 'crit-2', maxPoints: 20 }],
          evaluations: [
            {
              totalScore: 14,
              finalizedAt: new Date(),
              grid: {
                id: 'grid-2',
                criteria: [{ id: 'crit-2', maxPoints: 20 }],
              },
            },
          ],
        },
        {
          id: 'grid-3',
          name: 'Soutenance',
          type: EvaluationType.DEFENSE,
          weight: 20,
          criteria: [{ id: 'crit-3', maxPoints: 20 }],
          evaluations: [
            {
              totalScore: 18,
              finalizedAt: new Date(),
              grid: {
                id: 'grid-3',
                criteria: [{ id: 'crit-3', maxPoints: 20 }],
              },
            },
          ],
        },
      ];

      const mockGroup = {
        id: 'group-1',
        name: 'Groupe A',
        members: [
          {
            user: {
              id: 'student-1',
              firstname: 'Jean',
              lastname: 'Dupont',
              email: 'jean.dupont@example.com',
            },
          },
        ],
      };

      mockPrismaService.evaluationGrid.findMany.mockResolvedValue(mockGrids);
      mockPrismaService.group.findUnique.mockResolvedValue(mockGroup);

      // WHEN
      const finalGrade = await service.calculateProjectFinalGrade(
        projectId,
        entityId,
      );

      // THEN
      // Expected calculation:
      // Livrable: (16/20) * 50 = 40
      // Rapport: (14/20) * 30 = 21
      // Soutenance: (18/20) * 20 = 18
      // Total weighted: 79
      // Final score: (79/100) * 20 = 15.8
      expect(finalGrade.finalScore).toBe(15.8);
      expect(finalGrade.percentage).toBe(79);
      expect(finalGrade.gridContributions).toHaveLength(3);
      expect(finalGrade.hasIncompleteParts).toBe(false);
      expect(finalGrade.calculationStrategy).toBe('WEIGHTED');
    });

    it('should handle missing components with EXCLUDE strategy', async () => {
      // GIVEN
      const mockGrids = [
        {
          id: 'grid-1',
          name: 'Livrable',
          type: EvaluationType.DELIVERABLE,
          weight: 50,
          criteria: [{ id: 'crit-1', maxPoints: 20 }],
          evaluations: [
            {
              totalScore: 16,
              finalizedAt: new Date(),
              grid: {
                id: 'grid-1',
                criteria: [{ id: 'crit-1', maxPoints: 20 }],
              },
            },
          ],
        },
        {
          id: 'grid-2',
          name: 'Rapport',
          type: EvaluationType.REPORT,
          weight: 30,
          criteria: [{ id: 'crit-2', maxPoints: 20 }],
          evaluations: [], // Missing evaluation
        },
        {
          id: 'grid-3',
          name: 'Soutenance',
          type: EvaluationType.DEFENSE,
          weight: 20,
          criteria: [{ id: 'crit-3', maxPoints: 20 }],
          evaluations: [
            {
              totalScore: 18,
              finalizedAt: new Date(),
              grid: {
                id: 'grid-3',
                criteria: [{ id: 'crit-3', maxPoints: 20 }],
              },
            },
          ],
        },
      ];

      const mockGroup = {
        id: 'group-1',
        name: 'Groupe A',
        members: [],
      };

      mockPrismaService.evaluationGrid.findMany.mockResolvedValue(mockGrids);
      mockPrismaService.group.findUnique.mockResolvedValue(mockGroup);

      // WHEN
      const finalGrade = await service.calculateProjectFinalGrade(
        projectId,
        entityId,
        { missingStrategy: 'EXCLUDE' },
      );

      // THEN
      expect(finalGrade.hasIncompleteParts).toBe(true);
      expect(finalGrade.calculationStrategy).toBe('EXCLUDE_MISSING');
      expect(finalGrade.includedWeight).toBe(70); // 50 + 20
    });

    it('should throw NotFoundException for invalid entity', async () => {
      // GIVEN
      mockPrismaService.evaluationGrid.findMany.mockResolvedValue([]);
      mockPrismaService.group.findUnique.mockResolvedValue(null);
      mockPrismaService.user.findUnique.mockResolvedValue(null);

      // WHEN & THEN
      await expect(
        service.calculateProjectFinalGrade(projectId, 'invalid-entity'),
      ).rejects.toThrow(NotFoundException);
    });
  });

  describe('getProjectFinalGrades', () => {
    const projectId = 'project-1';

    it('should return project overview with statistics', async () => {
      // GIVEN
      const mockProject = {
        id: projectId,
        name: 'Test Project',
        groups: [
          { id: 'group-1', name: 'Group 1', members: [] },
          { id: 'group-2', name: 'Group 2', members: [] },
        ],
      };

      mockPrismaService.project.findUnique.mockResolvedValue(mockProject);

      // Mock calculateProjectFinalGrade to return specific scores
      const originalMethod = service.calculateProjectFinalGrade;
      service.calculateProjectFinalGrade = jest
        .fn()
        .mockImplementation(async (projectId, entityId) => {
          const scores = { 'group-1': 16, 'group-2': 14 };
          return {
            entityId,
            finalScore: scores[entityId] || 0,
            entityType: 'GROUP',
            entityName: `Group ${entityId.split('-')[1]}`,
            projectId,
            maxScore: 20,
            percentage: (scores[entityId] || 0) * 5,
            totalWeight: 100,
            includedWeight: 100,
            hasIncompleteParts: false,
            calculationStrategy: 'WEIGHTED',
            gridContributions: [],
            calculatedAt: new Date(),
            entity: {
              id: entityId,
              name: `Group ${entityId.split('-')[1]}`,
              members: [],
            },
          };
        });

      // WHEN
      const result = await service.getProjectFinalGrades(projectId);

      // THEN
      expect(result.projectName).toBe('Test Project');
      expect(result.totalEntities).toBe(2);
      expect(result.completedEvaluations).toBe(2);
      expect(result.averageScore).toBe(15); // (16+14)/2

      // Restore original method
      service.calculateProjectFinalGrade = originalMethod;
    });

    it('should throw NotFoundException for invalid project', async () => {
      // GIVEN
      mockPrismaService.project.findUnique.mockResolvedValue(null);

      // WHEN & THEN
      await expect(
        service.getProjectFinalGrades('invalid-project'),
      ).rejects.toThrow(NotFoundException);
    });
  });

  describe('getEntityDetails', () => {
    it('should return group details correctly', async () => {
      // GIVEN
      const mockGroup = {
        id: 'group-1',
        name: 'Test Group',
        members: [
          {
            user: {
              id: 'student-1',
              firstname: 'Jean',
              lastname: 'Dupont',
              email: 'jean.dupont@example.com',
            },
          },
        ],
      };

      mockPrismaService.group.findUnique.mockResolvedValue(mockGroup);

      // WHEN
      const result = await service['getEntityDetails']('group-1');

      // THEN
      expect(result.type).toBe('GROUP');
      expect(result.name).toBe('Test Group');
      expect(result.details.members).toHaveLength(1);
      expect(result.details.members[0].firstname).toBe('Jean');
    });

    it('should throw NotFoundException for invalid entity', async () => {
      // GIVEN
      mockPrismaService.group.findUnique.mockResolvedValue(null);
      mockPrismaService.user.findUnique.mockResolvedValue(null);

      // WHEN & THEN
      await expect(
        service['getEntityDetails']('invalid-entity'),
      ).rejects.toThrow(NotFoundException);
    });
  });
});
