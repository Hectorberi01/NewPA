import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { EvaluationGridService } from '../services/evaluation-grid.service';
import { PrismaService } from '../../prisma/prisma.service';
import {
  CreateEvaluationGridDto,
  UpdateEvaluationGridDto,
  DuplicateToProjectDto,
  EvaluationType,
} from '../dto';

describe('EvaluationGridService', () => {
  let service: EvaluationGridService;
  let prisma: jest.Mocked<PrismaService>;

  const mockUserId = 'user123';
  const mockProjectId = 'project123';
  const mockTemplateId = 'template123';
  const mockGridId = 'grid123';

  const mockTemplate = {
    id: mockTemplateId,
    name: 'Template Test',
    projectId: null,
    type: EvaluationType.DELIVERABLE,
    weight: 0.3,
    isTemplate: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    criteria: [
      {
        id: 'crit1',
        name: 'Critère 1',
        description: 'Description 1',
        maxPoints: 5,
        weight: 50,
        order: 1,
        gridId: mockTemplateId,
        scope: 'GROUP',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: 'crit2',
        name: 'Critère 2',
        description: 'Description 2',
        maxPoints: 5,
        weight: 50,
        order: 2,
        gridId: mockTemplateId,
        scope: 'GROUP',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ],
    _count: { evaluations: 0 },
  };

  const mockProject = {
    id: mockProjectId,
    name: 'Test Project',
    userId: mockUserId,
  };

  beforeEach(async () => {
    const mockPrisma = {
      evaluationGrid: {
        findMany: jest.fn(),
        findFirst: jest.fn(),
        findUnique: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
      },
      evaluationCriterion: {
        deleteMany: jest.fn(),
        createMany: jest.fn(),
      },
      project: {
        findFirst: jest.fn(),
        findUnique: jest.fn(),
      },
      deliverable: {
        findFirst: jest.fn(),
        update: jest.fn(),
      },
      $transaction: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EvaluationGridService,
        {
          provide: PrismaService,
          useValue: mockPrisma,
        },
      ],
    }).compile();

    service = module.get<EvaluationGridService>(EvaluationGridService);
    prisma = module.get(PrismaService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe.skip('getTemplates', () => {
    it('should return all templates', async () => {
      const expectedTemplates = [mockTemplate];
      prisma.evaluationGrid.findMany.mockResolvedValue(expectedTemplates);

      const result = await service.getTemplates();

      expect(result).toEqual(expectedTemplates);
      expect(prisma.evaluationGrid.findMany).toHaveBeenCalledWith({
        where: {
          isTemplate: true,
          projectId: null,
        },
        include: {
          criteria: {
            orderBy: { order: 'asc' },
          },
          _count: {
            select: {
              evaluations: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
      });
    });
  });

  describe.skip('createTemplate', () => {
    const createTemplateDto: CreateEvaluationGridDto = {
      name: 'New Template',
      type: EvaluationType.DELIVERABLE,
      weight: 0.3,
      criteria: [
        {
          name: 'Critère 1',
          maxPoints: 5,
          weight: 50,
          order: 1,
        },
        {
          name: 'Critère 2',
          maxPoints: 5,
          weight: 50,
          order: 2,
        },
      ],
    };

    it('should create a template successfully', async () => {
      const createdTemplate = { ...mockTemplate, ...createTemplateDto };
      prisma.evaluationGrid.create.mockResolvedValue(createdTemplate);

      const result = await service.createTemplate(
        createTemplateDto,
        mockUserId,
      );

      expect(result).toEqual(createdTemplate);
      expect(prisma.evaluationGrid.create).toHaveBeenCalledWith({
        data: {
          name: createTemplateDto.name,
          projectId: null,
          type: createTemplateDto.type,
          weight: createTemplateDto.weight,
          isTemplate: true,
          criteria: {
            create: createTemplateDto.criteria.map((criterion, index) => ({
              name: criterion.name,
              description: criterion.description,
              maxPoints: criterion.maxPoints,
              weight: criterion.weight,
              order: criterion.order ?? index,
            })),
          },
        },
        include: {
          criteria: {
            orderBy: { order: 'asc' },
          },
        },
      });
    });

    it('should throw BadRequestException when criteria weights do not sum to 100', async () => {
      const invalidDto = {
        ...createTemplateDto,
        criteria: [
          { name: 'Critère 1', maxPoints: 5, weight: 30 },
          { name: 'Critère 2', maxPoints: 5, weight: 30 },
        ],
      };

      await expect(
        service.createTemplate(invalidDto, mockUserId),
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe.skip('updateTemplate', () => {
    const updateDto: UpdateEvaluationGridDto = {
      name: 'Updated Template',
      criteria: [
        {
          name: 'Updated Critère 1',
          maxPoints: 4,
          weight: 60,
        },
        {
          name: 'Updated Critère 2',
          maxPoints: 6,
          weight: 40,
        },
      ],
    };

    it('should update template successfully', async () => {
      prisma.evaluationGrid.findFirst.mockResolvedValue(mockTemplate);

      const mockTransaction = jest.fn().mockImplementation((callback) =>
        callback({
          evaluationGrid: {
            update: jest
              .fn()
              .mockResolvedValue({ ...mockTemplate, ...updateDto }),
            findUnique: jest
              .fn()
              .mockResolvedValue({ ...mockTemplate, ...updateDto }),
          },
          evaluationCriterion: {
            deleteMany: jest.fn(),
            createMany: jest.fn(),
          },
        }),
      );
      prisma.$transaction.mockImplementation(mockTransaction);

      const result = await service.updateTemplate(
        mockTemplateId,
        updateDto,
        mockUserId,
      );

      expect(result).toBeDefined();
      expect(prisma.evaluationGrid.findFirst).toHaveBeenCalledWith({
        where: {
          id: mockTemplateId,
          isTemplate: true,
          projectId: null,
        },
      });
    });

    it('should throw NotFoundException when template does not exist', async () => {
      prisma.evaluationGrid.findFirst.mockResolvedValue(null);

      await expect(
        service.updateTemplate(mockTemplateId, updateDto, mockUserId),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw BadRequestException when criteria weights are invalid', async () => {
      prisma.evaluationGrid.findFirst.mockResolvedValue(mockTemplate);

      const invalidUpdateDto = {
        ...updateDto,
        criteria: [
          { name: 'Critère 1', maxPoints: 5, weight: 30 },
          { name: 'Critère 2', maxPoints: 5, weight: 30 },
        ],
      };

      await expect(
        service.updateTemplate(mockTemplateId, invalidUpdateDto, mockUserId),
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe.skip('deleteTemplate', () => {
    it('should delete template successfully', async () => {
      prisma.evaluationGrid.findFirst.mockResolvedValue(mockTemplate);
      prisma.evaluationGrid.delete.mockResolvedValue(mockTemplate);

      await service.deleteTemplate(mockTemplateId, mockUserId);

      expect(prisma.evaluationGrid.delete).toHaveBeenCalledWith({
        where: { id: mockTemplateId },
      });
    });

    it('should throw NotFoundException when template does not exist', async () => {
      prisma.evaluationGrid.findFirst.mockResolvedValue(null);

      await expect(
        service.deleteTemplate(mockTemplateId, mockUserId),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw BadRequestException when template is being used', async () => {
      const usedTemplate = { ...mockTemplate, _count: { evaluations: 5 } };
      prisma.evaluationGrid.findFirst.mockResolvedValue(usedTemplate);

      await expect(
        service.deleteTemplate(mockTemplateId, mockUserId),
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe.skip('getProjectGrids', () => {
    it('should return project grids after validating access', async () => {
      prisma.project.findFirst.mockResolvedValue(mockProject);
      const projectGrids = [
        { ...mockTemplate, projectId: mockProjectId, isTemplate: false },
      ];
      prisma.evaluationGrid.findMany.mockResolvedValue(projectGrids);

      const result = await service.getProjectGrids(mockProjectId, mockUserId);

      expect(result).toEqual(projectGrids);
      expect(prisma.project.findFirst).toHaveBeenCalledWith({
        where: {
          id: mockProjectId,
          userId: mockUserId,
        },
      });
    });

    it('should throw NotFoundException when user has no access to project', async () => {
      prisma.project.findFirst.mockResolvedValue(null);

      await expect(
        service.getProjectGrids(mockProjectId, mockUserId),
      ).rejects.toThrow(NotFoundException);
    });
  });

  describe.skip('duplicateTemplateToProject', () => {
    const duplicateDto: DuplicateToProjectDto = {
      projectId: mockProjectId,
      name: 'Duplicated Grid',
    };

    it('should duplicate template to project successfully', async () => {
      prisma.evaluationGrid.findFirst
        .mockResolvedValueOnce(mockTemplate) // Template exists
        .mockResolvedValueOnce(null); // Project access check passes in validateProjectAccess

      prisma.project.findFirst.mockResolvedValue(mockProject);

      const duplicatedGrid = {
        ...mockTemplate,
        id: 'newgrid123',
        name: duplicateDto.name,
        projectId: duplicateDto.projectId,
        isTemplate: false,
        project: { id: mockProjectId, name: 'Test Project' },
      };

      prisma.evaluationGrid.create.mockResolvedValue(duplicatedGrid);

      const result = await service.duplicateTemplateToProject(
        mockTemplateId,
        duplicateDto,
        mockUserId,
      );

      expect(result).toEqual(duplicatedGrid);
      expect(prisma.evaluationGrid.findFirst).toHaveBeenCalledWith({
        where: {
          id: mockTemplateId,
          isTemplate: true,
          projectId: null,
        },
        include: {
          criteria: {
            orderBy: { order: 'asc' },
          },
        },
      });
    });

    it('should throw NotFoundException when template does not exist', async () => {
      prisma.evaluationGrid.findFirst.mockResolvedValue(null);

      await expect(
        service.duplicateTemplateToProject(
          mockTemplateId,
          duplicateDto,
          mockUserId,
        ),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException when user has no access to target project', async () => {
      prisma.evaluationGrid.findFirst.mockResolvedValue(mockTemplate);
      prisma.project.findFirst.mockResolvedValue(null);

      await expect(
        service.duplicateTemplateToProject(
          mockTemplateId,
          duplicateDto,
          mockUserId,
        ),
      ).rejects.toThrow(NotFoundException);
    });
  });

  describe('getGrid', () => {
    it('should return grid when user has access', async () => {
      const gridWithDetails = {
        ...mockTemplate,
        project: { id: mockProjectId, name: 'Test Project' },
        _count: { evaluations: 3 },
      };
      prisma.evaluationGrid.findFirst.mockResolvedValue(gridWithDetails);

      const result = await service.getGrid(mockGridId, mockUserId);

      expect(result).toEqual({
        ...gridWithDetails,
        criteria: gridWithDetails.criteria,
        project: gridWithDetails.project,
        evaluationCount: 3,
      });
    });

    it('should throw NotFoundException when grid not found or no access', async () => {
      prisma.evaluationGrid.findFirst.mockResolvedValue(null);

      await expect(service.getGrid(mockGridId, mockUserId)).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  describe.skip('assignGridToDeliverable', () => {
    const deliverableId = 'deliverable123';

    it('should assign grid to deliverable successfully', async () => {
      const mockDeliverable = {
        id: deliverableId,
        project: { userId: mockUserId },
      };
      const mockGrid = { ...mockTemplate, project: { userId: mockUserId } };

      prisma.deliverable.findFirst.mockResolvedValue(mockDeliverable);
      prisma.evaluationGrid.findFirst.mockResolvedValue(mockGrid);
      prisma.deliverable.update.mockResolvedValue({
        ...mockDeliverable,
        evaluationGridId: mockGridId,
      });

      await service.assignGridToDeliverable(
        deliverableId,
        mockGridId,
        mockUserId,
      );

      expect(prisma.deliverable.update).toHaveBeenCalledWith({
        where: { id: deliverableId },
        data: { evaluationGridId: mockGridId },
      });
    });

    it('should throw NotFoundException when deliverable not found', async () => {
      prisma.deliverable.findFirst.mockResolvedValue(null);

      await expect(
        service.assignGridToDeliverable(deliverableId, mockGridId, mockUserId),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException when grid not found', async () => {
      const mockDeliverable = {
        id: deliverableId,
        project: { userId: mockUserId },
      };

      prisma.deliverable.findFirst.mockResolvedValue(mockDeliverable);
      prisma.evaluationGrid.findFirst.mockResolvedValue(null);

      await expect(
        service.assignGridToDeliverable(deliverableId, mockGridId, mockUserId),
      ).rejects.toThrow(NotFoundException);
    });
  });

  describe('validateProjectAccess (private method)', () => {
    it('should not throw when user has access to project', async () => {
      prisma.project.findFirst.mockResolvedValue(mockProject);

      // Test through a public method that calls validateProjectAccess
      await expect(
        service.getProjectGrids(mockProjectId, mockUserId),
      ).resolves.toBeDefined();
    });

    it('should throw NotFoundException when user has no access to project', async () => {
      prisma.project.findFirst.mockResolvedValue(null);

      // Test through a public method that calls validateProjectAccess
      await expect(
        service.getProjectGrids(mockProjectId, mockUserId),
      ).rejects.toThrow(NotFoundException);
    });
  });
});
