import { Test, TestingModule } from '@nestjs/testing';
import { GradingController } from '../grading.controller';
import { GradeEntryService } from '../services/grade-entry.service';
import { EvaluationGridService } from '../services/evaluation-grid.service';
import { JWTAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../../auth/guards/teacher.guard';
import { User } from '@prisma/client';

describe('GradingController - Final Grade Endpoints (US-GRA-003)', () => {
  let controller: GradingController;
  let gradeEntryService: GradeEntryService;

  const mockGradeEntryService = {
    getProjectFinalGrades: jest.fn(),
    calculateProjectFinalGrade: jest.fn(),
    recalculateProjectFinalGrades: jest.fn(),
  };

  const mockEvaluationGridService = {
    getByProject: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
  };

  const mockUser: User = {
    id: 'teacher-1',
    email: 'teacher@example.com',
    firstname: 'Test',
    lastname: 'Teacher',
    role: 'TEACHER',
    password: 'hashed',
    accessToken: null,
    refreshToken: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GradingController],
      providers: [
        {
          provide: GradeEntryService,
          useValue: mockGradeEntryService,
        },
        {
          provide: EvaluationGridService,
          useValue: mockEvaluationGridService,
        },
      ],
    })
      .overrideGuard(JWTAuthGuard)
      .useValue({ canActivate: jest.fn(() => true) })
      .overrideGuard(TeacherGuard)
      .useValue({ canActivate: jest.fn(() => true) })
      .compile();

    controller = module.get<GradingController>(GradingController);
    gradeEntryService = module.get<GradeEntryService>(GradeEntryService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('GET /grade-entries/project/:projectId/final-grades', () => {
    const projectId = 'project-1';

    it('should return project final grades with default options', async () => {
      // GIVEN
      const mockResponse = {
        projectId,
        projectName: 'Test Project',
        totalEntities: 3,
        completedEvaluations: 2,
        averageScore: 15.5,
        maxScore: 20,
        finalGrades: [
          {
            entityId: 'group-1',
            entityType: 'GROUP',
            entityName: 'Group 1',
            finalScore: 16.0,
            percentage: 80.0,
          },
          {
            entityId: 'group-2',
            entityType: 'GROUP',
            entityName: 'Group 2',
            finalScore: 15.0,
            percentage: 75.0,
          },
        ],
        lastCalculatedAt: new Date(),
        statistics: {
          min: 15.0,
          max: 16.0,
          median: 15.5,
          standardDeviation: 0.5,
          distribution: [
            { range: '0-5', count: 0 },
            { range: '5-10', count: 0 },
            { range: '10-15', count: 1 },
            { range: '15-20', count: 1 },
          ],
        },
      };

      mockGradeEntryService.getProjectFinalGrades.mockResolvedValue(
        mockResponse,
      );

      // WHEN
      const result = await controller.getProjectFinalGrades(projectId);

      // THEN
      expect(service.getProjectFinalGrades).toHaveBeenCalledWith(projectId, {
        missingStrategy: 'PROPORTIONAL',
        includeVisibleOnly: false,
        includeFinalizedOnly: true,
        includeStatistics: true,
      });
      expect(result).toBeDefined();
      expect(result.projectId).toBe(projectId);
      expect(result.finalGrades).toHaveLength(2);
    });

    it('should handle query parameters correctly', async () => {
      // GIVEN
      const mockResponse = {
        projectId,
        projectName: 'Test Project',
        totalEntities: 2,
        completedEvaluations: 2,
        averageScore: 14.0,
        maxScore: 20,
        finalGrades: [],
        lastCalculatedAt: new Date(),
      };

      mockGradeEntryService.getProjectFinalGrades.mockResolvedValue(
        mockResponse,
      );

      // WHEN
      await controller.getProjectFinalGrades(
        projectId,
        'EXCLUDE',
        'true',
        'false',
        'false',
      );

      // THEN
      expect(service.getProjectFinalGrades).toHaveBeenCalledWith(projectId, {
        missingStrategy: 'EXCLUDE',
        includeVisibleOnly: true,
        includeFinalizedOnly: false,
        includeStatistics: false,
      });
    });

    it('should use default values for missing query parameters', async () => {
      // GIVEN
      const mockResponse = {
        projectId,
        projectName: 'Test Project',
        finalGrades: [],
        lastCalculatedAt: new Date(),
      };

      mockGradeEntryService.getProjectFinalGrades.mockResolvedValue(
        mockResponse,
      );

      // WHEN
      await controller.getProjectFinalGrades(
        projectId,
        undefined,
        undefined,
        undefined,
        undefined,
      );

      // THEN
      expect(service.getProjectFinalGrades).toHaveBeenCalledWith(projectId, {
        missingStrategy: 'PROPORTIONAL',
        includeVisibleOnly: false,
        includeFinalizedOnly: true,
        includeStatistics: true,
      });
    });
  });

  describe('GET /grade-entries/entity/:entityId/final-grade', () => {
    const entityId = 'group-1';
    const projectId = 'project-1';

    it('should return entity final grade', async () => {
      // GIVEN
      const mockResponse = {
        entityId,
        entityType: 'GROUP',
        entityName: 'Group 1',
        projectId,
        finalScore: 16.5,
        maxScore: 20,
        percentage: 82.5,
        totalWeight: 100,
        includedWeight: 100,
        hasIncompleteParts: false,
        calculationStrategy: 'WEIGHTED',
        gridContributions: [
          {
            gridId: 'grid-1',
            gridName: 'Livrable',
            gridType: 'DELIVERABLE',
            score: 17,
            maxScore: 20,
            weight: 50,
            contribution: 8.5,
            isCompleted: true,
            isMissing: false,
          },
          {
            gridId: 'grid-2',
            gridName: 'Rapport',
            gridType: 'REPORT',
            score: 15,
            maxScore: 20,
            weight: 30,
            contribution: 4.5,
            isCompleted: true,
            isMissing: false,
          },
          {
            gridId: 'grid-3',
            gridName: 'Soutenance',
            gridType: 'DEFENSE',
            score: 18,
            maxScore: 20,
            weight: 20,
            contribution: 3.6,
            isCompleted: true,
            isMissing: false,
          },
        ],
        calculatedAt: new Date(),
        entity: {
          id: entityId,
          name: 'Group 1',
          members: [],
        },
      };

      mockGradeEntryService.calculateProjectFinalGrade.mockResolvedValue(
        mockResponse,
      );

      // WHEN
      const result = await controller.getEntityFinalGrade(entityId, projectId);

      // THEN
      expect(service.calculateProjectFinalGrade).toHaveBeenCalledWith(
        projectId,
        entityId,
        {
          missingStrategy: 'PROPORTIONAL',
          includeVisibleOnly: false,
          includeFinalizedOnly: true,
        },
      );
      expect(result).toBeDefined();
      expect(result.entityId).toBe(entityId);
      expect(result.finalScore).toBe(16.5);
      expect(result.gridContributions).toHaveLength(3);
    });

    it('should throw error when projectId is missing', async () => {
      // WHEN & THEN
      await expect(
        controller.getEntityFinalGrade(entityId, undefined),
      ).rejects.toThrow('Project ID is required');
    });

    it('should handle query parameters correctly', async () => {
      // GIVEN
      const mockResponse = {
        entityId,
        entityType: 'GROUP',
        finalScore: 14.0,
        gridContributions: [],
        calculatedAt: new Date(),
      };

      mockGradeEntryService.calculateProjectFinalGrade.mockResolvedValue(
        mockResponse,
      );

      // WHEN
      await controller.getEntityFinalGrade(
        entityId,
        projectId,
        'ZERO',
        'true',
        'false',
      );

      // THEN
      expect(service.calculateProjectFinalGrade).toHaveBeenCalledWith(
        projectId,
        entityId,
        {
          missingStrategy: 'ZERO',
          includeVisibleOnly: true,
          includeFinalizedOnly: false,
        },
      );
    });
  });

  describe('POST /grade-entries/project/:projectId/recalculate', () => {
    const projectId = 'project-1';

    it('should recalculate project final grades', async () => {
      // GIVEN
      const mockResponse = {
        projectId,
        projectName: 'Test Project',
        totalEntities: 2,
        completedEvaluations: 2,
        averageScore: 15.0,
        maxScore: 20,
        finalGrades: [
          {
            entityId: 'group-1',
            finalScore: 16.0,
          },
          {
            entityId: 'group-2',
            finalScore: 14.0,
          },
        ],
        lastCalculatedAt: new Date(),
      };

      mockGradeEntryService.recalculateProjectFinalGrades.mockResolvedValue(
        mockResponse,
      );

      // WHEN
      const result = await controller.recalculateProjectFinalGrades(projectId);

      // THEN
      expect(service.recalculateProjectFinalGrades).toHaveBeenCalledWith(
        projectId,
      );
      expect(result).toBeDefined();
      expect(result.projectId).toBe(projectId);
      expect(result.finalGrades).toHaveLength(2);
    });

    it('should handle service errors properly', async () => {
      // GIVEN
      mockGradeEntryService.recalculateProjectFinalGrades.mockRejectedValue(
        new Error('Database error'),
      );

      // WHEN & THEN
      await expect(
        controller.recalculateProjectFinalGrades(projectId),
      ).rejects.toThrow('Database error');
    });
  });

  describe('Class transformer integration', () => {
    it('should properly transform response DTOs', async () => {
      // GIVEN
      const mockResponse = {
        projectId: 'project-1',
        projectName: 'Test Project',
        finalGrades: [],
        lastCalculatedAt: new Date(),
        internalField: 'should be excluded', // This should be excluded by @Expose
      };

      mockGradeEntryService.getProjectFinalGrades.mockResolvedValue(
        mockResponse,
      );

      // WHEN
      const result = await controller.getProjectFinalGrades('project-1');

      // THEN
      expect(result).toBeDefined();
      expect(result.projectId).toBe('project-1');
      expect(result.projectName).toBe('Test Project');
      // Internal field should be excluded by class-transformer
      expect((result as any).internalField).toBeUndefined();
    });
  });
});
