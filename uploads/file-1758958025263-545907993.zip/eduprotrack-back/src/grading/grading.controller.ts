import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
  ApiOkResponse,
  ApiCreatedResponse,
  ApiBadRequestResponse,
  ApiUnauthorizedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
} from '@nestjs/swagger';
import { EvaluationGridService } from './services/evaluation-grid.service';
import { GradeEntryService } from './services/grade-entry.service';
import {
  CreateEvaluationGridDto,
  UpdateEvaluationGridDto,
  EvaluationGridResponseDto,
  CreateEvaluationCriterionDto,
  CreateGradeEntryDto,
  UpdateGradeEntryDto,
  GradeEntryResponseDto,
} from './dto';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { AuthenticatedRequest } from '../auth/types/auth.types';

@ApiTags('Grading')
@Controller('grading')
@UseGuards(JWTAuthGuard)
@ApiBearerAuth('JWT-auth')
export class GradingController {
  constructor(
    private readonly evaluationGridService: EvaluationGridService,
    private readonly gradeEntryService: GradeEntryService,
  ) {}

  // ============================================================================
  // EVALUATION GRIDS MANAGEMENT
  // ============================================================================

  @Get('projects/:projectId/grids')
  @ApiOperation({
    summary: "Lister les grilles d'un projet",
    description:
      "Récupère toutes les grilles d'évaluation d'un projet spécifique",
  })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiOkResponse({
    description: 'Liste des grilles du projet récupérée avec succès',
    type: [EvaluationGridResponseDto],
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({
    description: 'Accès réservé aux enseignants ou accès au projet refusé',
  })
  @ApiNotFoundResponse({ description: 'Projet non trouvé' })
  async getProjectGrids(
    @Param('projectId') projectId: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<EvaluationGridResponseDto[]> {
    return this.evaluationGridService.getProjectGrids(projectId, req.user.id);
  }

  @Get('projects/:projectId/grids/default')
  @ApiOperation({
    summary: "Récupérer la grille par défaut d'un projet",
    description:
      "Récupère la première grille d'évaluation disponible pour un projet (pour l'app mobile)",
  })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiOkResponse({
    description: 'Grille par défaut récupérée avec succès',
    type: EvaluationGridResponseDto,
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({
    description: 'Accès réservé aux enseignants ou accès au projet refusé',
  })
  @ApiNotFoundResponse({ description: 'Aucune grille trouvée pour ce projet' })
  async getProjectDefaultGrid(
    @Param('projectId') projectId: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<EvaluationGridResponseDto> {
    return this.evaluationGridService.getProjectDefaultGrid(
      projectId,
      req.user.id,
    );
  }

  @Post('projects/:projectId/grids')
  @ApiOperation({
    summary: 'Créer une grille pour un projet',
    description: "Crée une nouvelle grille d'évaluation spécifique à un projet",
  })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiBody({ type: CreateEvaluationGridDto })
  @ApiCreatedResponse({
    description: 'Grille de projet créée avec succès',
    type: EvaluationGridResponseDto,
  })
  @ApiBadRequestResponse({
    description: 'Données invalides ou poids des critères incorrects',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({
    description: 'Accès réservé aux enseignants ou accès au projet refusé',
  })
  @ApiNotFoundResponse({ description: 'Projet non trouvé' })
  async createProjectGrid(
    @Param('projectId') projectId: string,
    @Body() dto: CreateEvaluationGridDto,
    @Req() req: AuthenticatedRequest,
  ): Promise<EvaluationGridResponseDto> {
    return this.evaluationGridService.createProjectGrid(
      projectId,
      dto,
      req.user.id,
    );
  }

  @Get('grids/:id')
  @ApiOperation({
    summary: 'Récupérer une grille par ID',
    description: "Récupère les détails d'une grille d'évaluation spécifique",
  })
  @ApiParam({ name: 'id', description: 'ID de la grille' })
  @ApiOkResponse({
    description: 'Grille récupérée avec succès',
    type: EvaluationGridResponseDto,
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({
    description: 'Accès réservé aux enseignants ou accès refusé',
  })
  @ApiNotFoundResponse({ description: 'Grille non trouvée' })
  async getGrid(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<EvaluationGridResponseDto> {
    return this.evaluationGridService.getGrid(id, req.user.id);
  }

  @Put('grids/:id')
  @ApiOperation({
    summary: 'Mettre à jour une grille',
    description: "Met à jour une grille d'évaluation existante",
  })
  @ApiParam({ name: 'id', description: 'ID de la grille à mettre à jour' })
  @ApiBody({ type: UpdateEvaluationGridDto })
  @ApiOkResponse({
    description: 'Grille mise à jour avec succès',
    type: EvaluationGridResponseDto,
  })
  @ApiBadRequestResponse({
    description: 'Données invalides ou poids des critères incorrects',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({
    description: 'Accès réservé aux enseignants ou accès refusé',
  })
  @ApiNotFoundResponse({ description: 'Grille non trouvée' })
  async updateGrid(
    @Param('id') id: string,
    @Body() dto: UpdateEvaluationGridDto,
    @Req() req: AuthenticatedRequest,
  ): Promise<EvaluationGridResponseDto> {
    return this.evaluationGridService.updateGrid(id, dto, req.user.id);
  }

  @Delete('grids/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({
    summary: 'Supprimer une grille',
    description:
      "Supprime une grille d'évaluation (impossible si utilisée dans des évaluations)",
  })
  @ApiParam({ name: 'id', description: 'ID de la grille à supprimer' })
  @ApiResponse({ status: 204, description: 'Grille supprimée avec succès' })
  @ApiBadRequestResponse({
    description: 'Grille utilisée dans des évaluations, suppression impossible',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({
    description: 'Accès réservé aux enseignants ou accès refusé',
  })
  @ApiNotFoundResponse({ description: 'Grille non trouvée' })
  async deleteGrid(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<void> {
    return this.evaluationGridService.deleteGrid(id, req.user.id);
  }

  @Post('grids/:id/criteria')
  @ApiOperation({
    summary: 'Ajouter un critère à une grille',
    description:
      "Ajoute un nouveau critère d'évaluation à une grille existante",
  })
  @ApiParam({ name: 'id', description: 'ID de la grille' })
  @ApiBody({ type: CreateEvaluationCriterionDto })
  @ApiCreatedResponse({
    description: 'Critère ajouté avec succès',
    type: EvaluationGridResponseDto,
  })
  @ApiBadRequestResponse({
    description: 'Données invalides ou poids des critères incorrects',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({
    description: 'Accès réservé aux enseignants ou accès refusé',
  })
  @ApiNotFoundResponse({ description: 'Grille non trouvée' })
  async addCriterionToGrid(
    @Param('id') gridId: string,
    @Body() dto: CreateEvaluationCriterionDto,
    @Req() req: AuthenticatedRequest,
  ): Promise<EvaluationGridResponseDto> {
    return this.evaluationGridService.addCriterionToGrid(
      gridId,
      dto,
      req.user.id,
    );
  }

  // ============================================================================
  // GRADE ENTRIES MANAGEMENT
  // ============================================================================

  @Post('evaluations')
  @ApiOperation({
    summary: 'Créer une nouvelle évaluation',
    description:
      'Permet à un enseignant de créer une nouvelle évaluation pour un groupe ou un étudiant',
  })
  @ApiBody({ type: CreateGradeEntryDto })
  @ApiCreatedResponse({
    description: 'Évaluation créée avec succès',
    type: GradeEntryResponseDto,
  })
  @ApiBadRequestResponse({
    description: 'Données invalides ou grille non trouvée',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  async createGradeEntry(
    @Body() dto: CreateGradeEntryDto,
    @Req() req: AuthenticatedRequest,
  ): Promise<GradeEntryResponseDto> {
    return this.gradeEntryService.createGradeEntry(dto, req.user.id);
  }

  @Get('evaluations/grid/:gridId')
  @ApiOperation({
    summary: 'Lister les évaluations par grille',
    description: "Récupère toutes les évaluations d'une grille spécifique",
  })
  @ApiParam({ name: 'gridId', description: 'ID de la grille' })
  @ApiOkResponse({
    description: 'Liste des évaluations récupérée avec succès',
    type: [GradeEntryResponseDto],
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  @ApiNotFoundResponse({ description: 'Grille non trouvée' })
  async getGradeEntriesByGrid(
    @Param('gridId') gridId: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<GradeEntryResponseDto[]> {
    return this.gradeEntryService.getGradeEntriesByGrid(gridId, req.user.id);
  }

  @Get('evaluations/:id')
  @ApiOperation({
    summary: 'Récupérer une évaluation par ID',
    description: "Récupère les détails d'une évaluation spécifique",
  })
  @ApiParam({ name: 'id', description: "ID de l'évaluation" })
  @ApiOkResponse({
    description: 'Évaluation récupérée avec succès',
    type: GradeEntryResponseDto,
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  @ApiNotFoundResponse({ description: 'Évaluation non trouvée' })
  async getGradeEntry(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<GradeEntryResponseDto> {
    return this.gradeEntryService.getGradeEntry(id, req.user.id);
  }

  @Put('evaluations/:id')
  @ApiOperation({
    summary: 'Mettre à jour une évaluation',
    description: 'Met à jour une évaluation existante',
  })
  @ApiParam({ name: 'id', description: "ID de l'évaluation à mettre à jour" })
  @ApiBody({ type: UpdateGradeEntryDto })
  @ApiOkResponse({
    description: 'Évaluation mise à jour avec succès',
    type: GradeEntryResponseDto,
  })
  @ApiBadRequestResponse({
    description: 'Données invalides',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  @ApiNotFoundResponse({ description: 'Évaluation non trouvée' })
  async updateGradeEntry(
    @Param('id') id: string,
    @Body() dto: UpdateGradeEntryDto,
    @Req() req: AuthenticatedRequest,
  ): Promise<GradeEntryResponseDto> {
    return this.gradeEntryService.updateGradeEntry(id, dto, req.user.id);
  }

  @Delete('evaluations/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({
    summary: 'Supprimer une évaluation',
    description: 'Supprime une évaluation',
  })
  @ApiParam({ name: 'id', description: "ID de l'évaluation à supprimer" })
  @ApiResponse({ status: 204, description: 'Évaluation supprimée avec succès' })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  @ApiNotFoundResponse({ description: 'Évaluation non trouvée' })
  async deleteGradeEntry(
    @Param('id') id: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<{ message: string }> {
    return this.gradeEntryService.deleteGradeEntry(id, req.user.id);
  }

  @Get('evaluations/group/:groupId')
  @ApiOperation({
    summary: 'Lister les évaluations par groupe',
    description: "Récupère toutes les évaluations d'un groupe spécifique",
  })
  @ApiParam({ name: 'groupId', description: 'ID du groupe' })
  @ApiOkResponse({
    description: 'Liste des évaluations du groupe récupérée avec succès',
    type: [GradeEntryResponseDto],
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  @ApiNotFoundResponse({ description: 'Groupe non trouvé' })
  async getGradeEntriesByGroup(
    @Param('groupId') groupId: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<GradeEntryResponseDto[]> {
    return this.gradeEntryService.getGradeEntriesByGroup(groupId, req.user.id);
  }

  @Get('evaluations/evaluation/:entityId')
  @ApiOperation({
    summary: 'Récupérer une évaluation par entité',
    description:
      'Récupère une évaluation existante pour une entité spécifique (groupe ou étudiant)',
  })
  @ApiParam({
    name: 'entityId',
    description: "ID de l'entité évaluée (groupe ou étudiant)",
  })
  @ApiOkResponse({
    description: 'Évaluation récupérée avec succès',
    type: GradeEntryResponseDto,
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  @ApiNotFoundResponse({ description: 'Évaluation non trouvée' })
  async getGradeEntryByEntity(
    @Param('entityId') entityId: string,
    @Query('entityType') entityType: 'GROUP' | 'STUDENT',
    @Query('projectId') projectId: string,
    @Req() req: AuthenticatedRequest,
  ): Promise<GradeEntryResponseDto> {
    return this.gradeEntryService.getGradeEntryByEntity(
      entityId,
      entityType,
      projectId,
      req.user.id,
    );
  }

  @Post('evaluations/publish')
  @ApiOperation({
    summary: "Publier les notes d'un groupe",
    description:
      "Met à jour le statut des évaluations d'un groupe pour les publier",
  })
  @ApiBody({
    schema: {
      properties: {
        projectId: { type: 'string' },
        groupId: { type: 'string' },
      },
      required: ['projectId', 'groupId'],
    },
  })
  @ApiOkResponse({
    description: 'Notes publiées avec succès',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  async publishGrades(
    @Body() body: { projectId: string; groupId: string },
    @Req() req: AuthenticatedRequest,
  ): Promise<{ message: string; publishedCount: number }> {
    return this.gradeEntryService.publishGrades(
      body.projectId,
      body.groupId,
      req.user.id,
    );
  }
}
