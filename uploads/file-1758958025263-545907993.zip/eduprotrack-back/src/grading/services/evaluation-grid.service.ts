import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import {
  CreateEvaluationGridDto,
  UpdateEvaluationGridDto,
  EvaluationGridResponseDto,
  CreateEvaluationCriterionDto,
} from '../dto';

@Injectable()
export class EvaluationGridService {
  constructor(private prisma: PrismaService) {}

  async getProjectGrids(
    projectId: string,
    userId: string,
  ): Promise<EvaluationGridResponseDto[]> {
    const project = await this.prisma.project.findFirst({
      where: {
        id: projectId,
        userId: userId,
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé ou accès refusé');
    }

    const grids = await this.prisma.evaluationGrid.findMany({
      where: {
        projectId,
        isTemplate: false,
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
        _count: {
          select: {
            evaluations: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return grids.map((grid) => ({
      ...grid,
      criteria: grid.criteria,
      evaluationCount: grid._count.evaluations,
    }));
  }

  async getProjectDefaultGrid(
    projectId: string,
    userId: string,
  ): Promise<EvaluationGridResponseDto> {
    const project = await this.prisma.project.findFirst({
      where: {
        id: projectId,
        userId: userId,
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé ou accès refusé');
    }

    const grid = await this.prisma.evaluationGrid.findFirst({
      where: {
        projectId,
        isTemplate: false,
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
        _count: {
          select: {
            evaluations: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    if (!grid) {
      throw new NotFoundException('Aucune grille trouvée pour ce projet');
    }

    return {
      ...grid,
      criteria: grid.criteria,
      evaluationCount: grid._count.evaluations,
    };
  }

  async createProjectGrid(
    projectId: string,
    dto: CreateEvaluationGridDto,
    userId: string,
  ): Promise<EvaluationGridResponseDto> {
    const project = await this.prisma.project.findFirst({
      where: {
        id: projectId,
        userId: userId,
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé ou accès refusé');
    }

    // Validate weights sum to 100%
    const totalWeight = dto.criteria.reduce(
      (sum, criterion) => sum + criterion.weight,
      0,
    );
    if (Math.abs(totalWeight - 100) > 0.01) {
      throw new BadRequestException(
        `Total weight of criteria must equal 100%, got ${totalWeight}%`,
      );
    }

    // Check if grid type already exists for this project
    const existingGrid = await this.prisma.evaluationGrid.findFirst({
      where: {
        projectId,
        type: dto.type,
        isTemplate: false,
      },
    });

    if (existingGrid) {
      throw new BadRequestException(
        `Une grille de type ${dto.type} existe déjà pour ce projet`,
      );
    }

    // Check total weight of all grids for this project
    const existingGrids = await this.prisma.evaluationGrid.findMany({
      where: {
        projectId,
        isTemplate: false,
      },
      select: {
        weight: true,
      },
    });

    const totalUsedWeight = existingGrids.reduce(
      (sum, grid) => sum + (grid.weight || 0),
      0,
    );
    const totalWeightAfterCreation = totalUsedWeight + dto.weight;

    if (totalWeightAfterCreation > 1.0) {
      throw new BadRequestException(
        `Le poids total des grilles ne peut pas dépasser 100%. ` +
          `Poids actuel: ${(totalUsedWeight * 100).toFixed(1)}%, ` +
          `poids demandé: ${(dto.weight * 100).toFixed(1)}%, ` +
          `total: ${(totalWeightAfterCreation * 100).toFixed(1)}%`,
      );
    }

    const grid = await this.prisma.evaluationGrid.create({
      data: {
        name: dto.name,
        projectId,
        type: dto.type,
        weight: dto.weight,
        isTemplate: false,
        criteria: {
          create: dto.criteria.map((criterion, index) => ({
            name: criterion.name,
            description: criterion.description,
            maxPoints: criterion.maxPoints,
            weight: criterion.weight,
            order: criterion.order ?? index,
          })),
        },
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
      },
    });

    return {
      ...grid,
      criteria: grid.criteria,
    };
  }

  async getGrid(
    id: string,
    userId: string,
  ): Promise<EvaluationGridResponseDto> {
    const grid = await this.prisma.evaluationGrid.findFirst({
      where: {
        id,
        OR: [{ project: { userId: userId } }, { isTemplate: true }],
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
        _count: {
          select: {
            evaluations: true,
          },
        },
      },
    });

    if (!grid) {
      throw new NotFoundException('Grille non trouvée ou accès refusé');
    }

    return {
      ...grid,
      criteria: grid.criteria,
      evaluationCount: grid._count.evaluations,
    };
  }

  async updateGrid(
    id: string,
    dto: UpdateEvaluationGridDto,
    userId: string,
  ): Promise<EvaluationGridResponseDto> {
    const existingGrid = await this.prisma.evaluationGrid.findFirst({
      where: {
        id,
        project: { userId: userId },
        isTemplate: false,
      },
      include: {
        criteria: true,
        _count: {
          select: {
            evaluations: true,
          },
        },
      },
    });

    if (!existingGrid) {
      throw new NotFoundException('Grille non trouvée ou accès refusé');
    }

    if (existingGrid._count.evaluations > 0) {
      throw new BadRequestException(
        'Impossible de modifier une grille déjà utilisée dans des évaluations',
      );
    }

    // Validate weights if criteria are being updated
    if (dto.criteria) {
      const totalWeight = dto.criteria.reduce(
        (sum, criterion) => sum + criterion.weight,
        0,
      );
      if (Math.abs(totalWeight - 100) > 0.01) {
        throw new BadRequestException(
          `Total weight of criteria must equal 100%, got ${totalWeight}%`,
        );
      }
    }

    const updatedGrid = await this.prisma.evaluationGrid.update({
      where: { id },
      data: {
        name: dto.name,
        weight: dto.weight,
        criteria: dto.criteria
          ? {
              deleteMany: {},
              create: dto.criteria.map((criterion, index) => ({
                name: criterion.name,
                description: criterion.description,
                maxPoints: criterion.maxPoints,
                weight: criterion.weight,
                order: criterion.order ?? index,
              })),
            }
          : undefined,
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
      },
    });

    return {
      ...updatedGrid,
      criteria: updatedGrid.criteria,
    };
  }

  async deleteGrid(id: string, userId: string): Promise<void> {
    const existingGrid = await this.prisma.evaluationGrid.findFirst({
      where: {
        id,
        project: { userId: userId },
        isTemplate: false,
      },
      include: {
        _count: {
          select: {
            evaluations: true,
          },
        },
      },
    });

    if (!existingGrid) {
      throw new NotFoundException('Grille non trouvée ou accès refusé');
    }

    if (existingGrid._count.evaluations > 0) {
      throw new BadRequestException(
        'Impossible de supprimer une grille utilisée dans des évaluations',
      );
    }

    await this.prisma.evaluationGrid.delete({
      where: { id },
    });
  }

  async addCriterionToGrid(
    gridId: string,
    dto: CreateEvaluationCriterionDto,
    userId: string,
  ): Promise<EvaluationGridResponseDto> {
    const existingGrid = await this.prisma.evaluationGrid.findFirst({
      where: {
        id: gridId,
        project: { userId: userId },
        isTemplate: false,
      },
      include: {
        criteria: true,
        _count: {
          select: {
            evaluations: true,
          },
        },
      },
    });

    if (!existingGrid) {
      throw new NotFoundException('Grille non trouvée ou accès refusé');
    }

    if (existingGrid._count.evaluations > 0) {
      throw new BadRequestException(
        'Impossible de modifier une grille déjà utilisée dans des évaluations',
      );
    }

    // Check if adding this criterion would exceed 100% weight
    const currentTotalWeight = existingGrid.criteria.reduce(
      (sum, criterion) => sum + criterion.weight,
      0,
    );
    const newTotalWeight = currentTotalWeight + dto.weight;

    if (newTotalWeight > 100.01) {
      throw new BadRequestException(
        `Adding this criterion would exceed 100% total weight (current: ${currentTotalWeight}%, new: ${newTotalWeight}%)`,
      );
    }

    const nextOrder =
      Math.max(...existingGrid.criteria.map((c) => c.order), 0) + 1;

    await this.prisma.evaluationCriterion.create({
      data: {
        name: dto.name,
        description: dto.description,
        maxPoints: dto.maxPoints,
        weight: dto.weight,
        order: dto.order ?? nextOrder,
        gridId: gridId,
      },
    });

    return this.getGrid(gridId, userId);
  }
}
