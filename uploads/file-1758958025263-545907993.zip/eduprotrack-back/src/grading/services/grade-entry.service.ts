import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import {
  CreateGradeEntryDto,
  UpdateGradeEntryDto,
  BulkGradeDto,
  CopyGradeDto,
  GradeEntryResponseDto,
} from '../dto';
import { EvaluationStatus, EvaluationType } from '@prisma/client';

@Injectable()
export class GradeEntryService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Create a new grade entry (evaluation)
   */
  async createGradeEntry(dto: CreateGradeEntryDto, teacherId: string) {
    // Extract projectId from evaluationGrid
    const grid = await this.prisma.evaluationGrid.findFirst({
      where: {
        id: dto.evaluationGridId,
        project: { userId: teacherId },
      },
      include: {
        criteria: true,
        project: true,
      },
    });

    if (!grid) {
      throw new NotFoundException(
        "Grille d'évaluation non trouvée ou accès refusé",
      );
    }

    const projectId = grid.projectId;

    // Validate target entity exists
    const targetEntityId = dto.groupId || dto.studentId;
    const entityType = dto.groupId ? 'GROUP' : 'STUDENT';

    if (dto.groupId) {
      const group = await this.prisma.group.findFirst({
        where: { id: dto.groupId, projectId },
      });
      if (!group) {
        throw new NotFoundException('Groupe non trouvé');
      }
    } else if (dto.studentId) {
      const student = await this.prisma.user.findFirst({
        where: {
          id: dto.studentId,
          role: 'STUDENT',
          studentPromotions: {
            some: {
              promotion: {
                projects: {
                  some: { id: projectId },
                },
              },
            },
          },
        },
      });
      if (!student) {
        throw new NotFoundException('Étudiant non trouvé dans ce projet');
      }
    }

    // Check if evaluation already exists
    const existingEvaluation = await this.prisma.evaluation.findFirst({
      where: {
        gridId: dto.evaluationGridId,
        evaluatedEntityId: targetEntityId,
      },
    });

    if (existingEvaluation) {
      throw new BadRequestException(
        'Une évaluation existe déjà pour cette entité avec cette grille',
      );
    }

    // Validate all criteria are scored
    const criteriaIds = grid.criteria.map((c) => c.id);
    const scoredCriteriaIds = dto.scores.map((s) => s.criterionId);

    const missingCriteria = criteriaIds.filter(
      (id) => !scoredCriteriaIds.includes(id),
    );

    if (missingCriteria.length > 0) {
      throw new BadRequestException(
        `Tous les critères doivent être notés. Critères manquants: ${missingCriteria.length}`,
      );
    }

    // Validate scores are within bounds
    for (const score of dto.scores) {
      const criterion = grid.criteria.find((c) => c.id === score.criterionId);
      if (!criterion) {
        throw new BadRequestException(`Critère invalide: ${score.criterionId}`);
      }
      if (score.points < 0 || score.points > criterion.maxPoints) {
        throw new BadRequestException(
          `Score invalide pour ${criterion.name}: doit être entre 0 et ${criterion.maxPoints}`,
        );
      }
    }

    // Calculate weighted total
    const calculatedScore = this.calculateWeightedScore(dto.scores, grid);

    // Create evaluation with scores
    const evaluation = await this.prisma.evaluation.create({
      data: {
        gridId: dto.evaluationGridId,
        evaluatedEntityId: targetEntityId,
        entityType,
        evaluatorId: teacherId,
        status: dto.status || 'DRAFT',
        calculatedScore,
        totalScore: calculatedScore,
        globalComments: dto.globalComment,
        scores: {
          create: dto.scores.map((score) => ({
            criterionId: score.criterionId,
            valueType: 'NUMERIC',
            numericValue: score.points,
            normalizedScore: this.normalizeScore(
              score.points,
              grid.criteria.find((c) => c.id === score.criterionId),
            ),
            weight: grid.criteria.find((c) => c.id === score.criterionId)
              ?.weight,
            feedback: score.comment,
          })),
        },
      },
      include: {
        grid: {
          include: { criteria: true },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
    });

    return await this.transformToGradeEntryResponse(evaluation);
  }

  /**
   * Get all evaluations by grid
   */
  async getGradeEntriesByGrid(gridId: string, teacherId: string) {
    // Verify the grid belongs to teacher's project
    const grid = await this.prisma.evaluationGrid.findFirst({
      where: {
        id: gridId,
        project: { userId: teacherId },
      },
    });

    if (!grid) {
      throw new NotFoundException(
        "Grille d'évaluation non trouvée ou accès refusé",
      );
    }

    const evaluations = await this.prisma.evaluation.findMany({
      where: {
        gridId: gridId,
      },
      include: {
        grid: {
          include: { criteria: true },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return Promise.all(
      evaluations.map((evaluation) =>
        this.transformToGradeEntryResponse(evaluation),
      ),
    );
  }

  /**
   * Get all evaluations for a project
   */
  async findAllByProject(projectId: string, teacherId: string) {
    await this.validateProjectAccess(projectId, teacherId);

    return this.prisma.evaluation.findMany({
      where: {
        grid: { projectId },
      },
      include: {
        grid: {
          include: { criteria: true },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Get a specific evaluation
   */
  async getGradeEntry(evaluationId: string, teacherId: string) {
    const evaluation = await this.prisma.evaluation.findUnique({
      where: { id: evaluationId },
      include: {
        grid: {
          include: {
            criteria: true,
            project: {
              select: { userId: true },
            },
          },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
    });

    if (!evaluation) {
      throw new NotFoundException('Évaluation non trouvée');
    }

    // Verify access
    if (evaluation.grid.project.userId !== teacherId) {
      throw new ForbiddenException('Accès refusé à cette évaluation');
    }

    return await this.transformToGradeEntryResponse(evaluation);
  }

  /**
   * Get a specific evaluation (internal method)
   */
  async findOne(evaluationId: string, teacherId: string) {
    const evaluation = await this.prisma.evaluation.findUnique({
      where: { id: evaluationId },
      include: {
        grid: {
          include: {
            criteria: true,
            project: {
              select: { userId: true },
            },
          },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
    });

    if (!evaluation) {
      throw new NotFoundException('Évaluation non trouvée');
    }

    // Verify access
    if (evaluation.grid.project.userId !== teacherId) {
      throw new ForbiddenException('Accès refusé à cette évaluation');
    }

    return evaluation;
  }

  /**
   * Update an existing evaluation
   */
  async updateGradeEntry(
    evaluationId: string,
    dto: UpdateGradeEntryDto,
    teacherId: string,
  ) {
    // Find and validate existing evaluation
    const existingEvaluation = await this.findOne(evaluationId, teacherId);

    if (existingEvaluation.status === 'LOCKED') {
      throw new BadRequestException('Cette évaluation est verrouillée');
    }

    // If updating scores, validate them
    if (dto.scores) {
      const grid = existingEvaluation.grid;

      // Validate all criteria are scored
      const criteriaIds = grid.criteria.map((c) => c.id);
      const scoredCriteriaIds = dto.scores.map((s) => s.criterionId);

      const missingCriteria = criteriaIds.filter(
        (id) => !scoredCriteriaIds.includes(id),
      );

      if (missingCriteria.length > 0) {
        throw new BadRequestException(
          `Tous les critères doivent être notés. Critères manquants: ${missingCriteria.length}`,
        );
      }

      // Validate scores are within bounds
      for (const score of dto.scores) {
        const criterion = grid.criteria.find((c) => c.id === score.criterionId);
        if (!criterion) {
          throw new BadRequestException(
            `Critère invalide: ${score.criterionId}`,
          );
        }
        if (score.points < 0 || score.points > criterion.maxPoints) {
          throw new BadRequestException(
            `Score invalide pour ${criterion.name}: doit être entre 0 et ${criterion.maxPoints}`,
          );
        }
      }
    }

    // Calculate new score if scores are updated
    const calculatedScore = dto.scores
      ? this.calculateWeightedScore(dto.scores, existingEvaluation.grid)
      : existingEvaluation.calculatedScore;

    // Update evaluation
    const updatedEvaluation = await this.prisma.evaluation.update({
      where: { id: evaluationId },
      data: {
        ...(dto.status && { status: dto.status }),
        ...(dto.globalComment !== undefined && {
          globalComments: dto.globalComment,
        }),
        ...(dto.scores && {
          calculatedScore,
          totalScore: calculatedScore,
          scores: {
            deleteMany: {},
            create: dto.scores.map((score) => ({
              criterionId: score.criterionId,
              valueType: 'NUMERIC',
              numericValue: score.points,
              normalizedScore: this.normalizeScore(
                score.points,
                existingEvaluation.grid.criteria.find(
                  (c) => c.id === score.criterionId,
                ),
              ),
              weight: existingEvaluation.grid.criteria.find(
                (c) => c.id === score.criterionId,
              )?.weight,
              feedback: score.comment,
            })),
          },
        }),
        ...(dto.status === 'FINALIZED' && { finalizedAt: new Date() }),
        lastModifiedAt: new Date(),
      },
      include: {
        grid: {
          include: { criteria: true },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
    });

    return this.transformToGradeEntryResponse(updatedEvaluation);
  }

  /**
   * Update an existing evaluation (internal method)
   */
  async update(
    evaluationId: string,
    dto: UpdateGradeEntryDto,
    teacherId: string,
  ) {
    // Find and validate existing evaluation
    const existingEvaluation = await this.findOne(evaluationId, teacherId);

    if (existingEvaluation.status === 'LOCKED') {
      throw new BadRequestException('Cette évaluation est verrouillée');
    }

    // If updating scores, validate them
    if (dto.scores) {
      const grid = existingEvaluation.grid;

      // Validate all criteria are scored
      const criteriaIds = grid.criteria.map((c) => c.id);
      const scoredCriteriaIds = dto.scores.map((s) => s.criterionId);

      const missingCriteria = criteriaIds.filter(
        (id) => !scoredCriteriaIds.includes(id),
      );

      if (missingCriteria.length > 0) {
        throw new BadRequestException(
          `Tous les critères doivent être notés. Critères manquants: ${missingCriteria.length}`,
        );
      }

      // Validate scores are within bounds
      for (const score of dto.scores) {
        const criterion = grid.criteria.find((c) => c.id === score.criterionId);
        if (!criterion) {
          throw new BadRequestException(
            `Critère invalide: ${score.criterionId}`,
          );
        }
        if (score.points < 0 || score.points > criterion.maxPoints) {
          throw new BadRequestException(
            `Score invalide pour ${criterion.name}: doit être entre 0 et ${criterion.maxPoints}`,
          );
        }
      }
    }

    // Calculate new score if scores are updated
    const calculatedScore = dto.scores
      ? this.calculateWeightedScore(dto.scores, existingEvaluation.grid)
      : existingEvaluation.calculatedScore;

    // Update evaluation
    return this.prisma.evaluation.update({
      where: { id: evaluationId },
      data: {
        ...(dto.status && { status: dto.status }),
        ...(dto.globalComment !== undefined && {
          globalComments: dto.globalComment,
        }),
        ...(dto.scores && {
          calculatedScore,
          totalScore: calculatedScore,
          scores: {
            deleteMany: {},
            create: dto.scores.map((score) => ({
              criterionId: score.criterionId,
              valueType: 'NUMERIC',
              numericValue: score.points,
              normalizedScore: this.normalizeScore(
                score.points,
                existingEvaluation.grid.criteria.find(
                  (c) => c.id === score.criterionId,
                ),
              ),
              weight: existingEvaluation.grid.criteria.find(
                (c) => c.id === score.criterionId,
              )?.weight,
              feedback: score.comment,
            })),
          },
        }),
        ...(dto.status === 'FINALIZED' && { finalizedAt: new Date() }),
        lastModifiedAt: new Date(),
      },
      include: {
        grid: {
          include: { criteria: true },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
    });
  }

  /**
   * Delete an evaluation
   */
  async deleteGradeEntry(evaluationId: string, teacherId: string) {
    const evaluation = await this.findOne(evaluationId, teacherId);

    if (evaluation.status === 'LOCKED') {
      throw new BadRequestException(
        'Impossible de supprimer une évaluation verrouillée',
      );
    }

    await this.prisma.evaluation.delete({
      where: { id: evaluationId },
    });

    return { message: 'Évaluation supprimée avec succès' };
  }

  /**
   * Delete an evaluation (internal method)
   */
  async remove(evaluationId: string, teacherId: string) {
    const evaluation = await this.findOne(evaluationId, teacherId);

    if (evaluation.status === 'LOCKED') {
      throw new BadRequestException(
        'Impossible de supprimer une évaluation verrouillée',
      );
    }

    await this.prisma.evaluation.delete({
      where: { id: evaluationId },
    });

    return { message: 'Évaluation supprimée avec succès' };
  }

  /**
   * Bulk grade multiple entities
   */
  async bulkGrade(projectId: string, dto: BulkGradeDto, teacherId: string) {
    await this.validateProjectAccess(projectId, teacherId);

    const results = [];
    const errors = [];

    for (const entityId of dto.targetEntityIds) {
      try {
        const gradeDto: CreateGradeEntryDto = {
          evaluationGridId: dto.evaluationGridId,
          ...(dto.targetType === 'GROUP'
            ? { groupId: entityId }
            : { studentId: entityId }),
          scores: dto.scores.map((score) => ({
            criterionId: score.criterionId,
            points: score.points,
            comment: score.comment,
          })),
          globalComment: dto.globalComment,
          status: dto.status,
        };

        const result = await this.createGradeEntry(gradeDto, teacherId);
        results.push({ entityId, success: true, evaluationId: result.id });
      } catch (error) {
        errors.push({
          entityId,
          success: false,
          error: error.message,
        });
      }
    }

    return {
      successful: results.length,
      failed: errors.length,
      results,
      errors,
    };
  }

  /**
   * Copy grades from one entity to another
   */
  async copyGrades(projectId: string, dto: CopyGradeDto, teacherId: string) {
    await this.validateProjectAccess(projectId, teacherId);

    // Find source evaluation
    const sourceEvaluation = await this.prisma.evaluation.findFirst({
      where: {
        evaluatedEntityId: dto.sourceEntityId,
        gridId: dto.evaluationGridId,
      },
      include: {
        scores: true,
      },
    });

    if (!sourceEvaluation) {
      throw new NotFoundException('Évaluation source non trouvée');
    }

    // Create grade entry for target
    const gradeDto: CreateGradeEntryDto = {
      evaluationGridId: dto.evaluationGridId,
      ...(dto.targetType === 'GROUP'
        ? { groupId: dto.targetEntityId }
        : { studentId: dto.targetEntityId }),
      scores: sourceEvaluation.scores.map((score) => ({
        criterionId: score.criterionId,
        points: score.numericValue || 0,
        comment: score.feedback,
      })),
      globalComment: sourceEvaluation.globalComments,
      status: 'DRAFT',
    };

    return this.createGradeEntry(gradeDto, teacherId);
  }

  /**
   * Finalize an evaluation
   */
  async finalize(evaluationId: string, teacherId: string) {
    const evaluation = await this.findOne(evaluationId, teacherId);

    if (evaluation.status === 'LOCKED') {
      throw new BadRequestException('Cette évaluation est déjà verrouillée');
    }

    return this.prisma.evaluation.update({
      where: { id: evaluationId },
      data: {
        status: 'FINALIZED',
        finalizedAt: new Date(),
        isVisibleToStudents: true,
      },
    });
  }

  /**
   * Get grade entry by entity (used by mobile app)
   */
  async getGradeEntryByEntity(
    entityId: string,
    entityType: 'GROUP' | 'STUDENT',
    projectId: string,
    teacherId: string,
  ): Promise<GradeEntryResponseDto> {
    // Validate project access
    await this.validateProjectAccess(projectId, teacherId);

    // Find the evaluation for this entity in this project
    const evaluation = await this.prisma.evaluation.findFirst({
      where: {
        evaluatedEntityId: entityId,
        entityType: entityType,
        grid: { projectId },
      },
      include: {
        grid: {
          include: { criteria: true },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
    });

    if (!evaluation) {
      throw new NotFoundException(
        'Aucune évaluation trouvée pour cette entité dans ce projet',
      );
    }

    return await this.transformToGradeEntryResponse(evaluation);
  }

  /**
   * Get evaluations for a specific student
   */
  async getStudentGrades(studentId: string, projectId?: string) {
    const where: {
      OR: Array<{
        evaluatedEntityId?: string;
        entityType?: string;
        group?: {
          members: {
            some: { userId: string };
          };
        };
      }>;
      isVisibleToStudents: boolean;
      grid?: { projectId: string };
    } = {
      OR: [
        { evaluatedEntityId: studentId, entityType: 'STUDENT' },
        {
          group: {
            members: {
              some: { userId: studentId },
            },
          },
        },
      ],
      isVisibleToStudents: true,
    };

    if (projectId) {
      where.grid = { projectId };
    }

    return this.prisma.evaluation.findMany({
      where,
      include: {
        grid: {
          select: {
            name: true,
            type: true,
            project: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
        scores: {
          where: {
            OR: [
              { userId: null }, // Group scores
              { userId: studentId }, // Individual scores
            ],
          },
          include: {
            criterion: {
              select: {
                name: true,
                description: true,
                maxPoints: true,
              },
            },
          },
        },
        evaluator: {
          select: {
            firstname: true,
            lastname: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Helper: Validate project access
   */
  private async validateProjectAccess(projectId: string, teacherId: string) {
    const project = await this.prisma.project.findFirst({
      where: {
        id: projectId,
        userId: teacherId,
      },
    });

    if (!project) {
      throw new ForbiddenException('Accès refusé à ce projet');
    }
  }

  /**
   * Helper: Calculate weighted score
   */
  private calculateWeightedScore(
    scores: Array<{ criterionId: string; points: number }>,
    grid: {
      criteria: Array<{
        id: string;
        maxPoints: number;
        weight: number;
      }>;
    },
  ): number {
    let totalWeightedScore = 0;

    for (const score of scores) {
      const criterion = grid.criteria.find((c) => c.id === score.criterionId);
      if (criterion) {
        const normalizedScore = (score.points / criterion.maxPoints) * 100;
        const weightedScore = (normalizedScore * criterion.weight) / 100;
        totalWeightedScore += weightedScore;
      }
    }

    return Math.round(totalWeightedScore * 100) / 100;
  }

  /**
   * Helper: Normalize score
   */
  private normalizeScore(
    points: number,
    criterion: { maxPoints: number } | null,
  ): number {
    if (!criterion) return 0;
    return (points / criterion.maxPoints) * 100;
  }

  /**
   * Get all evaluations for a group
   */
  async getGradeEntriesByGroup(
    groupId: string,
    teacherId: string,
  ): Promise<GradeEntryResponseDto[]> {
    // First verify that the teacher has access to this group
    const group = await this.prisma.group.findFirst({
      where: {
        id: groupId,
        project: { userId: teacherId },
      },
      include: {
        project: { select: { id: true } },
      },
    });

    if (!group) {
      throw new NotFoundException('Groupe non trouvé ou accès refusé');
    }

    const evaluations = await this.prisma.evaluation.findMany({
      where: {
        evaluatedEntityId: groupId,
        entityType: 'GROUP',
        grid: { projectId: group.project.id },
      },
      include: {
        grid: {
          include: { criteria: true },
        },
        scores: {
          include: { criterion: true },
        },
        group: true,
        evaluator: {
          select: {
            id: true,
            firstname: true,
            lastname: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return Promise.all(
      evaluations.map((evaluation) =>
        this.transformToGradeEntryResponse(evaluation),
      ),
    );
  }

  /**
   * Publish grades for a group
   */
  async publishGrades(
    projectId: string,
    groupId: string,
    teacherId: string,
  ): Promise<{ message: string; publishedCount: number }> {
    // Validate project access
    await this.validateProjectAccess(projectId, teacherId);

    // Verify the group belongs to this project
    const group = await this.prisma.group.findFirst({
      where: {
        id: groupId,
        projectId: projectId,
      },
    });

    if (!group) {
      throw new NotFoundException('Groupe non trouvé dans ce projet');
    }

    // Update all draft and finalized evaluations for this group to published
    const result = await this.prisma.evaluation.updateMany({
      where: {
        evaluatedEntityId: groupId,
        entityType: 'GROUP',
        grid: { projectId },
        status: { in: ['DRAFT', 'FINALIZED'] },
      },
      data: {
        status: 'FINALIZED',
        isVisibleToStudents: true,
        finalizedAt: new Date(),
      },
    });

    return {
      message: 'Notes publiées avec succès',
      publishedCount: result.count,
    };
  }

  /**
   * Transform Prisma evaluation to GradeEntryResponseDto
   */
  private async transformToGradeEntryResponse(evaluation: {
    id: string;
    gridId: string;
    entityType: string;
    evaluatedEntityId: string;
    evaluatorId?: string;
    calculatedScore?: number;
    globalComments?: string;
    status: string;
    createdAt: Date;
    updatedAt: Date;
    scores: Array<{
      id: string;
      criterionId: string;
      numericValue: number;
      feedback?: string;
      criterion: {
        name: string;
        maxPoints: number;
        weight: number;
      };
    }>;
    grid: {
      name: string;
      type: string;
      criteria: Array<{
        id: string;
        maxPoints: number;
        weight: number;
      }>;
    };
    group?: {
      name: string;
    };
    evaluator?: {
      firstname: string;
      lastname: string;
    };
  }): Promise<GradeEntryResponseDto> {
    // Get user data for student evaluations
    let user = null;
    if (evaluation.entityType === 'STUDENT') {
      user = await this.prisma.user.findUnique({
        where: { id: evaluation.evaluatedEntityId },
        select: { firstname: true, lastname: true },
      });
    }

    // Get evaluator data if not already included
    let evaluator = evaluation.evaluator;
    if (!evaluator && evaluation.evaluatorId) {
      evaluator = await this.prisma.user.findUnique({
        where: { id: evaluation.evaluatorId },
        select: { firstname: true, lastname: true },
      });
    }

    // Calculate total score
    const totalPoints =
      evaluation.calculatedScore ||
      evaluation.scores.reduce((sum: number, score) => {
        const criterion = evaluation.grid.criteria.find(
          (c) => c.id === score.criterionId,
        );
        const normalizedScore = criterion
          ? (score.numericValue / criterion.maxPoints) * criterion.weight
          : 0;
        return sum + normalizedScore;
      }, 0);

    return {
      id: evaluation.id,
      evaluationGridId: evaluation.gridId,
      groupId:
        evaluation.entityType === 'GROUP'
          ? evaluation.evaluatedEntityId
          : undefined,
      studentId:
        evaluation.entityType === 'STUDENT'
          ? evaluation.evaluatedEntityId
          : undefined,
      evaluatedById: evaluation.evaluatorId || '',
      globalComment: evaluation.globalComments,
      status: evaluation.status as EvaluationStatus,
      totalScore: Math.round((totalPoints || 0) * 100) / 100, // Round to 2 decimals
      createdAt: evaluation.createdAt,
      updatedAt: evaluation.updatedAt,
      scores: evaluation.scores.map((score) => ({
        id: score.id,
        criterionId: score.criterionId,
        points: score.numericValue || 0,
        comment: score.feedback,
        criterion: {
          name: score.criterion.name,
          maxPoints: score.criterion.maxPoints,
          weight: score.criterion.weight,
        },
      })),
      evaluationGrid: {
        name: evaluation.grid.name,
        type: evaluation.grid.type as EvaluationType,
      },
      group: evaluation.group
        ? {
            name: evaluation.group.name,
          }
        : undefined,
      student:
        evaluation.entityType === 'STUDENT' && user
          ? {
              firstName: user.firstname || '',
              lastName: user.lastname || '',
            }
          : undefined,
      evaluatedBy: {
        firstName: evaluator?.firstname || '',
        lastName: evaluator?.lastname || '',
      },
    };
  }
}
