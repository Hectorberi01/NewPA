import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { EvaluationStatus, EvaluationType } from '@prisma/client';

export class CriterionScoreResponseDto {
  @ApiProperty({
    description: 'Identifiant unique du score',
    example: 'score_abc123',
  })
  id: string;

  @ApiProperty({
    description: "Identifiant du critère d'évaluation",
    example: 'crit_abc123',
  })
  criterionId: string;

  @ApiProperty({
    description: 'Points attribués pour ce critère',
    example: 15.5,
  })
  points: number;

  @ApiPropertyOptional({
    description: 'Commentaire sur ce critère',
    example: 'Excellent travail sur cette partie',
    nullable: true,
  })
  comment?: string;

  @ApiProperty({
    description: 'Informations sur le critère',
    type: 'object',
    additionalProperties: false,
  })
  criterion: {
    name: string;
    maxPoints: number;
    weight: number;
  };
}

export class GradeEntryResponseDto {
  @ApiProperty({
    description: "Identifiant unique de l'évaluation",
    example: 'eval_abc123',
  })
  id: string;

  @ApiProperty({
    description: "Identifiant de la grille d'évaluation",
    example: 'grid_abc123',
  })
  evaluationGridId: string;

  @ApiPropertyOptional({
    description: 'Identifiant du groupe évalué',
    example: 'group_xyz789',
    nullable: true,
  })
  groupId?: string;

  @ApiPropertyOptional({
    description: "Identifiant de l'étudiant évalué",
    example: 'student_def456',
    nullable: true,
  })
  studentId?: string;

  @ApiProperty({
    description: "Identifiant de l'enseignant évaluateur",
    example: 'teacher_ghi789',
  })
  evaluatedById: string;

  @ApiPropertyOptional({
    description: "Commentaire global sur l'évaluation",
    example: 'Bon travail général avec quelques améliorations possibles',
    nullable: true,
  })
  globalComment?: string;

  @ApiProperty({
    description: "Statut de l'évaluation",
    enum: EvaluationStatus,
    example: EvaluationStatus.FINALIZED,
  })
  status: EvaluationStatus;

  @ApiProperty({
    description: 'Score total calculé (sur 100)',
    example: 85.5,
  })
  totalScore: number;

  @ApiProperty({
    description: 'Date de création',
    example: '2024-01-15T10:30:00Z',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Date de dernière modification',
    example: '2024-01-15T14:20:00Z',
  })
  updatedAt: Date;

  @ApiProperty({
    description: 'Scores détaillés par critère',
    type: [CriterionScoreResponseDto],
    isArray: true,
  })
  scores: CriterionScoreResponseDto[];

  @ApiProperty({
    description: "Informations sur la grille d'évaluation",
    type: 'object',
    additionalProperties: false,
  })
  evaluationGrid: {
    name: string;
    type: EvaluationType;
  };

  @ApiPropertyOptional({
    description: 'Informations sur le groupe évalué',
    type: 'object',
    additionalProperties: false,
    nullable: true,
  })
  group?: {
    name: string;
  };

  @ApiPropertyOptional({
    description: "Informations sur l'étudiant évalué",
    type: 'object',
    additionalProperties: false,
    nullable: true,
  })
  student?: {
    firstName: string;
    lastName: string;
  };

  @ApiProperty({
    description: "Informations sur l'enseignant évaluateur",
    type: 'object',
    additionalProperties: false,
  })
  evaluatedBy: {
    firstName: string;
    lastName: string;
  };
}
