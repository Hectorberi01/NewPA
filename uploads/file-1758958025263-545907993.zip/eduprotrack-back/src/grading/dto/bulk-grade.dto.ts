import {
  IsString,
  IsNotEmpty,
  IsEnum,
  IsArray,
  ValidateNested,
  ArrayMinSize,
  IsOptional,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { EvaluationStatus } from '@prisma/client';
import { CriterionScoreDto } from './create-grade-entry.dto';

export class BulkGradeDto {
  @ApiProperty({
    description: "Identifiant de la grille d'évaluation à utiliser",
    example: 'grid_abc123',
  })
  @IsString()
  @IsNotEmpty()
  evaluationGridId: string;

  @ApiProperty({
    description: 'Type des entités cibles (GROUP ou STUDENT)',
    enum: ['GROUP', 'STUDENT'],
    example: 'GROUP',
  })
  @IsEnum(['GROUP', 'STUDENT'])
  targetType: 'GROUP' | 'STUDENT';

  @ApiProperty({
    description: 'Liste des identifiants des entités à noter',
    type: [String],
    example: ['group_123', 'group_456'],
  })
  @IsArray()
  @ArrayMinSize(1)
  @IsString({ each: true })
  targetEntityIds: string[];

  @ApiProperty({
    description: 'Scores à appliquer à toutes les entités',
    type: [CriterionScoreDto],
    isArray: true,
  })
  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => CriterionScoreDto)
  scores: CriterionScoreDto[];

  @ApiPropertyOptional({
    description: 'Commentaire global à appliquer à toutes les évaluations',
    example: 'Bon travail général',
  })
  @IsString()
  @IsOptional()
  globalComment?: string;

  @ApiPropertyOptional({
    description: "Statut de l'évaluation",
    enum: EvaluationStatus,
    example: EvaluationStatus.DRAFT,
    default: EvaluationStatus.DRAFT,
  })
  @IsEnum(EvaluationStatus)
  @IsOptional()
  status?: EvaluationStatus = EvaluationStatus.DRAFT;
}
