// Grade Entry DTOs
export * from './create-grade-entry.dto';
export * from './update-grade-entry.dto';
export * from './grade-entry-response.dto';
export * from './bulk-grade.dto';
export * from './copy-grade.dto';

// Evaluation Grid DTOs
export * from './create-evaluation-grid.dto';
export * from './update-evaluation-grid.dto';
export * from './evaluation-grid-response.dto';
export * from './duplicate-grid.dto';

// Final Grade DTOs
export * from './final-grade-response.dto';

// Export individual DTO classes for specific imports
export { CreateEvaluationCriterionDto } from './create-evaluation-grid.dto';
export { CriterionScoreDto } from './create-grade-entry.dto';

// Re-export enums and types from Prisma
export {
  EvaluationStatus,
  ScoreValueType,
  EvaluationType,
} from '@prisma/client';
