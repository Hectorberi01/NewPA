import { ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsEnum,
  IsOptional,
  IsArray,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { EvaluationStatus } from '@prisma/client';
import { CriterionScoreDto } from './create-grade-entry.dto';

export class UpdateGradeEntryDto {
  @ApiPropertyOptional({
    description: 'Scores mis à jour pour chaque critère de la grille',
    type: [CriterionScoreDto],
    isArray: true,
  })
  @IsArray()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => CriterionScoreDto)
  scores?: CriterionScoreDto[];

  @ApiPropertyOptional({
    description: "Commentaire global sur l'évaluation",
    example: 'Bon travail général avec quelques améliorations possibles',
  })
  @IsString()
  @IsOptional()
  globalComment?: string;

  @ApiPropertyOptional({
    description: "Statut de l'évaluation",
    enum: EvaluationStatus,
    example: EvaluationStatus.FINALIZED,
    enumName: 'EvaluationStatus',
  })
  @IsEnum(EvaluationStatus)
  @IsOptional()
  status?: EvaluationStatus;
}
