import { IsString, IsNotEmpty, IsEnum } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CopyGradeDto {
  @ApiProperty({
    description: "Identifiant de la grille d'évaluation",
    example: 'grid_abc123',
  })
  @IsString()
  @IsNotEmpty()
  evaluationGridId: string;

  @ApiProperty({
    description: "Identifiant de l'entité source",
    example: 'group_123',
  })
  @IsString()
  @IsNotEmpty()
  sourceEntityId: string;

  @ApiProperty({
    description: "Identifiant de l'entité cible",
    example: 'group_456',
  })
  @IsString()
  @IsNotEmpty()
  targetEntityId: string;

  @ApiProperty({
    description: "Type de l'entité cible (GROUP ou STUDENT)",
    enum: ['GROUP', 'STUDENT'],
    example: 'GROUP',
  })
  @IsEnum(['GROUP', 'STUDENT'])
  targetType: 'GROUP' | 'STUDENT';
}
