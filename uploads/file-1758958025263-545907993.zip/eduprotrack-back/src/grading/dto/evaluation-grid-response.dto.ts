import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { EvaluationType } from '@prisma/client';

export class EvaluationCriterionResponseDto {
  @ApiProperty({
    description: 'Identifiant unique du critère',
    example: 'cm123456',
  })
  id: string;

  @ApiProperty({
    description: 'Nom du critère',
    example: 'Qualité du code',
  })
  name: string;

  @ApiPropertyOptional({
    description: 'Description du critère',
    example: 'Respect des bonnes pratiques',
  })
  description?: string;

  @ApiProperty({
    description: 'Points maximum',
    example: 5,
  })
  maxPoints: number;

  @ApiProperty({
    description: 'Poids en pourcentage',
    example: 25,
  })
  weight: number;

  @ApiProperty({
    description: "Ordre d'affichage",
    example: 1,
  })
  order: number;

  @ApiProperty({
    description: 'Date de création',
    example: '2024-01-15T10:30:00.000Z',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Date de mise à jour',
    example: '2024-01-15T10:30:00.000Z',
  })
  updatedAt: Date;
}

export class EvaluationGridResponseDto {
  @ApiProperty({
    description: 'Identifiant unique de la grille',
    example: 'cm123456',
  })
  id: string;

  @ApiProperty({
    description: 'Nom de la grille',
    example: 'Grille Livrable Java',
  })
  name: string;

  @ApiPropertyOptional({
    description: 'ID du projet (null pour les templates)',
    example: 'cm123456',
  })
  projectId?: string;

  @ApiProperty({
    description: "Type d'évaluation",
    enum: EvaluationType,
    example: EvaluationType.DELIVERABLE,
  })
  type: EvaluationType;

  @ApiProperty({
    description: 'Poids dans le calcul final',
    example: 0.3,
  })
  weight: number;

  @ApiProperty({
    description: "Indique si c'est un template",
    example: true,
  })
  isTemplate: boolean;

  @ApiProperty({
    description: 'Date de création',
    example: '2024-01-15T10:30:00.000Z',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Date de mise à jour',
    example: '2024-01-15T10:30:00.000Z',
  })
  updatedAt: Date;

  @ApiProperty({
    description: 'Liste des critères',
    type: [EvaluationCriterionResponseDto],
  })
  criteria: EvaluationCriterionResponseDto[];

  @ApiPropertyOptional({
    description: 'Informations du projet (si applicable)',
  })
  project?: {
    id: string;
    name: string;
  };

  @ApiPropertyOptional({
    description: "Nombre d'évaluations utilisant cette grille",
    example: 5,
  })
  evaluationCount?: number;
}
