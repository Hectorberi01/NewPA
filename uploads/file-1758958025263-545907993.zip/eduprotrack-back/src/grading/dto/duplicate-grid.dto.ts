import { IsString, IsNotEmpty, IsOptional } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class DuplicateGridDto {
  @ApiProperty({
    description: 'Nom de la grille dupliquée',
    example: 'Grille Livrable Java - Copie',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({
    description: 'ID du projet cible (omis pour créer un template)',
    example: 'proj_123',
  })
  @IsString()
  @IsOptional()
  projectId?: string;
}

export class DuplicateToProjectDto {
  @ApiProperty({
    description: 'ID du projet cible',
    example: 'proj_123',
  })
  @IsString()
  @IsNotEmpty()
  projectId: string;

  @ApiPropertyOptional({
    description: 'Nom personnalisé pour la grille dupliquée',
    example: 'Grille Projet 2024',
  })
  @IsString()
  @IsOptional()
  name?: string;
}
