import {
  IsString,
  IsNotEmpty,
  IsEnum,
  IsNumber,
  IsOptional,
  IsArray,
  ValidateNested,
  ArrayMinSize,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { EvaluationStatus } from '@prisma/client';

export class CriterionScoreDto {
  @ApiProperty({
    description: "Identifiant du critère d'évaluation",
    example: 'crit_abc123',
  })
  @IsString()
  @IsNotEmpty()
  criterionId: string;

  @ApiProperty({
    description: 'Points attribués pour ce critère',
    example: 15.5,
    minimum: 0,
  })
  @IsNumber()
  points: number;

  @ApiPropertyOptional({
    description: 'Commentaire sur ce critère',
    example: 'Excellent travail sur cette partie',
  })
  @IsString()
  @IsOptional()
  comment?: string;
}

export class CreateGradeEntryDto {
  @ApiProperty({
    description: "Identifiant de la grille d'évaluation",
    example: 'grid_abc123',
  })
  @IsString()
  @IsNotEmpty()
  evaluationGridId: string;

  @ApiPropertyOptional({
    description:
      'Identifiant du groupe évalué (null pour évaluation individuelle)',
    example: 'group_xyz789',
    nullable: true,
  })
  @IsString()
  @IsOptional()
  groupId?: string;

  @ApiPropertyOptional({
    description:
      "Identifiant de l'étudiant évalué (null pour évaluation de groupe)",
    example: 'student_def456',
    nullable: true,
  })
  @IsString()
  @IsOptional()
  studentId?: string;

  @ApiProperty({
    description: 'Scores pour chaque critère de la grille',
    type: [CriterionScoreDto],
    isArray: true,
  })
  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => CriterionScoreDto)
  scores: CriterionScoreDto[];

  @ApiPropertyOptional({
    description: "Commentaire global sur l'évaluation",
    example: 'Bon travail général avec quelques améliorations possibles',
  })
  @IsString()
  @IsOptional()
  globalComment?: string;

  @ApiPropertyOptional({
    description: "Statut de l'évaluation",
    enum: EvaluationStatus,
    example: EvaluationStatus.DRAFT,
    enumName: 'EvaluationStatus',
    default: EvaluationStatus.DRAFT,
  })
  @IsEnum(EvaluationStatus)
  @IsOptional()
  status?: EvaluationStatus = EvaluationStatus.DRAFT;
}
