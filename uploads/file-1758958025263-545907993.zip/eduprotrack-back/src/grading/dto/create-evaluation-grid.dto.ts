import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsEnum,
  IsNumber,
  IsBoolean,
  IsArray,
  ValidateNested,
  Min,
  Max,
  IsNotEmpty,
} from 'class-validator';
import { Type } from 'class-transformer';
import { EvaluationType } from '@prisma/client';

export class CreateEvaluationCriterionDto {
  @ApiProperty({
    description: "Nom du critère d'évaluation",
    example: 'Qualité du code',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({
    description: 'Description détaillée du critère',
    example: 'Respect des bonnes pratiques de programmation',
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({
    description: 'Points maximum pour ce critère',
    example: 5,
    minimum: 0,
  })
  @IsNumber()
  @Min(0)
  maxPoints: number;

  @ApiProperty({
    description: 'Poids du critère dans le calcul final (pourcentage)',
    example: 25,
    minimum: 0,
    maximum: 100,
  })
  @IsNumber()
  @Min(0)
  @Max(100)
  weight: number;

  @ApiPropertyOptional({
    description: "Ordre d'affichage du critère",
    example: 1,
    minimum: 0,
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  order?: number;
}

export class CreateEvaluationGridDto {
  @ApiProperty({
    description: "Nom de la grille d'évaluation",
    example: 'Grille Livrable Java',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({
    description: 'ID du projet (omis pour créer un template)',
    example: 'cm123456',
  })
  @IsOptional()
  @IsString()
  projectId?: string;

  @ApiProperty({
    description: "Type d'évaluation",
    enum: EvaluationType,
    example: EvaluationType.DELIVERABLE,
  })
  @IsEnum(EvaluationType)
  type: EvaluationType;

  @ApiProperty({
    description: 'Poids de la grille dans le calcul final du projet',
    example: 0.3,
    minimum: 0,
    maximum: 1,
  })
  @IsNumber()
  @Min(0)
  @Max(1)
  weight: number;

  @ApiPropertyOptional({
    description: "Indique si c'est un template réutilisable",
    example: true,
    default: false,
  })
  @IsOptional()
  @IsBoolean()
  isTemplate?: boolean;

  @ApiProperty({
    description: "Liste des critères d'évaluation",
    type: [CreateEvaluationCriterionDto],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateEvaluationCriterionDto)
  criteria: CreateEvaluationCriterionDto[];
}
