import { ApiProperty } from '@nestjs/swagger';
import { EvaluationType, EvaluationStatus } from '@prisma/client';

export class GridSummaryDto {
  @ApiProperty({
    description: "Identifiant de la grille d'évaluation",
    example: 'grid_123',
  })
  id: string;

  @ApiProperty({
    description: 'Nom de la grille',
    example: 'Grille Livrable Java',
  })
  name: string;

  @ApiProperty({
    description: "Type d'évaluation",
    enum: EvaluationType,
    example: EvaluationType.DELIVERABLE,
  })
  type: EvaluationType;

  @ApiProperty({
    description: 'Poids de la grille dans le calcul final',
    example: 0.3,
  })
  weight: number;

  @ApiProperty({
    description: 'Score obtenu pour cette grille',
    example: 85.5,
    nullable: true,
  })
  score: number | null;

  @ApiProperty({
    description: 'Score pondéré (score * weight)',
    example: 25.65,
    nullable: true,
  })
  weightedScore: number | null;

  @ApiProperty({
    description: "Statut de l'évaluation",
    enum: EvaluationStatus,
    example: EvaluationStatus.FINALIZED,
    nullable: true,
  })
  status: EvaluationStatus | null;
}

export class FinalGradeResponseDto {
  @ApiProperty({
    description: 'Identifiant du projet',
    example: 'proj_123',
  })
  projectId: string;

  @ApiProperty({
    description: 'Nom du projet',
    example: 'Projet Java 2024',
  })
  projectName: string;

  @ApiProperty({
    description: "Identifiant de l'entité évaluée (groupe ou étudiant)",
    example: 'group_123',
  })
  entityId: string;

  @ApiProperty({
    description: "Type de l'entité (GROUP ou STUDENT)",
    enum: ['GROUP', 'STUDENT'],
    example: 'GROUP',
  })
  entityType: 'GROUP' | 'STUDENT';

  @ApiProperty({
    description: "Nom de l'entité",
    example: 'Groupe 1',
  })
  entityName: string;

  @ApiProperty({
    description: "Résumé des grilles d'évaluation",
    type: [GridSummaryDto],
  })
  grids: GridSummaryDto[];

  @ApiProperty({
    description: 'Note finale calculée',
    example: 78.5,
  })
  finalGrade: number;

  @ApiProperty({
    description: 'Note finale sur 20',
    example: 15.7,
  })
  finalGradeOutOf20: number;

  @ApiProperty({
    description: 'Lettre de notation (A, B, C, etc.)',
    example: 'B',
    nullable: true,
  })
  letterGrade: string | null;

  @ApiProperty({
    description: 'Toutes les grilles ont été complétées',
    example: true,
  })
  isComplete: boolean;

  @ApiProperty({
    description: 'Date de calcul',
    example: '2024-01-15T10:00:00.000Z',
  })
  calculatedAt: Date;
}
