import { ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { CreateEvaluationCriterionDto } from './create-evaluation-grid.dto';
import {
  IsOptional,
  IsString,
  IsNotEmpty,
  ValidateNested,
  IsArray,
  IsEnum,
  IsNumber,
  Min,
  Max,
} from 'class-validator';
import { Type } from 'class-transformer';
import { EvaluationType } from '@prisma/client';

export class UpdateEvaluationCriterionDto extends PartialType(
  CreateEvaluationCriterionDto,
) {
  @ApiPropertyOptional({
    description: 'ID du critère (pour les critères existants)',
    example: 'cm123456',
  })
  @IsOptional()
  @IsString()
  @IsNotEmpty()
  id?: string;
}

export class UpdateEvaluationGridDto {
  @ApiPropertyOptional({
    description: "Nom de la grille d'évaluation",
    example: 'Grille Livrable Java - Modifiée',
  })
  @IsOptional()
  @IsString()
  @IsNotEmpty()
  name?: string;

  @ApiPropertyOptional({
    description: "Type d'évaluation",
    enum: EvaluationType,
    example: EvaluationType.DELIVERABLE,
  })
  @IsOptional()
  @IsEnum(EvaluationType)
  type?: EvaluationType;

  @ApiPropertyOptional({
    description: 'Poids de la grille dans le calcul final du projet',
    example: 0.3,
    minimum: 0,
    maximum: 1,
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(1)
  weight?: number;

  @ApiPropertyOptional({
    description: "Liste des critères d'évaluation mis à jour",
    type: [UpdateEvaluationCriterionDto],
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UpdateEvaluationCriterionDto)
  criteria?: UpdateEvaluationCriterionDto[];
}
