import { Module } from '@nestjs/common';
import { GradingController } from './grading.controller';
import { GradeEntryService } from './services/grade-entry.service';
import { EvaluationGridService } from './services/evaluation-grid.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [GradingController],
  providers: [GradeEntryService, EvaluationGridService],
  exports: [GradeEntryService, EvaluationGridService],
})
export class GradingModule {}
