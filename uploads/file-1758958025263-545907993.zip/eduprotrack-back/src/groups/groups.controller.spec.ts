import type { TestingModule } from '@nestjs/testing';
import { Test } from '@nestjs/testing';
import { GroupsController } from './groups.controller';
import { GroupsService } from './groups.service';
import { GroupManagementService } from './group-management.service';
import { PrismaService } from '../prisma/prisma.service';

describe('GroupsController', () => {
  let controller: GroupsController;
  let service: GroupsService;

  const mockPrismaService = {
    project: {
      findUnique: jest.fn(),
    },
    group: {
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
      count: jest.fn(),
    },
    groupMember: {
      findMany: jest.fn(),
      findFirst: jest.fn(),
      create: jest.fn(),
      createMany: jest.fn(),
      delete: jest.fn(),
      deleteMany: jest.fn(),
    },
  };

  const mockGroupsService = {
    create: jest.fn(),
    findAllByProject: jest.fn(),
    findOne: jest.fn(),
    update: jest.fn(),
    addMember: jest.fn(),
    removeMember: jest.fn(),
    remove: jest.fn(),
  };

  const mockGroupManagementService = {
    getAvailableGroups: jest.fn(),
    joinGroup: jest.fn(),
    leaveGroup: jest.fn(),
    getStudentGroup: jest.fn(),
    performAutoAssignment: jest.fn(),
    performRandomAssignment: jest.fn(),
    sendDeadlineReminder: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GroupsController],
      providers: [
        {
          provide: GroupsService,
          useValue: mockGroupsService,
        },
        {
          provide: GroupManagementService,
          useValue: mockGroupManagementService,
        },
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
      ],
    }).compile();

    controller = module.get<GroupsController>(GroupsController);
    service = module.get<GroupsService>(GroupsService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
