import { Module } from '@nestjs/common';
import { GroupsService } from './groups.service';
import { GroupsController } from './groups.controller';
import { GroupManagementService } from './group-management.service';
import { PrismaService } from '../prisma/prisma.service';
import { EmailService } from '../notifications/email.service';
import { TemplateService } from '../notifications/template.service';

@Module({
  controllers: [GroupsController],
  providers: [
    GroupsService,
    GroupManagementService,
    PrismaService,
    EmailService,
    TemplateService,
  ],
  exports: [GroupsService, GroupManagementService],
})
export class GroupsModule {}
