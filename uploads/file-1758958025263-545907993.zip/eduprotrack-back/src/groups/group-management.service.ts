import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { GroupFormationMode, ProjectStatus } from '@prisma/client';
import { EmailService } from '../notifications/email.service';
import {
  ProjectTemplate,
  TemplateService,
} from '../notifications/template.service';

@Injectable()
export class GroupManagementService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly emailService: EmailService,
    private readonly templateService: TemplateService,
  ) {}

  /**
   * Récupération des groupes disponibles pour un projet en mode FREE
   */
  async getAvailableGroups(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        groups: {
          include: {
            members: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                    email: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    if (project.groupFormationMode !== GroupFormationMode.FREE) {
      throw new BadRequestException("Ce projet n'est pas en mode libre");
    }

    // Retourner uniquement les groupes non complets
    const availableGroups = project.groups.filter(
      (group) => group.members.length < project.maxGroupSize,
    );

    return {
      project: {
        id: project.id,
        name: project.name,
        minGroupSize: project.minGroupSize,
        maxGroupSize: project.maxGroupSize,
        groupDeadline: project.groupDeadline,
      },
      availableGroups: availableGroups.map((group) => ({
        id: group.id,
        name: group.name,
        currentMembersCount: group.members.length,
        maxMembers: project.maxGroupSize,
        members: group.members.map((m) => ({
          id: m.user.id,
          firstname: m.user.firstname,
          lastname: m.user.lastname,
        })),
      })),
    };
  }

  /**
   * Rejoindre un groupe (mode FREE)
   */
  async joinGroup(studentId: string, groupId: string) {
    const group = await this.prisma.group.findUnique({
      where: { id: groupId },
      include: {
        project: true,
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
      },
    });

    if (!group) {
      throw new NotFoundException('Groupe non trouvé');
    }

    const project = group.project;

    // Vérifications
    if (project.groupFormationMode !== GroupFormationMode.FREE) {
      throw new BadRequestException("Ce projet n'est pas en mode libre");
    }

    if (project.groupDeadline && new Date() > new Date(project.groupDeadline)) {
      throw new BadRequestException(
        'La deadline pour rejoindre un groupe est dépassée',
      );
    }

    if (group.members.length >= project.maxGroupSize) {
      throw new BadRequestException('Ce groupe est complet');
    }

    // Vérifier que l'étudiant n'est pas déjà dans un groupe pour ce projet
    const existingMembership = await this.prisma.groupMember.findFirst({
      where: {
        userId: studentId,
        group: { projectId: project.id },
      },
    });

    if (existingMembership) {
      throw new BadRequestException(
        'Vous êtes déjà dans un groupe pour ce projet',
      );
    }

    // Vérifier que l'étudiant appartient à la promotion du projet
    const studentPromotion = await this.prisma.studentPromotion.findFirst({
      where: {
        userId: studentId,
        promotionId: project.promotionId,
      },
    });

    if (!studentPromotion) {
      throw new ForbiddenException(
        "Vous n'appartenez pas à la promotion de ce projet",
      );
    }

    // Ajouter l'étudiant au groupe
    await this.prisma.groupMember.create({
      data: {
        groupId: groupId,
        userId: studentId,
      },
    });

    // Récupérer les informations complètes pour l'email
    const updatedGroup = await this.prisma.group.findUnique({
      where: { id: groupId },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
        project: {
          select: { id: true, name: true },
        },
      },
    });

    // Envoyer l'email de confirmation à l'étudiant qui vient de rejoindre
    if (updatedGroup) {
      const studentUser = await this.prisma.user.findUnique({
        where: { id: studentId },
        select: { email: true, firstname: true, lastname: true },
      });

      if (studentUser?.email) {
        const template = this.templateService.getGroupJoinTemplate(
          updatedGroup.project,
          updatedGroup,
          studentUser,
        );
        await this.emailService.sendEmail(
          studentUser.email,
          template.subject,
          template.html,
        );
      }
    }

    // Retourner le groupe mis à jour
    return this.prisma.group.findUnique({
      where: { id: groupId },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
        project: {
          select: { id: true, name: true },
        },
      },
    });
  }

  /**
   * Quitter un groupe (mode FREE)
   */
  async leaveGroup(studentId: string, groupId: string) {
    const membership = await this.prisma.groupMember.findFirst({
      where: {
        userId: studentId,
        groupId: groupId,
      },
      include: {
        group: {
          include: {
            project: true,
          },
        },
      },
    });

    if (!membership) {
      throw new NotFoundException("Vous n'êtes pas membre de ce groupe");
    }

    const project = membership.group.project;

    if (project.groupFormationMode !== GroupFormationMode.FREE) {
      throw new BadRequestException(
        "Vous ne pouvez quitter un groupe qu'en mode libre",
      );
    }

    if (project.groupDeadline && new Date() > new Date(project.groupDeadline)) {
      throw new BadRequestException(
        'La deadline pour modifier les groupes est dépassée',
      );
    }

    // Supprimer le membership
    await this.prisma.groupMember.delete({
      where: { id: membership.id },
    });

    return { message: 'Vous avez quitté le groupe avec succès' };
  }

  /**
   * Récupérer le groupe d'un étudiant pour un projet
   */
  async getStudentGroup(studentId: string, projectId: string) {
    const membership = await this.prisma.groupMember.findFirst({
      where: {
        userId: studentId,
        group: { projectId },
      },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                    email: true,
                  },
                },
              },
            },
            project: {
              select: { id: true, name: true, groupFormationMode: true },
            },
          },
        },
      },
    });

    if (!membership) {
      return null;
    }

    return membership.group;
  }

  /**
   * 🆕 NOUVEAU : Affectation aléatoire des étudiants (Mode RANDOM)
   */
  async performRandomAssignment(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        teacher: {
          select: {
            firstname: true,
            lastname: true,
          },
        },
        promotion: {
          include: {
            students: {
              include: {
                user: true,
              },
            },
          },
        },
        groups: {
          include: {
            members: true,
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    // Vérifier que le projet est en brouillon (DRAFT) pour permettre les modifications
    if (project.status !== ProjectStatus.DRAFT) {
      throw new BadRequestException(
        'L\'affectation aléatoire ne peut être effectuée que lorsque le projet est en brouillon',
      );
    }

    console.log(
      `🎲 Démarrage affectation aléatoire pour projet: ${project.name}`,
    );

    // Supprimer tous les groupes existants
    await this.prisma.groupMember.deleteMany({
      where: { group: { projectId } },
    });

    await this.prisma.group.deleteMany({
      where: { projectId },
    });

    // Récupérer tous les étudiants de la promotion
    const allStudents = project.promotion.students.map((sp) => sp.userId);
    console.log(`👥 Étudiants à affecter: ${allStudents.length}`);

    // Mélanger aléatoirement les étudiants (algorithme Fisher-Yates)
    const shuffledStudents = this.shuffleArray([...allStudents]);

    // Calculer le nombre optimal de groupes
    const optimalGroupSize = Math.floor(
      (project.minGroupSize + project.maxGroupSize) / 2,
    );
    const nbGroups = Math.ceil(shuffledStudents.length / optimalGroupSize);

    console.log(
      `📊 Groupes à créer: ${nbGroups} (taille optimale: ${optimalGroupSize})`,
    );

    // Créer les groupes et affecter les étudiants
    const createdGroups = [];
    for (let i = 0; i < nbGroups; i++) {
      // Calculer la taille du groupe actuel
      const remainingStudents = shuffledStudents.length - i * optimalGroupSize;
      const remainingGroups = nbGroups - i;
      const currentGroupSize = Math.min(
        optimalGroupSize,
        Math.ceil(remainingStudents / remainingGroups),
      );

      // Extraire les étudiants pour ce groupe
      const groupStudents = shuffledStudents.splice(0, currentGroupSize);

      // Créer le groupe
      const group = await this.prisma.group.create({
        data: {
          name: `Groupe ${i + 1}`,
          projectId: projectId,
        },
      });

      // Ajouter les membres
      await this.prisma.groupMember.createMany({
        data: groupStudents.map((studentId) => ({
          groupId: group.id,
          userId: studentId,
        })),
      });

      createdGroups.push({
        name: group.name,
        memberCount: groupStudents.length,
      });

      console.log(
        `✅ ${group.name} créé avec ${groupStudents.length} étudiants`,
      );
    }

    // Envoyer les notifications
    await this.notifyRandomAssignment(
      project,
      createdGroups as { name: string; memberCount: number }[],
    );

    const result = {
      message: `${allStudents.length} étudiants affectés aléatoirement en ${nbGroups} groupes`,
      totalStudents: allStudents.length,
      totalGroups: nbGroups,
      groups: createdGroups,
    };

    console.log(`🎉 Affectation aléatoire terminée:`, result);
    return result;
  }

  /**
   * Affectation automatique des étudiants non-groupés
   */
  async performAutoAssignment(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        teacher: {
          select: {
            firstname: true,
            lastname: true,
          },
        },
        promotion: {
          include: {
            students: {
              include: {
                user: true,
              },
            },
          },
        },
        groups: {
          include: {
            members: {
              include: {
                user: true,
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    // Vérifier que le projet est en brouillon (DRAFT) pour permettre les modifications
    if (project.status !== ProjectStatus.DRAFT) {
      throw new BadRequestException(
        'L\'affectation automatique ne peut être effectuée que lorsque le projet est en brouillon',
      );
    }

    console.log(
      `🎯 Démarrage affectation automatique pour projet: ${project.name}`,
    );

    // Récupérer les étudiants non-groupés
    const allStudentIds = project.promotion.students.map((sp) => sp.userId);
    const groupedStudentIds = project.groups.flatMap((g) =>
      g.members.map((m) => m.userId),
    );
    let ungroupedStudentIds = allStudentIds.filter(
      (id) => !groupedStudentIds.includes(id),
    );

    console.log(`📁 Étudiants total: ${allStudentIds.length}`);
    console.log(`👥 Étudiants déjà groupés: ${groupedStudentIds.length}`);
    console.log(`🚫 Étudiants non-groupés: ${ungroupedStudentIds.length}`);

    // Identifier et libérer les groupes sous-dimensionnés
    const undersizedGroups = project.groups.filter(
      (group) => group.members.length < project.minGroupSize,
    );

    console.log(`⚠️ Groupes sous-dimensionnés: ${undersizedGroups.length}`);

    // Libérer les membres des groupes sous-dimensionnés
    for (const group of undersizedGroups) {
      const membersToLiberate = group.members.map((m) => m.userId);
      ungroupedStudentIds.push(...membersToLiberate);
      console.log(
        `🔓 Libération de ${membersToLiberate.length} étudiants du groupe ${group.name}`,
      );

      await this.prisma.groupMember.deleteMany({
        where: { groupId: group.id },
      });

      // Supprimer le groupe vide
      await this.prisma.group.delete({
        where: { id: group.id },
      });
    }

    if (ungroupedStudentIds.length === 0) {
      return {
        message: 'Tous les étudiants sont déjà groupés',
        assignedStudents: 0,
        totalAssignments: 0,
        newGroupsCreated: 0,
      };
    }

    // Mélanger aléatoirement les étudiants pour équité
    ungroupedStudentIds = this.shuffleArray(ungroupedStudentIds);

    // Trouver les groupes avec des places disponibles (exclure ceux supprimés)
    const availableGroups = project.groups.filter(
      (group) =>
        group.members.length < project.maxGroupSize &&
        !undersizedGroups.find((ug) => ug.id === group.id),
    );

    console.log(
      `📊 Groupes avec places disponibles: ${availableGroups.length}`,
    );

    // Affecter aux groupes existants avec places disponibles
    let totalAssigned = 0;
    const assignments: {
      groupId: string;
      groupName: string;
      studentIds: string[];
    }[] = [];

    for (const group of availableGroups.sort(
      (a, b) => a.members.length - b.members.length,
    )) {
      const availableSlots = project.maxGroupSize - group.members.length;
      const studentsToAssign = Math.min(
        availableSlots,
        ungroupedStudentIds.length,
      );

      if (studentsToAssign > 0 && ungroupedStudentIds.length > 0) {
        const studentIds = ungroupedStudentIds.splice(0, studentsToAssign);

        await this.prisma.groupMember.createMany({
          data: studentIds.map((studentId) => ({
            groupId: group.id,
            userId: studentId,
          })),
        });

        assignments.push({
          groupId: group.id,
          groupName: group.name,
          studentIds,
        });

        totalAssigned += studentIds.length;
        console.log(
          `✅ Affectés ${studentIds.length} étudiants au groupe ${group.name}`,
        );
      }

      if (ungroupedStudentIds.length === 0) break;
    }

    // Créer de nouveaux groupes pour les étudiants restants
    let newGroupsCreated = 0;
    while (ungroupedStudentIds.length > 0) {
      // Calculer la taille optimale du nouveau groupe
      const optimalSize = Math.min(
        project.maxGroupSize,
        Math.max(
          project.minGroupSize,
          Math.ceil(
            ungroupedStudentIds.length /
              Math.ceil(ungroupedStudentIds.length / project.maxGroupSize),
          ),
        ),
      );

      const studentsForNewGroup = ungroupedStudentIds.splice(0, optimalSize);

      // Créer le nouveau groupe
      const existingGroupsCount = await this.prisma.group.count({
        where: { projectId },
      });

      const newGroup = await this.prisma.group.create({
        data: {
          name: `Groupe ${existingGroupsCount + 1}`,
          projectId: projectId,
        },
      });

      // Ajouter les étudiants au nouveau groupe
      await this.prisma.groupMember.createMany({
        data: studentsForNewGroup.map((studentId) => ({
          groupId: newGroup.id,
          userId: studentId,
        })),
      });

      assignments.push({
        groupId: newGroup.id,
        groupName: newGroup.name,
        studentIds: studentsForNewGroup,
      });

      console.log(
        `✅ Nouveau groupe créé: ${newGroup.name} avec ${studentsForNewGroup.length} étudiants`,
      );
      totalAssigned += studentsForNewGroup.length;
      newGroupsCreated++;
    }

    // Notifier tous les étudiants affectés
    for (const assignment of assignments) {
      const group = await this.prisma.group.findUnique({
        where: { id: assignment.groupId },
        include: {
          members: {
            include: {
              user: true,
            },
          },
        },
      });

      if (group) {
        for (const member of group.members) {
          if (assignment.studentIds.includes(member.userId)) {
            const template = this.templateService.getAutoAssignmentTemplate(
              project,
              group,
            );
            if (member.user.email) {
              await this.emailService.sendEmail(
                member.user.email,
                template.subject,
                template.html,
              );
            }
          }
        }
      }
    }

    const result = {
      message: `${totalAssigned} étudiants ont été affectés automatiquement`,
      assignedStudents: totalAssigned,
      totalAssignments: assignments.length,
      newGroupsCreated,
      groupsDetails: assignments.map((a) => ({
        groupName: a.groupName,
        studentsAssigned: a.studentIds.length,
      })),
    };

    console.log(`🎉 Résultat final:`, result);
    return result;
  }

  /**
   * Créer des groupes vides pour le mode FREE
   */
  async createEmptyGroups(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        promotion: {
          include: {
            students: true,
          },
        },
        groups: true,
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    if (project.groupFormationMode !== GroupFormationMode.FREE) {
      throw new BadRequestException(
        'La création de groupes vides est uniquement disponible en mode FREE',
      );
    }

    // Calculer le nombre optimal de groupes
    const nbStudents = project.promotion.students.length;
    const optimalGroupCount = Math.ceil(nbStudents / project.minGroupSize);
    const existingGroupsCount = project.groups.length;

    if (existingGroupsCount >= optimalGroupCount) {
      return {
        message: 'Nombre suffisant de groupes déjà créés',
        existingGroups: existingGroupsCount,
        optimalGroups: optimalGroupCount,
      };
    }

    // Créer les groupes manquants
    const groupsToCreate = optimalGroupCount - existingGroupsCount;
    const createdGroups = [];

    for (let i = 0; i < groupsToCreate; i++) {
      const group = await this.prisma.group.create({
        data: {
          name: `Groupe ${existingGroupsCount + i + 1}`,
          projectId: projectId,
        },
      });
      createdGroups.push(group);
    }

    console.log(
      `✅ ${groupsToCreate} groupes vides créés pour le projet ${project.name}`,
    );

    return {
      message: `${groupsToCreate} groupes vides créés avec succès`,
      createdGroups: createdGroups.length,
      totalGroups: existingGroupsCount + createdGroups.length,
      optimalGroups: optimalGroupCount,
    };
  }

  /**
   * Validation des contraintes de groupes
   */
  async validateGroupConstraints(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        groups: {
          include: {
            members: {
              include: {
                user: {
                  select: {
                    id: true,
                    firstname: true,
                    lastname: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    const violations = [];
    const validGroups = [];

    for (const group of project.groups) {
      const memberCount = group.members.length;
      const groupInfo = {
        id: group.id,
        name: group.name,
        memberCount,
        members: group.members.map((m) => ({
          id: m.user.id,
          name: `${m.user.firstname} ${m.user.lastname}`,
        })),
      };

      // Vérifier la taille du groupe
      if (memberCount < project.minGroupSize) {
        violations.push({
          ...groupInfo,
          violation: 'GROUP_TOO_SMALL',
          message: `Groupe trop petit (${memberCount}/${project.minGroupSize} min)`,
        });
      } else if (memberCount > project.maxGroupSize) {
        violations.push({
          ...groupInfo,
          violation: 'GROUP_TOO_LARGE',
          message: `Groupe trop grand (${memberCount}/${project.maxGroupSize} max)`,
        });
      } else {
        validGroups.push(groupInfo);
      }
    }

    // Vérifier les doublons d'étudiants
    const allMemberIds = project.groups.flatMap((g) =>
      g.members.map((m) => m.userId),
    );
    const duplicateIds = allMemberIds.filter(
      (id, index) => allMemberIds.indexOf(id) !== index,
    );

    if (duplicateIds.length > 0) {
      violations.push({
        violation: 'DUPLICATE_STUDENTS',
        message: `Étudiants présents dans plusieurs groupes`,
        duplicateStudentIds: [...new Set(duplicateIds)],
      });
    }

    // Vérifier la deadline en mode FREE
    let deadlineViolation: {
      violation: string;
      message: string;
      deadline: Date;
    } | null = null;
    if (
      project.groupFormationMode === GroupFormationMode.FREE &&
      project.groupDeadline &&
      new Date() > new Date(project.groupDeadline)
    ) {
      deadlineViolation = {
        violation: 'DEADLINE_PASSED',
        message: 'La deadline de formation des groupes est dépassée',
        deadline: project.groupDeadline,
      };
    }

    return {
      isValid: violations.length === 0 && !deadlineViolation,
      validGroups,
      violations,
      deadlineViolation,
      summary: {
        totalGroups: project.groups.length,
        validGroups: validGroups.length,
        violatingGroups: violations.length,
        totalStudents: allMemberIds.length,
        duplicateStudents: duplicateIds.length,
      },
    };
  }

  /**
   * 🆕 Algorithme de mélange Fisher-Yates
   */
  private shuffleArray<T>(array: T[]): T[] {
    const result = [...array];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  /**
   * 🆕 Notification pour affectation aléatoire
   */
  private async notifyRandomAssignment(
    project: { id: string },
    _groups: unknown[],
  ) {
    // Récupérer tous les groupes créés avec leurs membres
    const finalGroups = await this.prisma.group.findMany({
      where: { projectId: project.id },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
      },
    });

    // Notifier tous les étudiants
    for (const group of finalGroups) {
      for (const member of group.members) {
        const template = this.templateService.getRandomAssignmentTemplate(
          project as ProjectTemplate,
          group,
        );
        if (member.user.email) {
          await this.emailService.sendEmail(
            member.user.email,
            template.subject,
            template.html,
          );
        }
      }
    }
  }

  /**
   * Envoi du rappel deadline (J-1)
   */
  async sendDeadlineReminder(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        teacher: {
          select: {
            firstname: true,
            lastname: true,
          },
        },
        promotion: {
          include: {
            students: {
              include: {
                user: true,
              },
            },
          },
        },
        groups: {
          include: {
            members: true,
          },
        },
      },
    });

    if (!project || project.groupFormationMode !== GroupFormationMode.FREE) {
      return;
    }

    // Identifier les étudiants non-groupés
    const groupedStudentIds = project.groups.flatMap((g) =>
      g.members.map((m) => m.userId),
    );
    const ungroupedStudents = project.promotion.students.filter(
      (sp) => !groupedStudentIds.includes(sp.userId),
    );

    // Envoyer le rappel
    const template = this.templateService.getDeadlineReminderTemplate(project);
    for (const studentPromotion of ungroupedStudents) {
      if (studentPromotion.user.email) {
        await this.emailService.sendEmail(
          studentPromotion.user.email,
          template.subject,
          template.html,
        );
      }
    }

    return {
      message: `Rappel envoyé à ${ungroupedStudents.length} étudiants non-groupés`,
      remindedStudents: ungroupedStudents.length,
    };
  }
}
