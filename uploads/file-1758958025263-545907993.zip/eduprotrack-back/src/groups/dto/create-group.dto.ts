import { IsArray, IsOptional, IsString } from 'class-validator';

export class CreateGroupDto {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  members?: string[];
}
