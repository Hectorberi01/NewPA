import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Request,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';
import { GroupsService } from './groups.service';
import { GroupManagementService } from './group-management.service';
import { CreateGroupDto } from './dto/create-group.dto';
import { UpdateGroupDto } from './dto/update-group.dto';
import { AddGroupMemberDto } from './dto/add-group-member.dto';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../auth/guards/teacher.guard';
import { StudentGuard } from '../auth/guards/student.guard';
import type { AuthenticatedRequest } from '../auth/types/auth.types';

@ApiTags('Groups')
@ApiBearerAuth('JWT-auth')
@Controller('groups')
@UseGuards(JWTAuthGuard)
export class GroupsController {
  constructor(
    private readonly groupsService: GroupsService,
    private readonly groupManagementService: GroupManagementService,
  ) {}

  @Post('project/:projectId')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Créer un nouveau groupe pour un projet' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiBody({ type: CreateGroupDto })
  @ApiResponse({ status: 201, description: 'Groupe créé avec succès' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Enseignant requis' })
  create(
    @Param('projectId') projectId: string,
    @Body() createGroupDto: CreateGroupDto,
  ) {
    return this.groupsService.create(projectId, createGroupDto);
  }

  @Get('project/:projectId')
  @ApiOperation({ summary: "Récupérer tous les groupes d'un projet" })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({
    status: 200,
    description: 'Liste des groupes récupérée avec succès',
  })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  findAllByProject(@Param('projectId') projectId: string) {
    return this.groupsService.findAllByProject(projectId);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Récupérer un groupe par son ID' })
  @ApiParam({ name: 'id', description: 'ID du groupe' })
  @ApiResponse({ status: 200, description: 'Groupe récupéré avec succès' })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 404, description: 'Groupe non trouvé' })
  findOne(@Param('id') id: string) {
    return this.groupsService.findOne(id);
  }

  @Patch(':id')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Mettre à jour un groupe' })
  @ApiParam({ name: 'id', description: 'ID du groupe' })
  @ApiBody({ type: UpdateGroupDto })
  @ApiResponse({ status: 200, description: 'Groupe mis à jour avec succès' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Enseignant requis' })
  @ApiResponse({ status: 404, description: 'Groupe non trouvé' })
  update(@Param('id') id: string, @Body() updateGroupDto: UpdateGroupDto) {
    return this.groupsService.update(id, updateGroupDto);
  }

  @Post(':id/members')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Ajouter un membre à un groupe' })
  @ApiParam({ name: 'id', description: 'ID du groupe' })
  @ApiBody({ type: AddGroupMemberDto })
  @ApiResponse({ status: 201, description: 'Membre ajouté avec succès' })
  @ApiResponse({
    status: 400,
    description: 'Données invalides ou membre déjà dans un groupe',
  })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Enseignant requis' })
  @ApiResponse({ status: 404, description: 'Groupe ou utilisateur non trouvé' })
  addMember(
    @Param('id') groupId: string,
    @Body() addMemberDto: AddGroupMemberDto,
  ) {
    return this.groupsService.addMember(groupId, addMemberDto);
  }

  @Delete(':id/members/:userId')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: "Retirer un membre d'un groupe" })
  @ApiParam({ name: 'id', description: 'ID du groupe' })
  @ApiParam({ name: 'userId', description: "ID de l'utilisateur à retirer" })
  @ApiResponse({ status: 200, description: 'Membre retiré avec succès' })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Enseignant requis' })
  @ApiResponse({ status: 404, description: 'Groupe ou utilisateur non trouvé' })
  removeMember(@Param('id') groupId: string, @Param('userId') userId: string) {
    return this.groupsService.removeMember(groupId, userId);
  }

  @Delete(':id')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Supprimer un groupe' })
  @ApiParam({ name: 'id', description: 'ID du groupe' })
  @ApiResponse({ status: 200, description: 'Groupe supprimé avec succès' })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Enseignant requis' })
  @ApiResponse({ status: 404, description: 'Groupe non trouvé' })
  remove(@Param('id') id: string) {
    return this.groupsService.remove(id);
  }

  // 🆕 Endpoints pour gestion avancée des groupes

  /**
   * Récupérer les groupes disponibles pour un projet (mode FREE)
   */
  @Get('available/:projectId')
  @UseGuards(StudentGuard)
  @ApiOperation({
    summary: 'Récupérer les groupes disponibles pour rejoindre (mode FREE)',
  })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({
    status: 200,
    description: 'Liste des groupes disponibles récupérée avec succès',
  })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Étudiant requis' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  getAvailableGroups(@Param('projectId') projectId: string) {
    return this.groupManagementService.getAvailableGroups(projectId);
  }

  /**
   * Rejoindre un groupe (mode FREE)
   */
  @Post(':groupId/join')
  @UseGuards(StudentGuard)
  @ApiOperation({ summary: 'Rejoindre un groupe disponible (mode FREE)' })
  @ApiParam({ name: 'groupId', description: 'ID du groupe à rejoindre' })
  @ApiResponse({ status: 200, description: 'Groupe rejoint avec succès' })
  @ApiResponse({
    status: 400,
    description:
      'Impossible de rejoindre le groupe (complet, déjà membre, etc.)',
  })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Étudiant requis' })
  @ApiResponse({ status: 404, description: 'Groupe non trouvé' })
  joinGroup(
    @Param('groupId') groupId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    return this.groupManagementService.joinGroup(req.user.id, groupId);
  }

  /**
   * Quitter un groupe (mode FREE)
   */
  @Post(':groupId/leave')
  @UseGuards(StudentGuard)
  @ApiOperation({ summary: 'Quitter un groupe (mode FREE)' })
  @ApiParam({ name: 'groupId', description: 'ID du groupe à quitter' })
  @ApiResponse({ status: 200, description: 'Groupe quitté avec succès' })
  @ApiResponse({
    status: 400,
    description: 'Impossible de quitter le groupe (pas membre, etc.)',
  })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Étudiant requis' })
  @ApiResponse({ status: 404, description: 'Groupe non trouvé' })
  leaveGroup(
    @Param('groupId') groupId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    return this.groupManagementService.leaveGroup(req.user.id, groupId);
  }

  /**
   * Récupérer le groupe d'un étudiant pour un projet
   */
  @Get('student/:projectId/my-group')
  @UseGuards(StudentGuard)
  @ApiOperation({ summary: 'Récupérer mon groupe pour un projet donné' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({
    status: 200,
    description: "Groupe de l'étudiant récupéré avec succès",
  })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Étudiant requis' })
  @ApiResponse({
    status: 404,
    description: 'Aucun groupe trouvé pour cet étudiant sur ce projet',
  })
  getStudentGroup(
    @Param('projectId') projectId: string,
    @Request() req: AuthenticatedRequest,
  ) {
    return this.groupManagementService.getStudentGroup(req.user.id, projectId);
  }

  /**
   * Affectation automatique des étudiants non-groupés
   */
  @Post('project/:projectId/auto-assign')
  @UseGuards(TeacherGuard)
  @ApiOperation({
    summary:
      'Affecter automatiquement les étudiants non-groupés aux groupes existants',
  })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({
    status: 200,
    description: 'Affectation automatique réalisée avec succès',
  })
  @ApiResponse({
    status: 400,
    description: "Impossible d'effectuer l'affectation automatique",
  })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Enseignant requis' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  performAutoAssignment(@Param('projectId') projectId: string) {
    return this.groupManagementService.performAutoAssignment(projectId);
  }

  /**
   * Affectation aléatoire de tous les étudiants
   */
  @Post('project/:projectId/random-assign')
  @UseGuards(TeacherGuard)
  @ApiOperation({
    summary: 'Affecter aléatoirement tous les étudiants en groupes équilibrés',
  })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({
    status: 200,
    description: 'Affectation aléatoire réalisée avec succès',
  })
  @ApiResponse({
    status: 400,
    description: "Impossible d'effectuer l'affectation aléatoire",
  })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Enseignant requis' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  performRandomAssignment(@Param('projectId') projectId: string) {
    return this.groupManagementService.performRandomAssignment(projectId);
  }

  /**
   * Envoyer un rappel de deadline aux étudiants non-groupés
   */
  @Post('project/:projectId/send-reminder')
  @UseGuards(TeacherGuard)
  @ApiOperation({
    summary: 'Envoyer un rappel de deadline aux étudiants non-groupés',
  })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 200, description: 'Rappel envoyé avec succès' })
  @ApiResponse({ status: 400, description: "Impossible d'envoyer le rappel" })
  @ApiResponse({ status: 401, description: 'Non autorisé' })
  @ApiResponse({ status: 403, description: 'Accès refusé - Enseignant requis' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  sendDeadlineReminder(@Param('projectId') projectId: string) {
    return this.groupManagementService.sendDeadlineReminder(projectId);
  }
}
