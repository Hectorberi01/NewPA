import type { TestingModule } from '@nestjs/testing';
import { Test } from '@nestjs/testing';
import type { Provider } from '@nestjs/common';
import { NotFoundException, BadRequestException } from '@nestjs/common';
import { GroupFormationMode } from '@prisma/client';
import { GroupManagementService } from './group-management.service';
import { PrismaService } from '../prisma/prisma.service';
import { EmailService } from '../notifications/email.service';
import { TemplateService } from '../notifications/template.service';

describe('GroupManagementService', () => {
  let service: GroupManagementService;
  let prismaService: PrismaService;

  const mockPrismaService = {
    project: {
      findUnique: jest.fn(),
    },
    group: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      deleteMany: jest.fn(),
      count: jest.fn(),
    },
    groupMember: {
      findFirst: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      createMany: jest.fn(),
      delete: jest.fn(),
      deleteMany: jest.fn(),
    },
    studentPromotion: {
      findFirst: jest.fn(),
    },
  } as unknown as PrismaService;

  const mockEmailService = {
    sendEmail: jest.fn(),
  } as unknown as EmailService;

  const mockTemplateService = {
    getAutoAssignmentTemplate: jest.fn(),
    getRandomAssignmentTemplate: jest.fn(),
    getDeadlineReminderTemplate: jest.fn(),
  } as unknown as TemplateService;

  beforeEach(async () => {
    const providers: Provider[] = [
      GroupManagementService,
      {
        provide: PrismaService,
        useValue: mockPrismaService,
      },
      {
        provide: EmailService,
        useValue: mockEmailService,
      },
      {
        provide: TemplateService,
        useValue: mockTemplateService,
      },
    ];

    const module: TestingModule = await Test.createTestingModule({
      providers,
    }).compile();

    service = module.get<GroupManagementService>(GroupManagementService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('getAvailableGroups', () => {
    it('should return available groups for FREE mode project', async () => {
      const projectId = 'test-project-id';
      const mockProject = {
        id: projectId,
        name: 'Test Project',
        groupFormationMode: GroupFormationMode.FREE,
        minGroupSize: 2,
        maxGroupSize: 4,
        groupDeadline: new Date(),
        groups: [
          {
            id: 'group-1',
            name: 'Groupe 1',
            members: [
              {
                user: {
                  id: 'user-1',
                  firstname: 'John',
                  lastname: 'Doe',
                  email: 'john@test.com',
                },
              },
            ],
          },
        ],
      };

      (mockPrismaService.project.findUnique as jest.Mock).mockResolvedValue(
        mockProject,
      );
      (mockPrismaService.group.findMany as jest.Mock).mockResolvedValue(
        mockProject.groups,
      );
      (mockPrismaService.groupMember.findMany as jest.Mock).mockResolvedValue(
        mockProject.groups[0].members,
      );

      (
        mockPrismaService.studentPromotion.findFirst as jest.Mock
      ).mockResolvedValue({
        students: [{ userId: 'user-1' }],
      });

      (mockPrismaService.group.count as jest.Mock).mockResolvedValue(1);

      const result = await service.getAvailableGroups(projectId);

      expect(result).toEqual({
        project: {
          id: projectId,
          name: 'Test Project',
          minGroupSize: 2,
          maxGroupSize: 4,
          groupDeadline: mockProject.groupDeadline,
        },
        availableGroups: [
          {
            id: 'group-1',
            name: 'Groupe 1',
            currentMembersCount: 1,
            maxMembers: 4,
            members: [
              {
                id: 'user-1',
                firstname: 'John',
                lastname: 'Doe',
              },
            ],
          },
        ],
      });
    });

    it('should throw NotFoundException for non-existent project', async () => {
      (mockPrismaService.project.findUnique as jest.Mock).mockResolvedValue(
        null,
      );

      await expect(service.getAvailableGroups('invalid-id')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw BadRequestException for non-FREE mode project', async () => {
      const mockProject = {
        groupFormationMode: GroupFormationMode.MANUAL,
      };

      (mockPrismaService.project.findUnique as jest.Mock).mockResolvedValue(
        mockProject,
      );

      await expect(service.getAvailableGroups('test-id')).rejects.toThrow(
        BadRequestException,
      );
    });
  });

  describe('performRandomAssignment', () => {
    it('should perform random assignment correctly', async () => {
      const projectId = 'test-project-id';
      const mockProject = {
        id: projectId,
        name: 'Test Project',
        minGroupSize: 2,
        maxGroupSize: 4,
        promotion: {
          students: [
            { userId: 'user-1' },
            { userId: 'user-2' },
            { userId: 'user-3' },
            { userId: 'user-4' },
          ],
        },
        groups: [],
      };

      (mockPrismaService.project.findUnique as jest.Mock).mockResolvedValue(
        mockProject,
      );
      (mockPrismaService.groupMember.deleteMany as jest.Mock).mockResolvedValue(
        { count: 0 },
      );
      (mockPrismaService.group.deleteMany as jest.Mock).mockResolvedValue({
        count: 0,
      });
      (mockPrismaService.group.create as jest.Mock).mockImplementation(
        (createData: { data: { name: string } }) => ({
          id: 'generated-id',
          name: createData.data.name,
        }),
      );
      (mockPrismaService.groupMember.createMany as jest.Mock).mockResolvedValue(
        { count: 2 },
      );
      (
        mockTemplateService.getRandomAssignmentTemplate as jest.Mock
      ).mockReturnValue({
        subject: 'Test Subject',
        html: 'Test HTML',
      });
      (mockPrismaService.group.findMany as jest.Mock).mockResolvedValue([
        {
          id: 'group-1',
          name: 'Groupe 1',
          members: [
            {
              user: {
                id: 'user-1',
                firstname: 'John',
                lastname: 'Doe',
                email: 'john@example.com',
              },
            },
            {
              user: {
                id: 'user-2',
                firstname: 'Jane',
                lastname: 'Smith',
                email: 'jane@example.com',
              },
            },
          ],
        },
      ]);

      const result = await service.performRandomAssignment(projectId);

      expect(result).toEqual({
        message: expect.stringContaining('4 étudiants affectés aléatoirement'),
        totalStudents: 4,
        totalGroups: expect.any(Number),
        groups: expect.any(Array),
      });

      expect(mockPrismaService.group.create).toHaveBeenCalled();
      expect(mockPrismaService.groupMember.createMany).toHaveBeenCalled();
    });
  });

  describe('shuffleArray', () => {
    it('should return array with same elements but potentially different order', () => {
      const originalArray = [1, 2, 3, 4, 5];

      const shuffled = (service as any)['shuffleArray'](
        originalArray,
      ) as number[];

      expect(shuffled).toHaveLength(originalArray.length);
      expect([...shuffled].sort()).toEqual([...originalArray].sort());
    });

    it('should not modify original array', () => {
      const originalArray = [1, 2, 3, 4, 5];
      const originalCopy = [...originalArray];
      (service as any)['shuffleArray'](originalArray);

      expect(originalArray).toEqual(originalCopy);
    });
  });
});
