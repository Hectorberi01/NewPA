import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import type { CreateGroupDto } from './dto/create-group.dto';
import type { UpdateGroupDto } from './dto/update-group.dto';
import type { AddGroupMemberDto } from './dto/add-group-member.dto';
import type { Prisma, ProjectStatus } from '@prisma/client';
import { EmailService } from '../notifications/email.service';
import { TemplateService } from '../notifications/template.service';

@Injectable()
export class GroupsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly emailService: EmailService,
    private readonly templateService: TemplateService,
  ) {}

  /**
   * Création d'un groupe (pour enseignants)
   */
  async create(projectId: string, createGroupDto: CreateGroupDto) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    // Vérifier que le projet est en brouillon (DRAFT) pour permettre les modifications
    if (project.status !== ProjectStatus.DRAFT) {
      throw new BadRequestException(
        'Les groupes ne peuvent être modifiés que lorsque le projet est en brouillon',
      );
    }

    // Validation des contraintes de taille
    if (createGroupDto.members && createGroupDto.members.length > 0) {
      if (
        createGroupDto.members.length < project.minGroupSize ||
        createGroupDto.members.length > project.maxGroupSize
      ) {
        throw new BadRequestException(
          `Le groupe doit contenir entre ${project.minGroupSize} et ${project.maxGroupSize} membres`,
        );
      }

      // Vérifier qu'aucun membre n'est déjà dans un groupe pour ce projet
      const existingMemberships = await this.prisma.groupMember.findMany({
        where: {
          userId: { in: createGroupDto.members },
          group: { projectId },
        },
      });

      if (existingMemberships.length > 0) {
        throw new BadRequestException(
          'Certains étudiants sont déjà dans un groupe pour ce projet',
        );
      }
    }

    // Générer un nom automatique si non fourni
    const existingGroupsCount = await this.prisma.group.count({
      where: { projectId },
    });

    const groupName =
      createGroupDto.name ?? `Groupe ${existingGroupsCount + 1}`;

    // Créer le groupe
    const group = await this.prisma.group.create({
      data: {
        name: groupName,
        projectId: projectId,
      },
    });

    // Ajouter les membres si fournis
    if (createGroupDto.members && createGroupDto.members.length > 0) {
      await this.prisma.groupMember.createMany({
        data: createGroupDto.members.map((userId) => ({
          groupId: group.id,
          userId: userId,
        })),
      });

      // Envoyer des emails de notification aux membres ajoutés
      const membersWithEmail = await this.prisma.user.findMany({
        where: { id: { in: createGroupDto.members } },
        select: { id: true, email: true, firstname: true, lastname: true },
      });

      const projectWithGroup = await this.prisma.project.findUnique({
        where: { id: projectId },
        select: { id: true, name: true },
      });

      const groupWithMembers = {
        id: group.id,
        name: group.name,
        project: projectWithGroup,
      };

      for (const member of membersWithEmail) {
        if (member.email) {
          // Utiliser le service de template pour créer l'email
          const template = this.templateService.getManualAssignmentTemplate(
            projectWithGroup,
            groupWithMembers,
            member,
          );
          await this.emailService.sendEmail(
            member.email,
            template.subject,
            template.html,
          );
        }
      }
    }

    return this.prisma.group.findUnique({
      where: { id: group.id },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
        project: {
          select: { id: true, name: true },
        },
      },
    });
  }

  /**
   * Récupération de tous les groupes d'un projet
   */
  async findAllByProject(projectId: string) {
    return this.prisma.group.findMany({
      where: { projectId },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
      },
    });
  }

  /**
   * Récupération d'un groupe par ID
   */
  async findOne(id: string) {
    const group = await this.prisma.group.findUnique({
      where: { id },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
        project: {
          select: {
            id: true,
            name: true,
            minGroupSize: true,
            maxGroupSize: true,
          },
        },
      },
    });

    if (!group) {
      throw new NotFoundException(`Groupe avec l'ID ${id} non trouvé`);
    }

    return group;
  }

  /**
   * Mise à jour d'un groupe
   */
  async update(id: string, updateGroupDto: UpdateGroupDto) {
    // Vérifier que le groupe existe et récupérer le projet associé
    const group = await this.prisma.group.findUnique({
      where: { id },
      include: { project: true },
    });

    if (!group) {
      throw new NotFoundException(`Groupe avec l'ID ${id} non trouvé`);
    }

    // Vérifier que le projet est en brouillon (DRAFT) pour permettre les modifications
    if (group.project.status !== 'DRAFT') {
      throw new BadRequestException(
        'Les groupes ne peuvent être modifiés que lorsque le projet est en brouillon',
      );
    }

    // Filtrer les propriétés undefined pour Prisma
    const updateData: Prisma.GroupUpdateInput = {};

    if (updateGroupDto.name !== undefined) {
      updateData.name = updateGroupDto.name;
    }

    return this.prisma.group.update({
      where: { id },
      data: updateData,
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
      },
    });
  }

  /**
   * Ajout d'un membre à un groupe
   */
  async addMember(groupId: string, addMemberDto: AddGroupMemberDto) {
    const group = await this.findOne(groupId);

    // Vérifier que le projet est en brouillon (DRAFT) pour permettre les modifications
    if (group.project.status !== 'DRAFT') {
      throw new BadRequestException(
        'Les groupes ne peuvent être modifiés que lorsque le projet est en brouillon',
      );
    }

    // Vérifier la capacité du groupe
    if (group.members.length >= group.project.maxGroupSize) {
      throw new BadRequestException('Le groupe a atteint sa capacité maximale');
    }

    // Vérifier que l'utilisateur n'est pas déjà dans un groupe pour ce projet
    const existingMembership = await this.prisma.groupMember.findFirst({
      where: {
        userId: addMemberDto.userId,
        group: { projectId: group.project.id },
      },
    });

    if (existingMembership) {
      throw new BadRequestException(
        'Cet étudiant est déjà dans un groupe pour ce projet',
      );
    }

    // Ajouter le membre
    await this.prisma.groupMember.create({
      data: {
        groupId: groupId,
        userId: addMemberDto.userId,
      },
    });

    return this.findOne(groupId);
  }

  /**
   * Suppression d'un membre d'un groupe
   */
  async removeMember(groupId: string, userId: string) {
    const group = await this.prisma.group.findUnique({
      where: { id: groupId },
      include: { project: true },
    });

    if (!group) {
      throw new NotFoundException(`Groupe avec l'ID ${groupId} non trouvé`);
    }

    // Vérifier que le projet est en brouillon (DRAFT) pour permettre les modifications
    if (group.project.status !== 'DRAFT') {
      throw new BadRequestException(
        'Les groupes ne peuvent être modifiés que lorsque le projet est en brouillon',
      );
    }

    const membership = await this.prisma.groupMember.findFirst({
      where: {
        groupId: groupId,
        userId: userId,
      },
    });

    if (!membership) {
      throw new NotFoundException(
        "Cet utilisateur n'est pas membre de ce groupe",
      );
    }

    await this.prisma.groupMember.delete({
      where: { id: membership.id },
    });

    return this.findOne(groupId);
  }

  /**
   * Suppression d'un groupe
   */
  async remove(id: string) {
    const group = await this.findOne(id);

    // Vérifier que le projet est en brouillon (DRAFT) pour permettre les modifications
    if (group.project.status !== 'DRAFT') {
      throw new BadRequestException(
        'Les groupes ne peuvent être modifiés que lorsque le projet est en brouillon',
      );
    }

    // Supprimer d'abord tous les membres
    await this.prisma.groupMember.deleteMany({
      where: { groupId: id },
    });

    // Puis supprimer le groupe
    await this.prisma.group.delete({
      where: { id },
    });

    return { message: `Groupe ${group.name} supprimé avec succès` };
  }
}
