import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Put,
  Req,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';
import { UserService } from './user.service';
import { JWTAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import type { AuthenticatedRequest } from 'src/auth/types/auth.types';
import { UpdateUserDto } from './dto/update-user.dto';

@ApiTags('Users')
@Controller('users')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get('me')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({
    summary: "Récupérer les informations de l'utilisateur connecté",
  })
  @ApiResponse({
    status: 200,
    description: 'Informations utilisateur récupérées avec succès',
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getMe(@Req() req: AuthenticatedRequest) {
    return await this.userService.getUser(req.user);
  }

  @Get()
  @ApiOperation({ summary: 'Récupérer tous les utilisateurs' })
  @ApiResponse({ status: 200, description: 'Liste de tous les utilisateurs' })
  findAll() {
    return this.userService.getAllUsers();
  }

  @Get('students/without-promotion')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Récupérer les étudiants sans promotion' })
  @ApiResponse({
    status: 200,
    description: 'Liste des étudiants sans promotion assignée',
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  async getStudentsWithoutPromotion() {
    return await this.userService.getStudentsWithoutPromotion();
  }

  @Delete(':id')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Supprimer un utilisateur' })
  @ApiParam({ name: 'id', description: "ID de l'utilisateur à supprimer" })
  @ApiResponse({ status: 200, description: 'Utilisateur supprimé avec succès' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Utilisateur non trouvé' })
  async deleteUser(@Param('id') id: string) {
    return this.userService.deleteUser(id);
  }

  @Put()
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({
    summary: "Mettre à jour les informations de l'utilisateur connecté",
  })
  @ApiBody({
    type: UpdateUserDto,
    description: 'Données de mise à jour (partielles)',
    examples: {
      'Mise à jour prénom': {
        value: { firstname: 'John' },
        description: 'Mise à jour du prénom uniquement',
      },
      'Mise à jour complète': {
        value: {
          firstname: 'John',
          lastname: 'Smith',
          email: 'john.smith@example.com',
        },
        description: 'Mise à jour de plusieurs champs',
      },
    },
  })
  @ApiResponse({
    status: 200,
    description: 'Utilisateur mis à jour avec succès',
    schema: {
      example: {
        id: 'user_123',
        email: 'john.smith@example.com',
        firstname: 'John',
        lastname: 'Smith',
        role: 'STUDENT',
        updatedAt: '2024-01-15T14:30:00Z',
      },
    },
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  async updateUser(
    @Req() req: AuthenticatedRequest,
    @Body() body: UpdateUserDto,
  ) {
    return this.userService.updateUser(req.user.id, body);
  }

  @Get('promotion/teacher/:id')
  @UseGuards(JWTAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: "Récupérer la promotion d'un enseignant" })
  @ApiParam({ name: 'id', description: "ID de l'enseignant" })
  @ApiResponse({
    status: 200,
    description: "Promotion de l'enseignant récupérée avec succès",
  })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({
    status: 404,
    description: 'Enseignant ou promotion non trouvé(e)',
  })
  async getPromotionByTeacher(@Param('id') id: string) {
    return await this.userService.getPromotionByTeacherId(id);
  }
}
