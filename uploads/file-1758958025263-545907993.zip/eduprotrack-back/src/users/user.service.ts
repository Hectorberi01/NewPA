import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import type { Prisma } from '@prisma/client';
import { Role } from '@prisma/client';
import type { CreateUserDto } from './dto/create-user.dto';
import type { ValidatedUser } from 'src/auth/types/auth.types';

@Injectable()
export class UserService {
  constructor(private readonly prisma: PrismaService) {}

  async getUser(payload: ValidatedUser) {
    const foundedUser = await this.prisma.user.findUnique({
      where: {
        id: payload.id,
      },
      select: {
        id: true,
        email: true,
        firstname: true,
        lastname: true,
        role: true,
      },
    });

    if (!foundedUser) {
      throw new NotFoundException('Utilisateur non trouvé');
    }

    return foundedUser;
  }

  async createTeacherUser(data: CreateUserDto) {
    // ✅ Créer avec le bon type Prisma et gérer les undefined
    const userData: Prisma.UserCreateInput = {
      email: data.email,
      firstname: data.firstname,
      lastname: data.lastname,
      role: data.role,
      // Filtrer undefined pour exactOptionalPropertyTypes
      accessToken: data.accessToken ?? null,
      refreshToken: data.refreshToken ?? null,
    };

    const user = await this.prisma.user.create({
      data: userData,
    });

    return user;
  }

  async getAllUsers() {
    return this.prisma.user.findMany({
      select: {
        id: true,
        email: true,
        firstname: true,
        lastname: true,
        role: true,
      },
    });
  }

  async deleteUser(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    await this.prisma.user.delete({
      where: { id },
    });
  }

  async updateUser(id: string, data: Partial<CreateUserDto>) {
    const updateData: Prisma.UserUpdateInput = {};

    if (data.email !== undefined) updateData.email = data.email;
    if (data.firstname !== undefined) updateData.firstname = data.firstname;
    if (data.lastname !== undefined) updateData.lastname = data.lastname;
    if (data.role !== undefined) updateData.role = data.role;
    if (data.accessToken !== undefined)
      updateData.accessToken = data.accessToken ?? null;
    if (data.refreshToken !== undefined)
      updateData.refreshToken = data.refreshToken ?? null;

    const user = await this.prisma.user.update({
      where: { id },
      data: updateData,
    });

    return user;
  }

  async getStudentsWithoutPromotion() {
    const students = await this.prisma.user.findMany({
      where: {
        role: Role.STUDENT,
        studentPromotions: {
          none: {},
        },
      },
      select: {
        id: true,
        email: true,
        firstname: true,
        lastname: true,
        role: true,
      },
    });

    return students;
  }

  async getPromotionByTeacherId(teacherId: string) {
    return this.prisma.promotion.findMany({
      where: {
        teachers: {
          some: {
            user: {
              id: teacherId,
            },
          },
        },
      },
      select: {
        id: true,
        name: true,
      },
    });
  }
}
