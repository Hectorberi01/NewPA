import type { Role } from '@prisma/client';

export interface UserDto {
  id: string;
  email: string;
  name: string;
  role: Role;
  createdAt: Date;
}
