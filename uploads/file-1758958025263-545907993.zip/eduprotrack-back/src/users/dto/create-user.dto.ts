import { IsEmail, IsEnum, IsOptional, IsString } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Role } from '@prisma/client';

export interface CreateUserDto {
  email: string;
  firstname: string;
  lastname: string;
  avatar?: string | null;
  role: Role;
  accessToken?: string | null;
  refreshToken?: string | null;
}

// Classe pour la validation avec class-validator
export class CreateUserDtoValidation implements CreateUserDto {
  @ApiProperty({
    description: "Adresse email de l'utilisateur",
    example: 'john.doe@example.com',
    format: 'email',
  })
  @IsEmail()
  email!: string;

  @ApiProperty({
    description: "Prénom de l'utilisateur",
    example: 'John',
    minLength: 1,
    maxLength: 50,
  })
  @IsString()
  firstname!: string;

  @ApiProperty({
    description: "Nom de famille de l'utilisateur",
    example: 'Doe',
    minLength: 1,
    maxLength: 50,
  })
  @IsString()
  lastname!: string;

  @ApiPropertyOptional({
    description: "URL de l'avatar de l'utilisateur",
    example: 'https://example.com/avatars/john-doe.jpg',
    nullable: true,
  })
  @IsOptional()
  @IsString()
  avatar?: string | null;

  @ApiProperty({
    description: "Rôle de l'utilisateur dans le système",
    enum: Role,
    example: Role.STUDENT,
    enumName: 'Role',
  })
  @IsEnum(Role)
  role!: Role;

  @ApiPropertyOptional({
    description: "Token d'accès JWT (géré automatiquement)",
    example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
    nullable: true,
  })
  @IsOptional()
  @IsString()
  accessToken?: string | null;

  @ApiPropertyOptional({
    description: 'Token de rafraîchissement (géré automatiquement)',
    example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
    nullable: true,
  })
  @IsOptional()
  @IsString()
  refreshToken?: string | null;
}
