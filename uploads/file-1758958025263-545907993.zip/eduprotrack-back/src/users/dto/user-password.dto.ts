import { IsEmail, IsString } from 'class-validator';

export interface UserPasswordDto {
  email: string;
  password: string;
}

export class UserPasswordDtoValidation implements UserPasswordDto {
  @IsEmail()
  email!: string;

  @IsString()
  password!: string;
}
