import { PartialType, OmitType } from '@nestjs/swagger';
import { CreateUserDtoValidation } from './create-user.dto';

export class UpdateUserDto extends PartialType(
  OmitType(CreateUserDtoValidation, ['accessToken', 'refreshToken'] as const),
) {}
