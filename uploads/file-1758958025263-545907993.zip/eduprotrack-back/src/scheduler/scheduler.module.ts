import { Module } from '@nestjs/common';
import type { Provider } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { SchedulerService } from './scheduler.service';
import { SchedulerController } from './scheduler.controller';
import { PrismaService } from '../prisma/prisma.service';
import { GroupsModule } from '../groups/groups.module';
import { EmailService } from '../notifications/email.service';
import { TemplateService } from '../notifications/template.service';

const providers: Provider[] = [
  SchedulerService,
  PrismaService,
  EmailService,
  TemplateService,
];

@Module({
  imports: [ScheduleModule.forRoot(), GroupsModule],
  controllers: [SchedulerController],
  providers,
  exports: [SchedulerService],
})
export class SchedulerModule {}
