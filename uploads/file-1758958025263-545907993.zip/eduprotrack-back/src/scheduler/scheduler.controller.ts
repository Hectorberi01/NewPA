import { Controller, Get, Post, Param, UseGuards } from '@nestjs/common';
import { SchedulerService } from './scheduler.service';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../auth/guards/teacher.guard';

@Controller('admin/scheduler')
@UseGuards(JWTAuthGuard, TeacherGuard)
export class SchedulerController {
  constructor(private readonly schedulerService: SchedulerService) {}

  /**
   * Statistiques du scheduler
   */
  @Get('stats')
  getStats() {
    return this.schedulerService.getSchedulerStats();
  }

  /**
   * Forcer l'affectation automatique pour un projet
   */
  @Post('force-assignment/:projectId')
  forceAutoAssignment(@Param('projectId') projectId: string) {
    return this.schedulerService.forceAutoAssignment(projectId);
  }
}
