import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../prisma/prisma.service';
import { GroupManagementService } from '../groups/group-management.service';
import { GroupFormationMode } from '@prisma/client';

@Injectable()
export class SchedulerService {
  private readonly logger = new Logger(SchedulerService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly groupManagementService: GroupManagementService,
  ) {}

  /**
   * Tâche quotidienne pour les rappels de deadline (J-1)
   * Exécutée tous les jours à 10h00
   */
  @Cron('0 10 * * *')
  async handleDeadlineReminders() {
    this.logger.log('Exécution de la tâche de rappel deadline...');

    try {
      // Calculer la date de demain
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);

      const dayAfterTomorrow = new Date(tomorrow);
      dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 1);

      // Trouver les projets avec deadline entre demain 00:00 et après-demain 00:00
      const projectsWithDeadline = await this.prisma.project.findMany({
        where: {
          groupFormationMode: GroupFormationMode.FREE,
          groupDeadline: {
            gte: tomorrow,
            lt: dayAfterTomorrow,
          },
        },
      });

      this.logger.log(
        `${projectsWithDeadline.length} projets avec deadline demain trouvés`,
      );

      for (const project of projectsWithDeadline) {
        try {
          await this.groupManagementService.sendDeadlineReminder(project.id);
          this.logger.log(
            `Rappel envoyé pour le projet ${project.name} (${project.id})`,
          );
        } catch (error) {
          this.logger.error(
            `Erreur lors de l'envoi du rappel pour le projet ${project.id}:`,
            error,
          );
        }
      }
    } catch (error) {
      this.logger.error('Erreur lors de la tâche de rappel deadline:', error);
    }
  }

  /**
   * Tâche toutes les heures pour l'affectation automatique
   * Vérifie les deadlines passées
   */
  @Cron(CronExpression.EVERY_HOUR)
  async handleAutoAssignments() {
    this.logger.log('Vérification des affectations automatiques...');

    try {
      const now = new Date();

      // Trouver les projets avec deadline dépassée mais pas encore traités
      const projectsWithExpiredDeadline = await this.prisma.project.findMany({
        where: {
          groupFormationMode: GroupFormationMode.FREE,
          groupDeadline: {
            lt: now,
          },
          // On pourrait ajouter un flag "autoAssignmentDone" pour éviter les doublons
        },
      });

      this.logger.log(
        `${projectsWithExpiredDeadline.length} projets avec deadline expirée trouvés`,
      );

      for (const project of projectsWithExpiredDeadline) {
        try {
          // Vérifier s'il y a des étudiants non-groupés
          const result =
            await this.groupManagementService.performAutoAssignment(project.id);

          if (result.assignedStudents) {
            this.logger.log(
              `Affectation automatique réalisée pour le projet ${project.name}: ${result.assignedStudents} étudiants affectés`,
            );
          }

          // Optionnel : marquer le projet comme traité
          // await this.prisma.project.update({
          //   where: { id: project.id },
          //   data: { autoAssignmentDone: true }
          // });
        } catch (error) {
          this.logger.error(
            `Erreur lors de l'affectation automatique pour le projet ${project.id}:`,
            error,
          );
        }
      }
    } catch (error) {
      this.logger.error(
        "Erreur lors de la tâche d'affectation automatique:",
        error,
      );
    }
  }

  /**
   * Tâche manuelle pour forcer l'affectation automatique d'un projet
   */
  async forceAutoAssignment(projectId: string) {
    this.logger.log(
      `Affectation automatique forcée pour le projet ${projectId}`,
    );

    try {
      const result =
        await this.groupManagementService.performAutoAssignment(projectId);
      this.logger.log(
        `Affectation automatique réalisée: ${result.assignedStudents} étudiants affectés`,
      );
      return result;
    } catch (error) {
      this.logger.error(
        `Erreur lors de l'affectation automatique forcée:`,
        error,
      );
      throw error;
    }
  }

  /**
   * Tâche de nettoyage hebdomadaire
   * Supprime les groupes vides des projets anciens
   */
  @Cron('0 2 * * 0') // Dimanche à 2h00
  async handleWeeklyCleanup() {
    this.logger.log('Exécution du nettoyage hebdomadaire...');

    try {
      // Supprimer les groupes vides de plus de 7 jours
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);

      const result = await this.prisma.group.deleteMany({
        where: {
          createdAt: { lt: weekAgo },
          members: { none: {} }, // Groupes sans membres
        },
      });

      this.logger.log(
        `${result.count} groupes vides supprimés lors du nettoyage`,
      );
    } catch (error) {
      this.logger.error('Erreur lors du nettoyage hebdomadaire:', error);
    }
  }

  // TODO: Rappels automatiques pour les rapports - à réimplémenter selon les nouveaux besoins
  // Les méthodes de rappels pour rapports ont été temporairement désactivées
  // suite à la refactorisation du système de rapports

  /**
   * Méthode pour obtenir les statistiques du scheduler
   */
  async getSchedulerStats() {
    try {
      const now = new Date();

      const upcomingDeadlines = await this.prisma.project.count({
        where: {
          groupFormationMode: GroupFormationMode.FREE,
          groupDeadline: { gt: now },
        },
      });

      const expiredDeadlines = await this.prisma.project.count({
        where: {
          groupFormationMode: GroupFormationMode.FREE,
          groupDeadline: { lt: now },
        },
      });

      const emptyGroups = await this.prisma.group.count({
        where: {
          members: { none: {} },
        },
      });

      return {
        upcomingDeadlines,
        expiredDeadlines,
        emptyGroups,
        lastCheck: now,
      };
    } catch (error: unknown) {
      this.logger.error('Error getting scheduler stats:', error);
      throw error;
    }
  }
}
