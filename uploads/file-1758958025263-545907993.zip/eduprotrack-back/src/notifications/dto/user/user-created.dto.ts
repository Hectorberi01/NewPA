import { IsString } from 'class-validator';

export interface UserCreatedDto {
  type: string;
  name: string;
  email: string;
  role: string;
}

export class UserCreatedDtoValidation implements UserCreatedDto {
  @IsString()
  type!: string;

  @IsString()
  name!: string;

  @IsString()
  email!: string;

  @IsString()
  role!: string;
}
