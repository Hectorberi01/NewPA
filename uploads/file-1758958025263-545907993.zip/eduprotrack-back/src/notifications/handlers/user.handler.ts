import { Injectable, Logger } from '@nestjs/common';
import { EmailService } from '../email.service';
import { TemplateService } from '../template.service';
import { UserCreatedDto } from '../dto/user/user-created.dto';

interface StudentCredentials {
  firstname: string;
  lastname: string;
  email: string;
  password: string;
  loginUrl: string;
}

@Injectable()
export class UserHandler {
  private readonly logger = new Logger(UserHandler.name);

  constructor(
    private readonly emailService: EmailService,
    private readonly templateService: TemplateService,
  ) {}

  async handleUserCreated(userCreatedEvent: UserCreatedDto) {
    try {
      this.logger.debug(
        `User created event received for: ${userCreatedEvent.email}`,
      );

      // Générer le template d'email
      const { subject, html } =
        this.templateService.getWelcomeTemplate(userCreatedEvent);

      // Envoyer l'email
      await this.emailService.sendEmail(userCreatedEvent.email, subject, html);

      this.logger.log(`Welcome email sent to ${userCreatedEvent.email}`);
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      this.logger.error(`Error processing user.created event: ${errorMessage}`);
    }
  }

  async handleStudentCreated(studentCredentials: StudentCredentials) {
    try {
      this.logger.debug(
        `Student created event received for: ${studentCredentials.email}`,
      );

      // Générer le template d'email avec les identifiants
      const { subject, html } =
        this.templateService.getStudentCredentialsTemplate(studentCredentials);

      // Envoyer l'email
      await this.emailService.sendEmail(
        studentCredentials.email,
        subject,
        html,
      );

      this.logger.log(`Credentials email sent to ${studentCredentials.email}`);
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      this.logger.error(
        `Error processing student.created event: ${errorMessage}`,
      );
    }
  }
}
