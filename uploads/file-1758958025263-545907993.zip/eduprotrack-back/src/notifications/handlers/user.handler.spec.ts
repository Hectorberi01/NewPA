import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { UserHandler } from './user.handler';
import { EmailService } from '../email.service';
import { TemplateService } from '../template.service';
import type { UserCreatedDto } from '../dto/user/user-created.dto';
import { Role } from '@prisma/client';

describe('UserHandler', () => {
  let handler: UserHandler;

  const mockEmailService = {
    sendEmail: jest.fn().mockResolvedValue(undefined),
  };

  const mockTemplateService = {
    getWelcomeTemplate: jest.fn().mockReturnValue({
      subject: 'Welcome',
      html: '<p>Welcome</p>',
    }),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UserHandler,
        {
          provide: EmailService,
          useValue: mockEmailService,
        },
        {
          provide: TemplateService,
          useValue: mockTemplateService,
        },
      ],
    }).compile();

    handler = module.get<UserHandler>(UserHandler);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(handler).toBeDefined();
  });

  it('should initialize correctly', () => {
    expect(handler).toBeDefined();
  });

  it('should handle user created event', async () => {
    const userEvent = {
      name: 'John Doe',
      email: 'john@example.com',
      role: Role.TEACHER,
    };

    // Reset mock before test
    mockTemplateService.getWelcomeTemplate.mockReturnValue({
      subject: 'Welcome',
      html: '<p>Welcome</p>',
    });

    await handler.handleUserCreated(userEvent as UserCreatedDto);

    expect(mockTemplateService.getWelcomeTemplate).toHaveBeenCalledWith(
      userEvent,
    );
    expect(mockEmailService.sendEmail).toHaveBeenCalledWith(
      'john@example.com',
      'Welcome',
      '<p>Welcome</p>',
    );
  });
});
