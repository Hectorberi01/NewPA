import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import { EmailService } from './email.service';
import * as nodemailer from 'nodemailer';

// Mock de nodemailer avec un typage correct
jest.mock('nodemailer', () => ({
  createTransport: jest.fn().mockReturnValue({
    sendMail: jest.fn().mockResolvedValue({
      accepted: ['test@example.com'],
      rejected: [],
      envelopeTime: 10,
      messageTime: 20,
      messageSize: 500,
      response: '250 OK',
      envelope: {
        from: 'test@example.com',
        to: ['test@example.com'],
      },
    }),
    verify: jest.fn().mockResolvedValue(true),
  }),
}));

describe('EmailService', () => {
  let service: EmailService;
  let mockTransporter: any;

  beforeEach(async () => {
    // Mock des variables d'environnement pour les tests
    process.env.SMTP_HOST = 'localhost';
    process.env.SMTP_PORT = '1025';
    process.env.SMTP_USER = '';
    process.env.SMTP_PASSWORD = '';
    process.env.SMTP_FROM = 'test@example.com';
    process.env.SMTP_SECURE = 'false';

    // Réinitialiser les mocks
    jest.clearAllMocks();

    mockTransporter = {
      sendMail: jest.fn().mockResolvedValue({
        accepted: ['test@example.com'],
        rejected: [],
        envelopeTime: 10,
        messageTime: 20,
        messageSize: 500,
        response: '250 OK',
        envelope: {
          from: 'test@example.com',
          to: ['test@example.com'],
        },
      }),
      verify: jest.fn().mockResolvedValue(true),
    };

    (nodemailer.createTransport as jest.Mock).mockReturnValue(mockTransporter);

    const module: TestingModule = await Test.createTestingModule({
      providers: [EmailService],
    }).compile();

    service = module.get<EmailService>(EmailService);
  });

  afterEach(() => {
    // Nettoyer les variables d'environnement
    delete process.env.SMTP_HOST;
    delete process.env.SMTP_PORT;
    delete process.env.SMTP_USER;
    delete process.env.SMTP_PASSWORD;
    delete process.env.SMTP_FROM;
    delete process.env.SMTP_SECURE;
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should send email successfully', async () => {
    const to = 'test@example.com';
    const subject = 'Test Subject';
    const html = '<p>Test content</p>';

    await expect(service.sendEmail(to, subject, html)).resolves.not.toThrow();

    expect(mockTransporter.sendMail).toHaveBeenCalledWith({
      from: 'test@example.com',
      to,
      subject,
      html,
    });
  });

  it('should handle email sending errors gracefully', async () => {
    const error = new Error('SMTP connection failed');
    mockTransporter.sendMail.mockRejectedValue(error);

    // Le service devrait logger l'erreur mais ne pas lancer d'exception
    await expect(
      service.sendEmail('test@example.com', 'Test Subject', '<p>Test</p>'),
    ).resolves.not.toThrow();

    expect(mockTransporter.sendMail).toHaveBeenCalled();
  });

  it('should handle missing transporter gracefully', async () => {
    // Simuler un échec d'initialisation du transporter
    (nodemailer.createTransport as jest.Mock).mockImplementation(() => {
      throw new Error('Failed to create transport');
    });

    const module: TestingModule = await Test.createTestingModule({
      providers: [EmailService],
    }).compile();

    const serviceWithFailedTransporter = module.get<EmailService>(EmailService);

    // Devrait ne pas lancer d'exception même si le transporter n'est pas initialisé
    await expect(
      serviceWithFailedTransporter.sendEmail(
        'test@example.com',
        'Test Subject',
        '<p>Test</p>',
      ),
    ).resolves.not.toThrow();
  });

  it('should use correct SMTP configuration', () => {
    expect(nodemailer.createTransport).toHaveBeenCalledWith({
      host: 'localhost',
      port: 1025,
      secure: false,
      auth: undefined,
    });
  });
});
