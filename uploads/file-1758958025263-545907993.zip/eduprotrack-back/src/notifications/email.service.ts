import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import type { Transporter } from 'nodemailer';

@Injectable()
export class EmailService {
  private readonly transporter: Transporter | null;
  private readonly logger = new Logger(EmailService.name);

  constructor() {
    try {
      const host = process.env.SMTP_HOST ?? 'localhost';
      const port = Number(process.env.SMTP_PORT ?? '1025');
      const user = process.env.SMTP_USER ?? '';
      const pass = process.env.SMTP_PASSWORD ?? '';
      const secure = process.env.SMTP_SECURE === 'true';

      this.logger.log(
        `📧 Email configuration: Host=${host}, Port=${port}, Secure=${secure}`,
      );

      this.transporter = nodemailer.createTransport({
        host,
        port,
        secure,
        auth: user ? { user, pass } : undefined,
        // Ajout de tolérance pour éviter les crashes
        // pool: false,
        // maxConnections: 1,
        // maxMessages: 1,
      });

      this.logger.log('✅ Email service initialized successfully');
    } catch (error) {
      this.logger.error('❌ Failed to initialize email service:', error);
      this.transporter = null;
    }
  }

  async sendEmail(to: string, subject: string, html: string): Promise<void> {
    try {
      if (!this.transporter) {
        this.logger.warn(
          '⚠️ Email transporter not initialized, skipping email',
        );
        return;
      }

      await this.transporter.sendMail({
        from: process.env.SMTP_FROM ?? 'noreply@eduprotrack.com',
        to,
        subject,
        html,
      });

      this.logger.log(`✅ Email sent successfully to ${to}`);
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      this.logger.error(`❌ Failed to send email to ${to}: ${errorMessage}`);
      // Ne pas faire crash l'app, juste logger l'erreur
    }
  }
}
