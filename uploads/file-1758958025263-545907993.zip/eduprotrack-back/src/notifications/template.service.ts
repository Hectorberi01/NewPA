import { Injectable } from '@nestjs/common';
// Types are imported but not used in this service yet
// import type {
//   ProjectNotificationData,
//   GroupWithMembers,
// } from '../types/common.types';

interface UserTemplate {
  name: string;
  email: string;
  role: string;
}

interface StudentCredentialsTemplate {
  firstname: string;
  lastname: string;
  email: string;
  password: string;
  loginUrl: string;
}

// 🎯 INTERFACES POUR TEMPLATES EMAIL PROJET
export interface ProjectTemplate {
  id: string;
  name: string;
  description?: string | null;
  teacher: {
    firstname: string | null;
    lastname: string | null;
  };
  promotion: {
    name: string;
  };
  groupFormationMode: string;
  minGroupSize: number;
  maxGroupSize: number;
  groupDeadline?: Date | null;
}

// 🎯 INTERFACES POUR TEMPLATES EMAIL RAPPORT
export interface ReportTemplate {
  id: string;
  title: string;
  description?: string | null;
  deadline?: Date | null;
  collaborationType: string;
  project: {
    id: string;
    name: string;
    userId: string;
  };
  group?: {
    name: string;
    members: Array<{
      user: {
        firstname: string | null;
        lastname: string | null;
      };
    }>;
  };
}

interface GroupTemplate {
  name: string;
  members: Array<{
    user: {
      firstname: string | null;
      lastname: string | null;
    };
  }>;
}

@Injectable()
export class TemplateService {
  getWelcomeTemplate(user: UserTemplate): { subject: string; html: string } {
    const roleText = user.role === 'TEACHER' ? 'enseignant' : 'étudiant';

    const subject = `Bienvenue sur le Gestionnaire de Projets Étudiants - Compte ${roleText}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4a4a4a;">Bienvenue sur le Gestionnaire de Projets Étudiants</h2>
        <p>Bonjour ${user.name},</p>
        <p>Votre compte <strong>${roleText}</strong> a été créé avec succès.</p>
        <p>Vous pouvez maintenant vous connecter sur la plateforme avec votre adresse email : <strong>${user.email}</strong></p>
        <div style="margin-top: 30px; text-align: center;">
          <a href="http://localhost:3000/login" 
             style="background-color: #4285f4; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">
            Se connecter
          </a>
        </div>
        <p style="margin-top: 30px; font-size: 0.9em; color: #666;">
          Si vous n'êtes pas à l'origine de cette demande, veuillez ignorer cet email.
        </p>
      </div>
    `;

    return { subject, html };
  }

  getStudentCredentialsTemplate(student: StudentCredentialsTemplate): {
    subject: string;
    html: string;
  } {
    const subject = 'Bienvenue ! Votre compte étudiant EduProTrack';

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #2c3e50; text-align: center; margin-bottom: 30px;">
            🎓 EduProTrack - Gestionnaire de Projets Étudiants
          </h1>
          
          <h2 style="color: #34495e; margin-bottom: 20px;">
            Bonjour ${student.firstname} ${student.lastname} !
          </h2>
          
          <p style="color: #555; line-height: 1.6; margin-bottom: 20px;">
            Votre compte étudiant a été créé avec succès sur la plateforme 
            <strong>EduProTrack</strong>.
          </p>
          
          <div style="background-color: #ecf0f1; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h3 style="color: #2c3e50; margin-top: 0; margin-bottom: 15px;">🔑 Vos identifiants de connexion</h3>
            <p style="color: #2c3e50; margin: 10px 0; font-size: 16px;">
              <strong>📧 Email :</strong> <span style="background-color: #fff; padding: 5px 10px; border-radius: 4px; font-family: monospace;">${student.email}</span>
            </p>
            <p style="color: #2c3e50; margin: 10px 0; font-size: 16px;">
              <strong>🔒 Mot de passe :</strong> <span style="background-color: #fff; padding: 5px 10px; border-radius: 4px; font-family: monospace;">${student.password}</span>
            </p>
          </div>
          
          <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 6px; margin: 25px 0;">
            <p style="color: #856404; margin: 0; font-size: 14px;">
              ⚠️ <strong>Important :</strong> Conservez précieusement ces identifiants. 
              Nous vous recommandons de changer votre mot de passe lors de votre première connexion.
            </p>
          </div>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="${student.loginUrl}" 
               style="background-color: #3498db; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; transition: background-color 0.3s;">
              🚀 Se connecter maintenant
            </a>
          </div>
          
          <h3 style="color: #2c3e50; margin-top: 30px; margin-bottom: 15px;">
            Une fois connecté, vous pourrez :
          </h3>
          
          <ul style="color: #555; line-height: 1.8; padding-left: 20px;">
            <li>📋 Consulter vos projets assignés</li>
            <li>👥 Former ou rejoindre des groupes</li>
            <li>📤 Soumettre vos livrables</li>
            <li>📝 Rédiger vos rapports en ligne</li>
            <li>📊 Suivre vos notes et évaluations</li>
          </ul>
          
          <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ecf0f1;">
            <p style="color: #7f8c8d; font-size: 12px; margin: 0;">
              Si vous n'êtes pas à l'origine de cette demande ou si vous rencontrez des difficultés, 
              contactez votre enseignant ou l'administrateur de la plateforme.
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * Template pour notification projet visible
   */
  getProjectVisibleTemplate(project: ProjectTemplate): {
    subject: string;
    html: string;
  } {
    const subject = `Nouveau projet disponible : ${project.name}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #2c3e50; text-align: center; margin-bottom: 30px;">
            📚 Nouveau Projet Disponible
          </h1>
          
          <h2 style="color: #34495e; margin-bottom: 20px;">
            ${project.name}
          </h2>
          
          <div style="background-color: #ecf0f1; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h3 style="color: #2c3e50; margin-top: 0;">📋 Détails du projet</h3>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Description :</strong> ${project.description ?? 'Aucune description fournie'}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Enseignant :</strong> ${project.teacher.firstname || 'Prénom'} ${project.teacher.lastname || 'Nom'}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Promotion :</strong> ${project.promotion.name}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Mode de formation des groupes :</strong> ${this.getFormationModeText(project.groupFormationMode)}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Taille des groupes :</strong> ${project.minGroupSize} à ${project.maxGroupSize} étudiants
            </p>
          </div>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/projects" 
               style="background-color: #3498db; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              👀 Voir le projet
            </a>
          </div>
          
          <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ecf0f1;">
            <p style="color: #7f8c8d; font-size: 12px; margin: 0;">
              Vous pouvez maintenant consulter ce projet et, selon le mode choisi par l'enseignant, 
              former ou rejoindre un groupe.
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * Template pour rappel deadline formation groupes
   */
  getDeadlineReminderTemplate(project: ProjectTemplate): {
    subject: string;
    html: string;
  } {
    const subject = `⏰ Rappel : Formation des groupes - ${project.name}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #e74c3c; text-align: center; margin-bottom: 30px;">
            ⏰ Rappel Important
          </h1>
          
          <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h2 style="color: #856404; margin-top: 0;">
              Formation des groupes - ${project.name}
            </h2>
            <p style="color: #856404; margin: 15px 0; font-size: 16px;">
              <strong>⚠️ La deadline approche !</strong> Vous avez jusqu'à demain pour rejoindre un groupe.
            </p>
            <p style="color: #856404; margin: 10px 0;">
              <strong>Date limite :</strong> ${
                project.groupDeadline
                  ? new Date(project.groupDeadline).toLocaleDateString(
                      'fr-FR',
                      {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      },
                    )
                  : 'Non définie'
              }
            </p>
          </div>
          
          <p style="color: #2c3e50; line-height: 1.6; margin: 20px 0;">
            Si vous n'avez pas encore rejoint un groupe, nous vous encourageons à le faire rapidement. 
            Après la deadline, les étudiants non-groupés seront automatiquement affectés à un groupe.
          </p>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/projects/${project.id}" 
               style="background-color: #e74c3c; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              🏃‍♂️ Rejoindre un groupe maintenant
            </a>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * Template pour notification affectation automatique
   */
  getAutoAssignmentTemplate(
    project: ProjectTemplate,
    group: GroupTemplate,
  ): { subject: string; html: string } {
    const subject = `Affectation automatique - ${project.name}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #2c3e50; text-align: center; margin-bottom: 30px;">
            🎲 Affectation Automatique
          </h1>
          
          <p style="color: #2c3e50; line-height: 1.6; margin: 20px 0;">
            La deadline pour former les groupes étant dépassée, vous avez été automatiquement 
            affecté(e) à un groupe pour le projet <strong>${project.name}</strong>.
          </p>
          
          <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h3 style="color: #155724; margin-top: 0;">👥 Votre groupe</h3>
            <p style="color: #155724; margin: 10px 0; font-size: 16px;">
              <strong>Nom :</strong> ${group.name}
            </p>
            <p style="color: #155724; margin: 10px 0;">
              <strong>Membres :</strong>
            </p>
            <ul style="color: #155724; margin: 10px 0; padding-left: 20px;">
              ${group.members.map((member) => `<li>${member.user.firstname || 'Prénom'} ${member.user.lastname || 'Nom'}</li>`).join('')}
            </ul>
          </div>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/projects/${project.id}" 
               style="background-color: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              👥 Voir mon groupe
            </a>
          </div>
          
          <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ecf0f1;">
            <p style="color: #7f8c8d; font-size: 12px; margin: 0;">
              Vous pouvez maintenant commencer à travailler avec vos coéquipiers. 
              Bonne collaboration !
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * 🆕 Template pour notification affectation aléatoire
   */
  getRandomAssignmentTemplate(
    project: ProjectTemplate,
    group: GroupTemplate,
  ): { subject: string; html: string } {
    const subject = `Affectation aléatoire - ${project.name}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #6f42c1; text-align: center; margin-bottom: 30px;">
            🎲 Affectation Aléatoire
          </h1>
          
          <p style="color: #2c3e50; line-height: 1.6; margin: 20px 0;">
            Les groupes ont été formés aléatoirement pour le projet <strong>${project.name}</strong>. 
            Voici votre équipe !
          </p>
          
          <div style="background-color: #e8d5ff; border: 1px solid #d6bbfc; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h3 style="color: #6f42c1; margin-top: 0;">🎯 Votre groupe</h3>
            <p style="color: #6f42c1; margin: 10px 0; font-size: 16px;">
              <strong>Nom :</strong> ${group.name}
            </p>
            <p style="color: #6f42c1; margin: 10px 0;">
              <strong>Membres :</strong>
            </p>
            <ul style="color: #6f42c1; margin: 10px 0; padding-left: 20px;">
              ${group.members.map((member) => `<li>${member.user.firstname || 'Prénom'} ${member.user.lastname || 'Nom'}</li>`).join('')}
            </ul>
          </div>
          
          <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 6px; margin: 25px 0;">
            <p style="color: #155724; margin: 0; font-size: 14px;">
              💡 <strong>Conseil :</strong> C'est une excellente opportunité de travailler avec de nouvelles personnes 
              et de développer vos compétences collaboratives !
            </p>
          </div>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/projects/${project.id}" 
               style="background-color: #6f42c1; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              🚀 Découvrir mon équipe
            </a>
          </div>
          
          <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ecf0f1;">
            <p style="color: #7f8c8d; font-size: 12px; margin: 0;">
              N'hésitez pas à prendre contact avec vos coéquipiers pour organiser votre travail. 
              Bonne collaboration et bon projet !
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * Template pour rappel de deadline de rapport
   */
  getReportDeadlineReminderTemplate(data: {
    report: ReportTemplate;
    daysBefore: number;
  }): { subject: string; html: string } {
    const { report, daysBefore } = data;

    const urgencyLevel = this.getUrgencyLevel(daysBefore);
    const collaborationText = this.getCollaborationText(
      report.collaborationType,
    );

    const subject = `${urgencyLevel.emoji} Rappel : ${report.title} - ${urgencyLevel.text}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: ${urgencyLevel.color}; text-align: center; margin-bottom: 30px;">
            ${urgencyLevel.emoji} Rappel de Deadline
          </h1>
          
          <div style="background-color: ${urgencyLevel.bgColor}; border: 1px solid ${urgencyLevel.borderColor}; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h2 style="color: ${urgencyLevel.textColor}; margin-top: 0;">
              ${report.title}
            </h2>
            <p style="color: ${urgencyLevel.textColor}; margin: 15px 0; font-size: 16px;">
              <strong>${urgencyLevel.message}</strong>
            </p>
            <p style="color: ${urgencyLevel.textColor}; margin: 10px 0;">
              <strong>Projet :</strong> ${report.project.name}
            </p>
            <p style="color: ${urgencyLevel.textColor}; margin: 10px 0;">
              <strong>Enseignant :</strong> Professeur (${report.project.userId})
            </p>
            <p style="color: ${urgencyLevel.textColor}; margin: 10px 0;">
              <strong>Type :</strong> ${collaborationText}
            </p>
            <p style="color: ${urgencyLevel.textColor}; margin: 10px 0;">
              <strong>Date limite :</strong> ${
                report.deadline
                  ? new Date(report.deadline).toLocaleDateString('fr-FR', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'Non définie'
              }
            </p>
          </div>
          
          ${
            report.description
              ? `
            <div style="background-color: #f8f9fa; padding: 15px; border-radius: 6px; margin: 20px 0;">
              <h3 style="color: #2c3e50; margin-top: 0;">📋 Description</h3>
              <p style="color: #555; margin: 0;">${report.description}</p>
            </div>
          `
              : ''
          }
          
          ${
            report.group
              ? `
            <div style="background-color: #e8f5e8; padding: 15px; border-radius: 6px; margin: 20px 0;">
              <h3 style="color: #2c3e50; margin-top: 0;">👥 Votre groupe : ${report.group.name}</h3>
              <p style="color: #555; margin: 5px 0;">Membres du groupe :</p>
              <ul style="color: #555; margin: 10px 0; padding-left: 20px;">
                ${report.group.members.map((member) => `<li>${member.user.firstname || 'Prénom'} ${member.user.lastname || 'Nom'}</li>`).join('')}
              </ul>
            </div>
          `
              : ''
          }
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/reports/${report.id}" 
               style="background-color: ${urgencyLevel.color}; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              📝 Accéder au rapport
            </a>
          </div>
          
          <div style="background-color: #d1ecf1; border: 1px solid #bee5eb; padding: 15px; border-radius: 6px; margin: 25px 0;">
            <p style="color: #0c5460; margin: 0; font-size: 14px;">
              💡 <strong>Conseil :</strong> N'attendez pas la dernière minute ! Commencez dès maintenant 
              pour avoir le temps de bien structurer votre travail.
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * Template pour rappel de rapport en retard
   */
  getOverdueReportReminderTemplate(data: { report: ReportTemplate }): {
    subject: string;
    html: string;
  } {
    const { report } = data;

    const collaborationText = this.getCollaborationText(
      report.collaborationType,
    );
    const subject = `🚨 URGENT : Rapport en retard - ${report.title}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #dc3545; text-align: center; margin-bottom: 30px;">
            🚨 Rapport en Retard
          </h1>
          
          <div style="background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h2 style="color: #721c24; margin-top: 0;">
              ${report.title}
            </h2>
            <p style="color: #721c24; margin: 15px 0; font-size: 16px;">
              <strong>⚠️ Ce rapport est en retard !</strong> La deadline était le ${
                report.deadline
                  ? new Date(report.deadline).toLocaleDateString('fr-FR', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'Non définie'
              }
            </p>
            <p style="color: #721c24; margin: 10px 0;">
              <strong>Projet :</strong> ${report.project.name}
            </p>
            <p style="color: #721c24; margin: 10px 0;">
              <strong>Type :</strong> ${collaborationText}
            </p>
          </div>
          
          <p style="color: #2c3e50; line-height: 1.6; margin: 20px 0;">
            Votre rapport n'a pas été soumis dans les temps. Contactez rapidement votre enseignant 
            pour discuter des conséquences et des possibilités de rattrapage.
          </p>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/reports/${report.id}" 
               style="background-color: #dc3545; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              🏃‍♂️ Finaliser le rapport maintenant
            </a>
          </div>
          
          <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 6px; margin: 25px 0;">
            <p style="color: #856404; margin: 0; font-size: 14px;">
              📞 <strong>Besoin d'aide ?</strong> Contactez votre enseignant 
              pour discuter de votre situation.
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * Détermine le niveau d'urgence selon les jours restants
   */
  private getUrgencyLevel(daysBefore: number): {
    emoji: string;
    text: string;
    message: string;
    color: string;
    bgColor: string;
    borderColor: string;
    textColor: string;
  } {
    if (daysBefore >= 7) {
      return {
        emoji: '📅',
        text: 'Deadline dans 1 semaine',
        message: 'Vous avez encore une semaine pour terminer votre rapport.',
        color: '#17a2b8',
        bgColor: '#d1ecf1',
        borderColor: '#bee5eb',
        textColor: '#0c5460',
      };
    } else if (daysBefore >= 3) {
      return {
        emoji: '⏰',
        text: 'Deadline dans 3 jours',
        message: 'Plus que 3 jours ! Il est temps de finaliser votre rapport.',
        color: '#ffc107',
        bgColor: '#fff3cd',
        borderColor: '#ffeaa7',
        textColor: '#856404',
      };
    } else if (daysBefore >= 1) {
      return {
        emoji: '🚨',
        text: 'Deadline demain',
        message: 'URGENT ! Vous devez rendre votre rapport demain.',
        color: '#dc3545',
        bgColor: '#f8d7da',
        borderColor: '#f5c6cb',
        textColor: '#721c24',
      };
    } else {
      return {
        emoji: '🔥',
        text: "Deadline aujourd'hui",
        message: "TRÈS URGENT ! La deadline est aujourd'hui !",
        color: '#dc3545',
        bgColor: '#f8d7da',
        borderColor: '#f5c6cb',
        textColor: '#721c24',
      };
    }
  }

  /**
   * Texte lisible pour le type de collaboration
   */
  private getCollaborationText(collaborationType: string): string {
    switch (collaborationType) {
      case 'INDIVIDUAL':
        return 'Rapport individuel';
      case 'GROUP':
        return 'Rapport de groupe';
      default:
        return collaborationType;
    }
  }

  /**
   * Texte lisible pour le mode de formation
   */
  private getFormationModeText(mode: string): string {
    switch (mode) {
      case 'MANUAL':
        return "Manuel (groupes créés par l'enseignant)";
      case 'FREE':
        return 'Libre (vous choisissez votre groupe)';
      case 'RANDOM':
        return 'Aléatoire (groupes formés automatiquement)';
      default:
        return mode;
    }
  }

  /**
   * Template pour rappel de deadline de rapport
   */
  generateReportReminderTemplate(data: {
    studentName: string;
    projectTitle: string;
    deadline: Date;
    daysBefore: number;
    reportUrl: string;
  }): string {
    const deadlineFormatted = data.deadline.toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const urgencyInfo = this.getUrgencyLevel(data.daysBefore);

    return `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: ${urgencyInfo.color}; text-align: center; margin-bottom: 30px;">
            ${urgencyInfo.emoji} Rappel de Rapport
          </h1>
          
          <div style="background-color: ${urgencyInfo.bgColor}; border: 1px solid ${urgencyInfo.borderColor}; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h2 style="color: ${urgencyInfo.textColor}; margin-top: 0;">
              ${urgencyInfo.text}
            </h2>
            <p style="color: ${urgencyInfo.textColor}; margin: 10px 0;">
              ${urgencyInfo.message}
            </p>
          </div>
          
          <div style="margin: 25px 0;">
            <h3 style="color: #2c3e50; margin-bottom: 15px;">Bonjour ${data.studentName},</h3>
            <p style="color: #2c3e50; margin: 10px 0;">
              Nous vous rappelons que vous devez rendre votre rapport pour le projet <strong>${data.projectTitle}</strong>.
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Deadline :</strong> ${deadlineFormatted}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Temps restant :</strong> ${data.daysBefore} jour(s)
            </p>
          </div>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="${data.reportUrl}" 
               style="background-color: #3498db; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              📝 Accéder au rapport
            </a>
          </div>
          
          <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ecf0f1;">
            <p style="color: #7f8c8d; font-size: 12px; margin: 0;">
              N'oubliez pas de sauvegarder régulièrement votre travail et de respecter les consignes données.
            </p>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Template pour rappel de rapport en retard
   */
  generateOverdueReportTemplate(data: {
    studentName: string;
    projectTitle: string;
    deadline: Date;
    reportUrl: string;
  }): string {
    const deadlineFormatted = data.deadline.toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    return `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #dc3545; text-align: center; margin-bottom: 30px;">
            🚨 RAPPORT EN RETARD
          </h1>
          
          <div style="background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h2 style="color: #721c24; margin-top: 0;">
              Action requise immédiatement !
            </h2>
            <p style="color: #721c24; margin: 10px 0;">
              Votre rapport n'a pas été rendu dans les délais. Il est impératif de le soumettre au plus vite.
            </p>
          </div>
          
          <div style="margin: 25px 0;">
            <h3 style="color: #2c3e50; margin-bottom: 15px;">Bonjour ${data.studentName},</h3>
            <p style="color: #2c3e50; margin: 10px 0;">
              Votre rapport pour le projet <strong>${data.projectTitle}</strong> n'a pas été rendu dans les délais.
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Deadline dépassée :</strong> ${deadlineFormatted}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              Veuillez contacter votre enseignant et rendre votre rapport au plus vite.
            </p>
          </div>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="${data.reportUrl}" 
               style="background-color: #dc3545; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              🚨 Rendre le rapport maintenant
            </a>
          </div>
          
          <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ecf0f1;">
            <p style="color: #7f8c8d; font-size: 12px; margin: 0;">
              Ce message est automatique. En cas de problème technique, contactez le support.
            </p>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Template pour notification de rejoindre un groupe (mode FREE)
   */
  getGroupJoinTemplate(
    project: { id: string; name: string },
    group: { id: string; name: string },
    student: { firstname: string; lastname: string; email: string },
  ): { subject: string; html: string } {
    const subject = `Vous avez rejoint un groupe - ${project.name}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #28a745; text-align: center; margin-bottom: 30px;">
            ✅ Groupe rejoint avec succès !
          </h1>
          
          <div style="margin: 25px 0;">
            <h3 style="color: #2c3e50; margin-bottom: 15px;">Bonjour ${student.firstname} ${student.lastname},</h3>
            <p style="color: #2c3e50; line-height: 1.6; margin: 20px 0;">
              Félicitations ! Vous avez rejoint avec succès le groupe <strong>${group.name}</strong> 
              pour le projet <strong>${project.name}</strong>.
            </p>
          </div>
          
          <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h3 style="color: #155724; margin-top: 0;">📋 Informations du groupe</h3>
            <p style="color: #155724; margin: 10px 0;">
              <strong>Nom du groupe :</strong> ${group.name}
            </p>
            <p style="color: #155724; margin: 10px 0;">
              <strong>Projet :</strong> ${project.name}
            </p>
          </div>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/projects/${project.id}" 
               style="background-color: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              🚀 Voir mon groupe
            </a>
          </div>
          
          <div style="background-color: #d1ecf1; border: 1px solid #bee5eb; padding: 15px; border-radius: 6px; margin: 25px 0;">
            <p style="color: #0c5460; margin: 0; font-size: 14px;">
              💡 <strong>Prochaine étape :</strong> Prenez contact avec vos coéquipiers pour organiser votre travail !
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * Template pour notification d'affectation manuelle (mode MANUAL)
   */
  getManualAssignmentTemplate(
    project: { id: string; name: string },
    group: { id: string; name: string },
    student: { firstname: string; lastname: string; email: string },
  ): { subject: string; html: string } {
    const subject = `Affectation à un groupe - ${project.name}`;

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #17a2b8; text-align: center; margin-bottom: 30px;">
            👥 Affectation à un groupe
          </h1>
          
          <div style="margin: 25px 0;">
            <h3 style="color: #2c3e50; margin-bottom: 15px;">Bonjour ${student.firstname} ${student.lastname},</h3>
            <p style="color: #2c3e50; line-height: 1.6; margin: 20px 0;">
              Votre enseignant vous a affecté au groupe <strong>${group.name}</strong> 
              pour le projet <strong>${project.name}</strong>.
            </p>
          </div>
          
          <div style="background-color: #d1ecf1; border: 1px solid #bee5eb; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h3 style="color: #0c5460; margin-top: 0;">📋 Informations du groupe</h3>
            <p style="color: #0c5460; margin: 10px 0;">
              <strong>Nom du groupe :</strong> ${group.name}
            </p>
            <p style="color: #0c5460; margin: 10px 0;">
              <strong>Projet :</strong> ${project.name}
            </p>
          </div>
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/projects/${project.id}" 
               style="background-color: #17a2b8; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
               🚀 Découvrir mon équipe
            </a>
          </div>
          
          <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 6px; margin: 25px 0;">
            <p style="color: #856404; margin: 0; font-size: 14px;">
              💡 <strong>Conseil :</strong> Prenez contact avec vos coéquipiers dès que possible pour bien démarrer le projet !
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }
}
