import { Module } from '@nestjs/common';
import { EmailService } from './email.service';
import { TemplateService } from './template.service';
import { UserHandler } from './handlers/user.handler';
import { ConfigModule } from '@nestjs/config';
import { NotificationController } from './notification.controller';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
  ],
  controllers: [NotificationController],
  providers: [EmailService, TemplateService, UserHandler],
  exports: [EmailService, TemplateService, UserHandler],
})
export class NotificationModule {}
