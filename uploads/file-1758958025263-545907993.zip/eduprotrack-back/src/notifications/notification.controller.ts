import { Controller, Get, Post, Body } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';

interface UserDto {
  name: string;
  email: string;
  role: string;
}

@ApiTags('Notifications')
@Controller()
export class NotificationController {
  constructor() {}

  @Get('health')
  getHealth() {
    return {
      status: 'ok',
      service: 'notification-service',
      timestamp: new Date().toISOString(),
    };
  }

  @Post('test/user-created')
  testUserCreated(@Body() userDto: UserDto) {
    // TODO Envoyer l'email à l'utilisateur

    return {
      success: true,
      data: userDto,
    };
  }
}
