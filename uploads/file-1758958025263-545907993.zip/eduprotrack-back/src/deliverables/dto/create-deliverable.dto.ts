import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsEnum,
  IsDateString,
  IsBoolean,
  IsNumber,
  IsArray,
  Min,
  Max,
  MaxLength,
  IsInt,
} from 'class-validator';
import { Transform } from 'class-transformer';
import { DeliverableType } from '@prisma/client';

/**
 * DTO pour la création d'un nouveau livrable
 * Respecte les spécifications de l'US-DEL-001
 */
export class CreateDeliverableDto {
  @IsString()
  @IsNotEmpty({
    message: 'Le nom est obligatoire',
  })
  @MaxLength(100, {
    message: 'Le nom ne peut pas dépasser 100 caractères',
  })
  name: string;

  @IsString()
  @IsOptional()
  @MaxLength(1000, {
    message: 'La description ne peut pas dépasser 1000 caractères',
  })
  description?: string;

  @IsEnum(DeliverableType, {
    message: 'Le type doit être ARCHIVE ou GIT_LINK',
  })
  type: DeliverableType;

  @IsDateString(
    {},
    {
      message: 'La deadline doit être une date valide',
    },
  )
  deadline: string;

  @IsBoolean()
  @IsOptional()
  @Transform(({ value }) => value === 'true' || value === true)
  allowLateSubmission?: boolean = false;

  @IsNumber(
    { maxDecimalPlaces: 2 },
    { message: 'Le malus doit être un nombre décimal' },
  )
  @IsOptional()
  @Min(0, {
    message: 'Le malus ne peut pas être négatif',
  })
  latePenalty?: number;

  @IsInt({
    message: 'Le nombre de jours maximum doit être un entier',
  })
  @IsOptional()
  @Min(1, {
    message: 'Le délai maximum doit être au moins 1 jour',
  })
  @Max(365, {
    message: 'Le délai maximum ne peut pas dépasser 365 jours',
  })
  maxLateDays?: number;

  @IsNumber(
    {},
    {
      message: 'La taille maximale doit être un nombre',
    },
  )
  @IsOptional()
  @Min(1, {
    message: 'La taille maximale doit être positive',
  })
  @Max(1024 * 1024 * 1024, {
    message: 'La taille maximale ne peut pas dépasser 1 GB',
  })
  maxFileSize?: number;

  @IsArray()
  @IsOptional()
  @IsString({ each: true })
  allowedExtensions?: string[];

  @IsArray()
  @IsOptional()
  @IsString({ each: true })
  requiredFiles?: string[];
}
