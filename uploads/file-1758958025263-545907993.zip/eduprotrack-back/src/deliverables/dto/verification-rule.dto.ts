import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsBoolean,
  IsObject,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

/**
 * DTO pour la création d'une nouvelle règle de validation
 * Supporte différents types de validation selon l'US-DEL-002.md
 */
export class CreateVerificationRuleDto {
  @ApiProperty({
    description: 'Type de règle de validation',
    enum: [
      'FILE_SIZE',
      'REQUIRED_FILES',
      'FOLDER_STRUCTURE',
      'CONTENT_REGEX',
      'GIT_VALIDATION',
    ],
    example: 'FILE_SIZE',
    examples: {
      'Taille fichier': {
        value: 'FILE_SIZE',
        description: 'Validation de la taille du fichier',
      },
      'Fichiers requis': {
        value: 'REQUIRED_FILES',
        description: 'Validation de la présence de fichiers',
      },
      'Structure dossiers': {
        value: 'FOLDER_STRUCTURE',
        description: "Validation de l'architecture des dossiers",
      },
      'Contenu regex': {
        value: 'CONTENT_REGEX',
        description: 'Validation du contenu par regex',
      },
      'Validation Git': {
        value: 'GIT_VALIDATION',
        description: 'Validation du dépôt Git',
      },
    },
  })
  @IsString()
  @IsNotEmpty({
    message: 'Le type de règle est obligatoire',
  })
  ruleType: string;

  @ApiProperty({
    description: 'Configuration de la règle (varie selon le type)',
    example: { maxSizeMB: 50, minSizeMB: 1 },
    examples: {
      FILE_SIZE: {
        value: { maxSizeMB: 50, minSizeMB: 1 },
        description: 'Configuration pour taille de fichier',
      },
      REQUIRED_FILES: {
        value: { patterns: ['README.md', '*.js', 'package.json'] },
        description: 'Configuration pour fichiers requis',
      },
      FOLDER_STRUCTURE: {
        value: {
          requiredFolders: ['src', 'tests'],
          forbiddenFolders: ['node_modules'],
        },
        description: 'Configuration pour structure de dossiers',
      },
      CONTENT_REGEX: {
        value: {
          fileName: 'README.md',
          pattern: 'Installation',
          mustMatch: true,
        },
        description: 'Configuration pour validation de contenu',
      },
    },
  })
  @IsObject()
  @IsNotEmpty({
    message: 'Les paramètres de la règle sont obligatoires',
  })
  ruleValue: Record<string, unknown>;

  @ApiProperty({
    description: "Message d'erreur personnalisé affiché en cas d'échec",
    example: 'Le fichier dépasse la taille maximale autorisée',
  })
  @IsString()
  @IsNotEmpty({
    message: "Le message d'erreur est obligatoire",
  })
  errorMessage: string;

  @ApiPropertyOptional({
    description: 'Indique si la règle est active',
    example: true,
    default: true,
  })
  @IsBoolean()
  @IsOptional()
  isActive?: boolean = true;
}

/**
 * DTO pour la mise à jour d'une règle de validation
 */
export class UpdateVerificationRuleDto {
  @ApiPropertyOptional({
    description: 'Type de règle de validation',
    enum: [
      'FILE_SIZE',
      'REQUIRED_FILES',
      'FOLDER_STRUCTURE',
      'CONTENT_REGEX',
      'GIT_VALIDATION',
    ],
    example: 'FILE_SIZE',
  })
  @IsString()
  @IsOptional()
  ruleType?: string;

  @ApiPropertyOptional({
    description: 'Configuration de la règle',
    example: { maxSizeMB: 100 },
  })
  @IsObject()
  @IsOptional()
  ruleValue?: Record<string, unknown>;

  @ApiPropertyOptional({
    description: "Message d'erreur personnalisé",
    example: 'Le fichier est trop volumineux',
  })
  @IsString()
  @IsOptional()
  errorMessage?: string;

  @ApiPropertyOptional({
    description: 'Indique si la règle est active',
    example: true,
  })
  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}

/**
 * DTO de réponse pour les opérations sur les règles de validation
 */
export class VerificationRuleResponseDto {
  @ApiProperty({
    description: 'Identifiant unique de la règle',
    example: 'rule_abc123',
  })
  id: string;

  @ApiProperty({
    description: 'ID du livrable associé',
    example: 'deliverable_456',
  })
  deliverableId: string;

  @ApiProperty({
    description: 'Type de règle',
    example: 'FILE_SIZE',
  })
  ruleType: string;

  @ApiProperty({
    description: 'Configuration de la règle',
    example: { maxSizeMB: 50 },
  })
  ruleValue: Record<string, unknown>;

  @ApiProperty({
    description: "Message d'erreur",
    example: 'Le fichier dépasse la taille maximale',
  })
  errorMessage: string;

  @ApiProperty({
    description: 'Statut actif de la règle',
    example: true,
  })
  isActive: boolean;

  @ApiProperty({
    description: 'Date de création',
    example: '2024-01-15T10:30:00Z',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Date de dernière modification',
    example: '2024-01-15T14:20:00Z',
  })
  updatedAt: Date;
}

/**
 * DTO pour le résultat de validation d'une règle individuelle
 */
export class ValidationRuleResultDto {
  @ApiProperty({
    description: 'Type de règle validée',
    example: 'FILE_SIZE',
  })
  ruleType: string;

  @ApiProperty({
    description: 'Nom lisible de la règle',
    example: 'Taille de fichier',
  })
  ruleName: string;

  @ApiProperty({
    description: 'Indique si la règle est respectée',
    example: true,
  })
  passed: boolean;

  @ApiPropertyOptional({
    description: 'Message descriptif du résultat',
    example: 'Fichier conforme à la taille maximale',
  })
  message?: string;

  @ApiPropertyOptional({
    description: 'Détails supplémentaires de la validation',
    example: { actualSizeMB: 25.5, maxSizeMB: 50 },
  })
  details?: Record<string, unknown>;
}

/**
 * DTO pour le résultat de validation
 */
export class ValidationResultDto {
  @ApiProperty({
    description: 'Indique si la validation est réussie',
    example: true,
  })
  isValid: boolean;

  @ApiProperty({
    description: 'Liste des erreurs de validation',
    example: ['Le fichier est trop volumineux', 'README.md manquant'],
    type: [String],
  })
  errors: string[];

  @ApiProperty({
    description: 'Liste des avertissements',
    example: ['Structure recommandée non respectée'],
    type: [String],
  })
  warnings: string[];

  @ApiProperty({
    description: 'Détails de validation pour chaque règle',
    type: [ValidationRuleResultDto],
  })
  details: ValidationRuleResultDto[];
}
