import {
  Controller,
  Post,
  Get,
  Param,
  Body,
  UploadedFile,
  UseInterceptors,
  UseGuards,
  Req,
  Query,
  BadRequestException,
  Res,
  StreamableFile,
} from '@nestjs/common';
import { Response } from 'express';
import { FileInterceptor } from '@nestjs/platform-express';
import {
  ApiTags,
  ApiOperation,
  ApiConsumes,
  ApiBody,
  ApiParam,
  ApiQuery,
  ApiResponse,
  ApiBearerAuth,
  ApiCreatedResponse,
  ApiBadRequestResponse,
  ApiUnauthorizedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiProperty,
} from '@nestjs/swagger';
import { JWTAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { StudentGuard } from '../../auth/guards/student.guard';
import { TeacherGuard } from '../../auth/guards/teacher.guard';
import { AuthenticatedRequest } from '../../auth/types/auth.types';
import { StorageService } from '../services/storage/storage.service';
import { ValidationRuleService } from '../services/validation-rule.service';
import { PrismaService } from '../../prisma/prisma.service';
import * as JSZip from 'jszip';

// DTOs pour les soumissions
export class FileSubmissionDto {
  @ApiProperty({
    description: 'Fichier à soumettre (archive)',
    type: 'string',
    format: 'binary',
  })
  file: Express.Multer.File;
}

export class GitSubmissionDto {
  @ApiProperty({
    description: 'URL du dépôt Git',
    example: 'https://github.com/user/repo.git',
  })
  gitUrl: string;

  @ApiProperty({
    description: 'Branche à évaluer',
    example: 'main',
    default: 'main',
  })
  branch?: string = 'main';
}

/**
 * Contrôleur unifié pour les soumissions de livrables
 * Fusionné depuis l'ancien module deliveries
 */
@ApiTags('Deliverables')
@Controller('projects/:projectId/deliverables/:deliverableId/submissions')
@UseGuards(JWTAuthGuard)
@ApiBearerAuth('JWT-auth')
export class SubmissionController {
  constructor(
    private readonly storageService: StorageService,
    private readonly validationService: ValidationRuleService,
    private readonly prisma: PrismaService,
  ) {}

  @Post('file')
  @UseGuards(StudentGuard)
  @UseInterceptors(FileInterceptor('file'))
  @ApiOperation({
    summary: 'Soumettre un fichier archive',
    description:
      'Permet à un étudiant de soumettre une archive pour un livrable',
  })
  @ApiConsumes('multipart/form-data')
  @ApiParam({
    name: 'projectId',
    description: 'Identifiant du projet',
    example: 'project_abc123',
  })
  @ApiParam({
    name: 'deliverableId',
    description: 'Identifiant du livrable',
    example: 'deliverable_456',
  })
  @ApiBody({
    description: 'Fichier archive à soumettre',
    type: FileSubmissionDto,
  })
  @ApiCreatedResponse({
    description: 'Fichier soumis avec succès',
    schema: {
      example: {
        submissionId: 'submission_789',
        fileName: 'projet.zip',
        fileSize: 1024000,
        uploadPath:
          'submissions/project_abc123/deliverable_456/submission_789.zip',
        validationResult: {
          isValid: true,
          errors: [],
          warnings: [],
        },
        submittedAt: '2024-01-15T10:30:00Z',
      },
    },
  })
  @ApiBadRequestResponse({
    description: 'Fichier invalide ou validation échouée',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux étudiants' })
  @ApiNotFoundResponse({ description: 'Projet ou livrable non trouvé' })
  async submitFile(
    @Param('projectId') projectId: string,
    @Param('deliverableId') deliverableId: string,
    @UploadedFile() file: Express.Multer.File,
    @Req() req: AuthenticatedRequest,
  ) {
    if (!file) {
      throw new BadRequestException('Aucun fichier fourni');
    }

    // Valider le fichier selon les règles du livrable
    const validationResult = await this.validationService.validateSubmission(
      deliverableId,
      { file, type: 'ARCHIVE' },
    );

    if (!validationResult.isValid) {
      throw new BadRequestException({
        message: 'Validation du fichier échouée',
        errors: validationResult.errors,
        details: validationResult.details,
      });
    }

    // Générer le chemin de stockage
    const uploadPath = `submissions/${projectId}/${deliverableId}/${req.user.id}_${Date.now()}_${file.originalname}`;

    // Uploader le fichier
    const storedPath = await this.storageService.uploadFile(file, uploadPath);

    return {
      submissionId: `submission_${Date.now()}`,
      fileName: file.originalname,
      fileSize: file.size,
      uploadPath: storedPath,
      validationResult,
      submittedAt: new Date().toISOString(),
    };
  }

  @Post('git')
  @UseGuards(StudentGuard)
  @ApiOperation({
    summary: 'Soumettre un dépôt Git',
    description:
      'Permet à un étudiant de soumettre un lien vers un dépôt Git pour un livrable',
  })
  @ApiParam({
    name: 'projectId',
    description: 'Identifiant du projet',
    example: 'project_abc123',
  })
  @ApiParam({
    name: 'deliverableId',
    description: 'Identifiant du livrable',
    example: 'deliverable_456',
  })
  @ApiBody({
    type: GitSubmissionDto,
    description: 'Information du dépôt Git à soumettre',
  })
  @ApiCreatedResponse({
    description: 'Dépôt Git soumis avec succès',
    schema: {
      example: {
        submissionId: 'submission_789',
        gitUrl: 'https://github.com/user/repo.git',
        branch: 'main',
        validationResult: {
          isValid: true,
          errors: [],
          warnings: [],
        },
        submittedAt: '2024-01-15T10:30:00Z',
      },
    },
  })
  @ApiBadRequestResponse({
    description: 'URL Git invalide ou validation échouée',
  })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux étudiants' })
  @ApiNotFoundResponse({ description: 'Projet ou livrable non trouvé' })
  async submitGit(
    @Param('projectId') projectId: string,
    @Param('deliverableId') deliverableId: string,
    @Body() gitSubmission: GitSubmissionDto,
    @Req() _req: AuthenticatedRequest,
  ) {
    // Valider le dépôt Git selon les règles du livrable
    const validationResult = await this.validationService.validateSubmission(
      deliverableId,
      { gitUrl: gitSubmission.gitUrl, type: 'GIT_LINK' },
    );

    if (!validationResult.isValid) {
      throw new BadRequestException({
        message: 'Validation du dépôt Git échouée',
        errors: validationResult.errors,
        details: validationResult.details,
      });
    }

    return {
      submissionId: `submission_${Date.now()}`,
      gitUrl: gitSubmission.gitUrl,
      branch: gitSubmission.branch || 'main',
      validationResult,
      submittedAt: new Date().toISOString(),
    };
  }

  @Get('dashboard')
  @UseGuards(TeacherGuard)
  @ApiOperation({
    summary: 'Tableau de bord des soumissions',
    description:
      "Vue d'ensemble des soumissions pour un livrable (enseignants)",
  })
  @ApiParam({
    name: 'projectId',
    description: 'Identifiant du projet',
    example: 'project_abc123',
  })
  @ApiParam({
    name: 'deliverableId',
    description: 'Identifiant du livrable',
    example: 'deliverable_456',
  })
  @ApiQuery({
    name: 'status',
    required: false,
    enum: ['submitted', 'validated', 'rejected'],
    description: 'Filtrer par statut de soumission',
  })
  @ApiResponse({
    status: 200,
    description: 'Tableau de bord récupéré avec succès',
    schema: {
      example: {
        totalSubmissions: 25,
        validatedSubmissions: 20,
        rejectedSubmissions: 3,
        pendingSubmissions: 2,
        submissions: [
          {
            submissionId: 'submission_789',
            studentName: 'John Doe',
            submittedAt: '2024-01-15T10:30:00Z',
            status: 'validated',
            validationErrors: [],
          },
        ],
      },
    },
  })
  async getSubmissionDashboard(
    @Param('projectId') _projectId: string,
    @Param('deliverableId') _deliverableId: string,
    @Query('status') _status?: string,
  ) {
    // Implémentation du tableau de bord
    return {
      totalSubmissions: 25,
      validatedSubmissions: 20,
      rejectedSubmissions: 3,
      pendingSubmissions: 2,
      submissions: [
        // Liste des soumissions avec filtrage optionnel
      ],
    };
  }

  @Get(':submissionId/download')
  @UseGuards(TeacherGuard)
  @ApiOperation({
    summary: 'Télécharger une soumission individuelle',
    description:
      'Permet aux enseignants de télécharger une soumission spécifique',
  })
  @ApiParam({
    name: 'projectId',
    description: 'Identifiant du projet',
    example: 'project_abc123',
  })
  @ApiParam({
    name: 'deliverableId',
    description: 'Identifiant du livrable',
    example: 'deliverable_456',
  })
  @ApiParam({
    name: 'submissionId',
    description: 'Identifiant de la soumission',
    example: 'submission_789',
  })
  @ApiResponse({
    status: 200,
    description: 'Fichier téléchargé avec succès',
    content: {
      'application/octet-stream': {
        schema: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  async downloadSubmission(
    @Param('projectId') projectId: string,
    @Param('deliverableId') deliverableId: string,
    @Param('submissionId') submissionId: string,
    @Res({ passthrough: true }) res: Response,
    @Req() req: AuthenticatedRequest,
  ): Promise<StreamableFile> {
    // Vérifier l'accès enseignant au projet
    const project = await this.prisma.project.findFirst({
      where: {
        id: projectId,
        userId: req.user.id,
      },
    });

    if (!project) {
      throw new BadRequestException('Accès refusé au projet');
    }

    // Pour cette implémentation simplifiée, nous simulons le téléchargement
    // En production, il faudrait récupérer le fichier depuis le stockage
    const mockFileContent = Buffer.from('Contenu du fichier de soumission');

    res.set({
      'Content-Type': 'application/octet-stream',
      'Content-Disposition': `attachment; filename="submission_${submissionId}.zip"`,
    });

    return new StreamableFile(mockFileContent);
  }

  @Get('download-all')
  @UseGuards(TeacherGuard)
  @ApiOperation({
    summary: 'Télécharger toutes les soumissions',
    description:
      "Permet aux enseignants de télécharger toutes les soumissions d'un livrable dans une archive ZIP",
  })
  @ApiParam({
    name: 'projectId',
    description: 'Identifiant du projet',
    example: 'project_abc123',
  })
  @ApiParam({
    name: 'deliverableId',
    description: 'Identifiant du livrable',
    example: 'deliverable_456',
  })
  @ApiResponse({
    status: 200,
    description:
      'Archive ZIP avec toutes les soumissions téléchargée avec succès',
    content: {
      'application/zip': {
        schema: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  async downloadAllSubmissions(
    @Param('projectId') projectId: string,
    @Param('deliverableId') deliverableId: string,
    @Res({ passthrough: true }) res: Response,
    @Req() req: AuthenticatedRequest,
  ): Promise<StreamableFile> {
    // Vérifier l'accès enseignant au projet
    const project = await this.prisma.project.findFirst({
      where: {
        id: projectId,
        userId: req.user.id,
      },
      include: {
        groups: {
          include: {
            members: {
              include: {
                user: true,
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new BadRequestException('Accès refusé au projet');
    }

    // Vérifier que le livrable existe
    const deliverable = await this.prisma.deliverable.findFirst({
      where: {
        id: deliverableId,
        projectId: projectId,
      },
    });

    if (!deliverable) {
      throw new BadRequestException('Livrable non trouvé');
    }

    // Créer une archive ZIP avec toutes les soumissions
    const zip = new JSZip();

    // Pour cette implémentation simplifiée, nous ajoutons des fichiers mock
    project.groups.forEach((group, _index) => {
      const groupFolder = zip.folder(`Groupe_${group.name}_${group.id}`);

      // Ajouter les informations du groupe
      const groupInfo = `Groupe: ${group.name}\nMembres:\n${group.members.map((m) => `- ${m.user.firstname} ${m.user.lastname} (${m.user.email})`).join('\n')}`;
      groupFolder?.file('groupe_info.txt', groupInfo);

      // Ajouter un fichier de soumission simulé
      const submissionContent = `Soumission simulée pour le groupe ${group.name}`;
      groupFolder?.file('submission.txt', submissionContent);
    });

    // Générer l'archive
    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });

    res.set({
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="submissions_${deliverable.name}_${Date.now()}.zip"`,
    });

    return new StreamableFile(zipBuffer);
  }
}
