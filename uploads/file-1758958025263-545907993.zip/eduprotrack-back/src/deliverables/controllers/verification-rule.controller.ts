import {
  Controller,
  Post,
  Get,
  Put,
  Delete,
  Body,
  Param,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
  ApiCreatedResponse,
  ApiBadRequestResponse,
  ApiUnauthorizedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
} from '@nestjs/swagger';
import { JWTAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../../auth/guards/teacher.guard';
import { ValidationRuleService } from '../services/validation-rule.service';
import {
  CreateVerificationRuleDto,
  UpdateVerificationRuleDto,
} from '../dto/verification-rule.dto';
import type { VerificationRule } from '@prisma/client';

/**
 * Contrôleur pour la gestion des règles de validation
 * Gère les endpoints HTTP pour la création, mise à jour et suppression des règles
 * Implémente la fonctionnalité de gestion des règles de l'US-DEL-002.md
 */
@ApiTags('Deliverables')
@Controller('projects/:projectId/deliverables/:deliverableId/rules')
@UseGuards(JWTAuthGuard)
@ApiBearerAuth('JWT-auth')
export class VerificationRuleController {
  constructor(private readonly validationRuleService: ValidationRuleService) {}

  /**
   * Crée une nouvelle règle de validation pour un livrable
   * @param deliverableId - ID du livrable depuis les paramètres d'URL
   * @param createRuleDto - Données de création de la règle
   * @returns La règle de validation créée
   */
  @Post()
  @UseGuards(TeacherGuard)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    summary: 'Créer une règle de validation',
    description:
      'Ajoute une nouvelle règle de validation automatique pour un livrable',
  })
  @ApiParam({
    name: 'projectId',
    description: 'Identifiant du projet',
    example: 'project_abc123',
  })
  @ApiParam({
    name: 'deliverableId',
    description: 'Identifiant du livrable',
    example: 'deliverable_456',
  })
  @ApiBody({
    type: CreateVerificationRuleDto,
    description: 'Configuration de la règle de validation',
  })
  @ApiCreatedResponse({
    description: 'Règle de validation créée avec succès',
    schema: {
      example: {
        id: 'rule_789',
        deliverableId: 'deliverable_456',
        ruleType: 'FILE_SIZE',
        ruleValue: { maxSizeMB: 50 },
        errorMessage: 'Le fichier dépasse la taille maximale',
        isActive: true,
        createdAt: '2024-01-15T10:30:00Z',
      },
    },
  })
  @ApiBadRequestResponse({ description: 'Configuration de règle invalide' })
  @ApiUnauthorizedResponse({ description: 'Token JWT manquant ou invalide' })
  @ApiForbiddenResponse({ description: 'Accès réservé aux enseignants' })
  @ApiNotFoundResponse({ description: 'Livrable non trouvé' })
  async createRule(
    @Param('deliverableId') deliverableId: string,
    @Body() createRuleDto: CreateVerificationRuleDto,
  ): Promise<VerificationRule> {
    return this.validationRuleService.createRule(deliverableId, createRuleDto);
  }

  /**
   * Récupère toutes les règles de validation d'un livrable
   * @param deliverableId - ID du livrable depuis les paramètres d'URL
   * @returns Tableau des règles de validation
   */
  @Get()
  async getDeliverableRules(
    @Param('deliverableId') deliverableId: string,
  ): Promise<VerificationRule[]> {
    return this.validationRuleService.getDeliverableRules(deliverableId);
  }

  /**
   * Récupère une règle de validation spécifique par ID
   * @param ruleId - ID de la règle depuis les paramètres d'URL
   * @returns La règle de validation
   */
  @Get(':ruleId')
  async getRule(@Param('ruleId') ruleId: string): Promise<VerificationRule> {
    return this.validationRuleService.getRule(ruleId);
  }

  /**
   * Met à jour une règle de validation existante
   * @param ruleId - ID de la règle depuis les paramètres d'URL
   * @param updateRuleDto - Données de mise à jour de la règle
   * @returns La règle de validation mise à jour
   */
  @Put(':ruleId')
  @UseGuards(TeacherGuard)
  async updateRule(
    @Param('ruleId') ruleId: string,
    @Body() updateRuleDto: UpdateVerificationRuleDto,
  ): Promise<VerificationRule> {
    return this.validationRuleService.updateRule(ruleId, updateRuleDto);
  }

  /**
   * Supprime une règle de validation
   * @param ruleId - ID de la règle depuis les paramètres d'URL
   * @returns Réponse de succès
   */
  @Delete(':ruleId')
  @UseGuards(TeacherGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  async deleteRule(@Param('ruleId') ruleId: string): Promise<void> {
    return this.validationRuleService.deleteRule(ruleId);
  }
}
