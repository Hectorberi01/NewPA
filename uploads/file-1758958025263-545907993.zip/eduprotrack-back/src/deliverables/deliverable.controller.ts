import {
  Controller,
  Post,
  Get,
  Body,
  Param,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../auth/guards/teacher.guard';
import { DeliverableService } from './deliverable.service';
import { CreateDeliverableDto } from './dto/create-deliverable.dto';
import type { Deliverable } from '@prisma/client';

@ApiTags('Deliverables')
@Controller('projects/:projectId/deliverables')
@UseGuards(JWTAuthGuard)
@ApiBearerAuth('JWT-auth')
export class DeliverableController {
  constructor(private readonly deliverableService: DeliverableService) {}

  @Post()
  @UseGuards(TeacherGuard)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Créer un nouveau livrable pour un projet' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiBody({
    type: CreateDeliverableDto,
    description: 'Données du livrable à créer',
  })
  @ApiResponse({ status: 201, description: 'Livrable créé avec succès' })
  @ApiResponse({ status: 400, description: 'Données invalides' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  async createDeliverable(
    @Param('projectId') projectId: string,
    @Body() createDeliverableDto: CreateDeliverableDto,
  ): Promise<Deliverable> {
    return this.deliverableService.createDeliverable(
      projectId,
      createDeliverableDto,
    );
  }

  @Get()
  @ApiOperation({ summary: "Récupérer tous les livrables d'un projet" })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 200, description: 'Liste des livrables du projet' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Projet non trouvé' })
  async getProjectDeliverables(
    @Param('projectId') projectId: string,
  ): Promise<Deliverable[]> {
    return this.deliverableService.findByProjectId(projectId);
  }

  @Get(':deliverableId')
  @ApiOperation({ summary: 'Récupérer un livrable spécifique par ID' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiParam({ name: 'deliverableId', description: 'ID du livrable' })
  @ApiResponse({ status: 200, description: 'Détails du livrable' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 404, description: 'Livrable non trouvé' })
  async getDeliverable(
    @Param('projectId') projectId: string,
    @Param('deliverableId') deliverableId: string,
  ): Promise<Deliverable> {
    return this.deliverableService.findById(deliverableId);
  }

  @Get(':deliverableId/synthesis')
  @UseGuards(TeacherGuard)
  @ApiOperation({ summary: 'Récupérer la synthèse complète d\'un livrable avec analyse de plagiat' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiParam({ name: 'deliverableId', description: 'ID du livrable' })
  @ApiResponse({ status: 200, description: 'Synthèse du livrable par groupe' })
  @ApiResponse({ status: 401, description: 'Token JWT invalide ou manquant' })
  @ApiResponse({ status: 403, description: 'Accès réservé aux enseignants' })
  @ApiResponse({ status: 404, description: 'Livrable non trouvé' })
  async getDeliverableSynthesis(
    @Param('projectId') projectId: string,
    @Param('deliverableId') deliverableId: string,
  ) {
    return this.deliverableService.getDeliverableSynthesis(deliverableId);
  }
}
