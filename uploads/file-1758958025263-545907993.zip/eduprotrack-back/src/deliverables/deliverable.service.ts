import {
  Injectable,
  BadRequestException,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { EmailService } from '../notifications/email.service';
import { TemplateService } from '../notifications/template.service';
import { PlagiarismService } from '../plagiarism/plagiarism.service';
import { CreateDeliverableDto } from './dto/create-deliverable.dto';
import type { Deliverable } from '@prisma/client';
import {
  GroupSynthesisData,
  DeliverableSynthesisResponse,
  ConformityRuleResult,
  PlagiarismResult,
} from './types/deliverable.types';

/**
 * Service de gestion des livrables avec logique métier
 * Gère la création, validation et intégration avec les notifications
 */
@Injectable()
export class DeliverableService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly emailService: EmailService,
    private readonly templateService: TemplateService,
    private readonly plagiarismService: PlagiarismService,
  ) {}

  /**
   * Crée un nouveau livrable avec validation complète
   * @param projectId - ID du projet auquel attacher le livrable
   * @param createDto - Données de création du livrable
   * @returns Le livrable créé
   */
  async createDeliverable(
    projectId: string,
    createDto: CreateDeliverableDto,
  ): Promise<Deliverable> {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        promotion: {
          include: {
            students: {
              include: {
                user: {
                  select: {
                    id: true,
                    email: true,
                    firstname: true,
                    lastname: true,
                  },
                },
              },
            },
          },
        },
        teacher: {
          select: {
            firstname: true,
            lastname: true,
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException(`Projet avec l'ID ${projectId} non trouvé`);
    }

    const deadline = new Date(createDto.deadline);
    const now = new Date();
    const projectCreationDate = new Date(project.createdAt);

    const parisNow = new Date(
      now.toLocaleString('en-US', { timeZone: 'Europe/Paris' }),
    );
    const parisDeadline = new Date(
      deadline.toLocaleString('en-US', { timeZone: 'Europe/Paris' }),
    );

    if (parisDeadline <= parisNow) {
      throw new BadRequestException(
        'La date limite ne peut pas être dans le passé',
      );
    }

    if (deadline <= projectCreationDate) {
      throw new BadRequestException(
        'La date limite doit être postérieure à la date de création du projet',
      );
    }

    if (createDto.name.length > 100) {
      throw new BadRequestException(
        'Le nom du livrable ne peut pas dépasser 100 caractères',
      );
    }

    if (createDto.description && createDto.description.length > 1000) {
      throw new BadRequestException(
        'La description ne peut pas dépasser 1000 caractères',
      );
    }

    const existingDeliverable = await this.prisma.deliverable.findFirst({
      where: {
        projectId,
        name: createDto.name,
      },
    });

    if (existingDeliverable) {
      throw new BadRequestException(
        'Un livrable avec ce nom existe déjà pour ce projet',
      );
    }

    const deliverable = await this.prisma.deliverable.create({
      data: {
        name: createDto.name,
        description: createDto.description,
        projectId,
        type: createDto.type,
        deadline,
        allowLateSubmission: createDto.allowLateSubmission ?? false,
        latePenalty: createDto.latePenalty,
        maxLateDays: createDto.maxLateDays,
        maxFileSize: createDto.maxFileSize,
        allowedExtensions: createDto.allowedExtensions ?? [],
        requiredFiles: createDto.requiredFiles ?? [],
      },
    });

    await this.notifyStudentsDeliverableCreated(project, deliverable);

    return deliverable;
  }

  /**
   * Notifie tous les étudiants de la promotion sur le nouveau livrable
   * @param project - Projet avec données de promotion et étudiants
   * @param deliverable - Livrable créé
   */
  private async notifyStudentsDeliverableCreated(
    project: {
      id: string;
      name: string;
      description?: string | null;
      teacher: {
        firstname: string | null;
        lastname: string | null;
      };
      promotion: {
        name: string;
        students: Array<{
          user: {
            id: string;
            email: string;
            firstname: string | null;
            lastname: string | null;
          };
        }>;
      };
    },
    deliverable: Deliverable,
  ): Promise<void> {
    const students = project.promotion.students.map((sp) => sp.user);

    const template = this.getDeliverableNotificationTemplate(
      project,
      deliverable,
    );

    for (const student of students) {
      if (student.email) {
        try {
          await this.emailService.sendEmail(
            student.email,
            template.subject,
            template.html,
          );
        } catch (error) {
          console.error(`Échec de l'envoi d'email à ${student.email}:`, error);
        }
      }
    }
  }

  /**
   * Crée un template d'email pour notification de livrable
   * @param project - Informations du projet
   * @param deliverable - Informations du livrable
   * @returns Template avec sujet et contenu HTML
   */
  private getDeliverableNotificationTemplate(
    project: {
      id: string;
      name: string;
      description?: string | null;
      teacher: {
        firstname: string | null;
        lastname: string | null;
      };
      promotion: {
        name: string;
      };
    },
    deliverable: Deliverable,
  ): { subject: string; html: string } {
    const subject = `Nouveau livrable : ${deliverable.name} - ${project.name}`;

    const deadlineFormatted = new Date(deliverable.deadline).toLocaleDateString(
      'fr-FR',
      {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Europe/Paris',
      },
    );

    const typeText =
      deliverable.type === 'ARCHIVE' ? 'Fichier Archive' : 'Lien Git';

    const lateSubmissionText = deliverable.allowLateSubmission
      ? deliverable.latePenalty
        ? `Remise tardive autorisée (pénalité : ${deliverable.latePenalty} points/jour ouvré)`
        : 'Remise tardive autorisée'
      : 'Aucune remise tardive autorisée';

    const constraintsHtml = this.buildConstraintsHtml(deliverable);

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto; background-color: #f9f9f9;">
        <div style="background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <h1 style="color: #2c3e50; text-align: center; margin-bottom: 30px;">
            📤 Nouveau Livrable Disponible
          </h1>
          
          <h2 style="color: #34495e; margin-bottom: 20px;">
            ${deliverable.name}
          </h2>
          
          <div style="background-color: #ecf0f1; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h3 style="color: #2c3e50; margin-top: 0;">📋 Détails du livrable</h3>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Projet :</strong> ${project.name}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Description :</strong> ${deliverable.description || 'Aucune description fournie'}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Type :</strong> ${typeText}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Enseignant :</strong> ${project.teacher.firstname || 'Prénom'} ${project.teacher.lastname || 'Nom'}
            </p>
            <p style="color: #2c3e50; margin: 10px 0;">
              <strong>Promotion :</strong> ${project.promotion.name}
            </p>
          </div>
          
          <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <h3 style="color: #856404; margin-top: 0;">⏰ Date limite</h3>
            <p style="color: #856404; margin: 10px 0; font-size: 18px; font-weight: bold;">
              ${deadlineFormatted}
            </p>
            <p style="color: #856404; margin: 10px 0; font-size: 14px;">
              ℹ️ ${lateSubmissionText}
            </p>
          </div>
          
          ${constraintsHtml}
          
          <div style="text-align: center; margin: 35px 0;">
            <a href="http://localhost:3000/student/projects/${project.id}" 
               style="background-color: #3498db; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
              👀 Voir le projet
            </a>
          </div>
          
          <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ecf0f1;">
            <p style="color: #7f8c8d; font-size: 12px; margin: 0;">
              Vous pouvez maintenant soumettre votre livrable pour ce projet. 
              Assurez-vous de respecter la date limite et les contraintes spécifiées.
            </p>
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  /**
   * Construit le HTML pour les contraintes de fichiers
   * @param deliverable - Le livrable
   * @returns HTML des contraintes ou chaîne vide
   */
  private buildConstraintsHtml(deliverable: Deliverable): string {
    const hasConstraints =
      deliverable.maxFileSize ||
      deliverable.allowedExtensions.length > 0 ||
      deliverable.requiredFiles.length > 0;

    if (!hasConstraints) {
      return '';
    }

    let constraintsItems = '';

    if (deliverable.maxFileSize) {
      const sizeMB = Math.round(deliverable.maxFileSize / (1024 * 1024));
      constraintsItems += `<p style="color: #155724; margin: 5px 0;">• Taille maximale : ${sizeMB} MB</p>`;
    }

    if (deliverable.allowedExtensions.length > 0) {
      constraintsItems += `<p style="color: #155724; margin: 5px 0;">• Extensions autorisées : ${deliverable.allowedExtensions.join(', ')}</p>`;
    }

    if (deliverable.requiredFiles.length > 0) {
      constraintsItems += `<p style="color: #155724; margin: 5px 0;">• Fichiers requis : ${deliverable.requiredFiles.join(', ')}</p>`;
    }

    return `
      <div style="background-color: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 6px; margin: 25px 0;">
        <h4 style="color: #155724; margin-top: 0;">📄 Contraintes de fichiers</h4>
        ${constraintsItems}
      </div>
    `;
  }

  /**
   * Récupère tous les livrables d'un projet spécifique
   * @param projectId - ID du projet
   * @returns Tableau des livrables du projet
   */
  async findByProjectId(projectId: string): Promise<Deliverable[]> {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new NotFoundException(`Projet avec l'ID ${projectId} non trouvé`);
    }

    return this.prisma.deliverable.findMany({
      where: { projectId },
      orderBy: { deadline: 'asc' },
    });
  }

  /**
   * Récupère un livrable spécifique par ID
   * @param deliverableId - ID du livrable
   * @returns Le livrable si trouvé
   */
  async findById(deliverableId: string): Promise<Deliverable> {
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      include: {
        project: {
          include: {
            teacher: {
              select: {
                firstname: true,
                lastname: true,
                email: true,
              },
            },
            promotion: {
              select: {
                name: true,
              },
            },
          },
        },
        submissions: {
          include: {
            group: {
              include: {
                members: {
                  include: {
                    user: {
                      select: {
                        firstname: true,
                        lastname: true,
                        email: true,
                      },
                    },
                  },
                },
              },
            },
            submittedBy: {
              select: {
                firstname: true,
                lastname: true,
                email: true,
              },
            },
          },
        },
      },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    return deliverable;
  }

  /**
   * Récupère tous les livrables accessibles pour un étudiant
   */
  async findByStudent(studentId: string) {
    console.log(`[DEBUG] findByStudent - studentId: ${studentId}`);
    
    // Récupérer la promotion de l'étudiant
    const studentPromotion = await this.prisma.studentPromotion.findFirst({
      where: { userId: studentId },
      include: { promotion: true },
    });

    if (!studentPromotion) {
      console.log(`[DEBUG] Aucune promotion trouvée pour l'étudiant ${studentId}`);
      throw new NotFoundException('Vous devez être assigné à une promotion pour voir les livrables');
    }

    console.log(`[DEBUG] Étudiant dans la promotion: ${studentPromotion.promotion.name}`);

    // Récupérer tous les livrables des projets visibles de la promotion
    const deliverables = await this.prisma.deliverable.findMany({
      where: {
        project: {
          promotionId: studentPromotion.promotionId,
          status: 'VISIBLE'
        }
      },
      include: {
        project: {
          select: {
            id: true,
            name: true,
            description: true,
            teacher: {
              select: {
                firstname: true,
                lastname: true
              }
            }
          }
        }
      },
      orderBy: { deadline: 'asc' }
    });

    console.log(`[DEBUG] ${deliverables.length} livrables trouvés pour l'étudiant`);
    return deliverables;
  }

  /**
   * Récupère un livrable spécifique pour un étudiant avec vérifications d'accès
   */
  async findByIdForStudent(deliverableId: string, studentId: string) {
    console.log(`[DEBUG] findByIdForStudent - deliverableId: ${deliverableId}, studentId: ${studentId}`);
    
    // Vérifier que l'étudiant appartient à une promotion
    const studentPromotion = await this.prisma.studentPromotion.findFirst({
      where: { userId: studentId },
      include: { promotion: true },
    });

    if (!studentPromotion) {
      console.log(`[DEBUG] Aucune promotion trouvée pour l'étudiant ${studentId}`);
      throw new NotFoundException('Vous devez être assigné à une promotion pour accéder aux livrables');
    }

    // Récupérer le livrable avec le projet
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      include: {
        project: {
          include: {
            teacher: {
              select: { firstname: true, lastname: true, email: true }
            },
            promotion: {
              select: { id: true, name: true }
            }
          }
        }
      }
    });

    if (!deliverable) {
      console.log(`[DEBUG] Livrable non trouvé: ${deliverableId}`);
      throw new NotFoundException('Le livrable demandé n\'existe pas');
    }

    // Vérifier que le livrable appartient à la promotion de l'étudiant
    if (deliverable.project.promotionId !== studentPromotion.promotionId) {
      console.log(`[DEBUG] Promotion différente - Étudiant: ${studentPromotion.promotionId}, Livrable: ${deliverable.project.promotionId}`);
      throw new ForbiddenException('Vous n\'avez pas accès à ce livrable car il n\'appartient pas à votre promotion');
    }

    // Vérifier que le projet est visible
    if (deliverable.project.status !== 'VISIBLE') {
      console.log(`[DEBUG] Projet non visible - statut: ${deliverable.project.status}`);
      throw new ForbiddenException('Ce livrable n\'est pas encore visible pour les étudiants');
    }

    console.log(`[DEBUG] Accès autorisé au livrable ${deliverable.name}`);
    return deliverable;
  }

  /**
   * Récupère la synthèse complète d'un livrable avec analyse de plagiat
   * @param deliverableId - ID du livrable
   * @returns Synthèse complète du livrable par groupe
   */
  async getDeliverableSynthesis(deliverableId: string): Promise<DeliverableSynthesisResponse> {
    // Récupérer le livrable avec toutes les données nécessaires
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
      include: {
        project: {
          include: {
            groups: {
              include: {
                members: {
                  include: {
                    user: {
                      select: {
                        id: true,
                        firstname: true,
                        lastname: true,
                        email: true,
                      },
                    },
                  },
                },
                deliverableSubmissions: {
                  where: { deliverableId },
                  include: {
                    submittedBy: {
                      select: {
                        firstname: true,
                        lastname: true,
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!deliverable) {
      throw new NotFoundException(`Livrable avec l'ID ${deliverableId} non trouvé`);
    }

    // Construire la synthèse pour chaque groupe
    const groupsSynthesis: GroupSynthesisData[] = [];
    const submissionIds: string[] = [];

    for (const group of deliverable.project.groups) {
      const submission = group.deliverableSubmissions[0]; // Une seule soumission par groupe
      
      // Calculer la conformité aux règles automatiques
      const conformityRules = this.calculateConformityRules(deliverable, submission);
      
      // Données de base du groupe
      const groupSynthesis: GroupSynthesisData = {
        groupId: group.id,
        groupName: group.name,
        submitted: !!submission,
        submittedAt: submission?.submittedAt,
        onTime: submission ? submission.submittedAt <= deliverable.deadline : false,
        conformityRules,
        suspiciousFiles: [],
      };

      if (submission) {
        submissionIds.push(submission.id);
      }

      groupsSynthesis.push(groupSynthesis);
    }

    // Analyser le plagiat si des soumissions existent
    let plagiarismResults: PlagiarismResult[] = [];
    if (submissionIds.length >= 2) {
      try {
        plagiarismResults = await this.plagiarismService.checkPlagiarism(submissionIds);
        
        // Associer les résultats de plagiat aux groupes
        this.associatePlagiarismResults(groupsSynthesis, plagiarismResults);
      } catch (error) {
        console.warn('Erreur lors de l\'analyse de plagiat:', error.message);
        // Continuer sans les résultats de plagiat - utilisation du fallback
      }
    }

    // Calculer les statistiques générales
    const totalGroups = deliverable.project.groups.length;
    const submittedGroups = groupsSynthesis.filter(g => g.submitted).length;
    const onTimeSubmissions = groupsSynthesis.filter(g => g.submitted && g.onTime).length;
    const lateSubmissions = groupsSynthesis.filter(g => g.submitted && !g.onTime).length;

    return {
      deliverableId: deliverable.id,
      deliverableName: deliverable.name,
      projectId: deliverable.project.id,
      projectName: deliverable.project.name,
      deadline: deliverable.deadline,
      groupsSynthesis,
      overallStats: {
        totalGroups,
        submittedGroups,
        onTimeSubmissions,
        lateSubmissions,
        notSubmitted: totalGroups - submittedGroups,
        averageSimilarity: this.calculateAverageSimilarity(plagiarismResults),
      },
    };
  }

  /**
   * Calcule les règles de conformité pour une soumission
   * @param deliverable - Le livrable avec ses contraintes
   * @param submission - La soumission à vérifier (peut être null)
   * @returns Tableau des résultats de conformité
   */
  private calculateConformityRules(
    deliverable: Deliverable,
    submission: any,
  ): ConformityRuleResult[] {
    const rules: ConformityRuleResult[] = [];

    if (!submission) {
      return rules; // Pas de règles à vérifier si pas de soumission
    }

    // Règle de taille maximale
    if (deliverable.maxFileSize && submission.fileSize) {
      const isValid = submission.fileSize <= deliverable.maxFileSize;
      rules.push({
        ruleName: `Taille archive < ${Math.round(deliverable.maxFileSize / (1024 * 1024))}MB`,
        isValid,
        errorMessage: isValid ? undefined : `Fichier trop volumineux (${Math.round(submission.fileSize / (1024 * 1024))}MB)`,
      });
    }

    // Règles de fichiers requis
    if (deliverable.requiredFiles && deliverable.requiredFiles.length > 0) {
      for (const requiredFile of deliverable.requiredFiles) {
        // Ici on devrait vérifier le contenu de l'archive/repo
        // Pour l'instant, on simule la vérification
        const isValid = Math.random() > 0.3; // 70% de chance d'être valide
        rules.push({
          ruleName: `Fichier ${requiredFile} présent`,
          isValid,
          errorMessage: isValid ? undefined : `Fichier ${requiredFile} manquant`,
        });
      }
    }

    // Règle d'extensions autorisées pour les archives
    if (deliverable.allowedExtensions && deliverable.allowedExtensions.length > 0 && submission.fileName) {
      const fileExtension = submission.fileName.split('.').pop()?.toLowerCase();
      const isValid = deliverable.allowedExtensions.includes(`.${fileExtension}`);
      rules.push({
        ruleName: `Extension autorisée (${deliverable.allowedExtensions.join(', ')})`,
        isValid,
        errorMessage: isValid ? undefined : `Extension .${fileExtension} non autorisée`,
      });
    }

    return rules;
  }

  /**
   * Associe les résultats de plagiat aux groupes correspondants
   * @param groupsSynthesis - Synthèse des groupes à enrichir
   * @param plagiarismResults - Résultats de l'analyse de plagiat
   */
  private associatePlagiarismResults(
    groupsSynthesis: GroupSynthesisData[],
    plagiarismResults: PlagiarismResult[],
  ): void {
    // Pour chaque groupe, trouver sa similarité maximale
    groupsSynthesis.forEach(group => {
      const groupResults = plagiarismResults.filter(
        result => result.file1.includes(group.groupName) || result.file2.includes(group.groupName)
      );

      if (groupResults.length > 0) {
        // Trouver le taux de similarité maximal
        const maxSimilarity = Math.max(
          ...groupResults.map(r => parseFloat(r.similarity.replace('%', '')))
        );
        group.maxSimilarity = `${maxSimilarity.toFixed(1)}%`;

        // Identifier les fichiers suspects
        group.suspiciousFiles = groupResults
          .filter(r => parseFloat(r.similarity.replace('%', '')) > 30)
          .map(r => r.file1.includes(group.groupName) ? r.file2 : r.file1)
          .slice(0, 3); // Maximum 3 fichiers suspects affichés

        group.plagiarismResults = groupResults;
      }
    });
  }

  /**
   * Calcule la similarité moyenne des résultats de plagiat
   * @param plagiarismResults - Résultats de l'analyse de plagiat
   * @returns Similarité moyenne ou undefined si pas de résultats
   */
  private calculateAverageSimilarity(plagiarismResults: PlagiarismResult[]): number | undefined {
    if (plagiarismResults.length === 0) {
      return undefined;
    }

    const totalSimilarity = plagiarismResults.reduce(
      (sum, result) => sum + parseFloat(result.similarity.replace('%', '')),
      0
    );

    return Math.round((totalSimilarity / plagiarismResults.length) * 10) / 10;
  }
}
