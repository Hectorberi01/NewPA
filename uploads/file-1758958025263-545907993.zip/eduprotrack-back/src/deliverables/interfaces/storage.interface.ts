/**
 * Interface commune pour les services de stockage
 * Unification des services de stockage S3 et local
 */
export interface IStorageService {
  /**
   * Upload un fichier vers le stockage
   * @param file - Fichier à uploader
   * @param path - Chemin de destination
   * @returns URL d'accès au fichier
   */
  uploadFile(file: Express.Multer.File, path: string): Promise<string>;

  /**
   * Télécharge un fichier depuis le stockage
   * @param path - Chemin du fichier
   * @returns Buffer du fichier
   */
  downloadFile(path: string): Promise<Buffer>;

  /**
   * Supprime un fichier du stockage
   * @param path - Chemin du fichier
   * @returns Succès de l'opération
   */
  deleteFile(path: string): Promise<boolean>;

  /**
   * Vérifie si un fichier existe
   * @param path - Chemin du fichier
   * @returns Existence du fichier
   */
  fileExists(path: string): Promise<boolean>;

  /**
   * Génère une URL de téléchargement temporaire
   * @param path - Chemin du fichier
   * @param expiresIn - Durée de validité en secondes
   * @returns URL de téléchargement
   */
  generateDownloadUrl(path: string, expiresIn?: number): Promise<string>;
}

export interface StorageConfig {
  type: 'local' | 's3';
  localPath?: string;
  s3Bucket?: string;
  s3Region?: string;
}
