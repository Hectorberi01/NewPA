// Types pour le système de livrables - EDUPROTRACK
// Interfaces TypeScript pour le système de soumission de livrables
// Basé sur les spécifications US-DEL-001 et le schéma Prisma

import type {
  DeliverableType,
  SubmissionStatus,
  Deliverable as PrismaDeliverable,
  DeliverableSubmission as PrismaDeliverableSubmission,
  VerificationRule as PrismaVerificationRule,
} from '@prisma/client';

// =====================================================
// Types de base des livrables
// =====================================================

/**
 * Type de soumission de livrable
 */
export { DeliverableType };

/**
 * Statut d'une soumission de livrable
 */
export { SubmissionStatus };

// =====================================================
// Interfaces des livrables
// =====================================================

/**
 * Livrable avec données de projet et de soumissions liées
 */
export interface DeliverableWithDetails extends PrismaDeliverable {
  project: {
    id: string;
    name: string;
    status: string;
  };
  submissions: DeliverableSubmissionSummary[];
  verificationRules: VerificationRule[];
  _count: {
    submissions: number;
  };
}

/**
 * Livrable simplifié pour les vues de liste
 */
export interface DeliverableSummary {
  id: string;
  name: string;
  type: DeliverableType;
  deadline: Date;
  allowLateSubmission: boolean;
  submissionCount: number;
  projectName: string;
  createdAt: Date;
}

// =====================================================
// Interfaces des soumissions
// =====================================================
/**
 * Soumission avec données de livrable, groupe et utilisateur liées
 */
export interface DeliverableSubmissionWithDetails
  extends PrismaDeliverableSubmission {
  deliverable: {
    id: string;
    name: string;
    type: DeliverableType;
    deadline: Date;
    allowLateSubmission: boolean;
    latePenalty: number | null;
  };
  group: {
    id: string;
    name: string;
    members: {
      id: string;
      user: {
        id: string;
        email: string;
        firstname: string | null;
        lastname: string | null;
      };
    }[];
  };
  submittedBy: {
    id: string;
    email: string;
    firstname: string | null;
    lastname: string | null;
  };
}

/**
 * Soumission simplifiée pour les vues de liste
 */
export interface DeliverableSubmissionSummary {
  id: string;
  status: SubmissionStatus;
  submittedAt: Date;
  isLate: boolean;
  daysLate: number | null;
  penaltyApplied: number | null;
  groupName: string;
  submitterName: string;
  validationErrors: string[];
}

// =====================================================
// Interfaces des règles de validation
// =====================================================

/**
 * Entité règle de validation
 */
export type VerificationRule = PrismaVerificationRule;

/**
 * Configurations typées des règles de validation
 */
export interface VerificationRuleConfig {
  fileSize?: {
    maxSize: number; // En bytes
    minSize?: number;
  };
  filePresence?: {
    requiredFiles: string[];
    optionalFiles?: string[];
  };
  folderStructure?: {
    requiredFolders: string[];
    forbiddenFolders?: string[];
  };
  contentRegex?: {
    pattern: string;
    flags?: string;
    mustMatch?: boolean;
  };
  gitRepository?: {
    requirePublic: boolean;
    allowedHosts: string[];
    requireReadme?: boolean;
  };
}

/**
 * Résultat de validation pour une soumission
 */
export interface VerificationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  details: {
    ruleType: string;
    ruleName: string;
    passed: boolean;
    message?: string;
  }[];
}

// =====================================================
// Interfaces de requête/réponse
// =====================================================

/**
 * Requête pour créer un nouveau livrable
 */
export interface CreateDeliverableRequest {
  name: string;
  description?: string;
  projectId: string;
  type: DeliverableType;
  deadline: Date;
  allowLateSubmission?: boolean;
  latePenalty?: number;
  maxLateDays?: number;
  maxFileSize?: number;
  allowedExtensions?: string[];
  requiredFiles?: string[];
  verificationRules?: CreateVerificationRuleRequest[];
}

/**
 * Requête pour mettre à jour un livrable
 */
export interface UpdateDeliverableRequest {
  name?: string;
  description?: string;
  type?: DeliverableType;
  deadline?: Date;
  allowLateSubmission?: boolean;
  latePenalty?: number;
  maxLateDays?: number;
  maxFileSize?: number;
  allowedExtensions?: string[];
  requiredFiles?: string[];
}

/**
 * Requête pour créer une règle de validation
 */
export interface CreateVerificationRuleRequest {
  ruleType: string;
  ruleValue: string; // Chaîne JSON
  errorMessage: string;
}

/**
 * Requête pour soumettre un livrable
 */
export interface SubmitDeliverableRequest {
  deliverableId: string;
  groupId: string;
  type: DeliverableType;
  // Pour les soumissions de fichiers
  file?: Express.Multer.File;
  // Pour les soumissions Git
  gitUrl?: string;
}

/**
 * Réponse pour les opérations sur les livrables
 */
export interface DeliverableResponse {
  id: string;
  name: string;
  description: string | null;
  projectId: string;
  type: DeliverableType;
  deadline: Date;
  allowLateSubmission: boolean;
  latePenalty: number | null;
  maxLateDays: number | null;
  maxFileSize: number | null;
  allowedExtensions: string[];
  requiredFiles: string[];
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Réponse pour les opérations de soumission
 */
export interface SubmissionResponse {
  id: string;
  deliverableId: string;
  groupId: string;
  submittedById: string;
  fileUrl: string | null;
  gitUrl: string | null;
  fileName: string | null;
  fileSize: number | null;
  status: SubmissionStatus;
  submittedAt: Date;
  isLate: boolean;
  daysLate: number | null;
  penaltyApplied: number | null;
  isValid: boolean | null;
  validationErrors: string[];
  similarityScore: number | null;
  suspiciousGroups: string[];
  plagiarismChecked: boolean;
}

// =====================================================
// Configuration des soumissions tardives
// =====================================================

/**
 * Configuration pour la gestion des soumissions tardives
 */
export interface LateSubmissionConfig {
  allowLateSubmission: boolean;
  latePenalty?: number;
  maxLateDays?: number;
  gracePeriodMinutes?: number;
}

/**
 * Résultat du calcul de soumission tardive
 */
export interface LateSubmissionCalculation {
  isLate: boolean;
  daysLate: number;
  penaltyApplied: number;
  finalScore?: number;
}

// =====================================================
// Types de détection de plagiat
// =====================================================

/**
 * Requête de détection de plagiat
 */
export interface PlagiarismDetectionRequest {
  submissionId: string;
  fileContent?: string;
  repositoryUrl?: string;
  previousSubmissions: string[];
}

/**
 * Réponse de détection de plagiat
 */
export interface PlagiarismDetectionResponse {
  submissionId: string;
  similarityScore: number;
  suspiciousGroups: string[];
  detectionMethod: string;
  confidence: number;
  processedAt: Date;
}

// =====================================================
// Types de validation de fichiers
// =====================================================

/**
 * Configuration de validation de fichiers
 */
export interface FileValidationConfig {
  maxFileSize: number;
  allowedExtensions: string[];
  requiredFiles: string[];
  forbiddenFiles?: string[];
  scanForViruses?: boolean;
  checkZipBombs?: boolean;
}

/**
 * Résultat de validation de fichiers
 */
export interface FileValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  fileInfo: {
    name: string;
    size: number;
    mimeType: string;
    extension: string;
  };
  securityChecks: {
    virusScanPassed?: boolean;
    zipBombDetected?: boolean;
    suspiciousContent?: boolean;
  };
}

// =====================================================
// Types de validation de dépôt Git
// =====================================================

/**
 * Configuration de validation de dépôt Git
 */
export interface GitValidationConfig {
  allowedHosts: string[];
  requirePublic: boolean;
  requireReadme?: boolean;
  forbiddenPatterns?: string[];
  minimumCommits?: number;
}

/**
 * Résultat de validation de dépôt Git
 */
export interface GitValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  repositoryInfo: {
    url: string;
    host: string;
    owner: string;
    repository: string;
    isPublic: boolean;
    hasReadme: boolean;
    commitCount?: number;
    lastCommitDate?: Date;
  };
}

// =====================================================
// Types de statistiques de soumission
// =====================================================

/**
 * Statistiques de soumission pour un livrable
 */
export interface DeliverableStatistics {
  deliverableId: string;
  totalGroups: number;
  submittedGroups: number;
  lateSubmissions: number;
  validSubmissions: number;
  rejectedSubmissions: number;
  averageSimilarityScore: number;
  submissionRate: number;
  averageSubmissionTime: number; // Heures avant la deadline
}

/**
 * Statistiques de livrables à l'échelle du projet
 */
export interface ProjectDeliverableStatistics {
  projectId: string;
  totalDeliverables: number;
  completedDeliverables: number;
  overdueDeliverables: number;
  overallSubmissionRate: number;
  averageLateSubmissionRate: number;
  deliverableStats: DeliverableStatistics[];
}

// =====================================================
// Types d'options de filtrage
// =====================================================

/**
 * Options de filtrage des livrables
 */
export interface DeliverableFilters {
  projectId?: string;
  type?: DeliverableType;
  status?: 'active' | 'overdue' | 'completed';
  hasSubmissions?: boolean;
  createdAfter?: Date;
  createdBefore?: Date;
}

/**
 * Options de filtrage des soumissions
 */
export interface SubmissionFilters {
  deliverableId?: string;
  groupId?: string;
  submittedById?: string;
  status?: SubmissionStatus;
  isLate?: boolean;
  submittedAfter?: Date;
  submittedBefore?: Date;
}

/**
 * Options de pagination pour les requêtes de livrables
 */
export interface DeliverablePaginationOptions {
  page: number;
  limit: number;
  sortBy?: 'name' | 'deadline' | 'createdAt' | 'submissionCount';
  sortOrder?: 'asc' | 'desc';
}

/**
 * Résultat d'opération en lot
 */
export interface BulkOperationResult<T> {
  successful: T[];
  failed: {
    item: Partial<T>;
    error: string;
  }[];
  summary: {
    total: number;
    successful: number;
    failed: number;
  };
}

// =====================================================
// Types pour la synthèse de livrable avec plagiat
// =====================================================

/**
 * Résultat de conformité pour une règle automatique
 */
export interface ConformityRuleResult {
  ruleName: string;
  isValid: boolean;
  errorMessage?: string;
}

/**
 * Résultat d'analyse de plagiat entre deux soumissions
 */
export interface PlagiarismResult {
  file1: string;
  file2: string;
  similarity: string;
}

/**
 * Synthèse complète pour un groupe dans un livrable
 */
export interface GroupSynthesisData {
  groupId: string;
  groupName: string;
  submitted: boolean;
  submittedAt?: Date;
  onTime: boolean;
  conformityRules: ConformityRuleResult[];
  maxSimilarity?: string;
  suspiciousFiles?: string[];
  plagiarismResults?: PlagiarismResult[];
}

/**
 * Réponse complète de synthèse d'un livrable
 */
export interface DeliverableSynthesisResponse {
  deliverableId: string;
  deliverableName: string;
  projectId: string;
  projectName: string;
  deadline: Date;
  groupsSynthesis: GroupSynthesisData[];
  overallStats: {
    totalGroups: number;
    submittedGroups: number;
    onTimeSubmissions: number;
    lateSubmissions: number;
    notSubmitted: number;
    averageSimilarity?: number;
  };
}
