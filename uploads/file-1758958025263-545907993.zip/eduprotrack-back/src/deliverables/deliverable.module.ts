import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { DeliverableController } from './deliverable.controller';
import { VerificationRuleController } from './controllers/verification-rule.controller';
import { SubmissionController } from './controllers/submission.controller';
import { DeliverableService } from './deliverable.service';
import { ValidationRuleService } from './services/validation-rule.service';
import { FileAnalysisService } from './services/file-analysis.service';
import { GitValidationService } from './services/git-validation.service';
import { StorageService } from './services/storage/storage.service';
import { S3StorageService } from './services/storage/s3-storage.service';
import { PrismaModule } from '../prisma/prisma.module';
import { PlagiarismModule } from '../plagiarism/plagiarism.module';
import { EmailService } from '../notifications/email.service';
import { TemplateService } from '../notifications/template.service';

/**
 * Module unifié de gestion des livrables et soumissions
 * Fournit la création de livrables, les règles de validation, les soumissions et les services de stockage
 * Implémente les fonctionnalités US-DEL-001, US-DEL-002, et US-DEL-003
 */
@Module({
  imports: [PrismaModule, PlagiarismModule, ConfigModule],
  controllers: [
    DeliverableController,
    VerificationRuleController,
    SubmissionController,
  ],
  providers: [
    DeliverableService,
    ValidationRuleService,
    FileAnalysisService,
    GitValidationService,
    StorageService,
    {
      provide: 'S3_STORAGE',
      useClass: S3StorageService,
    },
    EmailService,
    TemplateService,
  ],
  exports: [
    DeliverableService,
    ValidationRuleService,
    FileAnalysisService,
    GitValidationService,
    StorageService,
  ],
})
export class DeliverableModule {}
