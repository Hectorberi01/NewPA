import { Injectable, BadRequestException } from '@nestjs/common';
import * as yauzl from 'yauzl';
import * as tar from 'tar-stream';
import { Readable } from 'stream';
import * as zlib from 'zlib';
import * as path from 'path';
import { minimatch } from 'minimatch';

/**
 * Interface pour les entrées ZIP yauzl
 */
interface ZipEntry {
  fileName: string;
  uncompressedSize: number;
}

/**
 * Interface pour les résultats d'analyse de fichiers
 */
export interface FileAnalysisResult {
  isValid: boolean;
  foundFiles: string[];
  missingFiles: string[];
  errors: string[];
}

/**
 * Interface pour les résultats d'analyse de structure de dossiers
 */
export interface FolderStructureResult {
  isValid: boolean;
  foundFolders: string[];
  missingFolders: string[];
  forbiddenFoldersFound: string[];
  errors: string[];
}

/**
 * Interface pour les résultats de validation de contenu de fichier
 */
export interface FileContentResult {
  isValid: boolean;
  matchFound: boolean;
  errors: string[];
}

/**
 * Service d'analyse d'archives de fichiers et de leur contenu
 * Implémente la fonctionnalité de validation de fichiers de l'US-DEL-002.md
 */
@Injectable()
export class FileAnalysisService {
  /**
   * Taille maximale de fichier pour l'analyse de contenu (10MB)
   */
  private readonly MAX_CONTENT_ANALYSIS_SIZE = 10 * 1024 * 1024;

  /**
   * Nombre maximum de fichiers à analyser dans une archive
   */
  private readonly MAX_FILES_TO_ANALYZE = 1000;

  /**
   * Vérifie si les fichiers requis sont présents dans l'archive
   * @param file - Le fichier uploadé (archive)
   * @param patterns - Tableau de motifs de fichiers à faire correspondre
   * @returns Résultat d'analyse avec fichiers trouvés et manquants
   */
  async checkRequiredFiles(
    file: Express.Multer.File,
    patterns: string[],
  ): Promise<FileAnalysisResult> {
    try {
      const fileList = await this.extractFileList(file);
      const foundFiles: string[] = [];
      const missingFiles: string[] = [];

      for (const pattern of patterns) {
        const matchingFiles = this.findMatchingFiles(fileList, pattern);
        if (matchingFiles.length > 0) {
          foundFiles.push(...matchingFiles);
        } else {
          missingFiles.push(pattern);
        }
      }

      return {
        isValid: missingFiles.length === 0,
        foundFiles: [...new Set(foundFiles)],
        missingFiles,
        errors: [],
      };
    } catch (error) {
      return {
        isValid: false,
        foundFiles: [],
        missingFiles: patterns,
        errors: [
          `Erreur lors de l'analyse: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
        ],
      };
    }
  }

  /**
   * Valide la structure de dossiers dans l'archive
   * @param file - Le fichier uploadé (archive)
   * @param config - Configuration de structure de dossiers
   * @returns Résultat de validation avec analyse de dossiers
   */
  async validateFolderStructure(
    file: Express.Multer.File,
    config: {
      requiredFolders: string[];
      forbiddenFolders?: string[];
    },
  ): Promise<FolderStructureResult> {
    try {
      const fileList = await this.extractFileList(file);
      const folders = this.extractFolderList(fileList);

      const foundFolders: string[] = [];
      const missingFolders: string[] = [];
      const forbiddenFoldersFound: string[] = [];

      // Vérifier les dossiers requis
      for (const requiredFolder of config.requiredFolders) {
        const normalizedRequired = this.normalizePath(requiredFolder);
        const found = folders.some((folder) =>
          this.matchesFolderPattern(folder, normalizedRequired),
        );

        if (found) {
          foundFolders.push(requiredFolder);
        } else {
          missingFolders.push(requiredFolder);
        }
      }

      // Vérifier les dossiers interdits
      if (config.forbiddenFolders) {
        for (const forbiddenFolder of config.forbiddenFolders) {
          const normalizedForbidden = this.normalizePath(forbiddenFolder);
          const found = folders.find((folder) =>
            this.matchesFolderPattern(folder, normalizedForbidden),
          );

          if (found) {
            forbiddenFoldersFound.push(found);
          }
        }
      }

      return {
        isValid:
          missingFolders.length === 0 && forbiddenFoldersFound.length === 0,
        foundFolders,
        missingFolders,
        forbiddenFoldersFound,
        errors: [],
      };
    } catch (error) {
      return {
        isValid: false,
        foundFolders: [],
        missingFolders: config.requiredFolders,
        forbiddenFoldersFound: [],
        errors: [
          `Erreur lors de l'analyse de structure: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
        ],
      };
    }
  }

  /**
   * Valide le contenu d'un fichier contre un motif regex
   * @param file - Le fichier uploadé (archive)
   * @param config - Configuration de validation de contenu
   * @returns Résultat de validation
   */
  async validateFileContent(
    file: Express.Multer.File,
    config: {
      fileName: string;
      pattern: string;
      flags?: string;
      mustMatch?: boolean;
    },
  ): Promise<FileContentResult> {
    try {
      const content = await this.extractFileContent(file, config.fileName);

      if (!content) {
        return {
          isValid: false,
          matchFound: false,
          errors: [`Fichier ${config.fileName} non trouvé dans l'archive`],
        };
      }

      const regex = new RegExp(config.pattern, config.flags || '');
      const matchFound = regex.test(content);
      const mustMatch = config.mustMatch !== false;

      return {
        isValid: mustMatch ? matchFound : !matchFound,
        matchFound,
        errors: [],
      };
    } catch (error) {
      return {
        isValid: false,
        matchFound: false,
        errors: [
          `Erreur lors de la validation de contenu: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
        ],
      };
    }
  }

  /**
   * Extrait la liste des fichiers de l'archive
   * @param file - Le fichier uploadé
   * @returns Tableau des chemins de fichiers
   */
  private async extractFileList(file: Express.Multer.File): Promise<string[]> {
    const mimeType = file.mimetype;
    const fileName = file.originalname.toLowerCase();

    if (mimeType === 'application/zip' || fileName.endsWith('.zip')) {
      return this.extractZipFileList(file.buffer);
    } else if (
      mimeType === 'application/x-tar' ||
      mimeType === 'application/gzip' ||
      fileName.endsWith('.tar') ||
      fileName.endsWith('.tar.gz') ||
      fileName.endsWith('.tgz')
    ) {
      return this.extractTarFileList(file.buffer, fileName.includes('.gz'));
    } else {
      throw new BadRequestException(
        `Format d'archive non supporté: ${mimeType}`,
      );
    }
  }

  /**
   * Extrait la liste des fichiers d'une archive ZIP
   * @param buffer - Buffer du fichier
   * @returns Tableau des chemins de fichiers
   */
  private async extractZipFileList(buffer: Buffer): Promise<string[]> {
    return new Promise((resolve, reject) => {
      const files: string[] = [];
      let processedFiles = 0;

      yauzl.fromBuffer(buffer, { lazyEntries: true }, (err, zipfile) => {
        if (err) {
          reject(new Error(`Erreur ZIP: ${err.message}`));
          return;
        }

        if (!zipfile) {
          reject(new Error('Archive ZIP invalide'));
          return;
        }

        zipfile.readEntry();

        zipfile.on('entry', (entry: ZipEntry) => {
          processedFiles++;
          if (processedFiles > this.MAX_FILES_TO_ANALYZE) {
            zipfile.close();
            reject(
              new Error(
                `Archive contient trop de fichiers (max: ${this.MAX_FILES_TO_ANALYZE})`,
              ),
            );
            return;
          }

          files.push(entry.fileName);
          zipfile.readEntry();
        });

        zipfile.on('end', () => {
          resolve(files);
        });

        zipfile.on('error', (err: Error) => {
          reject(new Error(`Erreur lecture ZIP: ${err.message}`));
        });
      });
    });
  }

  /**
   * Extrait la liste des fichiers d'une archive TAR
   * @param buffer - Buffer du fichier
   * @param isGzipped - Si le TAR est compressé avec gzip
   * @returns Tableau des chemins de fichiers
   */
  private async extractTarFileList(
    buffer: Buffer,
    isGzipped: boolean,
  ): Promise<string[]> {
    return new Promise((resolve, reject) => {
      const files: string[] = [];
      let processedFiles = 0;
      const extract = tar.extract();

      extract.on('entry', (header, stream, next) => {
        processedFiles++;
        if (processedFiles > this.MAX_FILES_TO_ANALYZE) {
          reject(
            new Error(
              `Archive contient trop de fichiers (max: ${this.MAX_FILES_TO_ANALYZE})`,
            ),
          );
          return;
        }

        files.push(header.name);
        stream.on('end', next);
        stream.resume();
      });

      extract.on('finish', () => {
        resolve(files);
      });

      extract.on('error', (err: Error) => {
        reject(new Error(`Erreur lecture TAR: ${err.message}`));
      });

      try {
        const stream = Readable.from(buffer);
        if (isGzipped) {
          stream.pipe(zlib.createGunzip()).pipe(extract);
        } else {
          stream.pipe(extract);
        }
      } catch (error) {
        reject(
          new Error(
            `Erreur traitement TAR: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
          ),
        );
      }
    });
  }

  /**
   * Extrait le contenu d'un fichier spécifique de l'archive
   * @param file - Le fichier uploadé
   * @param targetFileName - Nom du fichier à extraire
   * @returns Contenu du fichier sous forme de chaîne
   */
  private async extractFileContent(
    file: Express.Multer.File,
    targetFileName: string,
  ): Promise<string | null> {
    const mimeType = file.mimetype;
    const fileName = file.originalname.toLowerCase();

    if (mimeType === 'application/zip' || fileName.endsWith('.zip')) {
      return this.extractZipFileContent(file.buffer, targetFileName);
    } else if (
      mimeType === 'application/x-tar' ||
      mimeType === 'application/gzip' ||
      fileName.endsWith('.tar') ||
      fileName.endsWith('.tar.gz') ||
      fileName.endsWith('.tgz')
    ) {
      return this.extractTarFileContent(
        file.buffer,
        targetFileName,
        fileName.includes('.gz'),
      );
    } else {
      throw new BadRequestException(
        `Format d'archive non supporté: ${mimeType}`,
      );
    }
  }

  /**
   * Extrait le contenu d'un fichier ZIP
   * @param buffer - Buffer du fichier
   * @param targetFileName - Nom du fichier cible
   * @returns Contenu du fichier ou null si non trouvé
   */
  private async extractZipFileContent(
    buffer: Buffer,
    targetFileName: string,
  ): Promise<string | null> {
    return new Promise((resolve, reject) => {
      yauzl.fromBuffer(buffer, { lazyEntries: true }, (err, zipfile) => {
        if (err) {
          reject(new Error(`Erreur ZIP: ${err.message}`));
          return;
        }

        if (!zipfile) {
          reject(new Error('Archive ZIP invalide'));
          return;
        }

        zipfile.readEntry();

        zipfile.on('entry', (entry: ZipEntry) => {
          if (entry.fileName === targetFileName) {
            if (entry.uncompressedSize > this.MAX_CONTENT_ANALYSIS_SIZE) {
              zipfile.close();
              reject(
                new Error(
                  `Fichier trop volumineux pour l'analyse (max: ${this.MAX_CONTENT_ANALYSIS_SIZE / (1024 * 1024)}MB)`,
                ),
              );
              return;
            }

            zipfile.openReadStream(
              entry as yauzl.Entry,
              (err: Error | null, readStream?: NodeJS.ReadableStream) => {
                if (err) {
                  reject(new Error(`Erreur lecture fichier: ${err.message}`));
                  return;
                }

                if (!readStream) {
                  reject(new Error('Impossible de lire le fichier'));
                  return;
                }

                const chunks: Buffer[] = [];
                readStream.on('data', (chunk: Buffer) => chunks.push(chunk));
                readStream.on('end', () => {
                  const content = Buffer.concat(chunks).toString('utf-8');
                  zipfile.close();
                  resolve(content);
                });
                readStream.on('error', (err: Error) => {
                  zipfile.close();
                  reject(new Error(`Erreur lecture stream: ${err.message}`));
                });
              },
            );
          } else {
            zipfile.readEntry();
          }
        });

        zipfile.on('end', () => {
          resolve(null);
        });

        zipfile.on('error', (err: Error) => {
          reject(new Error(`Erreur lecture ZIP: ${err.message}`));
        });
      });
    });
  }

  /**
   * Extrait le contenu d'un fichier TAR
   * @param buffer - Buffer du fichier
   * @param targetFileName - Nom du fichier cible
   * @param isGzipped - Si le TAR est compressé avec gzip
   * @returns Contenu du fichier ou null si non trouvé
   */
  private async extractTarFileContent(
    buffer: Buffer,
    targetFileName: string,
    isGzipped: boolean,
  ): Promise<string | null> {
    return new Promise((resolve, reject) => {
      let found = false;
      const extract = tar.extract();

      extract.on('entry', (header, stream, next) => {
        if (header.name === targetFileName) {
          found = true;

          if (header.size > this.MAX_CONTENT_ANALYSIS_SIZE) {
            reject(
              new Error(
                `Fichier trop volumineux pour l'analyse (max: ${this.MAX_CONTENT_ANALYSIS_SIZE / (1024 * 1024)}MB)`,
              ),
            );
            return;
          }

          const chunks: Buffer[] = [];
          stream.on('data', (chunk: Buffer) => chunks.push(chunk));
          stream.on('end', () => {
            const content = Buffer.concat(chunks).toString('utf-8');
            resolve(content);
            next();
          });
          stream.on('error', (err: Error) => {
            reject(new Error(`Erreur lecture fichier: ${err.message}`));
          });
        } else {
          stream.on('end', next);
          stream.resume();
        }
      });

      extract.on('finish', () => {
        if (!found) {
          resolve(null);
        }
      });

      extract.on('error', (err: Error) => {
        reject(new Error(`Erreur lecture TAR: ${err.message}`));
      });

      try {
        const stream = Readable.from(buffer);
        if (isGzipped) {
          stream.pipe(zlib.createGunzip()).pipe(extract);
        } else {
          stream.pipe(extract);
        }
      } catch (error) {
        reject(
          new Error(
            `Erreur traitement TAR: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
          ),
        );
      }
    });
  }

  /**
   * Trouve les fichiers correspondant à un motif
   * @param fileList - Liste des fichiers
   * @param pattern - Motif à faire correspondre
   * @returns Tableau des fichiers correspondants
   */
  private findMatchingFiles(fileList: string[], pattern: string): string[] {
    return fileList.filter((file) => {
      if (file === pattern) {
        return true;
      }
      return minimatch(file, pattern, { matchBase: true });
    });
  }

  /**
   * Extrait la liste des dossiers de la liste des fichiers
   * @param fileList - Liste des fichiers
   * @returns Tableau des chemins de dossiers uniques
   */
  private extractFolderList(fileList: string[]): string[] {
    const folders = new Set<string>();

    for (const file of fileList) {
      const dir = path.dirname(file);
      if (dir && dir !== '.') {
        const parts = dir.split(path.sep);
        let currentPath = '';
        for (const part of parts) {
          currentPath = currentPath ? path.join(currentPath, part) : part;
          folders.add(this.normalizePath(currentPath));
        }
      }
    }

    return Array.from(folders);
  }

  /**
   * Normalise les séparateurs de chemin pour la compatibilité
   * @param pathStr - Chaîne de chemin
   * @returns Chemin normalisé
   */
  private normalizePath(pathStr: string): string {
    return pathStr.replace(/\\\\/g, '/');
  }

  /**
   * Vérifie si un dossier correspond à un motif
   * @param folder - Chemin de dossier réel
   * @param pattern - Motif à faire correspondre
   * @returns True si correspond
   */
  private matchesFolderPattern(folder: string, pattern: string): boolean {
    const normalizedFolder = this.normalizePath(folder);
    const normalizedPattern = this.normalizePath(pattern);

    return (
      normalizedFolder === normalizedPattern ||
      normalizedFolder.startsWith(normalizedPattern + '/') ||
      minimatch(normalizedFolder, normalizedPattern)
    );
  }
}
