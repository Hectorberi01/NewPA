import { Injectable, Inject } from '@nestjs/common';
import { IStorageService } from '../../interfaces/storage.interface';
import { S3StorageService } from './s3-storage.service';

/**
 * Service unifié de stockage
 * Utilise exclusivement S3 pour le stockage des fichiers
 */
@Injectable()
export class StorageService implements IStorageService {
  constructor(
    @Inject('S3_STORAGE') private readonly s3Storage: S3StorageService,
  ) {}

  async uploadFile(file: Express.Multer.File, path: string): Promise<string> {
    return this.s3Storage.uploadFile(file, path);
  }

  async downloadFile(path: string): Promise<Buffer> {
    return this.s3Storage.downloadFile(path);
  }

  async deleteFile(path: string): Promise<boolean> {
    return this.s3Storage.deleteFile(path);
  }

  async fileExists(path: string): Promise<boolean> {
    return this.s3Storage.fileExists(path);
  }

  async generateDownloadUrl(path: string, expiresIn?: number): Promise<string> {
    return this.s3Storage.generateDownloadUrl(path, expiresIn);
  }
}
