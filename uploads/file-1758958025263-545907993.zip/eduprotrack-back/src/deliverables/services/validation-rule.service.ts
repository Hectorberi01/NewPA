import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import {
  CreateVerificationRuleDto,
  UpdateVerificationRuleDto,
  ValidationResultDto,
  ValidationRuleResultDto,
} from '../dto/verification-rule.dto';
import type { VerificationRule } from '@prisma/client';
import { FileAnalysisService } from './file-analysis.service';
import { GitValidationService } from './git-validation.service';

// Type definitions for rule configurations
interface FileSizeRuleConfig {
  maxSizeMB: number;
  minSizeMB?: number;
}

interface RequiredFilesRuleConfig {
  patterns: string[];
}

interface FolderStructureRuleConfig {
  requiredFolders: string[];
  forbiddenFolders?: string[];
}

interface ContentRegexRuleConfig {
  fileName: string;
  pattern: string;
  flags?: string;
  mustMatch?: boolean;
}

interface GitValidationRuleConfig {
  requirePublic: boolean;
  allowedHosts?: string[];
  requireReadme?: boolean;
}

type RuleConfig =
  | FileSizeRuleConfig
  | RequiredFilesRuleConfig
  | FolderStructureRuleConfig
  | ContentRegexRuleConfig
  | GitValidationRuleConfig;

interface SubmissionData {
  file?: Express.Multer.File;
  gitUrl?: string;
  type: 'ARCHIVE' | 'GIT_LINK';
}

interface UpdateRuleData {
  ruleType?: string;
  ruleValue?: string;
  errorMessage?: string;
}

/**
 * Service de gestion des règles de validation et validation des soumissions
 * Implémente la fonctionnalité de validation de l'US-DEL-002.md
 */
@Injectable()
export class ValidationRuleService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly fileAnalysisService: FileAnalysisService,
    private readonly gitValidationService: GitValidationService,
  ) {}

  /**
   * Crée une nouvelle règle de validation pour un livrable
   * @param deliverableId - ID du livrable
   * @param createDto - Données de création de la règle
   * @returns La règle de validation créée
   */
  async createRule(
    deliverableId: string,
    createDto: CreateVerificationRuleDto,
  ): Promise<VerificationRule> {
    const deliverable = await this.prisma.deliverable.findUnique({
      where: { id: deliverableId },
    });

    if (!deliverable) {
      throw new NotFoundException(
        `Livrable avec l'ID ${deliverableId} non trouvé`,
      );
    }

    this.validateRuleConfiguration(createDto.ruleType, createDto.ruleValue);

    return this.prisma.verificationRule.create({
      data: {
        deliverableId,
        ruleType: createDto.ruleType,
        ruleValue: JSON.stringify(createDto.ruleValue),
        errorMessage: createDto.errorMessage,
      },
    });
  }

  /**
   * Met à jour une règle de validation existante
   * @param ruleId - ID de la règle
   * @param updateDto - Données de mise à jour de la règle
   * @returns La règle de validation mise à jour
   */
  async updateRule(
    ruleId: string,
    updateDto: UpdateVerificationRuleDto,
  ): Promise<VerificationRule> {
    const existingRule = await this.prisma.verificationRule.findUnique({
      where: { id: ruleId },
    });

    if (!existingRule) {
      throw new NotFoundException(`Règle avec l'ID ${ruleId} non trouvée`);
    }

    if (updateDto.ruleType && updateDto.ruleValue) {
      this.validateRuleConfiguration(updateDto.ruleType, updateDto.ruleValue);
    }

    const updateData: UpdateRuleData = {};
    if (updateDto.ruleType) {
      updateData.ruleType = updateDto.ruleType;
    }
    if (updateDto.ruleValue) {
      updateData.ruleValue = JSON.stringify(updateDto.ruleValue);
    }
    if (updateDto.errorMessage) {
      updateData.errorMessage = updateDto.errorMessage;
    }

    return this.prisma.verificationRule.update({
      where: { id: ruleId },
      data: updateData,
    });
  }

  /**
   * Supprime une règle de validation
   * @param ruleId - ID de la règle
   */
  async deleteRule(ruleId: string): Promise<void> {
    const rule = await this.prisma.verificationRule.findUnique({
      where: { id: ruleId },
    });

    if (!rule) {
      throw new NotFoundException(`Règle avec l'ID ${ruleId} non trouvée`);
    }

    await this.prisma.verificationRule.delete({
      where: { id: ruleId },
    });
  }

  /**
   * Récupère toutes les règles de validation d'un livrable
   * @param deliverableId - ID du livrable
   * @returns Tableau des règles de validation
   */
  async getDeliverableRules(
    deliverableId: string,
  ): Promise<VerificationRule[]> {
    return this.prisma.verificationRule.findMany({
      where: { deliverableId },
      orderBy: { createdAt: 'asc' },
    });
  }

  /**
   * Récupère une règle de validation spécifique
   * @param ruleId - ID de la règle
   * @returns La règle de validation
   */
  async getRule(ruleId: string): Promise<VerificationRule> {
    const rule = await this.prisma.verificationRule.findUnique({
      where: { id: ruleId },
    });

    if (!rule) {
      throw new NotFoundException(`Règle avec l'ID ${ruleId} non trouvée`);
    }

    return rule;
  }

  /**
   * Valide une soumission contre toutes les règles d'un livrable
   * @param deliverableId - ID du livrable
   * @param submissionData - Données de soumission (fichier ou URL Git)
   * @returns Résultat de validation
   */
  async validateSubmission(
    deliverableId: string,
    submissionData: {
      file?: Express.Multer.File;
      gitUrl?: string;
      type: 'ARCHIVE' | 'GIT_LINK';
    },
  ): Promise<ValidationResultDto> {
    const rules = await this.getDeliverableRules(deliverableId);
    const results: ValidationRuleResultDto[] = [];
    const errors: string[] = [];
    const warnings: string[] = [];

    for (const rule of rules) {
      try {
        const ruleConfig = JSON.parse(rule.ruleValue) as RuleConfig;
        const result = await this.validateSingleRule(
          rule.ruleType,
          ruleConfig,
          submissionData,
          rule.errorMessage,
        );

        results.push(result);

        if (!result.passed) {
          errors.push(result.message || rule.errorMessage);
        }
      } catch (error: unknown) {
        const errorMessage = `Erreur lors de la validation de la règle: ${error instanceof Error ? error.message : 'Erreur inconnue'}`;
        errors.push(errorMessage);
        results.push({
          ruleType: rule.ruleType,
          ruleName: `Règle ${rule.ruleType}`,
          passed: false,
          message: errorMessage,
        });
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      details: results,
    };
  }

  /**
   * Valide une soumission contre une règle unique
   * @param ruleType - Type de règle
   * @param ruleConfig - Configuration de la règle
   * @param submissionData - Données de soumission
   * @param errorMessage - Message d'erreur personnalisé
   * @returns Résultat de validation pour cette règle
   */
  private async validateSingleRule(
    ruleType: string,
    ruleConfig: RuleConfig,
    submissionData: SubmissionData,
    errorMessage: string,
  ): Promise<ValidationRuleResultDto> {
    switch (ruleType) {
      case 'FILE_SIZE':
        return this.validateFileSize(
          ruleConfig as FileSizeRuleConfig,
          submissionData,
          errorMessage,
        );

      case 'REQUIRED_FILES':
        return this.validateRequiredFiles(
          ruleConfig as RequiredFilesRuleConfig,
          submissionData,
          errorMessage,
        );

      case 'FOLDER_STRUCTURE':
        return this.validateFolderStructure(
          ruleConfig as FolderStructureRuleConfig,
          submissionData,
          errorMessage,
        );

      case 'CONTENT_REGEX':
        return this.validateContentRegex(
          ruleConfig as ContentRegexRuleConfig,
          submissionData,
          errorMessage,
        );

      case 'GIT_VALIDATION':
        return this.validateGitRepository(
          ruleConfig as GitValidationRuleConfig,
          submissionData,
          errorMessage,
        );

      default:
        throw new BadRequestException(`Type de règle inconnu: ${ruleType}`);
    }
  }

  /**
   * Valide la règle de taille de fichier
   */
  private validateFileSize(
    config: FileSizeRuleConfig,
    submissionData: SubmissionData,
    errorMessage: string,
  ): ValidationRuleResultDto {
    if (!submissionData.file) {
      return {
        ruleType: 'FILE_SIZE',
        ruleName: 'Taille de fichier',
        passed: false,
        message: 'Aucun fichier fourni pour la validation de taille',
      };
    }

    const fileSizeMB = submissionData.file.size / (1024 * 1024);
    const maxSizeMB = config.maxSizeMB;
    const minSizeMB = config.minSizeMB || 0;

    const passed = fileSizeMB <= maxSizeMB && fileSizeMB >= minSizeMB;

    return {
      ruleType: 'FILE_SIZE',
      ruleName: 'Taille de fichier',
      passed,
      message: passed
        ? undefined
        : `${errorMessage} (taille: ${fileSizeMB.toFixed(2)}MB, max: ${maxSizeMB}MB)`,
      details: {
        actualSizeMB: fileSizeMB,
        maxSizeMB,
        minSizeMB,
      },
    };
  }

  /**
   * Valide la règle de fichiers requis
   */
  private async validateRequiredFiles(
    config: RequiredFilesRuleConfig,
    submissionData: SubmissionData,
    errorMessage: string,
  ): Promise<ValidationRuleResultDto> {
    if (!submissionData.file) {
      return {
        ruleType: 'REQUIRED_FILES',
        ruleName: 'Fichiers requis',
        passed: false,
        message: 'Aucun fichier fourni pour la validation de fichiers requis',
      };
    }

    try {
      const result = await this.fileAnalysisService.checkRequiredFiles(
        submissionData.file,
        config.patterns,
      );

      return {
        ruleType: 'REQUIRED_FILES',
        ruleName: 'Fichiers requis',
        passed: result.isValid,
        message: result.isValid
          ? undefined
          : `${errorMessage}: ${result.missingFiles.join(', ')}`,
        details: {
          foundFiles: result.foundFiles,
          missingFiles: result.missingFiles,
          patterns: config.patterns,
        },
      };
    } catch (error) {
      return {
        ruleType: 'REQUIRED_FILES',
        ruleName: 'Fichiers requis',
        passed: false,
        message: `Erreur lors de l'analyse des fichiers: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
      };
    }
  }

  /**
   * Valide la règle de structure de dossiers
   */
  private async validateFolderStructure(
    config: FolderStructureRuleConfig,
    submissionData: SubmissionData,
    errorMessage: string,
  ): Promise<ValidationRuleResultDto> {
    if (!submissionData.file) {
      return {
        ruleType: 'FOLDER_STRUCTURE',
        ruleName: 'Structure de dossiers',
        passed: false,
        message: 'Aucun fichier fourni pour la validation de structure',
      };
    }

    try {
      const result = await this.fileAnalysisService.validateFolderStructure(
        submissionData.file,
        config,
      );

      return {
        ruleType: 'FOLDER_STRUCTURE',
        ruleName: 'Structure de dossiers',
        passed: result.isValid,
        message: result.isValid ? undefined : errorMessage,
        details: {
          foundFolders: result.foundFolders,
          missingFolders: result.missingFolders,
          forbiddenFoldersFound: result.forbiddenFoldersFound,
        },
      };
    } catch (error) {
      return {
        ruleType: 'FOLDER_STRUCTURE',
        ruleName: 'Structure de dossiers',
        passed: false,
        message: `Erreur lors de l'analyse de structure: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
      };
    }
  }

  /**
   * Valide la règle de contenu avec regex
   */
  private async validateContentRegex(
    config: ContentRegexRuleConfig,
    submissionData: SubmissionData,
    errorMessage: string,
  ): Promise<ValidationRuleResultDto> {
    if (!submissionData.file) {
      return {
        ruleType: 'CONTENT_REGEX',
        ruleName: 'Contenu de fichier',
        passed: false,
        message: 'Aucun fichier fourni pour la validation de contenu',
      };
    }

    try {
      const result = await this.fileAnalysisService.validateFileContent(
        submissionData.file,
        config,
      );

      return {
        ruleType: 'CONTENT_REGEX',
        ruleName: 'Contenu de fichier',
        passed: result.isValid,
        message: result.isValid ? undefined : errorMessage,
        details: {
          fileName: config.fileName,
          pattern: config.pattern,
          matchFound: result.matchFound,
        },
      };
    } catch (error) {
      return {
        ruleType: 'CONTENT_REGEX',
        ruleName: 'Contenu de fichier',
        passed: false,
        message: `Erreur lors de la validation de contenu: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
      };
    }
  }

  /**
   * Valide la règle de dépôt Git
   */
  private async validateGitRepository(
    config: GitValidationRuleConfig,
    submissionData: SubmissionData,
    errorMessage: string,
  ): Promise<ValidationRuleResultDto> {
    if (!submissionData.gitUrl) {
      return {
        ruleType: 'GIT_VALIDATION',
        ruleName: 'Dépôt Git',
        passed: false,
        message: 'Aucune URL Git fournie pour la validation',
      };
    }

    try {
      const result = await this.gitValidationService.validateGitRepository(
        submissionData.gitUrl,
        config,
      );

      return {
        ruleType: 'GIT_VALIDATION',
        ruleName: 'Dépôt Git',
        passed: result.isValid,
        message: result.isValid
          ? undefined
          : `${errorMessage}: ${result.errors.join(', ')}`,
        details: {
          url: submissionData.gitUrl,
          isPublic: result.repositoryInfo?.isPublic,
          host: result.repositoryInfo?.host,
          hasReadme: result.repositoryInfo?.hasReadme,
        },
      };
    } catch (error) {
      return {
        ruleType: 'GIT_VALIDATION',
        ruleName: 'Dépôt Git',
        passed: false,
        message: `Erreur lors de la validation Git: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
      };
    }
  }

  /**
   * Valide la configuration d'une règle avant sauvegarde
   * @param ruleType - Type de règle
   * @param ruleValue - Configuration de la règle
   */
  private validateRuleConfiguration(
    ruleType: string,
    ruleValue: Record<string, unknown>,
  ): void {
    switch (ruleType) {
      case 'FILE_SIZE': {
        const config = ruleValue as unknown as FileSizeRuleConfig;
        if (!config.maxSizeMB || config.maxSizeMB <= 0) {
          throw new BadRequestException(
            'FILE_SIZE rule requires positive maxSizeMB',
          );
        }
        break;
      }

      case 'REQUIRED_FILES': {
        const config = ruleValue as unknown as RequiredFilesRuleConfig;
        if (!config.patterns || !Array.isArray(config.patterns)) {
          throw new BadRequestException(
            'REQUIRED_FILES rule requires patterns array',
          );
        }
        break;
      }

      case 'FOLDER_STRUCTURE': {
        const config = ruleValue as unknown as FolderStructureRuleConfig;
        if (!config.requiredFolders || !Array.isArray(config.requiredFolders)) {
          throw new BadRequestException(
            'FOLDER_STRUCTURE rule requires requiredFolders array',
          );
        }
        break;
      }

      case 'CONTENT_REGEX': {
        const config = ruleValue as unknown as ContentRegexRuleConfig;
        if (!config.fileName || !config.pattern) {
          throw new BadRequestException(
            'CONTENT_REGEX rule requires fileName and pattern',
          );
        }
        try {
          new RegExp(config.pattern, config.flags || '');
        } catch (error) {
          throw new BadRequestException(
            `Invalid regex pattern: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
          );
        }
        break;
      }

      case 'GIT_VALIDATION': {
        const config = ruleValue as unknown as GitValidationRuleConfig;
        if (config.allowedHosts && !Array.isArray(config.allowedHosts)) {
          throw new BadRequestException(
            'GIT_VALIDATION allowedHosts must be an array',
          );
        }
        break;
      }

      default:
        throw new BadRequestException(`Unknown rule type: ${ruleType}`);
    }
  }
}
