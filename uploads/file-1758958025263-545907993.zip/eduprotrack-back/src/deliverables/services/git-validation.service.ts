import { Injectable, Logger } from '@nestjs/common';
import { execSync } from 'child_process';
import * as https from 'https';
import * as http from 'http';
import { URL } from 'url';

/**
 * Interface pour les informations de dépôt Git
 */
export interface GitRepositoryInfo {
  url: string;
  host: string;
  owner: string;
  repository: string;
  isPublic: boolean;
  hasReadme: boolean;
  commitCount?: number;
  lastCommitDate?: Date;
}

/**
 * Interface pour le résultat de validation Git
 */
export interface GitValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  repositoryInfo?: GitRepositoryInfo;
}

/**
 * Service de validation des dépôts Git
 * Implémente la fonctionnalité de validation Git de l'US-DEL-002.md
 */
@Injectable()
export class GitValidationService {
  private readonly logger = new Logger(GitValidationService.name);

  /**
   * Timeout pour les opérations Git (30 secondes comme spécifié dans l'US-DEL-002.md)
   */
  private readonly GIT_TIMEOUT = 30000;

  /**
   * Hôtes Git supportés
   */
  private readonly DEFAULT_ALLOWED_HOSTS = [
    'github.com',
    'gitlab.com',
    'bitbucket.org',
    'gitlab.univ-lyon1.fr',
  ];

  /**
   * Valide une URL de dépôt Git et son accessibilité
   * @param gitUrl - URL du dépôt Git
   * @param config - Configuration de validation
   * @returns Résultat de validation
   */
  async validateGitRepository(
    gitUrl: string,
    config: {
      requirePublic?: boolean;
      allowedHosts?: string[];
      requireReadme?: boolean;
    } = {},
  ): Promise<GitValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];
    let repositoryInfo: GitRepositoryInfo | undefined;

    try {
      // Valider le format de l'URL
      const urlValidation = this.validateGitUrl(gitUrl);
      if (!urlValidation.isValid) {
        return {
          isValid: false,
          errors: urlValidation.errors,
          warnings,
        };
      }

      repositoryInfo = urlValidation.repositoryInfo!;

      // Vérifier si l'hôte est autorisé
      const allowedHosts = config.allowedHosts || this.DEFAULT_ALLOWED_HOSTS;
      if (!allowedHosts.includes(repositoryInfo.host)) {
        errors.push(
          `Hôte non autorisé: ${repositoryInfo.host}. Hôtes autorisés: ${allowedHosts.join(', ')}`,
        );
      }

      // Tester l'accessibilité du dépôt
      const accessibilityResult =
        await this.testRepositoryAccessibility(gitUrl);
      if (!accessibilityResult.isAccessible) {
        errors.push(
          accessibilityResult.error ||
            'Dépôt inaccessible ou privé. Assurez-vous que le dépôt est public.',
        );
      } else {
        repositoryInfo.isPublic = accessibilityResult.isPublic;
      }

      // Vérifier si un dépôt public est requis
      if (config.requirePublic !== false && repositoryInfo.isPublic === false) {
        errors.push('Le dépôt doit être public pour cette soumission');
      }

      // Vérifier la présence d'un README si requis
      if (config.requireReadme && accessibilityResult.isAccessible) {
        const readmeResult = await this.checkReadmeExists(gitUrl);
        repositoryInfo.hasReadme = readmeResult.exists;
        if (!readmeResult.exists) {
          if (config.requireReadme) {
            errors.push('Le dépôt doit contenir un fichier README');
          } else {
            warnings.push('Aucun fichier README trouvé dans le dépôt');
          }
        }
      }
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Erreur inconnue';
      const errorStack = error instanceof Error ? error.stack : undefined;
      this.logger.error(`Erreur validation Git: ${errorMessage}`, errorStack);
      errors.push(`Erreur lors de la validation: ${errorMessage}`);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      repositoryInfo,
    };
  }

  /**
   * Valide le format de l'URL Git et extrait les informations du dépôt
   * @param gitUrl - URL Git à valider
   * @returns Résultat de validation avec informations du dépôt
   */
  private validateGitUrl(gitUrl: string): {
    isValid: boolean;
    errors: string[];
    repositoryInfo?: GitRepositoryInfo;
  } {
    const errors: string[] = [];

    try {
      // Validation URL de base
      let url: URL;
      try {
        url = new URL(gitUrl);
      } catch {
        errors.push('URL invalide');
        return { isValid: false, errors };
      }

      // Vérifier le protocole
      if (!['http:', 'https:'].includes(url.protocol)) {
        errors.push('Seuls les protocoles HTTP et HTTPS sont supportés');
      }

      // Extraire les informations du dépôt
      const host = url.hostname;
      const pathParts = url.pathname.split('/').filter(Boolean);

      if (pathParts.length < 2) {
        errors.push(
          'URL Git invalide. Format attendu: https://host.com/owner/repository',
        );
        return { isValid: false, errors };
      }

      const owner = pathParts[0];
      let repository = pathParts[1];

      // Supprimer l'extension .git si présente
      if (repository.endsWith('.git')) {
        repository = repository.slice(0, -4);
      }

      // Valider les noms de propriétaire et de dépôt
      if (!this.isValidGitName(owner)) {
        errors.push('Nom du propriétaire invalide');
      }

      if (!this.isValidGitName(repository)) {
        errors.push('Nom du dépôt invalide');
      }

      const repositoryInfo: GitRepositoryInfo = {
        url: gitUrl,
        host,
        owner,
        repository,
        isPublic: false,
        hasReadme: false,
      };

      return {
        isValid: errors.length === 0,
        errors,
        repositoryInfo,
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Erreur inconnue';
      errors.push(`Erreur lors de la validation de l'URL: ${errorMessage}`);
      return { isValid: false, errors };
    }
  }

  /**
   * Teste si le dépôt est accessible via git ls-remote
   * @param gitUrl - URL du dépôt Git
   * @returns Résultat d'accessibilité
   */
  private async testRepositoryAccessibility(gitUrl: string): Promise<{
    isAccessible: boolean;
    isPublic: boolean;
    error?: string;
  }> {
    return new Promise((resolve) => {
      try {
        const command = `git ls-remote --heads "${gitUrl}"`;

        const timeout = setTimeout(() => {
          resolve({
            isAccessible: false,
            isPublic: false,
            error: 'Timeout lors du test de connectivité (30s)',
          });
        }, this.GIT_TIMEOUT);

        try {
          const output = execSync(command, {
            timeout: this.GIT_TIMEOUT,
            stdio: 'pipe',
            encoding: 'utf-8',
          });

          clearTimeout(timeout);

          if (output && output.length > 0) {
            resolve({
              isAccessible: true,
              isPublic: true,
            });
          } else {
            resolve({
              isAccessible: false,
              isPublic: false,
              error: 'Dépôt vide ou inaccessible',
            });
          }
        } catch (error) {
          clearTimeout(timeout);

          const errorMessage =
            error instanceof Error
              ? error.message.toLowerCase()
              : 'erreur inconnue';
          if (
            errorMessage.includes('authentication') ||
            errorMessage.includes('permission denied') ||
            errorMessage.includes('not found')
          ) {
            resolve({
              isAccessible: false,
              isPublic: false,
              error: 'Dépôt privé ou inaccessible',
            });
          } else {
            resolve({
              isAccessible: false,
              isPublic: false,
              error: `Erreur Git: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
            });
          }
        }
      } catch (error) {
        resolve({
          isAccessible: false,
          isPublic: false,
          error: `Erreur système: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
        });
      }
    });
  }

  /**
   * Vérifie si un fichier README existe dans le dépôt
   * @param gitUrl - URL du dépôt Git
   * @returns Résultat indiquant si README existe
   */
  private async checkReadmeExists(gitUrl: string): Promise<{
    exists: boolean;
    error?: string;
  }> {
    return new Promise((resolve) => {
      try {
        const webUrl = this.gitUrlToWebUrl(gitUrl);
        if (webUrl) {
          this.checkReadmeViaHttp(webUrl)
            .then((exists) => {
              resolve({ exists });
            })
            .catch((error) => {
              resolve({
                exists: false,
                error: `Erreur vérification README: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
              });
            });
        } else {
          // Supposer que README existe si on ne peut pas vérifier
          resolve({ exists: true });
        }
      } catch (error) {
        resolve({
          exists: false,
          error: `Erreur système: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
        });
      }
    });
  }

  /**
   * Convertit une URL Git en URL web pour l'accès API
   * @param gitUrl - URL du dépôt Git
   * @returns URL web ou null si la conversion échoue
   */
  private gitUrlToWebUrl(gitUrl: string): string | null {
    try {
      const url = new URL(gitUrl);
      let webUrl = `${url.protocol}//${url.host}${url.pathname}`;

      // Supprimer l'extension .git
      if (webUrl.endsWith('.git')) {
        webUrl = webUrl.slice(0, -4);
      }

      return webUrl;
    } catch {
      return null;
    }
  }

  /**
   * Vérifie la présence d'un fichier README via requête HTTP
   * @param webUrl - URL web du dépôt
   * @returns Promise qui se résout à true si README existe
   */
  private async checkReadmeViaHttp(webUrl: string): Promise<boolean> {
    return new Promise((resolve, reject) => {
      try {
        const url = new URL(webUrl);
        const isHttps = url.protocol === 'https:';
        const client = isHttps ? https : http;

        // Essayer d'accéder aux emplacements courants de README
        const readmePaths = [
          '/blob/main/README.md',
          '/blob/master/README.md',
          '/blob/main/README.txt',
          '/blob/master/README.txt',
        ];

        let found = false;
        let completed = 0;

        for (const readmePath of readmePaths) {
          if (found) break;

          const requestUrl = webUrl + readmePath;

          const req = client.get(requestUrl, { timeout: 5000 }, (res) => {
            completed++;
            if (res.statusCode === 200) {
              found = true;
              resolve(true);
            } else if (completed === readmePaths.length && !found) {
              resolve(false);
            }
          });

          req.on('error', () => {
            completed++;
            if (completed === readmePaths.length && !found) {
              resolve(false);
            }
          });

          req.on('timeout', () => {
            req.destroy();
            completed++;
            if (completed === readmePaths.length && !found) {
              resolve(false);
            }
          });
        }

        // Timeout de secours
        setTimeout(() => {
          if (!found) {
            resolve(false);
          }
        }, 10000);
      } catch (error) {
        reject(error instanceof Error ? error : new Error('Erreur inconnue'));
      }
    });
  }

  /**
   * Valide si un nom est valide pour Git (propriétaire ou dépôt)
   * @param name - Nom à valider
   * @returns True si valide
   */
  private isValidGitName(name: string): boolean {
    // Validation de base pour les noms Git
    if (!name || name.length === 0) {
      return false;
    }

    // Vérifier les caractères interdits
    if (/[<>:"|?*\s]/.test(name)) {
      return false;
    }

    // Vérifier les noms réservés
    const reservedNames = ['.', '..', 'CON', 'PRN', 'AUX', 'NUL'];
    if (reservedNames.includes(name.toUpperCase())) {
      return false;
    }

    return true;
  }

  /**
   * Obtient les informations du dépôt sans validation complète
   * Utile pour afficher les détails du dépôt
   * @param gitUrl - URL du dépôt Git
   * @returns Informations du dépôt ou null
   */
  getRepositoryInfo(gitUrl: string): GitRepositoryInfo | null {
    const validation = this.validateGitUrl(gitUrl);
    return validation.isValid ? validation.repositoryInfo || null : null;
  }

  /**
   * Vérifie si Git est disponible sur le système
   * @returns True si Git est disponible
   */
  isGitAvailable(): boolean {
    try {
      execSync('git --version', { stdio: 'ignore' });
      return true;
    } catch {
      this.logger.warn('Git non disponible sur le système');
      return false;
    }
  }
}
