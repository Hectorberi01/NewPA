import { Controller, Get, Param, UseGuards, Request } from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
} from '@nestjs/swagger';
import { JWTAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../../auth/guards/teacher.guard';
import { GroupReportContentService } from '../services/group-report-content.service';

@ApiTags('Reports - Teacher View')
@ApiBearerAuth()
@UseGuards(JWTAuthGuard, TeacherGuard)
@Controller('projects/:projectId/groups/:groupId/report')
export class TeacherReportViewController {
  constructor(private groupReportContentService: GroupReportContentService) {}

  @Get('full')
  @ApiOperation({ summary: "Visualiser le rapport complet d'un groupe" })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiParam({ name: 'groupId', description: 'ID du groupe' })
  @ApiResponse({ status: 200 })
  async getFullGroupReport(
    @Param('projectId') projectId: string,
    @Param('groupId') groupId: string,
    @Request() req,
  ) {
    return this.groupReportContentService.getFullGroupReport(
      projectId,
      groupId,
      req.user.id,
    );
  }
}
