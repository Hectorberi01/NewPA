import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  UseGuards,
  Request,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
} from '@nestjs/swagger';
import { JWTAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../../auth/guards/teacher.guard';
import { ProjectReportService } from '../services/project-report.service';
import { ReportSectionService } from '../services/report-section.service';
import { GroupReportContentService } from '../services/group-report-content.service';
import {
  CreateProjectReportDto,
  UpdateProjectReportDto,
  CreateReportSectionDto,
  UpdateReportSectionDto,
  ReorderSectionsDto,
  ProjectReportResponseDto,
  ReportSectionResponseDto,
  ReportsOverviewDto,
} from '../dto';

@ApiTags('Reports - Teacher')
@ApiBearerAuth()
@UseGuards(JWTAuthGuard, TeacherGuard)
@Controller('projects/:projectId/report')
export class ProjectReportController {
  constructor(
    private projectReportService: ProjectReportService,
    private reportSectionService: ReportSectionService,
    private groupReportContentService: GroupReportContentService,
  ) {}

  @Post()
  @ApiOperation({ summary: 'Créer/activer un rapport pour un projet' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 201, type: ProjectReportResponseDto })
  async createReport(
    @Param('projectId') projectId: string,
    @Request() req,
    @Body() dto: CreateProjectReportDto,
  ) {
    return this.projectReportService.createReport(projectId, req.user.id, dto);
  }

  @Get()
  @ApiOperation({ summary: "Récupérer le rapport d'un projet" })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 200, type: ProjectReportResponseDto })
  async getReport(@Param('projectId') projectId: string, @Request() req) {
    return this.projectReportService.getReport(projectId, req.user.id);
  }

  @Put()
  @ApiOperation({ summary: "Modifier la configuration d'un rapport" })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 200, type: ProjectReportResponseDto })
  async updateReport(
    @Param('projectId') projectId: string,
    @Request() req,
    @Body() dto: UpdateProjectReportDto,
  ) {
    return this.projectReportService.updateReport(projectId, req.user.id, dto);
  }

  @Delete()
  @ApiOperation({ summary: 'Désactiver un rapport' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 200 })
  async deleteReport(@Param('projectId') projectId: string, @Request() req) {
    return this.projectReportService.deleteReport(projectId, req.user.id);
  }

  // Section Management
  @Post('sections')
  @ApiOperation({ summary: 'Ajouter une section au rapport' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 201, type: ReportSectionResponseDto })
  async createSection(
    @Param('projectId') projectId: string,
    @Request() req,
    @Body() dto: CreateReportSectionDto,
  ) {
    return this.reportSectionService.createSection(projectId, req.user.id, dto);
  }

  @Get('sections')
  @ApiOperation({ summary: "Récupérer toutes les sections d'un rapport" })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 200, type: [ReportSectionResponseDto] })
  async getSections(@Param('projectId') projectId: string, @Request() req) {
    return this.reportSectionService.getSections(projectId, req.user.id);
  }

  @Put('sections/:sectionId')
  @ApiOperation({ summary: 'Modifier une section' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiParam({ name: 'sectionId', description: 'ID de la section' })
  @ApiResponse({ status: 200, type: ReportSectionResponseDto })
  async updateSection(
    @Param('projectId') projectId: string,
    @Param('sectionId') sectionId: string,
    @Request() req,
    @Body() dto: UpdateReportSectionDto,
  ) {
    return this.reportSectionService.updateSection(
      projectId,
      sectionId,
      req.user.id,
      dto,
    );
  }

  @Delete('sections/:sectionId')
  @ApiOperation({ summary: 'Supprimer une section' })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiParam({ name: 'sectionId', description: 'ID de la section' })
  @ApiResponse({ status: 200 })
  async deleteSection(
    @Param('projectId') projectId: string,
    @Param('sectionId') sectionId: string,
    @Request() req,
  ) {
    return this.reportSectionService.deleteSection(
      projectId,
      sectionId,
      req.user.id,
    );
  }

  @Put('sections/reorder')
  @ApiOperation({ summary: "Réorganiser l'ordre des sections" })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 200, type: [ReportSectionResponseDto] })
  async reorderSections(
    @Param('projectId') projectId: string,
    @Request() req,
    @Body() dto: ReorderSectionsDto,
  ) {
    return this.reportSectionService.reorderSections(
      projectId,
      req.user.id,
      dto,
    );
  }

  // Reports Overview and Reading
  @Get('overview')
  @ApiOperation({ summary: "Vue d'ensemble de tous les rapports des groupes" })
  @ApiParam({ name: 'projectId', description: 'ID du projet' })
  @ApiResponse({ status: 200, type: ReportsOverviewDto })
  async getReportsOverview(
    @Param('projectId') projectId: string,
    @Request() req,
  ) {
    return this.groupReportContentService.getReportsOverview(
      projectId,
      req.user.id,
    );
  }
}
