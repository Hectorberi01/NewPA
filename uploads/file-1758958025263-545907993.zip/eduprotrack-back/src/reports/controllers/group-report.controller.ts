import {
  Controller,
  Get,
  Put,
  Body,
  Param,
  UseGuards,
  Request,
  NotFoundException,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
} from '@nestjs/swagger';
import { JWTAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { StudentGuard } from '../../auth/guards/student.guard';
import { GroupReportContentService } from '../services/group-report-content.service';
import {
  UpdateReportContentDto,
  GroupReportViewDto,
  GroupReportContentResponseDto,
} from '../dto';

@ApiTags('Reports - Student')
@ApiBearerAuth()
@UseGuards(JWTAuthGuard, StudentGuard)
@Controller('groups/:groupId/report')
export class GroupReportController {
  constructor(private groupReportContentService: GroupReportContentService) {}

  @Get()
  @ApiOperation({ summary: 'Visualiser les sections du rapport à remplir' })
  @ApiParam({ name: 'groupId', description: 'ID du groupe' })
  @ApiResponse({ status: 200, type: GroupReportViewDto })
  async getGroupReport(@Param('groupId') groupId: string, @Request() req) {
    return this.groupReportContentService.getGroupReport(groupId, req.user.id);
  }

  @Put('sections/:sectionId')
  @ApiOperation({ summary: "Modifier le contenu d'une section" })
  @ApiParam({ name: 'groupId', description: 'ID du groupe' })
  @ApiParam({ name: 'sectionId', description: 'ID de la section' })
  @ApiResponse({ status: 200, type: GroupReportContentResponseDto })
  async updateSectionContent(
    @Param('groupId') groupId: string,
    @Param('sectionId') sectionId: string,
    @Request() req,
    @Body() dto: UpdateReportContentDto,
  ) {
    return this.groupReportContentService.updateContent(
      groupId,
      sectionId,
      req.user.id,
      dto,
    );
  }

  @Get('sections/:sectionId')
  @ApiOperation({ summary: "Récupérer le contenu d'une section spécifique" })
  @ApiParam({ name: 'groupId', description: 'ID du groupe' })
  @ApiParam({ name: 'sectionId', description: 'ID de la section' })
  @ApiResponse({ status: 200, type: GroupReportContentResponseDto })
  async getSectionContent(
    @Param('groupId') groupId: string,
    @Param('sectionId') sectionId: string,
    @Request() req,
  ) {
    // Cette méthode permet de récupérer le contenu d'une section spécifique
    // pour l'édition ou la consultation détaillée
    const report = await this.groupReportContentService.getGroupReport(
      groupId,
      req.user.id,
    );
    const section = report.sections.find((s) => s.id === sectionId);

    if (!section) {
      throw new NotFoundException('Section non trouvée');
    }

    return {
      id: `${groupId}-${sectionId}`, // ID composite
      projectReportId: report.reportId,
      sectionId: section.id,
      groupId: groupId,
      content: section.content,
      status: section.status,
      lastModifiedBy: section.lastModifiedBy,
      lastModified: section.lastModified,
      createdAt: section.lastModified, // Approximation
    };
  }

  @Put('submit')
  @ApiOperation({ summary: 'Soumettre le rapport complet' })
  @ApiParam({ name: 'groupId', description: 'ID du groupe' })
  @ApiResponse({ status: 200 })
  async submitReport(@Param('groupId') groupId: string, @Request() req) {
    return this.groupReportContentService.submitReport(groupId, req.user.id);
  }
}
