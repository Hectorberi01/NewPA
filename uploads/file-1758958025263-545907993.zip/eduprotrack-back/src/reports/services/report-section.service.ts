import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import {
  CreateReportSectionDto,
  UpdateReportSectionDto,
  ReorderSectionsDto,
} from '../dto';

@Injectable()
export class ReportSectionService {
  constructor(private prisma: PrismaService) {}

  async createSection(
    projectId: string,
    userId: string,
    dto: CreateReportSectionDto,
  ) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    // Vérifier que le rapport existe
    const report = await this.prisma.projectReport.findUnique({
      where: { projectId },
    });

    if (!report) {
      throw new NotFoundException('Aucun rapport trouvé pour ce projet');
    }

    // Vérifier que l'ordre n'est pas déjà utilisé
    const existingOrder = await this.prisma.reportSection.findFirst({
      where: {
        projectReportId: report.id,
        order: dto.order,
      },
    });

    if (existingOrder) {
      throw new BadRequestException(
        `Une section avec l'ordre ${dto.order} existe déjà`,
      );
    }

    return this.prisma.reportSection.create({
      data: {
        projectReportId: report.id,
        ...dto,
      },
    });
  }

  async updateSection(
    projectId: string,
    sectionId: string,
    userId: string,
    dto: UpdateReportSectionDto,
  ) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    // Vérifier que la section existe et appartient au projet
    const section = await this.prisma.reportSection.findFirst({
      where: {
        id: sectionId,
        projectReport: { projectId },
      },
    });

    if (!section) {
      throw new NotFoundException('Section non trouvée');
    }

    // Si on change l'ordre, vérifier qu'il n'est pas déjà utilisé
    if (dto.order && dto.order !== section.order) {
      const existingOrder = await this.prisma.reportSection.findFirst({
        where: {
          projectReportId: section.projectReportId,
          order: dto.order,
          id: { not: sectionId },
        },
      });

      if (existingOrder) {
        throw new BadRequestException(
          `Une section avec l'ordre ${dto.order} existe déjà`,
        );
      }
    }

    return this.prisma.reportSection.update({
      where: { id: sectionId },
      data: dto,
    });
  }

  async deleteSection(projectId: string, sectionId: string, userId: string) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    // Vérifier que la section existe et appartient au projet
    const section = await this.prisma.reportSection.findFirst({
      where: {
        id: sectionId,
        projectReport: { projectId },
      },
    });

    if (!section) {
      throw new NotFoundException('Section non trouvée');
    }

    return this.prisma.reportSection.delete({
      where: { id: sectionId },
    });
  }

  async reorderSections(
    projectId: string,
    userId: string,
    dto: ReorderSectionsDto,
  ) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    // Vérifier que le rapport existe
    const report = await this.prisma.projectReport.findUnique({
      where: { projectId },
      include: {
        sections: true,
      },
    });

    if (!report) {
      throw new NotFoundException('Aucun rapport trouvé pour ce projet');
    }

    // Vérifier que tous les IDs de sections existent
    const existingSectionIds = report.sections.map((s) => s.id);
    const missingIds = dto.sectionIds.filter(
      (id) => !existingSectionIds.includes(id),
    );

    if (missingIds.length > 0) {
      throw new BadRequestException(
        `Sections non trouvées: ${missingIds.join(', ')}`,
      );
    }

    // Vérifier qu'on a tous les IDs existants
    if (dto.sectionIds.length !== existingSectionIds.length) {
      throw new BadRequestException(
        'La liste doit contenir tous les IDs de sections existants',
      );
    }

    // Mettre à jour l'ordre des sections
    const updatePromises = dto.sectionIds.map((sectionId, index) =>
      this.prisma.reportSection.update({
        where: { id: sectionId },
        data: { order: index + 1 },
      }),
    );

    await Promise.all(updatePromises);

    // Retourner les sections réordonnées
    return this.prisma.reportSection.findMany({
      where: { projectReportId: report.id },
      orderBy: { order: 'asc' },
    });
  }

  async getSections(projectId: string, userId: string) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    // Vérifier que le rapport existe
    const report = await this.prisma.projectReport.findUnique({
      where: { projectId },
    });

    if (!report) {
      throw new NotFoundException('Aucun rapport trouvé pour ce projet');
    }

    return this.prisma.reportSection.findMany({
      where: { projectReportId: report.id },
      orderBy: { order: 'asc' },
    });
  }
}
