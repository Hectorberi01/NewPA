import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { UpdateReportContentDto } from '../dto';
import { GroupReportViewDto, ReportsOverviewDto } from '../dto';

@Injectable()
export class GroupReportContentService {
  constructor(private prisma: PrismaService) {}

  async updateContent(
    groupId: string,
    sectionId: string,
    userId: string,
    dto: UpdateReportContentDto,
  ) {
    // Vérifier que l'utilisateur est membre du groupe
    const groupMember = await this.prisma.groupMember.findFirst({
      where: { groupId, userId },
    });

    if (!groupMember) {
      throw new ForbiddenException("Vous n'êtes pas membre de ce groupe");
    }

    // Vérifier que la section existe et que le rapport est activé
    const section = await this.prisma.reportSection.findUnique({
      where: { id: sectionId },
      include: {
        projectReport: {
          include: {
            project: {
              include: {
                groups: {
                  where: { id: groupId },
                },
              },
            },
          },
        },
      },
    });

    if (!section) {
      throw new NotFoundException('Section non trouvée');
    }

    if (section.projectReport.project.groups.length === 0) {
      throw new ForbiddenException("Ce groupe n'appartient pas à ce projet");
    }

    // Créer ou mettre à jour le contenu
    const existingContent = await this.prisma.groupReportContent.findUnique({
      where: {
        projectReportId_sectionId_groupId: {
          projectReportId: section.projectReportId,
          sectionId,
          groupId,
        },
      },
    });

    if (existingContent) {
      return this.prisma.groupReportContent.update({
        where: { id: existingContent.id },
        data: {
          content: dto.content,
          lastModifiedBy: userId,
          lastModified: new Date(),
        },
      });
    } else {
      return this.prisma.groupReportContent.create({
        data: {
          projectReportId: section.projectReportId,
          sectionId,
          groupId,
          content: dto.content,
          lastModifiedBy: userId,
          lastModified: new Date(),
        },
      });
    }
  }

  async getGroupReport(
    groupId: string,
    userId: string,
  ): Promise<GroupReportViewDto> {
    // Vérifier que l'utilisateur est membre du groupe
    const groupMember = await this.prisma.groupMember.findFirst({
      where: { groupId, userId },
    });

    if (!groupMember) {
      throw new ForbiddenException("Vous n'êtes pas membre de ce groupe");
    }

    // Récupérer le groupe avec le projet et le rapport
    const group = await this.prisma.group.findUnique({
      where: { id: groupId },
      include: {
        project: {
          include: {
            report: {
              include: {
                sections: {
                  orderBy: { order: 'asc' },
                },
              },
            },
          },
        },
      },
    });

    if (!group || !group.project.report) {
      throw new NotFoundException(
        'Groupe non trouvé ou aucun rapport pour ce projet',
      );
    }

    const report = group.project.report;

    // Récupérer le contenu existant pour chaque section
    const contents = await this.prisma.groupReportContent.findMany({
      where: {
        projectReportId: report.id,
        groupId,
      },
      include: {
        lastEditor: {
          select: { firstname: true, lastname: true },
        },
      },
    });

    // Construire la réponse
    const sections = report.sections.map((section) => {
      const content = contents.find((c) => c.sectionId === section.id);
      return {
        id: section.id,
        title: section.title,
        description: section.description,
        order: section.order,
        content: content?.content || '',
        status: content?.status || 'draft',
        lastModifiedBy: content?.lastEditor
          ? `${content.lastEditor.firstname} ${content.lastEditor.lastname}`
          : undefined,
        lastModified: content?.lastModified || new Date(),
      };
    });

    const completedSections = sections.filter(
      (s) => s.status === 'completed',
    ).length;
    const totalSections = sections.length;

    return {
      reportId: report.id,
      reportTitle: report.title,
      reportDescription: report.description,
      groupId: group.id,
      groupName: group.name,
      sections,
      progressPercentage:
        totalSections > 0 ? (completedSections / totalSections) * 100 : 0,
      completedSections,
      totalSections,
    };
  }

  async submitReport(groupId: string, userId: string) {
    // Vérifier que l'utilisateur est membre du groupe
    const groupMember = await this.prisma.groupMember.findFirst({
      where: { groupId, userId },
    });

    if (!groupMember) {
      throw new ForbiddenException("Vous n'êtes pas membre de ce groupe");
    }

    // Récupérer toutes les sections du rapport pour ce groupe
    const group = await this.prisma.group.findUnique({
      where: { id: groupId },
      include: {
        project: {
          include: {
            report: {
              include: {
                sections: true,
              },
            },
          },
        },
      },
    });

    if (!group || !group.project.report) {
      throw new NotFoundException(
        'Groupe non trouvé ou aucun rapport pour ce projet',
      );
    }

    const report = group.project.report;
    const sections = report.sections;

    // Vérifier que toutes les sections ont du contenu
    const contents = await this.prisma.groupReportContent.findMany({
      where: {
        projectReportId: report.id,
        groupId,
      },
    });

    // Vérifier que chaque section a du contenu non vide
    for (const section of sections) {
      const content = contents.find((c) => c.sectionId === section.id);
      if (!content || content.content.trim().length === 0) {
        throw new BadRequestException(
          `La section "${section.title}" est vide. Toutes les sections doivent être remplies avant soumission.`,
        );
      }
    }

    // Marquer toutes les sections comme completed
    const updatePromises = contents.map((content) =>
      this.prisma.groupReportContent.update({
        where: { id: content.id },
        data: {
          status: 'completed',
          lastModifiedBy: userId,
          lastModified: new Date(),
        },
      }),
    );

    await Promise.all(updatePromises);

    return { message: 'Rapport soumis avec succès' };
  }

  async getReportsOverview(
    projectId: string,
    userId: string,
  ): Promise<ReportsOverviewDto> {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
      include: {
        report: {
          include: {
            sections: {
              orderBy: { order: 'asc' },
            },
          },
        },
        groups: {
          include: {
            members: {
              include: {
                user: {
                  select: { firstname: true, lastname: true },
                },
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    if (!project.report) {
      throw new NotFoundException('Aucun rapport pour ce projet');
    }

    const report = project.report;
    const totalSections = report.sections.length;

    // Pour chaque groupe, calculer le progrès
    const groupsOverview = await Promise.all(
      project.groups.map(async (group) => {
        const contents = await this.prisma.groupReportContent.findMany({
          where: {
            projectReportId: report.id,
            groupId: group.id,
          },
        });

        const completedSections = contents.filter(
          (c) => c.status === 'completed',
        ).length;
        const progressPercentage =
          totalSections > 0 ? (completedSections / totalSections) * 100 : 0;
        const isSubmitted =
          completedSections === totalSections && totalSections > 0;

        const lastModified =
          contents.length > 0
            ? new Date(
                Math.max(...contents.map((c) => c.lastModified.getTime())),
              )
            : group.createdAt;

        const submittedAt = isSubmitted ? lastModified : undefined;

        return {
          groupId: group.id,
          groupName: group.name,
          memberNames: group.members.map(
            (m) => `${m.user.firstname} ${m.user.lastname}`,
          ),
          progressPercentage,
          completedSections,
          totalSections,
          isSubmitted,
          lastModified,
          submittedAt,
        };
      }),
    );

    const averageProgress =
      groupsOverview.length > 0
        ? groupsOverview.reduce((sum, g) => sum + g.progressPercentage, 0) /
          groupsOverview.length
        : 0;

    const submittedGroups = groupsOverview.filter((g) => g.isSubmitted).length;

    return {
      reportId: report.id,
      reportTitle: report.title,
      reportDescription: report.description,
      projectId: project.id,
      projectName: project.name,
      groups: groupsOverview,
      averageProgress,
      submittedGroups,
      totalGroups: groupsOverview.length,
    };
  }

  async getFullGroupReport(projectId: string, groupId: string, userId: string) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    // Récupérer le rapport complet du groupe
    const group = await this.prisma.group.findFirst({
      where: { id: groupId, projectId },
      include: {
        members: {
          include: {
            user: {
              select: { firstname: true, lastname: true },
            },
          },
        },
      },
    });

    if (!group) {
      throw new NotFoundException('Groupe non trouvé dans ce projet');
    }

    const report = await this.prisma.projectReport.findUnique({
      where: { projectId },
      include: {
        sections: {
          orderBy: { order: 'asc' },
        },
      },
    });

    if (!report) {
      throw new NotFoundException('Aucun rapport trouvé pour ce projet');
    }

    // Récupérer le contenu pour toutes les sections
    const contents = await this.prisma.groupReportContent.findMany({
      where: {
        projectReportId: report.id,
        groupId,
      },
      include: {
        lastEditor: {
          select: { firstname: true, lastname: true },
        },
      },
    });

    const sectionsWithContent = report.sections.map((section) => {
      const content = contents.find((c) => c.sectionId === section.id);
      return {
        id: section.id,
        title: section.title,
        description: section.description,
        order: section.order,
        content: content?.content || '',
        status: content?.status || 'draft',
        lastModifiedBy: content?.lastEditor
          ? `${content.lastEditor.firstname} ${content.lastEditor.lastname}`
          : undefined,
        lastModified: content?.lastModified || new Date(),
      };
    });

    return {
      reportId: report.id,
      reportTitle: report.title,
      reportDescription: report.description,
      groupId: group.id,
      groupName: group.name,
      members: group.members.map(
        (m) => `${m.user.firstname} ${m.user.lastname}`,
      ),
      sections: sectionsWithContent,
    };
  }

  /**
   * Récupère tous les rapports accessibles pour un étudiant
   */
  async getStudentReports(studentId: string) {
    console.log(`[DEBUG] getStudentReports - studentId: ${studentId}`);
    
    // Vérifier que l'étudiant appartient à une promotion
    const studentPromotion = await this.prisma.studentPromotion.findFirst({
      where: { userId: studentId },
      include: { promotion: true },
    });

    if (!studentPromotion) {
      console.log(`[DEBUG] Aucune promotion trouvée pour l'étudiant ${studentId}`);
      throw new NotFoundException('Vous devez être assigné à une promotion pour voir les rapports');
    }

    // Récupérer tous les groupes auxquels appartient l'étudiant
    const studentGroups = await this.prisma.groupMember.findMany({
      where: { userId: studentId },
      include: {
        group: {
          include: {
            project: {
              include: {
                teacher: { select: { firstname: true, lastname: true } },
                promotion: { select: { name: true } }
              }
            },
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } }
              }
            }
          }
        }
      }
    });

    if (studentGroups.length === 0) {
      console.log(`[DEBUG] Aucun groupe trouvé pour l'étudiant ${studentId}`);
      return [];
    }

    // Filtrer les projets visibles et avec rapports activés
    const reports = [];
    for (const studentGroup of studentGroups) {
      const { group } = studentGroup;
      
      // Vérifier que le projet est visible et a des rapports activés
      if (group.project.status === 'VISIBLE' && group.project.enableReports) {
        // Récupérer les sections du rapport pour ce projet
        const sections = await this.prisma.reportSection.findMany({
          where: { projectId: group.project.id },
          orderBy: { order: 'asc' }
        });

        reports.push({
          id: `report_${group.project.id}_${group.id}`,
          projectId: group.project.id,
          projectName: group.project.name,
          groupId: group.id,
          groupName: group.name,
          teacher: group.project.teacher,
          promotion: group.project.promotion,
          members: group.members.map(m => ({
            firstname: m.user.firstname,
            lastname: m.user.lastname
          })),
          sectionsCount: sections.length,
          hasContent: sections.length > 0
        });
      }
    }

    console.log(`[DEBUG] ${reports.length} rapports trouvés pour l'étudiant`);
    return reports;
  }

  /**
   * Récupère un rapport spécifique pour un étudiant avec vérifications d'accès
   */
  async getReportForStudent(reportId: string, studentId: string) {
    console.log(`[DEBUG] getReportForStudent - reportId: ${reportId}, studentId: ${studentId}`);
    
    // Extraire les IDs du reportId (format: report_projectId_groupId)
    const [, projectId, groupId] = reportId.split('_');
    
    if (!projectId || !groupId) {
      throw new BadRequestException('Format d\'ID de rapport invalide');
    }

    // Vérifier que l'étudiant fait partie du groupe
    const groupMember = await this.prisma.groupMember.findFirst({
      where: { groupId, userId: studentId },
      include: {
        group: {
          include: {
            project: {
              include: {
                teacher: { select: { firstname: true, lastname: true } },
                promotion: { select: { name: true } }
              }
            },
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } }
              }
            }
          }
        }
      }
    });

    if (!groupMember) {
      console.log(`[DEBUG] L'étudiant ${studentId} ne fait pas partie du groupe ${groupId}`);
      throw new ForbiddenException('Vous n\'avez pas accès à ce rapport car vous ne faites pas partie de ce groupe');
    }

    // Vérifier que le projet est visible et a les rapports activés
    if (groupMember.group.project.status !== 'VISIBLE') {
      console.log(`[DEBUG] Projet non visible - statut: ${groupMember.group.project.status}`);
      throw new ForbiddenException('Ce rapport n\'est pas encore visible pour les étudiants');
    }

    if (!groupMember.group.project.enableReports) {
      console.log(`[DEBUG] Rapports désactivés pour le projet ${projectId}`);
      throw new ForbiddenException('Les rapports ne sont pas activés pour ce projet');
    }

    // Récupérer le contenu du rapport (réutilise la méthode existante)
    const reportContent = await this.getGroupReport(groupId, studentId);

    console.log(`[DEBUG] Accès autorisé au rapport ${reportId}`);
    return {
      id: reportId,
      projectId,
      groupId,
      project: groupMember.group.project,
      group: {
        id: groupMember.group.id,
        name: groupMember.group.name,
        members: groupMember.group.members
      },
      ...reportContent
    };
  }
}
