import {
  Injectable,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateProjectReportDto, UpdateProjectReportDto } from '../dto';

@Injectable()
export class ProjectReportService {
  constructor(private prisma: PrismaService) {}

  async createReport(
    projectId: string,
    userId: string,
    dto: CreateProjectReportDto,
  ) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    // Vérifier qu'il n'y a pas déjà un rapport pour ce projet
    const existingReport = await this.prisma.projectReport.findUnique({
      where: { projectId },
    });

    if (existingReport) {
      throw new ConflictException('Un rapport existe déjà pour ce projet');
    }

    return this.prisma.projectReport.create({
      data: {
        projectId,
        ...dto,
      },
      include: {
        sections: {
          orderBy: { order: 'asc' },
        },
      },
    });
  }

  async updateReport(
    projectId: string,
    userId: string,
    dto: UpdateProjectReportDto,
  ) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    const report = await this.prisma.projectReport.findUnique({
      where: { projectId },
    });

    if (!report) {
      throw new NotFoundException('Aucun rapport trouvé pour ce projet');
    }

    return this.prisma.projectReport.update({
      where: { id: report.id },
      data: dto,
      include: {
        sections: {
          orderBy: { order: 'asc' },
        },
      },
    });
  }

  async deleteReport(projectId: string, userId: string) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    const report = await this.prisma.projectReport.findUnique({
      where: { projectId },
    });

    if (!report) {
      throw new NotFoundException('Aucun rapport trouvé pour ce projet');
    }

    // Supprimer le rapport
    return this.prisma.projectReport.delete({
      where: { id: report.id },
    });
  }

  async getReport(projectId: string, userId: string) {
    // Vérifier que l'utilisateur est propriétaire du projet
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });

    if (!project) {
      throw new NotFoundException(
        "Projet non trouvé ou vous n'avez pas les permissions",
      );
    }

    const report = await this.prisma.projectReport.findUnique({
      where: { projectId },
      include: {
        sections: {
          orderBy: { order: 'asc' },
        },
      },
    });

    if (!report) {
      throw new NotFoundException('Aucun rapport trouvé pour ce projet');
    }

    return report;
  }

  async checkReportExists(projectId: string): Promise<boolean> {
    const report = await this.prisma.projectReport.findUnique({
      where: { projectId },
    });

    return report !== null;
  }
}
