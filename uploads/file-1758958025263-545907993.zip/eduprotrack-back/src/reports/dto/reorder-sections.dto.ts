import { IsArray, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class ReorderSectionsDto {
  @ApiProperty({
    description: 'Liste ordonnée des IDs de sections',
    example: ['section1', 'section3', 'section2'],
    type: [String],
  })
  @IsArray()
  @IsString({ each: true })
  sectionIds: string[];
}
