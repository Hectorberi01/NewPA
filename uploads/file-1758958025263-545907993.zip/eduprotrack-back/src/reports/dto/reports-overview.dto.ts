import { ApiProperty } from '@nestjs/swagger';

export class GroupReportOverviewDto {
  @ApiProperty()
  groupId: string;

  @ApiProperty()
  groupName: string;

  @ApiProperty({ type: [String] })
  memberNames: string[];

  @ApiProperty({
    description: 'Pourcentage de sections complétées',
    example: 66.7,
  })
  progressPercentage: number;

  @ApiProperty({
    description: 'Nombre de sections complétées',
    example: 2,
  })
  completedSections: number;

  @ApiProperty({
    description: 'Nombre total de sections',
    example: 3,
  })
  totalSections: number;

  @ApiProperty({
    description: 'Toutes les sections sont-elles soumises (completed)',
    example: false,
  })
  isSubmitted: boolean;

  @ApiProperty({
    description: 'Date de dernière modification',
    example: '2024-01-15T10:30:00.000Z',
  })
  lastModified: Date;

  @ApiProperty({
    description: 'Date de soumission (si soumis)',
    required: false,
  })
  submittedAt?: Date;
}

export class ReportsOverviewDto {
  @ApiProperty()
  reportId: string;

  @ApiProperty()
  reportTitle: string;

  @ApiProperty({ required: false })
  reportDescription?: string;

  @ApiProperty()
  projectId: string;

  @ApiProperty()
  projectName: string;

  @ApiProperty({ type: [GroupReportOverviewDto] })
  groups: GroupReportOverviewDto[];

  @ApiProperty({
    description: 'Pourcentage moyen de progression de tous les groupes',
    example: 45.5,
  })
  averageProgress: number;

  @ApiProperty({
    description: 'Nombre de groupes ayant soumis leur rapport',
    example: 3,
  })
  submittedGroups: number;

  @ApiProperty({
    description: 'Nombre total de groupes',
    example: 8,
  })
  totalGroups: number;
}
