import { IsString, IsOptional, IsInt, Min } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class UpdateReportSectionDto {
  @ApiPropertyOptional({
    description: 'Titre de la section',
    example: 'Introduction',
  })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional({
    description: 'Description ou consignes pour la section',
    example: 'Présentez le contexte et les objectifs de votre projet',
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({
    description: "Ordre d'affichage de la section (commence à 1)",
    example: 1,
  })
  @IsOptional()
  @IsInt()
  @Min(1)
  order?: number;
}
