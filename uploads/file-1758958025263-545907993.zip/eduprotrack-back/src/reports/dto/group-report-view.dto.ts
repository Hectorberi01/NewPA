import { ApiProperty } from '@nestjs/swagger';

export class GroupReportSectionDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  title: string;

  @ApiProperty({ required: false })
  description?: string;

  @ApiProperty()
  order: number;

  @ApiProperty()
  content: string;

  @ApiProperty({ enum: ['draft', 'completed'] })
  status: string;

  @ApiProperty({ required: false })
  lastModifiedBy?: string;

  @ApiProperty()
  lastModified: Date;
}

export class GroupReportViewDto {
  @ApiProperty()
  reportId: string;

  @ApiProperty()
  reportTitle: string;

  @ApiProperty({ required: false })
  reportDescription?: string;

  @ApiProperty()
  groupId: string;

  @ApiProperty()
  groupName: string;

  @ApiProperty({ type: [GroupReportSectionDto] })
  sections: GroupReportSectionDto[];

  @ApiProperty({
    description: 'Pourcentage de sections complétées',
    example: 66.7,
  })
  progressPercentage: number;

  @ApiProperty({
    description: 'Nombre de sections complétées',
    example: 2,
  })
  completedSections: number;

  @ApiProperty({
    description: 'Nombre total de sections',
    example: 3,
  })
  totalSections: number;
}
