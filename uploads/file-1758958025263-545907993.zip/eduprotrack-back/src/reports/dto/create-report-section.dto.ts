import { IsString, IsOptional, IsInt, Min } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateReportSectionDto {
  @ApiProperty({
    description: 'Titre de la section',
    example: 'Introduction',
  })
  @IsString()
  title: string;

  @ApiPropertyOptional({
    description: 'Description ou consignes pour la section',
    example: 'Présentez le contexte et les objectifs de votre projet',
  })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({
    description: "Ordre d'affichage de la section (commence à 1)",
    example: 1,
  })
  @IsInt()
  @Min(1)
  order: number;
}
