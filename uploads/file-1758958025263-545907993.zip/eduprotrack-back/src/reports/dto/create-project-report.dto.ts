import { IsString, IsOptional } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateProjectReportDto {
  @ApiProperty({
    description: 'Titre du rapport',
    example: 'Rapport de projet - Développement mobile',
  })
  @IsString()
  title: string;

  @ApiPropertyOptional({
    description: 'Description optionnelle du rapport',
    example:
      'Ce rapport doit présenter votre travail de développement mobile en 3 parties principales.',
  })
  @IsOptional()
  @IsString()
  description?: string;
}
