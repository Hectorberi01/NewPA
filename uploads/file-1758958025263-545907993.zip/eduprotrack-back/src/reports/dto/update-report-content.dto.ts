import { IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateReportContentDto {
  @ApiProperty({
    description: 'Contenu HTML/Markdown de la section',
    example:
      '<h2>Introduction</h2><p>Notre projet consiste à développer une application mobile...</p>',
  })
  @IsString()
  content: string;
}
