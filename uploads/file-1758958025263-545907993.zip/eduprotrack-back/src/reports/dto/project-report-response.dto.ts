import { ApiProperty } from '@nestjs/swagger';

export class ProjectReportResponseDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  projectId: string;

  @ApiProperty()
  title: string;

  @ApiProperty({ required: false })
  description?: string;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;
}

export class ReportSectionResponseDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  projectReportId: string;

  @ApiProperty()
  title: string;

  @ApiProperty({ required: false })
  description?: string;

  @ApiProperty()
  order: number;

  @ApiProperty()
  createdAt: Date;

  @ApiProperty()
  updatedAt: Date;
}

export class GroupReportContentResponseDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  projectReportId: string;

  @ApiProperty()
  sectionId: string;

  @ApiProperty()
  groupId: string;

  @ApiProperty()
  content: string;

  @ApiProperty({ enum: ['draft', 'completed'] })
  status: string;

  @ApiProperty({ required: false })
  lastModifiedBy?: string;

  @ApiProperty()
  lastModified: Date;

  @ApiProperty()
  createdAt: Date;
}
