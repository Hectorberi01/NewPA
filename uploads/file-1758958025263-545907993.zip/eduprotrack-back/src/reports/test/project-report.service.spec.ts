import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, ConflictException } from '@nestjs/common';
import { ProjectReportService } from '../services/project-report.service';
import { PrismaService } from '../../prisma/prisma.service';

describe('ProjectReportService', () => {
  let service: ProjectReportService;
  let prisma: PrismaService;

  const mockPrismaService = {
    project: {
      findFirst: jest.fn(),
    },
    projectReport: {
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
    },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ProjectReportService,
        {
          provide: PrismaService,
          useValue: mockPrismaService,
        },
      ],
    }).compile();

    service = module.get<ProjectReportService>(ProjectReportService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('createReport', () => {
    const projectId = 'project-1';
    const userId = 'user-1';
    const createDto = {
      title: 'Test Report',
      description: 'Test Description',
      isEnabled: true,
    };

    it('should create a report successfully', async () => {
      const mockProject = { id: projectId, userId };
      const mockReport = {
        id: 'report-1',
        projectId,
        ...createDto,
        createdAt: new Date(),
        updatedAt: new Date(),
        sections: [],
      };

      mockPrismaService.project.findFirst.mockResolvedValue(mockProject);
      mockPrismaService.projectReport.findUnique.mockResolvedValue(null);
      mockPrismaService.projectReport.create.mockResolvedValue(mockReport);

      const result = await service.createReport(projectId, userId, createDto);

      expect(result).toEqual(mockReport);
      expect(mockPrismaService.project.findFirst).toHaveBeenCalledWith({
        where: { id: projectId, userId },
      });
      expect(mockPrismaService.projectReport.findUnique).toHaveBeenCalledWith({
        where: { projectId },
      });
      expect(mockPrismaService.projectReport.create).toHaveBeenCalledWith({
        data: { projectId, ...createDto },
        include: { sections: { orderBy: { order: 'asc' } } },
      });
    });

    it('should throw NotFoundException if project not found', async () => {
      mockPrismaService.project.findFirst.mockResolvedValue(null);

      await expect(
        service.createReport(projectId, userId, createDto),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw ConflictException if report already exists', async () => {
      const mockProject = { id: projectId, userId };
      const existingReport = { id: 'existing-report' };

      mockPrismaService.project.findFirst.mockResolvedValue(mockProject);
      mockPrismaService.projectReport.findUnique.mockResolvedValue(
        existingReport,
      );

      await expect(
        service.createReport(projectId, userId, createDto),
      ).rejects.toThrow(ConflictException);
    });
  });

  describe('updateReport', () => {
    const projectId = 'project-1';
    const userId = 'user-1';
    const updateDto = { title: 'Updated Title' };

    it('should update a report successfully', async () => {
      const mockProject = { id: projectId, userId };
      const mockExistingReport = { id: 'report-1', projectId };
      const mockUpdatedReport = {
        ...mockExistingReport,
        ...updateDto,
        sections: [],
      };

      mockPrismaService.project.findFirst.mockResolvedValue(mockProject);
      mockPrismaService.projectReport.findUnique.mockResolvedValue(
        mockExistingReport,
      );
      mockPrismaService.projectReport.update.mockResolvedValue(
        mockUpdatedReport,
      );

      const result = await service.updateReport(projectId, userId, updateDto);

      expect(result).toEqual(mockUpdatedReport);
      expect(mockPrismaService.projectReport.update).toHaveBeenCalledWith({
        where: { id: mockExistingReport.id },
        data: updateDto,
        include: { sections: { orderBy: { order: 'asc' } } },
      });
    });

    it('should throw NotFoundException if project not found', async () => {
      mockPrismaService.project.findFirst.mockResolvedValue(null);

      await expect(
        service.updateReport(projectId, userId, updateDto),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException if report not found', async () => {
      const mockProject = { id: projectId, userId };

      mockPrismaService.project.findFirst.mockResolvedValue(mockProject);
      mockPrismaService.projectReport.findUnique.mockResolvedValue(null);

      await expect(
        service.updateReport(projectId, userId, updateDto),
      ).rejects.toThrow(NotFoundException);
    });
  });

  describe('checkReportExists', () => {
    it('should return true if enabled report exists', async () => {
      const projectId = 'project-1';
      const mockReport = { id: 'report-1', isEnabled: true };

      mockPrismaService.projectReport.findUnique.mockResolvedValue(mockReport);

      const result = await service.checkReportExists(projectId);

      expect(result).toBe(true);
    });

    it('should return false if no report exists', async () => {
      const projectId = 'project-1';

      mockPrismaService.projectReport.findUnique.mockResolvedValue(null);

      const result = await service.checkReportExists(projectId);

      expect(result).toBe(false);
    });

    it('should return false if report exists but is disabled', async () => {
      const projectId = 'project-1';
      const mockReport = { id: 'report-1', isEnabled: false };

      mockPrismaService.projectReport.findUnique.mockResolvedValue(mockReport);

      const result = await service.checkReportExists(projectId);

      expect(result).toBe(false);
    });
  });
});
