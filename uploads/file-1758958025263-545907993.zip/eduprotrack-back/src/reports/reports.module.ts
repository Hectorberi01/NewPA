import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';

// Services
import { ProjectReportService } from './services/project-report.service';
import { ReportSectionService } from './services/report-section.service';
import { GroupReportContentService } from './services/group-report-content.service';

// Controllers
import { ProjectReportController } from './controllers/project-report.controller';
import { TeacherReportViewController } from './controllers/teacher-report-view.controller';
import { GroupReportController } from './controllers/group-report.controller';

@Module({
  imports: [PrismaModule],
  controllers: [
    ProjectReportController,
    TeacherReportViewController,
    GroupReportController,
  ],
  providers: [
    ProjectReportService,
    ReportSectionService,
    GroupReportContentService,
  ],
  exports: [
    ProjectReportService,
    ReportSectionService,
    GroupReportContentService,
  ],
})
export class ReportsModule {}
