import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { EvaluationType, CriterionScope } from '@prisma/client';

export class CreateEvaluationCriterionDto {
  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsNumber()
  @Min(0)
  maxPoints!: number;

  @IsNumber()
  @Min(0)
  @Max(100)
  weight!: number;

  @IsEnum(CriterionScope)
  @IsOptional()
  scope?: CriterionScope = CriterionScope.GROUP;

  @IsNumber()
  @Min(0)
  @IsOptional()
  order?: number = 0;
}

export class CreateEvaluationGridDto {
  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsString()
  @IsOptional()
  projectId?: string; // null if isTemplate = true

  @IsEnum(EvaluationType)
  type!: EvaluationType;

  @IsNumber()
  @Min(0)
  @Max(100)
  weight!: number;

  @IsBoolean()
  @IsOptional()
  isTemplate?: boolean = false;

  @IsString()
  @IsNotEmpty()
  createdById!: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateEvaluationCriterionDto)
  criteria!: CreateEvaluationCriterionDto[];
}

export interface ProjectEvaluationWeights {
  projectId: string;
  deliverableWeight?: number; // 0-100, si hasDeliverable
  reportWeight?: number; // 0-100, si hasReport
  defenseWeight?: number; // 0-100, si hasDefense
  totalWeight: number; // Doit être 100
}
