import { PartialType } from '@nestjs/mapped-types';
import { CreateEvaluationGridDto } from './create-evaluation-grid.dto';

export class UpdateEvaluationGridDto extends PartialType(
  CreateEvaluationGridDto,
) {}

export class DuplicateGridDto {
  @IsString()
  @IsNotEmpty()
  templateId!: string;

  @IsString()
  @IsNotEmpty()
  projectId!: string;

  @IsString()
  @IsOptional()
  name?: string; // New name for duplicated grid

  @IsNumber()
  @Min(0)
  @Max(100)
  @IsOptional()
  weight?: number; // New weight for project context
}

import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsNumber,
  Min,
  Max,
} from 'class-validator';
