import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
  CreateEvaluationGridDto,
  ProjectEvaluationWeights,
} from './dto/create-evaluation-grid.dto';
import {
  UpdateEvaluationGridDto,
  DuplicateGridDto,
} from './dto/update-evaluation-grid.dto';
import { EvaluationType } from '@prisma/client';

@Injectable()
export class EvaluationGridsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Create a new evaluation grid (template or project-specific)
   */
  async create(dto: CreateEvaluationGridDto) {
    // Validate criteria weights sum to 100%
    const totalCriteriaWeight = dto.criteria.reduce(
      (sum, criterion) => sum + criterion.weight,
      0,
    );

    if (Math.abs(totalCriteriaWeight - 100) > 0.01) {
      throw new BadRequestException(
        `Les poids des critères doivent totaliser 100% (actuellement: ${totalCriteriaWeight}%)`,
      );
    }

    // If not template, validate project exists and user has access
    if (!dto.isTemplate && dto.projectId) {
      const project = await this.prisma.project.findUnique({
        where: { id: dto.projectId },
      });

      if (!project) {
        throw new NotFoundException('Projet non trouvé');
      }

      if (project.userId !== dto.createdById) {
        throw new ForbiddenException(
          'Vous ne pouvez créer des grilles que pour vos propres projets',
        );
      }
    }

    return await this.prisma.evaluationGrid.create({
      data: {
        name: dto.name,
        projectId: dto.isTemplate ? null : dto.projectId,
        type: dto.type,
        weight: dto.weight,
        isTemplate: dto.isTemplate || false,
        criteria: {
          create: dto.criteria.map((criterion, index) => ({
            name: criterion.name,
            description: criterion.description,
            maxPoints: criterion.maxPoints,
            weight: criterion.weight,
            scope: criterion.scope,
            order: criterion.order || index,
          })),
        },
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
        project: {
          select: { id: true, name: true },
        },
      },
    });
  }

  /**
   * Get all templates available for use
   */
  async getTemplates(type?: EvaluationType) {
    return await this.prisma.evaluationGrid.findMany({
      where: {
        isTemplate: true,
        ...(type && { type }),
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
      },
      orderBy: [{ type: 'asc' }, { name: 'asc' }],
    });
  }

  /**
   * Get grids for a specific project
   */
  async getByProject(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    return await this.prisma.evaluationGrid.findMany({
      where: {
        projectId,
        isTemplate: false,
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
      },
      orderBy: { type: 'asc' },
    });
  }

  /**
   * Duplicate a template for use in a specific project
   */
  async duplicateTemplate(dto: DuplicateGridDto) {
    const template = await this.prisma.evaluationGrid.findUnique({
      where: { id: dto.templateId },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
      },
    });

    if (!template) {
      throw new NotFoundException('Template non trouvé');
    }

    if (!template.isTemplate) {
      throw new BadRequestException(
        'Seuls les templates peuvent être dupliqués',
      );
    }

    const project = await this.prisma.project.findUnique({
      where: { id: dto.projectId },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    return await this.prisma.evaluationGrid.create({
      data: {
        name: dto.name || `${template.name} (Copie)`,
        projectId: dto.projectId,
        type: template.type,
        weight: dto.weight || template.weight,
        isTemplate: false,
        criteria: {
          create: template.criteria.map((criterion) => ({
            name: criterion.name,
            description: criterion.description,
            maxPoints: criterion.maxPoints,
            weight: criterion.weight,
            scope: criterion.scope,
            order: criterion.order,
          })),
        },
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
        project: {
          select: { id: true, name: true },
        },
      },
    });
  }

  /**
   * Validate project evaluation weights total 100%
   */
  async validateProjectWeights(
    projectId: string,
  ): Promise<ProjectEvaluationWeights> {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        evaluationGrids: {
          where: { isTemplate: false },
        },
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    let deliverableWeight = 0;
    let reportWeight = 0;
    let defenseWeight = 0;

    project.evaluationGrids.forEach((grid) => {
      switch (grid.type) {
        case EvaluationType.DELIVERABLE:
          deliverableWeight += grid.weight;
          break;
        case EvaluationType.REPORT:
          reportWeight += grid.weight;
          break;
        case EvaluationType.DEFENSE:
          defenseWeight += grid.weight;
          break;
      }
    });

    const totalWeight = deliverableWeight + reportWeight + defenseWeight;

    return {
      projectId,
      deliverableWeight: deliverableWeight || undefined,
      reportWeight: reportWeight || undefined,
      defenseWeight: defenseWeight || undefined,
      totalWeight,
    };
  }

  /**
   * Update an evaluation grid
   */
  async update(id: string, dto: UpdateEvaluationGridDto, userId: string) {
    const grid = await this.prisma.evaluationGrid.findUnique({
      where: { id },
      include: { project: true },
    });

    if (!grid) {
      throw new NotFoundException('Grille non trouvée');
    }

    // Check permissions for project-specific grids

    if (!grid.isTemplate && grid.project?.userId !== userId) {
      throw new ForbiddenException(
        'Vous ne pouvez modifier que les grilles de vos propres projets',
      );
    }

    // Validate criteria weights if provided
    if (dto.criteria) {
      const totalCriteriaWeight = dto.criteria.reduce(
        (sum, criterion) => sum + criterion.weight,
        0,
      );

      if (Math.abs(totalCriteriaWeight - 100) > 0.01) {
        throw new BadRequestException(
          `Les poids des critères doivent totaliser 100% (actuellement: ${totalCriteriaWeight}%)`,
        );
      }
    }

    return await this.prisma.evaluationGrid.update({
      where: { id },
      data: {
        ...(dto.name && { name: dto.name }),
        ...(dto.weight !== undefined && { weight: dto.weight }),
        ...(dto.criteria && {
          criteria: {
            deleteMany: {}, // Remove existing criteria
            create: dto.criteria.map((criterion, index) => ({
              name: criterion.name,
              description: criterion.description,
              maxPoints: criterion.maxPoints,
              weight: criterion.weight,
              scope: criterion.scope,
              order: criterion.order || index,
            })),
          },
        }),
      },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
        project: {
          select: { id: true, name: true },
        },
      },
    });
  }

  /**
   * Delete an evaluation grid
   */
  async delete(id: string, userId: string) {
    const grid = await this.prisma.evaluationGrid.findUnique({
      where: { id },
      include: { project: true, evaluations: true },
    });

    if (!grid) {
      throw new NotFoundException('Grille non trouvée');
    }

    // Check permissions for project-specific grids

    if (!grid.isTemplate && grid.project?.userId !== userId) {
      throw new ForbiddenException(
        'Vous ne pouvez supprimer que les grilles de vos propres projets',
      );
    }

    // Check if grid has evaluations
    if (grid.evaluations.length > 0) {
      throw new BadRequestException(
        'Impossible de supprimer une grille contenant des évaluations',
      );
    }

    await this.prisma.evaluationGrid.delete({
      where: { id },
    });

    return { message: 'Grille supprimée avec succès' };
  }

  /**
   * Get a single evaluation grid by ID
   */
  async findById(id: string) {
    const grid = await this.prisma.evaluationGrid.findUnique({
      where: { id },
      include: {
        criteria: {
          orderBy: { order: 'asc' },
        },
        project: {
          select: { id: true, name: true },
        },
      },
    });

    if (!grid) {
      throw new NotFoundException('Grille non trouvée');
    }

    return grid;
  }
}
