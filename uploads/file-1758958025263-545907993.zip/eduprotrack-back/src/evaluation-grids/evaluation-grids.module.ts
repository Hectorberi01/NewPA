import { Module } from '@nestjs/common';
import { EvaluationGridsService } from './evaluation-grids.service';
import { EvaluationGridsController } from './evaluation-grids.controller';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [EvaluationGridsController],
  providers: [EvaluationGridsService],
  exports: [EvaluationGridsService],
})
export class EvaluationGridsModule {}
