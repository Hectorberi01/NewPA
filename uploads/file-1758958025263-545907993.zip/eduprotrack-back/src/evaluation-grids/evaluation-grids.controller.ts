import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  ValidationPipe,
} from '@nestjs/common';
import { EvaluationGridsService } from './evaluation-grids.service';
import { CreateEvaluationGridDto } from './dto/create-evaluation-grid.dto';
import {
  UpdateEvaluationGridDto,
  DuplicateGridDto,
} from './dto/update-evaluation-grid.dto';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../auth/guards/teacher.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { EvaluationType } from '@prisma/client';
import { ValidatedUser } from '../auth/types/auth.types';

@Controller('evaluation-grids')
@UseGuards(JWTAuthGuard, TeacherGuard)
export class EvaluationGridsController {
  constructor(
    private readonly evaluationGridsService: EvaluationGridsService,
  ) {}

  /**
   * Create a new evaluation grid (template or project-specific)
   */
  @Post()
  async create(
    @Body(ValidationPipe) createDto: CreateEvaluationGridDto,
    @CurrentUser() user: ValidatedUser,
  ) {
    return await this.evaluationGridsService.create({
      ...createDto,
      createdById: user.id,
    });
  }

  /**
   * Get all available templates
   */
  @Get('templates')
  async getTemplates(@Query('type') type?: EvaluationType) {
    return await this.evaluationGridsService.getTemplates(type);
  }

  /**
   * Get evaluation grids for a specific project
   */
  @Get('project/:projectId')
  async getByProject(@Param('projectId') projectId: string) {
    return await this.evaluationGridsService.getByProject(projectId);
  }

  /**
   * Validate project evaluation weights
   */
  @Get('project/:projectId/weights/validate')
  async validateProjectWeights(@Param('projectId') projectId: string) {
    return await this.evaluationGridsService.validateProjectWeights(projectId);
  }

  /**
   * Duplicate a template for use in a specific project
   */
  @Post('duplicate')
  async duplicateTemplate(
    @Body(ValidationPipe) duplicateDto: DuplicateGridDto,
  ) {
    return await this.evaluationGridsService.duplicateTemplate(duplicateDto);
  }

  /**
   * Get a single evaluation grid by ID
   */
  @Get(':id')
  async findById(@Param('id') id: string) {
    return await this.evaluationGridsService.findById(id);
  }

  /**
   * Update an evaluation grid
   */
  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body(ValidationPipe) updateDto: UpdateEvaluationGridDto,
    @CurrentUser() user: ValidatedUser,
  ) {
    return await this.evaluationGridsService.update(id, updateDto, user.id);
  }

  /**
   * Delete an evaluation grid
   */
  @Delete(':id')
  async delete(@Param('id') id: string, @CurrentUser() user: ValidatedUser) {
    return await this.evaluationGridsService.delete(id, user.id);
  }
}
