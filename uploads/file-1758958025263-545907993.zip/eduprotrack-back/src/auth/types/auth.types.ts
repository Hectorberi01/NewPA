import type { Request } from 'express';
import { Role } from '@prisma/client';

// =====================================================
// 🔐 GOOGLE OAUTH TYPES
// =====================================================

export interface GoogleProfile {
  id: string;
  displayName: string;
  name: {
    familyName: string;
    givenName: string;
  };
  emails: Array<{
    value: string;
    verified: boolean;
  }>;
  photos: Array<{
    value: string;
  }>;
  provider: 'google';
  _raw: string;
  _json: {
    sub: string;
    name: string;
    given_name: string;
    family_name: string;
    picture: string;
    email: string;
    email_verified: boolean;
    locale: string;
  };
}

// =====================================================
// 🔐 JWT PAYLOAD TYPES
// =====================================================

export interface JwtPayload {
  id: string; // user ID
  email: string;
  role: Role;
  firstname?: string;
  lastname?: string;
  iat?: number;
  exp?: number;
}

export interface ValidatedUser {
  id: string;
  email: string;
  role: Role;
  firstname: string;
  lastname: string;
}

// =====================================================
// 🔐 SSO USER TYPES (existing but exported)
// =====================================================

export interface SSOUser {
  email: string;
  role: Role;
  firstname: string;
  lastname: string;
  provider: 'azure' | 'google';
  picture?: string | null;
  accessToken?: string;
  refreshToken?: string;
}

// =====================================================
// 🔐 EXPRESS REQUEST TYPES (for Guards)
// =====================================================

export interface AuthenticatedRequest extends Request {
  user: ValidatedUser;
}

export interface VerifiedToken {
  email: string;
  name: string;
  given_name: string;
  family_name: string;
  upn?: string; // Azure specific
  email_verified?: boolean; // Google specific
}

// =====================================================
// 🔐 AZURE OAUTH TYPES
// =====================================================

export interface AzureOAuthParams {
  id_token: string;
  access_token: string;
  refresh_token: string;
  [key: string]: unknown;
}

export interface AzureTokenPayload {
  email?: string;
  upn?: string;
  family_name?: string;
  given_name?: string;
  name?: string;
  [key: string]: unknown;
}

export interface AzureProfile {
  id: string;
  displayName: string;
  [key: string]: unknown;
}

// =====================================================
// 🔐 GOOGLE OAUTH PROFILE EXTENDED
// =====================================================

export interface GoogleOAuthProfile {
  id: string;
  displayName: string;
  _json: {
    sub: string;
    name: string;
    given_name: string;
    family_name: string;
    picture: string;
    email: string;
    email_verified: boolean;
    locale: string;
  };
  [key: string]: unknown;
}

// =====================================================
// 🔐 EXPRESS REQUEST TYPES FOR MOBILE CALLBACKS
// =====================================================

export interface MobileAuthenticatedRequest extends Request {
  user: SSOUser;
}

// =====================================================
// 🔐 RESPONSE TYPES
// =====================================================

export interface MobileAuthResponse {
  redirect: (url: string) => void;
}
