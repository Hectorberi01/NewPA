import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';
import { UserService } from 'src/users/user.service';
import { Role } from '@prisma/client';
import { UserPasswordDto } from 'src/users/dto/user-password.dto';
import { compareSync } from 'bcryptjs';
import type { SSOUser, ValidatedUser } from './types/auth.types';

@Injectable()
export class AuthService {
  constructor(
    private readonly jwt: JwtService,
    private readonly userService: UserService,
    private readonly prisma: PrismaService,
  ) {}

  async validateOAuthLogin(user: SSOUser): Promise<{ token: string }> {
    let foundedUser = await this.prisma.user.findUnique({
      where: { email: user.email },
    });

    if (!foundedUser) {
      foundedUser = await this.userService.createTeacherUser({
        email: user.email,
        firstname: user.firstname,
        lastname: user.lastname,
        role: Role.TEACHER,
        accessToken: user.accessToken ?? null,
        refreshToken: user.refreshToken ?? null,
      });
    }

    const payload = {
      id: foundedUser.id,
      email: foundedUser.email,
      firstname: foundedUser.firstname,
      lastname: foundedUser.lastname,
      role: foundedUser.role,
    };

    const token = this.jwt.sign(payload, {
      expiresIn: process.env.JWT_EXPIRE_IN,
      secret: process.env.JWT_SECRET,
    });

    return { token };
  }

  async login(userPassword: UserPasswordDto): Promise<{ token: string }> {
    const { email, password } = userPassword;

    const foundedUser = await this.prisma.user.findUnique({
      where: { email: email },
    });

    if (!foundedUser) {
      throw new UnauthorizedException('Invalid credentials');
    }

    if (!foundedUser.password) {
      throw new UnauthorizedException(
        'Authentification par mot de passe non configurée',
      );
    }

    const isValidPassword = compareSync(password, foundedUser.password);

    console.log('Password validation:', isValidPassword);

    if (!isValidPassword) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const payload: ValidatedUser = {
      id: foundedUser.id,
      email: foundedUser.email,
      firstname: foundedUser.firstname,
      lastname: foundedUser.lastname,
      role: foundedUser.role,
    };

    const token = this.jwt.sign(payload, {
      expiresIn: process.env.JWT_EXPIRE_IN,
      secret: process.env.JWT_SECRET,
    });

    console.log('JWT token:', token);

    return { token };
  }
}
