import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { ValidatedUser } from '../types/auth.types';

export const CurrentUser = createParamDecorator(
  (data: unknown, ctx: ExecutionContext): ValidatedUser => {
    const request = ctx.switchToHttp().getRequest<{ user: ValidatedUser }>();
    return request.user;
  },
);
