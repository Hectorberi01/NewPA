import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-azure-ad-oauth2';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as jwt from 'jsonwebtoken';
import type {
  AzureOAuthParams,
  AzureTokenPayload,
  AzureProfile,
  SSOUser,
} from '../types/auth.types';
import { Role } from '@prisma/client';

@Injectable()
export class AzureMobileStrategy extends PassportStrategy(
  Strategy,
  'azure-mobile',
) {
  constructor(config: ConfigService) {
    super({
      clientID: config.get('AZURE_CLIENT_ID'),
      clientSecret: config.get('AZURE_CLIENT_SECRET'),
      callbackURL: config.get('AZURE_MOBILE_CALLBACK_URL'),
      tenant: config.get('AZURE_TENANT_ID'),
      resource: 'https://graph.microsoft.com',
    });
  }

  validate(
    accessToken: string,
    refreshToken: string,
    params: AzureOAuthParams,
    _profile: AzureProfile,
  ): SSOUser {
    const decoded = jwt.decode(params.id_token) as AzureTokenPayload;

    if (!decoded) {
      throw new Error('Invalid Azure token');
    }

    const user: SSOUser = {
      email: decoded.email || decoded.upn || '',
      firstname: decoded.family_name || '',
      lastname: decoded.given_name || '',
      provider: 'azure' as const,
      role: Role.TEACHER,
      accessToken,
      refreshToken,
    };
    return user;
  }
}
