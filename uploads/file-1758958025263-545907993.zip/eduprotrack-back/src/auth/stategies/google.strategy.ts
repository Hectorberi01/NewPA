import { PassportStrategy } from '@nestjs/passport';
import { Strategy, VerifyCallback } from 'passport-google-oauth20';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type { GoogleProfile, SSOUser } from '../types/auth.types';
import { Role } from '@prisma/client';

@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor(_configService: ConfigService) {
    super({
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: process.env.GOOGLE_CALLBACK_URL,
      scope: ['email', 'profile'],
    });
  }

  async validate(
    accessToken: string,
    refreshToken: string,
    profile: GoogleProfile,
    done: VerifyCallback,
  ): Promise<void> {
    try {
      console.log('Google profile received:', profile);

      if (!profile._json?.email) {
        return done(new Error('Email manquant dans le profil Google'));
      }

      const user: SSOUser = {
        email: profile._json.email,
        firstname: profile._json.given_name || '',
        lastname: profile._json.family_name || '',
        provider: 'google',
        role: Role.TEACHER,
        picture: profile._json.picture || null,
        accessToken,
        refreshToken,
      };

      console.log('Google user validated:', user);

      // Ensure async operation is properly awaited
      await Promise.resolve();
      done(null, user);
    } catch (error) {
      console.error('Google validation error:', error);
      done(
        new Error(
          `Erreur lors de la validation du profil Google: ${
            error instanceof Error ? error.message : String(error)
          }`,
        ),
      );
    }
  }
}
