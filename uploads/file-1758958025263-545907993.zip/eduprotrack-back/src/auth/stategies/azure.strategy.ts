import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-azure-ad-oauth2';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as jwt from 'jsonwebtoken';
import type { SSOUser, VerifiedToken } from '../types/auth.types';
import { Role } from '@prisma/client';

@Injectable()
export class AzureStrategy extends PassportStrategy(Strategy, 'azure') {
  constructor(_config: ConfigService) {
    super({
      clientID: process.env.AZURE_CLIENT_ID,
      clientSecret: process.env.AZURE_CLIENT_SECRET,
      callbackURL: process.env.AZURE_CALLBACK_URL,
      tenant: process.env.AZURE_TENANT_ID,
      resource: 'https://graph.microsoft.com',
    });
  }

  validate(
    accessToken: string,
    refreshToken: string,
    params: { id_token: string },
    _profile: unknown,
    done: (error: Error | null, user?: SSOUser) => void,
  ): void {
    try {
      console.log('Azure params received:', params);
      const decoded = jwt.decode(params.id_token) as VerifiedToken | null;
      console.log('Azure token decoded:', decoded);

      if (!decoded?.email && !decoded?.upn) {
        return done(new Error('Token Azure invalide ou email manquant'));
      }

      const user: SSOUser = {
        email: decoded.email ?? decoded.upn ?? '',
        firstname: decoded.given_name ?? '',
        lastname: decoded.family_name ?? '',
        role: Role.TEACHER, // Changé en TEACHER pour l'uniformité
        provider: 'azure',
        picture: null,
        accessToken,
        refreshToken,
      };

      console.log('Azure user validated:', user);
      done(null, user);
    } catch (error) {
      console.error('Azure validation error:', error);
      done(
        new Error(
          `Erreur lors du décodage du token Azure: ${
            error instanceof Error ? error.message : String(error)
          }`,
        ),
      );
    }
  }
}
