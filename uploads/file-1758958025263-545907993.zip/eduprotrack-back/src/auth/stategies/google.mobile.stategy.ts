import { PassportStrategy } from '@nestjs/passport';
import { Strategy, VerifyCallback } from 'passport-google-oauth20';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type { GoogleOAuthProfile, SSOUser } from '../types/auth.types';
import { Role } from '@prisma/client';

@Injectable()
export class GoogleMobileStrategy extends PassportStrategy(
  Strategy,
  'google-mobile',
) {
  constructor(configService: ConfigService) {
    super({
      clientID: configService.get('GOOGLE_CLIENT_ID'),
      clientSecret: configService.get('GOOGLE_CLIENT_SECRET'),
      callbackURL: configService.get('GOOGLE_MOBILE_CALLBACK_URL'),
      scope: ['email', 'profile'],
    });
  }

  validate(
    accessToken: string,
    refreshToken: string,
    profile: GoogleOAuthProfile,
    done: VerifyCallback,
  ): void {
    const user: SSOUser = {
      email: profile._json.email,
      firstname: profile._json.family_name, // nom
      lastname: profile._json.given_name, // prénom
      picture: profile._json.picture,
      provider: 'google' as const,
      role: Role.TEACHER,
      accessToken,
      refreshToken,
    };

    done(null, user);
  }
}
