import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { GoogleStrategy } from './stategies/google.strategy';
import { JwtStrategy } from './stategies/jwt.strategy';
import { UserModule } from 'src/users/user.module';
import { AzureStrategy } from './stategies/azure.strategy';
import { GoogleMobileStrategy } from './stategies/google.mobile.stategy';
import { AzureMobileStrategy } from './stategies/azure.mobile.stategy';

@Module({
  imports: [UserModule],
  controllers: [AuthController],
  providers: [
    AuthService,
    GoogleStrategy,
    AzureStrategy,
    JwtStrategy,
    GoogleMobileStrategy,
    AzureMobileStrategy,
  ],
})
export class AuthModule {}
