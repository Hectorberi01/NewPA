import {
  Body,
  Controller,
  Get,
  Post,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBody } from '@nestjs/swagger';
import type { Response } from 'express';
import { AuthService } from './auth.service';
import { AuthGuard } from '@nestjs/passport';
import { UserPasswordDtoValidation } from 'src/users/dto/user-password.dto';
import type {
  SSOUser,
  MobileAuthenticatedRequest,
  MobileAuthResponse,
} from './types/auth.types';

interface AuthenticatedRequest {
  user: SSOUser;
}

@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Get('google')
  @UseGuards(AuthGuard('google'))
  @ApiOperation({ summary: 'Authentification Google OAuth2' })
  @ApiResponse({ status: 302, description: 'Redirection vers Google OAuth2' })
  async googleAuth() {}

  @Get('google/mobile')
  @UseGuards(AuthGuard('google-mobile'))
  async googleMobileAuth() {}

  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  @ApiOperation({ summary: 'Callback Google OAuth2' })
  @ApiResponse({
    status: 302,
    description: 'Redirection vers le frontend avec token ou erreur',
  })
  async googleAuthRedirect(
    @Req() req: AuthenticatedRequest,
    @Res() res: Response,
  ): Promise<void> {
    try {
      console.log('Google callback user:', req.user);
      const { token } = await this.authService.validateOAuthLogin(req.user);
      res.redirect(`${process.env.FRONTEND_APP_URL}/teacher?token=${token}`);
    } catch (error) {
      console.error('Google callback error:', error);
      const frontendUrl =
        process.env.FRONTEND_APP_URL || 'http://localhost:3000';
      res.redirect(
        `${frontendUrl}/auth/error?message=${encodeURIComponent("Erreur d'authentification Google")}`,
      );
    }
  }

  @Get('google/mobile-callback')
  @UseGuards(AuthGuard('google-mobile'))
  async googleMobileCallback(
    @Req() req: MobileAuthenticatedRequest,
    @Res() res: Response & MobileAuthResponse,
  ): Promise<void> {
    const { token } = await this.authService.validateOAuthLogin(req.user);
    res.redirect(`eduprotrack://callback?token=${token}`);
  }

  @Get('azure')
  @UseGuards(AuthGuard('azure'))
  @ApiOperation({ summary: 'Authentification Azure OAuth2' })
  @ApiResponse({ status: 302, description: 'Redirection vers Azure OAuth2' })
  azureAuth() {}

  @Get('azure/mobile')
  @UseGuards(AuthGuard('azure-mobile'))
  async azureMobileAuth() {}

  @Get('azure/callback')
  @UseGuards(AuthGuard('azure'))
  @ApiOperation({ summary: 'Callback Azure OAuth2' })
  @ApiResponse({
    status: 302,
    description: 'Redirection vers le frontend avec token ou erreur',
  })
  async azureAuthRedirect(
    @Req() req: AuthenticatedRequest,
    @Res() res: Response,
  ): Promise<void> {
    try {
      console.log('Azure callback user:', req.user);
      const { token } = await this.authService.validateOAuthLogin(req.user);
      res.redirect(`${process.env.FRONTEND_APP_URL}/teacher?token=${token}`);
    } catch (error) {
      console.error('Azure callback error:', error);
      const frontendUrl =
        process.env.FRONTEND_APP_URL || 'http://localhost:4200';
      res.redirect(
        `${frontendUrl}/auth/error?message=${encodeURIComponent("Erreur d'authentification Azure")}`,
      );
    }
  }

  @Get('azure/mobile-callback')
  @UseGuards(AuthGuard('azure-mobile'))
  async azureMobileCallback(
    @Req() req: MobileAuthenticatedRequest,
    @Res() res: Response & MobileAuthResponse,
  ): Promise<void> {
    const { token } = await this.authService.validateOAuthLogin(req.user);
    res.redirect(`eduprotrack://callback?token=${token}`);
  }

  @Post('/student/login')
  @ApiOperation({ summary: 'Connexion étudiant avec email/mot de passe' })
  @ApiBody({ type: UserPasswordDtoValidation })
  @ApiResponse({ status: 200, description: 'Connexion réussie avec token JWT' })
  @ApiResponse({ status: 401, description: 'Identifiants invalides' })
  async login(@Body() body: UserPasswordDtoValidation) {
    console.log('Login attempt for:', body.email);
    return await this.authService.login(body);
  }
}
