import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { PlagiarismController } from './plagiarism.controller';
import { PlagiarismService } from './plagiarism.service';

@Module({
  imports: [HttpModule],
  controllers: [PlagiarismController],
  providers: [PlagiarismService],
  exports: [PlagiarismService],
})
export class PlagiarismModule {}
