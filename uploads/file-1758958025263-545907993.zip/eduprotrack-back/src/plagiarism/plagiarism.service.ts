import { Injectable, HttpException } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class PlagiarismService {
  constructor(private readonly httpService: HttpService) {}

  async checkPlagiarism(submissionIds: string[]) {
    if (!submissionIds || submissionIds.length < 2) {
      throw new HttpException('Au moins deux fichiers sont requis', 400);
    }

    const plagiarismServiceUrl =
      process.env.PLAGIARISM_SERVICE_URL || 'http://localhost:8000';

    try {
      const response = await firstValueFrom(
        this.httpService.post(
          `${plagiarismServiceUrl}/start_plagiarism_check`,
          {
            submission_ids: submissionIds,
          },
        ),
      );

      return response.data;
    } catch (error) {
      const msg =
        error?.response?.data?.detail || error.message || 'Erreur inconnue';
      throw new HttpException(
        `Erreur du service de plagiat : ${msg}`,
        error?.response?.status || 500,
      );
    }
  }
}
