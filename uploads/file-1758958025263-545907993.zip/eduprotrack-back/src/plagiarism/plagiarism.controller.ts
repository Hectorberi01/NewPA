import { Controller, Post, Body } from '@nestjs/common';
import { PlagiarismService } from './plagiarism.service';

@Controller('plagiarism')
export class PlagiarismController {
  constructor(private readonly plagiarismService: PlagiarismService) {}

  @Post('')
  async handlePlagiarism(@Body() body: { submissionIds: string[] }) {
    return this.plagiarismService.checkPlagiarism(body.submissionIds);
  }
}
