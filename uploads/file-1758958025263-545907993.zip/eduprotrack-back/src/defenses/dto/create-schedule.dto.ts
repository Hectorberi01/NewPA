import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsOptional,
  IsInt,
  Min,
  Max,
  IsString,
  ValidateNested,
  IsArray,
  ArrayMinSize,
} from 'class-validator';
import { Type } from 'class-transformer';

export class TimeSlotDto {
  @IsDateString()
  @ApiProperty({
    example: '2024-06-15T09:00:00Z',
    description: 'Heure de début du créneau',
  })
  startTime: string;

  @IsDateString()
  @ApiProperty({
    example: '2024-06-15T09:20:00Z',
    description: 'Heure de fin du créneau',
  })
  endTime: string;

  @IsString()
  @ApiProperty({
    example: 'group-123',
    description: 'ID du groupe assigné à ce créneau',
  })
  groupId: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'Salle 101',
    description: 'Lieu de la soutenance',
    required: false,
  })
  location?: string;
}

export class CreateScheduleDto {
  @IsDateString()
  @ApiProperty({
    example: '2024-06-15T09:00:00Z',
    description: 'Date et heure de début du planning',
  })
  startDateTime: string;

  @IsOptional()
  @IsInt()
  @Min(5)
  @Max(120)
  @ApiProperty({
    example: 20,
    description: 'Durée en minutes par groupe (5-120 min)',
    required: false,
  })
  durationPerGroup?: number;

  @IsOptional()
  @IsInt()
  @Min(0)
  @Max(60)
  @ApiProperty({
    example: 5,
    description: 'Pause en minutes entre groupes (0-60 min)',
    required: false,
  })
  breakBetweenGroups?: number;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'Salle 101',
    description: 'Lieu par défaut pour toutes les soutenances',
    required: false,
  })
  defaultLocation?: string;

  @IsOptional()
  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => TimeSlotDto)
  @ApiProperty({
    type: [TimeSlotDto],
    description: 'Créneaux manuels (alternatif au mode durée)',
    required: false,
  })
  timeSlots?: TimeSlotDto[];

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: '09:00',
    description: 'Heure de début des heures ouvrables',
    required: false,
  })
  workingHoursStart?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: '17:00',
    description: 'Heure de fin des heures ouvrables',
    required: false,
  })
  workingHoursEnd?: string;

  @IsOptional()
  @ApiProperty({
    example: true,
    description: 'Ignorer les weekends dans la planification',
    required: false,
    default: true,
  })
  skipWeekends?: boolean = true;
}
