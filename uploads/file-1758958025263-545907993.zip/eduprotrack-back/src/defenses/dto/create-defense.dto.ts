import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsDateString, IsOptional } from 'class-validator';

export class CreateDefenseDto {
  @IsString()
  @ApiProperty({
    example: 'Soutenance Projet Final',
    description: 'Titre de la soutenance',
  })
  title: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: "Soutenance des projets de fin d'année",
    description: 'Description de la soutenance',
    required: false,
  })
  description?: string;

  @IsDateString()
  @ApiProperty({
    example: '2024-06-15T09:00:00Z',
    description: 'Date et heure de début',
  })
  startDate: string;

  @IsDateString()
  @ApiProperty({
    example: '2024-06-15T17:00:00Z',
    description: 'Date et heure de fin',
  })
  endDate: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'Salle 101',
    description: 'Lieu de la soutenance',
    required: false,
  })
  location?: string;

  @IsString()
  @ApiProperty({
    example: 'promo-123',
    description: 'ID de la promotion concernée',
  })
  promotionId: string;
}
