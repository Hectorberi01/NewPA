import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsOptional,
  IsString,
  IsInt,
  Min,
} from 'class-validator';

export class UpdateSessionDto {
  @IsOptional()
  @IsDateString()
  @ApiProperty({
    example: '2024-06-15T10:00:00Z',
    description: 'Nouvelle heure de début',
    required: false,
  })
  startTime?: string;

  @IsOptional()
  @IsDateString()
  @ApiProperty({
    example: '2024-06-15T10:20:00Z',
    description: 'Nouvelle heure de fin',
    required: false,
  })
  endTime?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'Salle 102',
    description: 'Nouveau lieu de la soutenance',
    required: false,
  })
  location?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  @ApiProperty({
    example: 3,
    description: 'Nouvel ordre de passage',
    required: false,
  })
  order?: number;
}
