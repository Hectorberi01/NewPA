import { ApiProperty } from '@nestjs/swagger';
import { IsInt, Min, Max, IsOptional, IsString } from 'class-validator';

export class InsertBreakDto {
  @IsInt()
  @Min(0)
  @ApiProperty({
    example: 2,
    description:
      "Position d'insertion (après cette session - 0 = avant la première)",
    minimum: 0,
  })
  afterPosition: number;

  @IsInt()
  @Min(5)
  @Max(120)
  @ApiProperty({
    example: 30,
    description: 'Durée de la pause en minutes (5-120 min)',
    minimum: 5,
    maximum: 120,
  })
  duration: number;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'Pause déjeuner',
    description: 'Label descriptif de la pause',
    required: false,
  })
  label?: string;
}
