import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class SwapSessionsDto {
  @IsString()
  @ApiProperty({
    example: 'session-1',
    description: 'ID de la première session à échanger',
  })
  sessionId1: string;

  @IsString()
  @ApiProperty({
    example: 'session-2',
    description: 'ID de la seconde session à échanger',
  })
  sessionId2: string;
}
