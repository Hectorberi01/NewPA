import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  ArrayNotEmpty,
  IsString,
  IsOptional,
  IsBoolean,
} from 'class-validator';

export class ReorderSessionsDto {
  @IsArray()
  @ArrayNotEmpty()
  @IsString({ each: true })
  @ApiProperty({
    example: ['session-1', 'session-3', 'session-2'],
    description: 'Tableau des IDs de sessions dans le nouvel ordre',
    type: [String],
  })
  sessionIds: string[];

  @IsOptional()
  @IsBoolean()
  @ApiProperty({
    example: true,
    description: 'Recalculer automatiquement les horaires',
    default: true,
    required: false,
  })
  recalculateTimings?: boolean = true;
}
