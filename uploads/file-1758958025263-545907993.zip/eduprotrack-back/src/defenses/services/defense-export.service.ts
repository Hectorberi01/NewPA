import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import * as PDFDocument from 'pdfkit';
import {
  ProjectExportData,
  AttendanceData,
  ExportOptions,
  ExportDocument,
  ProjectWithDefenseSessions,
} from '../interfaces/defense.interfaces';

@Injectable()
export class DefenseExportService {
  constructor(private readonly prisma: PrismaService) {}

  async generateSchedulePDF(
    projectId: string,
    _options: ExportOptions = {},
  ): Promise<Buffer> {
    const projectData = await this.getProjectExportData(projectId);

    if (projectData.sessions.length === 0) {
      throw new NotFoundException(
        'Aucune session de soutenance trouvée pour ce projet',
      );
    }

    const title = 'Planning des Soutenances';
    const subtitle = `${projectData.project.name}\nEnseignant: ${projectData.project.teacher} - Promotion: ${projectData.project.promotion}`;
    const headers = ['#', 'Horaire', 'Groupe', 'Membres', 'Lieu'];

    const data = projectData.sessions.map((session) => ({
      order: session.order,
      horaire: `${this.formatTime(session.startTime)} - ${this.formatTime(session.endTime)}`,
      groupe: session.group.name,
      membres: session.group.members
        .map((m) => `${m.firstname} ${m.lastname}`)
        .join(', '),
      lieu: session.location || '-',
    }));

    return await this.generatePdfWithPDFKit(title, subtitle, data, headers);
  }

  async generateAttendanceSheetPDF(
    projectId: string,
    orderBy: 'groups' | 'alphabetical' = 'groups',
  ): Promise<Buffer> {
    const attendanceData = await this.getAttendanceData(projectId, orderBy);

    if (attendanceData.students.length === 0) {
      throw new NotFoundException('Aucun étudiant trouvé pour ce projet');
    }

    const title = "Liste d'Émargement";
    const subtitle = `${attendanceData.project.name}\nPromotion: ${attendanceData.project.promotion}\nOrdre: ${orderBy === 'groups' ? 'Par groupes' : 'Alphabétique'}`;
    const headers = ['Nom', 'Prénom', 'Groupe', 'Signature'];

    const data = attendanceData.students.map((student) => ({
      nom: student.lastname,
      prenom: student.firstname,
      groupe: student.groupName,
      signature: '________________________________',
    }));

    return await this.generatePdfWithPDFKit(title, subtitle, data, headers);
  }

  async generateBulkExport(
    projectId: string,
    includeDocuments: ExportDocument[] = [
      'schedule',
      'attendance-groups',
      'attendance-alphabetical',
    ],
  ): Promise<Buffer> {
    // Version simplifiée sans JSZip
    let content = 'Archive des documents de soutenance\n\n';

    if (includeDocuments.includes('schedule')) {
      const schedulePdf = await this.generateSchedulePDF(projectId);
      content +=
        'Planning des soutenances:\n' + schedulePdf.toString('utf-8') + '\n\n';
    }

    if (includeDocuments.includes('attendance-groups')) {
      const attendanceGroupsPdf = await this.generateAttendanceSheetPDF(
        projectId,
        'groups',
      );
      content +=
        'Émargement par groupes:\n' +
        attendanceGroupsPdf.toString('utf-8') +
        '\n\n';
    }

    if (includeDocuments.includes('attendance-alphabetical')) {
      const attendanceAlphaPdf = await this.generateAttendanceSheetPDF(
        projectId,
        'alphabetical',
      );
      content +=
        'Émargement alphabétique:\n' +
        attendanceAlphaPdf.toString('utf-8') +
        '\n\n';
    }

    return Buffer.from(content, 'utf-8');
  }

  private async getProjectExportData(
    projectId: string,
  ): Promise<ProjectExportData> {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        teacher: { select: { firstname: true, lastname: true } },
        promotion: { select: { name: true } },
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    // Récupérer les sessions de défense séparément
    const sessions = await this.prisma.defenseSession.findMany({
      where: { projectId },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
      },
      orderBy: { order: 'asc' },
    });

    return {
      project: {
        name: project.name,
        teacher: `${project.teacher.firstname} ${project.teacher.lastname}`,
        promotion: project.promotion.name,
      },
      sessions: sessions.map((session) => ({
        id: session.id,
        startTime: session.startTime,
        endTime: session.endTime,
        location: session.location,
        order: session.order,
        group: {
          name: session.group.name,
          members: session.group.members.map((member) => ({
            firstname: member.user.firstname,
            lastname: member.user.lastname,
          })),
        },
      })),
      generatedAt: new Date(),
    };
  }

  private async getAttendanceData(
    projectId: string,
    orderBy: 'groups' | 'alphabetical',
  ): Promise<AttendanceData> {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        promotion: { select: { name: true } },
        groups: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    let students = project.groups.flatMap((group) =>
      group.members.map((member) => ({
        firstname: member.user.firstname,
        lastname: member.user.lastname,
        groupName: group.name,
      })),
    );

    // Tri selon l'ordre demandé
    if (orderBy === 'alphabetical') {
      students = students.sort(
        (a, b) =>
          a.lastname.localeCompare(b.lastname) ||
          a.firstname.localeCompare(b.firstname),
      );
    } else {
      students = students.sort(
        (a, b) =>
          a.groupName.localeCompare(b.groupName) ||
          a.lastname.localeCompare(b.lastname),
      );
    }

    return {
      project: {
        name: project.name,
        promotion: project.promotion.name,
      },
      students,
      generatedAt: new Date(),
    };
  }

  private formatTime(date: Date): string {
    return date.toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  private formatDate(date: Date): string {
    return date.toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  // Nouvelles méthodes pour le contrôleur refactorisé
  async exportToPdf(defenseId: string): Promise<Buffer> {
    const defense = await this.prisma.project.findUnique({
      where: { id: defenseId },
      include: {
        defenseSessions: {
          include: {
            group: {
              include: {
                members: {
                  include: {
                    user: { select: { firstname: true, lastname: true } },
                  },
                },
              },
            },
          },
          orderBy: [{ order: 'asc' }, { startTime: 'asc' }],
        },
      },
    });

    if (!defense) {
      throw new NotFoundException('Projet non trouvé');
    }

    // Génération simple du contenu PDF (remplacer par Puppeteer plus tard)
    const content = this.generateHtmlContent(defense);

    // Pour l'instant, retourner le contenu HTML comme buffer
    // TODO: Utiliser Puppeteer pour générer un vrai PDF
    return Buffer.from(content, 'utf-8');
  }

  async exportToExcel(defenseId: string): Promise<Buffer> {
    const defense = await this.prisma.project.findUnique({
      where: { id: defenseId },
      include: {
        defenseSessions: {
          include: {
            group: {
              include: {
                members: {
                  include: {
                    user: { select: { firstname: true, lastname: true } },
                  },
                },
              },
            },
          },
          orderBy: [{ order: 'asc' }, { startTime: 'asc' }],
        },
      },
    });

    if (!defense) {
      throw new NotFoundException('Projet non trouvé');
    }

    // Génération simple du contenu Excel (remplacer par une vraie lib Excel plus tard)
    const csvContent = this.generateCsvContent(defense);

    // Pour l'instant, retourner du CSV comme buffer
    // TODO: Utiliser une librairie Excel pour générer un vrai fichier Excel
    return Buffer.from(csvContent, 'utf-8');
  }

  async exportToICS(defenseId: string): Promise<string> {
    const defense = await this.prisma.project.findUnique({
      where: { id: defenseId },
      include: {
        defenseSessions: {
          include: {
            group: {
              include: {
                members: {
                  include: {
                    user: { select: { firstname: true, lastname: true } },
                  },
                },
              },
            },
          },
          orderBy: [{ order: 'asc' }, { startTime: 'asc' }],
        },
      },
    });

    if (!defense) {
      throw new NotFoundException('Projet non trouvé');
    }

    return this.generateIcsContent(defense);
  }

  private generateHtmlContent(defense: ProjectWithDefenseSessions): string {
    const sessionsHtml = defense.defenseSessions
      .map((session) => {
        const groupName = session.group?.name || 'Pause';
        const members =
          session.group?.members
            ?.map((m) => `${m.user.firstname} ${m.user.lastname}`)
            .join(', ') || '';

        return `
        <tr>
          <td>${this.formatTime(session.startTime)} - ${this.formatTime(session.endTime)}</td>
          <td>${groupName}</td>
          <td>${members}</td>
          <td>${session.location || ''}</td>
        </tr>
      `;
      })
      .join('');

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Planning de soutenance - ${defense.title || defense.name}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          table { border-collapse: collapse; width: 100%; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f2f2f2; }
          h1 { color: #333; }
        </style>
      </head>
      <body>
        <h1>${defense.title || defense.name}</h1>
        <p><strong>Description:</strong> ${defense.description || 'N/A'}</p>
        <p><strong>Date:</strong> ${defense.startDate ? this.formatDate(defense.startDate) : 'N/A'} - ${defense.endDate ? this.formatDate(defense.endDate) : 'N/A'}</p>
        <p><strong>Lieu:</strong> ${defense.location || 'N/A'}</p>
        
        <h2>Sessions</h2>
        ${
          defense.defenseSessions.length > 0
            ? `
          <table>
            <thead>
              <tr>
                <th>Horaire</th>
                <th>Groupe</th>
                <th>Membres</th>
                <th>Lieu</th>
              </tr>
            </thead>
            <tbody>
              ${sessionsHtml}
            </tbody>
          </table>
        `
            : '<p>Aucune session planifiée</p>'
        }
      </body>
      </html>
    `;
  }

  private generateCsvContent(defense: ProjectWithDefenseSessions): string {
    const headers = 'Horaire,Groupe,Membres,Lieu\n';
    const rows = defense.defenseSessions
      .map((session) => {
        const groupName = session.group?.name || 'Pause';
        const members =
          session.group?.members
            ?.map((m) => `${m.user.firstname} ${m.user.lastname}`)
            .join('; ') || '';
        const timeRange = `${this.formatTime(session.startTime)} - ${this.formatTime(session.endTime)}`;

        return `"${timeRange}","${groupName}","${members}","${session.location || ''}"`;
      })
      .join('\n');

    return headers + rows;
  }

  private generateIcsContent(defense: ProjectWithDefenseSessions): string {
    const icsEvents = defense.defenseSessions
      .map((session) => {
        const groupName = session.group?.name || 'Pause';
        const members =
          session.group?.members
            ?.map((m) => `${m.user.firstname} ${m.user.lastname}`)
            .join(', ') || '';

        const startTime = this.formatICSDateTime(session.startTime);
        const endTime = this.formatICSDateTime(session.endTime);
        const summary = session.group
          ? `Soutenance - ${groupName}`
          : `Pause - ${session.label || 'Pause'}`;
        const description = session.group ? `Membres: ${members}` : '';

        return `BEGIN:VEVENT
DTSTART:${startTime}
DTEND:${endTime}
SUMMARY:${summary}
DESCRIPTION:${description}
LOCATION:${session.location || ''}
END:VEVENT`;
      })
      .join('\n');

    return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//EduProTrack//Defense Scheduling//EN
CALSCALE:GREGORIAN
${icsEvents}
END:VCALENDAR`;
  }

  /**
   * Génère un PDF à partir des données de défense en utilisant PDFKit
   */
  private async generatePdfWithPDFKit(
    title: string,
    subtitle: string,
    data: Record<string, unknown>[],
    headers: string[],
  ): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      try {
        const doc = new PDFDocument({
          size: 'A4',
          margins: { top: 50, bottom: 50, left: 50, right: 50 },
        });

        const buffers: Buffer[] = [];

        doc.on('data', (chunk) => buffers.push(chunk));
        doc.on('end', () => resolve(Buffer.concat(buffers)));
        doc.on('error', reject);

        // Header
        doc.fontSize(20).fillColor('#2563eb').text(title, { align: 'center' });

        doc.moveDown(0.5);

        doc
          .fontSize(16)
          .fillColor('#000000')
          .text(subtitle, { align: 'center' });

        doc.moveDown(1);

        // Date de génération
        doc
          .fontSize(10)
          .fillColor('#64748b')
          .text(`Document généré le ${this.formatDate(new Date())}`, {
            align: 'center',
          });

        doc.moveDown(2);

        // Tableau
        const startY = doc.y;
        const tableWidth = doc.page.width - 100;
        const colWidth = tableWidth / headers.length;

        // En-têtes du tableau
        doc.fillColor('#f1f5f9').rect(50, startY, tableWidth, 25).fill();

        doc.fillColor('#000000').fontSize(10).font('Helvetica-Bold');

        headers.forEach((header, i) => {
          doc.text(header, 55 + i * colWidth, startY + 8, {
            width: colWidth - 10,
            align: 'left',
          });
        });

        doc.font('Helvetica');

        // Lignes du tableau
        let currentY = startY + 25;
        data.forEach((row, rowIndex) => {
          const rowHeight = 25;

          // Alternance de couleur
          if (rowIndex % 2 === 0) {
            doc
              .fillColor('#f8fafc')
              .rect(50, currentY, tableWidth, rowHeight)
              .fill();
          }

          doc.fillColor('#000000');

          // Bordures
          doc
            .strokeColor('#e2e8f0')
            .rect(50, currentY, tableWidth, rowHeight)
            .stroke();

          // Contenu des cellules
          Object.values(row).forEach((cell: unknown, colIndex) => {
            doc.text(String(cell), 55 + colIndex * colWidth, currentY + 8, {
              width: colWidth - 10,
              height: rowHeight - 6,
              align: 'left',
              ellipsis: true,
            });
          });

          currentY += rowHeight;

          // Nouvelle page si nécessaire
          if (currentY > doc.page.height - 100) {
            doc.addPage();
            currentY = 50;
          }
        });

        doc.end();
      } catch (error) {
        reject(
          new Error(`Erreur lors de la génération du PDF: ${error.message}`),
        );
      }
    });
  }

  private formatICSDateTime(date: Date): string {
    return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  }
}
