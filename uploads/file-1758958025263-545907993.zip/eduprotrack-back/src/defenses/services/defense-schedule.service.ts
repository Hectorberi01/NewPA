import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import {
  DefenseSlot,
  ValidationResult,
  ScheduleConfig,
  ValidationError,
  ValidationWarning,
  DefenseSessionWithGroup,
  DefenseSession,
  PartialDefenseSession,
} from '../interfaces/defense.interfaces';
import { TimeSlotDto, CreateScheduleDto } from '../dto/create-schedule.dto';

@Injectable()
export class DefenseScheduleService {
  constructor(private readonly prisma: PrismaService) {}

  async calculateSlots(
    startDateTime: Date,
    groupIds: string[],
    config: ScheduleConfig,
    defaultLocation?: string,
  ): Promise<DefenseSessionWithGroup[]> {
    if (groupIds.length === 0) {
      throw new BadRequestException(
        'Aucun groupe fourni pour la planification',
      );
    }

    // Tri alphabétique des groupes pour ordre cohérent
    const sortedGroupIds = await this.sortGroupsAlphabetically(groupIds);

    const slots: DefenseSlot[] = [];
    let currentTime = new Date(startDateTime);

    for (let i = 0; i < sortedGroupIds.length; i++) {
      const groupId = sortedGroupIds[i];

      // Ajuster pour les contraintes horaires et weekends
      currentTime = this.adjustForConstraints(currentTime, config);

      const endTime = new Date(
        currentTime.getTime() + config.durationPerGroup * 60000,
      );

      slots.push({
        groupId,
        startTime: new Date(currentTime),
        endTime: new Date(endTime),
        order: i + 1,
        location: defaultLocation,
      });

      // Préparer l'heure de début de la session suivante (avec pause)
      currentTime = new Date(
        endTime.getTime() + config.breakBetweenGroups * 60000,
      );
    }

    // Créer les sessions en base
    const createdSessions = await this.createSessionsFromSlots(slots);

    return createdSessions;
  }

  async createFromTimeSlots(
    projectId: string,
    timeSlots: TimeSlotDto[],
    defaultLocation?: string,
  ): Promise<DefenseSessionWithGroup[]> {
    // Validation des créneaux manuels
    this.validateTimeSlots(timeSlots);

    const sessions = [];

    for (let i = 0; i < timeSlots.length; i++) {
      const slot = timeSlots[i];

      const session = await this.prisma.defenseSession.create({
        data: {
          projectId,
          groupId: slot.groupId,
          startTime: new Date(slot.startTime),
          endTime: new Date(slot.endTime),
          location: slot.location || defaultLocation,
          order: i + 1,
        },
        include: {
          group: {
            include: {
              members: {
                include: {
                  user: { select: { firstname: true, lastname: true } },
                },
              },
            },
          },
        },
      });

      sessions.push(session);
    }

    return sessions;
  }

  async validateSchedule(
    sessions: DefenseSessionWithGroup[] | DefenseSession[],
  ): Promise<ValidationResult> {
    const errors: ValidationError[] = [];
    const warnings: ValidationWarning[] = [];

    // Vérifier les chevauchements temporels
    const timeOverlaps = this.checkTimeOverlaps(sessions);
    errors.push(...timeOverlaps);

    // Vérifier l'ordre séquentiel
    const orderErrors = this.checkOrderConsistency(sessions);
    errors.push(...orderErrors);

    // Vérifier les weekends
    const weekendWarnings = this.checkWeekendSessions(sessions);
    warnings.push(...weekendWarnings);

    // Vérifier les heures ouvrables
    const hoursWarnings = this.checkWorkingHours(sessions);
    warnings.push(...hoursWarnings);

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      suggestions: this.generateSuggestions(errors, warnings),
    };
  }

  private async sortGroupsAlphabetically(
    groupIds: string[],
  ): Promise<string[]> {
    const groups = await this.prisma.group.findMany({
      where: { id: { in: groupIds } },
      select: { id: true, name: true },
      orderBy: { name: 'asc' },
    });

    return groups.map((g) => g.id);
  }

  private adjustForConstraints(time: Date, config: ScheduleConfig): Date {
    let adjustedTime = new Date(time);

    // Gestion des weekends
    if (config.skipWeekends) {
      while (adjustedTime.getDay() === 0 || adjustedTime.getDay() === 6) {
        // Si c'est le weekend, passer au lundi suivant à 9h
        const daysUntilMonday =
          adjustedTime.getDay() === 0 ? 1 : 8 - adjustedTime.getDay();
        adjustedTime.setDate(adjustedTime.getDate() + daysUntilMonday);
        adjustedTime.setHours(9, 0, 0, 0);
      }
    }

    // Gestion des heures ouvrables
    if (config.workingHours) {
      const [startHour, startMinute] = config.workingHours.start
        .split(':')
        .map(Number);
      const [endHour, endMinute] = config.workingHours.end
        .split(':')
        .map(Number);

      const currentHour = adjustedTime.getHours();
      const currentMinute = adjustedTime.getMinutes();
      const currentTotalMinutes = currentHour * 60 + currentMinute;
      const startTotalMinutes = startHour * 60 + startMinute;
      const endTotalMinutes = endHour * 60 + endMinute;

      // Si avant les heures ouvrables, reporter au début
      if (currentTotalMinutes < startTotalMinutes) {
        adjustedTime.setHours(startHour, startMinute, 0, 0);
      }
      // Si après les heures ouvrables, reporter au lendemain
      else if (currentTotalMinutes >= endTotalMinutes) {
        adjustedTime.setDate(adjustedTime.getDate() + 1);
        adjustedTime.setHours(startHour, startMinute, 0, 0);
        // Vérifier à nouveau les weekends
        adjustedTime = this.adjustForConstraints(adjustedTime, config);
      }
    }

    return adjustedTime;
  }

  private async createSessionsFromSlots(
    slots: DefenseSlot[],
  ): Promise<DefenseSessionWithGroup[]> {
    const sessions = [];

    for (const slot of slots) {
      const session = await this.prisma.defenseSession.create({
        data: {
          projectId: await this.getProjectIdFromGroup(slot.groupId),
          groupId: slot.groupId,
          startTime: slot.startTime,
          endTime: slot.endTime,
          location: slot.location,
          order: slot.order,
        },
        include: {
          group: {
            include: {
              members: {
                include: {
                  user: { select: { firstname: true, lastname: true } },
                },
              },
            },
          },
        },
      });

      sessions.push(session);
    }

    return sessions;
  }

  private async getProjectIdFromGroup(groupId: string): Promise<string> {
    const group = await this.prisma.group.findUnique({
      where: { id: groupId },
      select: { projectId: true },
    });

    if (!group) {
      throw new BadRequestException(`Groupe ${groupId} non trouvé`);
    }

    return group.projectId;
  }

  private validateTimeSlots(timeSlots: TimeSlotDto[]): void {
    for (let i = 0; i < timeSlots.length; i++) {
      const slot = timeSlots[i];
      const startTime = new Date(slot.startTime);
      const endTime = new Date(slot.endTime);

      if (startTime >= endTime) {
        throw new BadRequestException(
          `Créneau ${i + 1}: heure de début doit être antérieure à l'heure de fin`,
        );
      }

      // Vérifier les chevauchements
      for (let j = i + 1; j < timeSlots.length; j++) {
        const otherSlot = timeSlots[j];
        const otherStart = new Date(otherSlot.startTime);
        const otherEnd = new Date(otherSlot.endTime);

        if (this.timesOverlap(startTime, endTime, otherStart, otherEnd)) {
          throw new BadRequestException(
            `Chevauchement temporel entre créneaux ${i + 1} et ${j + 1}`,
          );
        }
      }
    }
  }

  private checkTimeOverlaps(
    sessions: DefenseSessionWithGroup[] | DefenseSession[],
  ): ValidationError[] {
    const errors: ValidationError[] = [];

    for (let i = 0; i < sessions.length; i++) {
      for (let j = i + 1; j < sessions.length; j++) {
        const session1 = sessions[i];
        const session2 = sessions[j];

        if (
          this.timesOverlap(
            session1.startTime,
            session1.endTime,
            session2.startTime,
            session2.endTime,
          )
        ) {
          errors.push({
            type: 'TIME_OVERLAP',
            message: `Chevauchement temporel entre les sessions ${session1.order} et ${session2.order}`,
            sessionIds: [session1.id, session2.id],
          });
        }
      }
    }

    return errors;
  }

  private checkOrderConsistency(
    sessions: DefenseSessionWithGroup[] | DefenseSession[],
  ): ValidationError[] {
    const errors: ValidationError[] = [];
    const orders = sessions.map((s) => s.order).sort((a, b) => a - b);

    // Vérifier qu'il n'y a pas de doublons
    const uniqueOrders = [...new Set(orders)];
    if (uniqueOrders.length !== orders.length) {
      errors.push({
        type: 'INVALID_ORDER',
        message: 'Ordres de passage dupliqués détectés',
        sessionIds: sessions.map((s) => s.id),
      });
    }

    // Vérifier la séquence (1, 2, 3, ...)
    for (let i = 0; i < uniqueOrders.length; i++) {
      if (uniqueOrders[i] !== i + 1) {
        errors.push({
          type: 'INVALID_ORDER',
          message: `Ordre de passage incohérent: attendu ${i + 1}, trouvé ${uniqueOrders[i]}`,
          sessionIds: sessions
            .filter((s) => s.order === uniqueOrders[i])
            .map((s) => s.id),
        });
      }
    }

    return errors;
  }

  private checkWeekendSessions(
    sessions: DefenseSessionWithGroup[] | DefenseSession[],
  ): ValidationWarning[] {
    const warnings: ValidationWarning[] = [];

    const weekendSessions = sessions.filter((s) => {
      const day = s.startTime.getDay();
      return day === 0 || day === 6; // Dimanche ou Samedi
    });

    if (weekendSessions.length > 0) {
      warnings.push({
        type: 'WEEKEND_SESSION',
        message: `${weekendSessions.length} session(s) planifiée(s) en weekend`,
        sessionIds: weekendSessions.map((s) => s.id),
      });
    }

    return warnings;
  }

  private checkWorkingHours(
    sessions: DefenseSessionWithGroup[] | DefenseSession[],
  ): ValidationWarning[] {
    const warnings: ValidationWarning[] = [];

    // Heures ouvrables par défaut: 8h-18h
    const defaultStart = 8 * 60; // 8h00 en minutes
    const defaultEnd = 18 * 60; // 18h00 en minutes

    const outsideHoursSessions = sessions.filter((s) => {
      const startMinutes =
        s.startTime.getHours() * 60 + s.startTime.getMinutes();
      const endMinutes = s.endTime.getHours() * 60 + s.endTime.getMinutes();

      return startMinutes < defaultStart || endMinutes > defaultEnd;
    });

    if (outsideHoursSessions.length > 0) {
      warnings.push({
        type: 'OUTSIDE_HOURS',
        message: `${outsideHoursSessions.length} session(s) en dehors des heures ouvrables (8h-18h)`,
        sessionIds: outsideHoursSessions.map((s) => s.id),
      });
    }

    return warnings;
  }

  private timesOverlap(
    start1: Date,
    end1: Date,
    start2: Date,
    end2: Date,
  ): boolean {
    return start1 < end2 && start2 < end1;
  }

  private generateSuggestions(
    errors: ValidationError[],
    warnings: ValidationWarning[],
  ): string[] {
    const suggestions: string[] = [];

    if (errors.some((e) => e.type === 'TIME_OVERLAP')) {
      suggestions.push(
        'Recalculer automatiquement les horaires pour éliminer les chevauchements',
      );
    }

    if (errors.some((e) => e.type === 'INVALID_ORDER')) {
      suggestions.push("Réorganiser automatiquement l'ordre de passage");
    }

    if (warnings.some((w) => w.type === 'WEEKEND_SESSION')) {
      suggestions.push('Reporter les sessions de weekend au lundi suivant');
    }

    if (warnings.some((w) => w.type === 'OUTSIDE_HOURS')) {
      suggestions.push(
        'Ajuster les horaires pour respecter les heures ouvrables',
      );
    }

    return suggestions;
  }

  // ===============================================
  // US-DEF-002: Fonctionnalités de Réorganisation
  // ===============================================

  async reorderSessions(
    projectId: string,
    newOrder: string[],
  ): Promise<DefenseSessionWithGroup[]> {
    // Validation de l'ordre fourni
    await this.validateReorderInput(projectId, newOrder);

    // Mise à jour des ordres en base avec transaction
    await this.prisma.$transaction(async (prisma) => {
      for (let i = 0; i < newOrder.length; i++) {
        const sessionId = newOrder[i];
        await prisma.defenseSession.update({
          where: { id: sessionId },
          data: { order: i + 1 },
        });
      }
    });

    // Recalcul des horaires selon le nouvel ordre
    return this.recalculateTimingsForProject(projectId);
  }

  async swapSessions(
    sessionId1: string,
    sessionId2: string,
  ): Promise<[DefenseSessionWithGroup, DefenseSessionWithGroup]> {
    // Récupération et validation des sessions à échanger
    const [session1, session2] = await this.validateSwapSessions(
      sessionId1,
      sessionId2,
    );

    // Échange des positions avec transaction atomique
    await this.prisma.$transaction([
      this.prisma.defenseSession.update({
        where: { id: sessionId1 },
        data: { order: session2.order },
      }),
      this.prisma.defenseSession.update({
        where: { id: sessionId2 },
        data: { order: session1.order },
      }),
    ]);

    // Recalcul des horaires pour tout le projet
    const updatedSessions = await this.recalculateTimingsForProject(
      session1.projectId,
    );

    // Retourner les deux sessions échangées
    const swappedSession1 = updatedSessions.find((s) => s.id === sessionId1);
    const swappedSession2 = updatedSessions.find((s) => s.id === sessionId2);

    return [swappedSession1, swappedSession2];
  }

  async insertBreak(
    projectId: string,
    afterPosition: number,
    breakConfig: { duration: number; label?: string },
  ): Promise<DefenseSessionWithGroup[]> {
    // Décalage des sessions suivant la position d'insertion
    await this.shiftSessionsAfterPosition(projectId, afterPosition);

    // Le "break" est représenté par un espace temporel dans le planning
    // Pas besoin de créer une entité spéciale, juste ajuster les horaires

    // Recalcul complet du timing avec la pause intégrée
    return this.recalculateTimingsForProjectWithBreak(
      projectId,
      afterPosition + 1,
      breakConfig.duration,
    );
  }

  private async validateReorderInput(
    projectId: string,
    newOrder: string[],
  ): Promise<void> {
    // Récupération des sessions actuelles du projet
    const existingSessions = await this.prisma.defenseSession.findMany({
      where: { projectId },
      select: { id: true },
    });

    const existingIds = existingSessions.map((s) => s.id).sort();
    const providedIds = [...newOrder].sort();

    // Vérification que tous les IDs sont présents et corrects
    if (existingIds.length !== providedIds.length) {
      throw new BadRequestException(
        `Nombre de sessions incorrect: attendu ${existingIds.length}, reçu ${providedIds.length}`,
      );
    }

    if (!existingIds.every((id, index) => id === providedIds[index])) {
      throw new BadRequestException(
        'Les IDs de sessions ne correspondent pas au projet',
      );
    }
  }

  private async validateSwapSessions(
    sessionId1: string,
    sessionId2: string,
  ): Promise<[PartialDefenseSession, PartialDefenseSession]> {
    const session1 = await this.prisma.defenseSession.findUnique({
      where: { id: sessionId1 },
      select: { id: true, order: true, projectId: true },
    });

    const session2 = await this.prisma.defenseSession.findUnique({
      where: { id: sessionId2 },
      select: { id: true, order: true, projectId: true },
    });

    if (!session1) {
      throw new BadRequestException(`Session ${sessionId1} non trouvée`);
    }

    if (!session2) {
      throw new BadRequestException(`Session ${sessionId2} non trouvée`);
    }

    if (session1.projectId !== session2.projectId) {
      throw new BadRequestException(
        'Les sessions doivent appartenir au même projet',
      );
    }

    return [session1, session2];
  }

  private async shiftSessionsAfterPosition(
    projectId: string,
    afterPosition: number,
  ): Promise<void> {
    // Décaler l'ordre de toutes les sessions après la position donnée
    await this.prisma.defenseSession.updateMany({
      where: {
        projectId,
        order: { gt: afterPosition },
      },
      data: {
        order: { increment: 1 },
      },
    });
  }

  private async recalculateTimingsForProject(
    projectId: string,
  ): Promise<DefenseSessionWithGroup[]> {
    const sessions = await this.prisma.defenseSession.findMany({
      where: { projectId },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
      },
      orderBy: { order: 'asc' },
    });

    return this.recalculateTimings(sessions);
  }

  private async recalculateTimingsForProjectWithBreak(
    projectId: string,
    breakPosition: number,
    breakDuration: number,
  ): Promise<DefenseSessionWithGroup[]> {
    const sessions = await this.prisma.defenseSession.findMany({
      where: { projectId },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
      },
      orderBy: { order: 'asc' },
    });

    return this.recalculateTimingsWithBreak(
      sessions,
      breakPosition,
      breakDuration,
    );
  }

  private async recalculateTimings(
    sessions: DefenseSessionWithGroup[],
  ): Promise<DefenseSessionWithGroup[]> {
    if (sessions.length === 0) return sessions;

    // Configuration par défaut pour le recalcul
    const defaultConfig: ScheduleConfig = {
      durationPerGroup: 20, // 20 minutes par défaut
      breakBetweenGroups: 5, // 5 minutes de pause
      skipWeekends: true,
    };

    // Tri par ordre
    const sortedSessions = sessions.sort((a, b) => a.order - b.order);

    // Garder l'heure de début de la première session
    let currentTime = new Date(sortedSessions[0].startTime);
    const updatedSessions: DefenseSessionWithGroup[] = [];

    for (const session of sortedSessions) {
      // Ajuster pour les contraintes (weekends, heures ouvrables)
      currentTime = this.adjustForConstraints(currentTime, defaultConfig);

      // Calculer la durée de la session (garde la durée originale)
      const originalDuration = Math.round(
        (session.endTime.getTime() - session.startTime.getTime()) / 60000,
      );
      const duration =
        originalDuration > 0
          ? originalDuration
          : defaultConfig.durationPerGroup;

      const endTime = new Date(currentTime.getTime() + duration * 60000);

      const updated = await this.prisma.defenseSession.update({
        where: { id: session.id },
        data: {
          startTime: new Date(currentTime),
          endTime: new Date(endTime),
        },
        include: {
          group: {
            include: {
              members: {
                include: {
                  user: { select: { firstname: true, lastname: true } },
                },
              },
            },
          },
        },
      });

      updatedSessions.push(updated);

      // Préparation pour la session suivante (avec pause)
      currentTime = new Date(
        endTime.getTime() + defaultConfig.breakBetweenGroups * 60000,
      );
    }

    return updatedSessions;
  }

  private async recalculateTimingsWithBreak(
    sessions: DefenseSessionWithGroup[],
    breakPosition: number,
    breakDuration: number,
  ): Promise<DefenseSessionWithGroup[]> {
    if (sessions.length === 0) return sessions;

    const defaultConfig: ScheduleConfig = {
      durationPerGroup: 20,
      breakBetweenGroups: 5,
      skipWeekends: true,
    };

    const sortedSessions = sessions.sort((a, b) => a.order - b.order);
    let currentTime = new Date(sortedSessions[0].startTime);
    const updatedSessions: DefenseSessionWithGroup[] = [];

    for (let i = 0; i < sortedSessions.length; i++) {
      const session = sortedSessions[i];

      // Insérer une pause après la position spécifiée
      if (session.order === breakPosition) {
        currentTime = new Date(currentTime.getTime() + breakDuration * 60000);
      }

      currentTime = this.adjustForConstraints(currentTime, defaultConfig);

      const originalDuration = Math.round(
        (session.endTime.getTime() - session.startTime.getTime()) / 60000,
      );
      const duration =
        originalDuration > 0
          ? originalDuration
          : defaultConfig.durationPerGroup;

      const endTime = new Date(currentTime.getTime() + duration * 60000);

      const updated = await this.prisma.defenseSession.update({
        where: { id: session.id },
        data: {
          startTime: new Date(currentTime),
          endTime: new Date(endTime),
        },
        include: {
          group: {
            include: {
              members: {
                include: {
                  user: { select: { firstname: true, lastname: true } },
                },
              },
            },
          },
        },
      });

      updatedSessions.push(updated);

      currentTime = new Date(
        endTime.getTime() + defaultConfig.breakBetweenGroups * 60000,
      );
    }

    return updatedSessions;
  }

  async validateProjectSchedule(projectId: string): Promise<ValidationResult> {
    const sessions = await this.prisma.defenseSession.findMany({
      where: { projectId },
      orderBy: { order: 'asc' },
    });

    return this.validateSchedule(sessions);
  }

  // Nouvelles méthodes pour le contrôleur refactorisé
  async createSchedule(
    defenseId: string,
    dto: CreateScheduleDto,
  ): Promise<DefenseSessionWithGroup[]> {
    // Trouve le projet et ses groupes
    const defense = await this.prisma.project.findUnique({
      where: { id: defenseId },
      include: { groups: true },
    });

    if (!defense) {
      throw new BadRequestException('Projet non trouvé');
    }

    if (!defense.groups || defense.groups.length === 0) {
      throw new BadRequestException('Aucun groupe associé à ce projet');
    }

    const config: ScheduleConfig = {
      durationPerGroup: dto.durationPerGroup || 20,
      breakBetweenGroups: dto.breakBetweenGroups || 5,
      workingHours:
        dto.workingHoursStart && dto.workingHoursEnd
          ? {
              start: dto.workingHoursStart,
              end: dto.workingHoursEnd,
            }
          : undefined,
      skipWeekends: dto.skipWeekends !== false,
    };

    const groupIds = defense.groups.map((g) => g.id);
    const startDateTime = new Date(dto.startDateTime);

    if (dto.timeSlots && dto.timeSlots.length > 0) {
      // Mode créneaux manuels
      return this.createFromTimeSlots(defenseId, dto.timeSlots);
    } else {
      // Mode automatique
      const slots = await this.calculateSlots(
        startDateTime,
        groupIds,
        config,
        dto.defaultLocation,
      );
      return this.createSessionsFromSlots(slots);
    }
  }

  async getSessionsByDefense(
    defenseId: string,
  ): Promise<DefenseSessionWithGroup[]> {
    return this.prisma.defenseSession.findMany({
      where: { projectId: defenseId },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
      },
      orderBy: [{ order: 'asc' }, { startTime: 'asc' }],
    });
  }

  async removeBreak(
    defenseId: string,
    breakId: string,
  ): Promise<DefenseSessionWithGroup[]> {
    // Trouve la session de pause
    const breakSession = await this.prisma.defenseSession.findUnique({
      where: { id: breakId },
    });

    if (!breakSession) {
      throw new BadRequestException('Session de pause non trouvée');
    }

    if (breakSession.projectId !== defenseId) {
      throw new BadRequestException(
        "Cette pause n'appartient pas à cette défense",
      );
    }

    if (breakSession.groupId) {
      throw new BadRequestException("Cette session n'est pas une pause");
    }

    // Supprime la pause et réorganise les autres sessions
    await this.prisma.$transaction(async (prisma) => {
      // Supprime la pause
      await prisma.defenseSession.delete({
        where: { id: breakId },
      });

      // Met à jour l'ordre des sessions suivantes
      await prisma.defenseSession.updateMany({
        where: {
          projectId: defenseId,
          order: { gt: breakSession.order },
        },
        data: {
          order: { decrement: 1 },
        },
      });
    });

    return this.getSessionsByDefense(defenseId);
  }
}
