import { Module } from '@nestjs/common';
import { DefensesController } from './defenses.controller';
import { DefensesService } from './defenses.service';
import { DefenseScheduleService } from './services/defense-schedule.service';
import { DefenseExportService } from './services/defense-export.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [DefensesController],
  providers: [DefensesService, DefenseScheduleService, DefenseExportService],
  exports: [DefensesService, DefenseScheduleService, DefenseExportService],
})
export class DefensesModule {}
