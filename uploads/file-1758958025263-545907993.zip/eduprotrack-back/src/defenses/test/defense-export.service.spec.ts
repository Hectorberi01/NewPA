import { Test, TestingModule } from '@nestjs/testing';
import { DefenseExportService } from '../services/defense-export.service';
import { PrismaService } from '../../prisma/prisma.service';
import {
  NotFoundException,
  InternalServerErrorException,
} from '@nestjs/common';
import * as puppeteer from 'puppeteer';

// Mock puppeteer
jest.mock('puppeteer');

describe('DefenseExportService', () => {
  let service: DefenseExportService;
  let prismaService: PrismaService;

  const mockDefense = {
    id: 'defense-123',
    title: 'Test Defense',
    description: 'Test Description',
    startDate: new Date('2024-06-15T09:00:00Z'),
    endDate: new Date('2024-06-15T17:00:00Z'),
    location: 'Room 101',
    sessions: [
      {
        id: 'session-1',
        startTime: new Date('2024-06-15T09:00:00Z'),
        endTime: new Date('2024-06-15T09:20:00Z'),
        location: 'Room 101',
        order: 1,
        group: {
          id: 'group-1',
          name: 'Group 1',
          members: [
            { id: 'student-1', firstname: 'Alice', lastname: 'Smith' },
            { id: 'student-2', firstname: 'Bob', lastname: 'Johnson' },
          ],
        },
      },
      {
        id: 'session-2',
        startTime: new Date('2024-06-15T09:30:00Z'),
        endTime: new Date('2024-06-15T09:50:00Z'),
        location: 'Room 102',
        order: 2,
        group: {
          id: 'group-2',
          name: 'Group 2',
          members: [
            { id: 'student-3', firstname: 'Charlie', lastname: 'Brown' },
          ],
        },
      },
    ],
  };

  const mockBrowser = {
    newPage: jest.fn(),
    close: jest.fn(),
  };

  const mockPage = {
    setContent: jest.fn(),
    pdf: jest.fn().mockResolvedValue(Buffer.from('mock-pdf-content')),
    close: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DefenseExportService,
        {
          provide: PrismaService,
          useValue: {
            defense: {
              findUnique: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<DefenseExportService>(DefenseExportService);
    prismaService = module.get<PrismaService>(PrismaService);

    // Reset mocks
    jest.clearAllMocks();

    // Setup puppeteer mocks
    (puppeteer.launch as jest.Mock).mockResolvedValue(mockBrowser);
    mockBrowser.newPage.mockResolvedValue(mockPage);
  });

  describe('exportToPdf', () => {
    it('should export defense schedule to PDF successfully', async () => {
      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(mockDefense as any);

      const result = await service.exportToPdf('defense-123');

      expect(result).toBeInstanceOf(Buffer);
      expect(puppeteer.launch).toHaveBeenCalledWith({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
      });
      expect(mockPage.setContent).toHaveBeenCalledWith(
        expect.stringContaining('Test Defense'),
        { waitUntil: 'networkidle0' },
      );
      expect(mockPage.pdf).toHaveBeenCalledWith({
        format: 'A4',
        margin: { top: '20px', right: '20px', bottom: '20px', left: '20px' },
        printBackground: true,
      });
      expect(mockBrowser.close).toHaveBeenCalled();
    });

    it('should throw NotFoundException when defense does not exist', async () => {
      jest.spyOn(prismaService.defense, 'findUnique').mockResolvedValue(null);

      await expect(service.exportToPdf('defense-123')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should handle puppeteer errors gracefully', async () => {
      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(mockDefense as any);
      (puppeteer.launch as jest.Mock).mockRejectedValue(
        new Error('Puppeteer failed'),
      );

      await expect(service.exportToPdf('defense-123')).rejects.toThrow(
        InternalServerErrorException,
      );
    });

    it('should include break sessions in PDF export', async () => {
      const defenseWithBreak = {
        ...mockDefense,
        sessions: [
          ...mockDefense.sessions,
          {
            id: 'break-1',
            startTime: new Date('2024-06-15T12:00:00Z'),
            endTime: new Date('2024-06-15T13:00:00Z'),
            location: 'Cafeteria',
            order: 3,
            group: null,
            isBreak: true,
            label: 'Lunch Break',
          },
        ],
      };

      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(defenseWithBreak as any);

      await service.exportToPdf('defense-123');

      expect(mockPage.setContent).toHaveBeenCalledWith(
        expect.stringContaining('Lunch Break'),
        { waitUntil: 'networkidle0' },
      );
    });
  });

  describe('exportToExcel', () => {
    it('should export defense schedule to Excel successfully', async () => {
      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(mockDefense as any);

      const result = await service.exportToExcel('defense-123');

      expect(result).toBeInstanceOf(Buffer);
      // Since we're using a mock Excel library, we mainly test that the method completes
      expect(prismaService.defense.findUnique).toHaveBeenCalledWith({
        where: { id: 'defense-123' },
        include: {
          sessions: {
            include: { group: { include: { members: true } } },
            orderBy: [{ order: 'asc' }, { startTime: 'asc' }],
          },
        },
      });
    });

    it('should throw NotFoundException when defense does not exist', async () => {
      jest.spyOn(prismaService.defense, 'findUnique').mockResolvedValue(null);

      await expect(service.exportToExcel('defense-123')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should handle empty sessions in Excel export', async () => {
      const defenseWithoutSessions = {
        ...mockDefense,
        sessions: [],
      };

      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(defenseWithoutSessions as any);

      const result = await service.exportToExcel('defense-123');

      expect(result).toBeInstanceOf(Buffer);
    });
  });

  describe('exportToICS', () => {
    it('should export defense schedule to ICS format successfully', async () => {
      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(mockDefense as any);

      const result = await service.exportToICS('defense-123');

      expect(typeof result).toBe('string');
      expect(result).toContain('BEGIN:VCALENDAR');
      expect(result).toContain('END:VCALENDAR');
      expect(result).toContain('BEGIN:VEVENT');
      expect(result).toContain('END:VEVENT');
      expect(result).toContain('Test Defense');
      expect(result).toContain('Group 1');
    });

    it('should throw NotFoundException when defense does not exist', async () => {
      jest.spyOn(prismaService.defense, 'findUnique').mockResolvedValue(null);

      await expect(service.exportToICS('defense-123')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should handle sessions without groups in ICS export', async () => {
      const defenseWithBreak = {
        ...mockDefense,
        sessions: [
          {
            id: 'break-1',
            startTime: new Date('2024-06-15T12:00:00Z'),
            endTime: new Date('2024-06-15T13:00:00Z'),
            location: 'Cafeteria',
            order: 1,
            group: null,
            isBreak: true,
            label: 'Lunch Break',
          },
        ],
      };

      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(defenseWithBreak as any);

      const result = await service.exportToICS('defense-123');

      expect(result).toContain('Lunch Break');
      expect(result).toContain('SUMMARY:Pause - Lunch Break');
    });
  });

  describe('private helper methods', () => {
    describe('generateHtmlContent', () => {
      it('should generate proper HTML structure', () => {
        // Access private method for testing
        const html = (service as any).generateHtmlContent(mockDefense);

        expect(html).toContain('<!DOCTYPE html>');
        expect(html).toContain(
          '<title>Planning de soutenance - Test Defense</title>',
        );
        expect(html).toContain('Test Defense');
        expect(html).toContain('Group 1');
        expect(html).toContain('Alice Smith, Bob Johnson');
        expect(html).toContain('09:00');
        expect(html).toContain('Room 101');
      });

      it('should handle defenses without sessions', () => {
        const defenseWithoutSessions = {
          ...mockDefense,
          sessions: [],
        };

        const html = (service as any).generateHtmlContent(
          defenseWithoutSessions,
        );

        expect(html).toContain('Aucune session planifiée');
      });
    });

    describe('formatICSDateTime', () => {
      it('should format date correctly for ICS', () => {
        const date = new Date('2024-06-15T09:00:00Z');
        const formatted = (service as any).formatICSDateTime(date);

        expect(formatted).toBe('20240615T090000Z');
      });
    });

    describe('formatDuration', () => {
      it('should format duration correctly', () => {
        const startTime = new Date('2024-06-15T09:00:00Z');
        const endTime = new Date('2024-06-15T09:20:00Z');

        const duration = (service as any).formatDuration(startTime, endTime);

        expect(duration).toBe('20 min');
      });

      it('should handle hour durations', () => {
        const startTime = new Date('2024-06-15T09:00:00Z');
        const endTime = new Date('2024-06-15T10:30:00Z');

        const duration = (service as any).formatDuration(startTime, endTime);

        expect(duration).toBe('1h 30 min');
      });
    });
  });
});
