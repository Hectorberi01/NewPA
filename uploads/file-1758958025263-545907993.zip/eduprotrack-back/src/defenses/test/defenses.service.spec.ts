import { Test, TestingModule } from '@nestjs/testing';
import { DefensesService } from '../defenses.service';
import { PrismaService } from '../../prisma/prisma.service';
import { DefenseScheduleService } from '../services/defense-schedule.service';
import { DefenseExportService } from '../services/defense-export.service';
import { ForbiddenException, NotFoundException } from '@nestjs/common';
import { DefenseStatus } from '@prisma/client';
import { CreateDefenseDto } from '../dto/create-defense.dto';
import { UpdateDefenseDto } from '../dto/update-defense.dto';

describe('DefensesService', () => {
  let service: DefensesService;
  let prismaService: PrismaService;
  let scheduleService: DefenseScheduleService;
  let exportService: DefenseExportService;

  const mockUser = {
    id: 'user-123',
    email: 'teacher@example.com',
    role: 'TEACHER',
    firstname: 'John',
    lastname: 'Doe',
  };

  const mockDefense = {
    id: 'defense-123',
    title: 'Test Defense',
    description: 'Test Description',
    startDate: new Date('2024-06-15T09:00:00Z'),
    endDate: new Date('2024-06-15T17:00:00Z'),
    location: 'Room 101',
    status: DefenseStatus.DRAFT,
    createdAt: new Date(),
    updatedAt: new Date(),
    userId: 'user-123',
    promotionId: 'promo-123',
    sessions: [],
    groups: [],
  };

  const mockProject = {
    id: 'project-123',
    name: 'Test Project',
    userId: 'user-123',
    groups: [
      {
        id: 'group-123',
        name: 'Group 1',
        members: [{ id: 'student-1', firstname: 'Alice', lastname: 'Smith' }],
      },
    ],
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DefensesService,
        {
          provide: PrismaService,
          useValue: {
            defense: {
              create: jest.fn(),
              findMany: jest.fn(),
              findUnique: jest.fn(),
              update: jest.fn(),
              delete: jest.fn(),
            },
            project: {
              findUnique: jest.fn(),
              findMany: jest.fn(),
            },
            user: {
              findUnique: jest.fn(),
            },
            promotion: {
              findUnique: jest.fn(),
            },
          },
        },
        {
          provide: DefenseScheduleService,
          useValue: {
            createSchedule: jest.fn(),
            updateSchedule: jest.fn(),
            reorganizeSessions: jest.fn(),
          },
        },
        {
          provide: DefenseExportService,
          useValue: {
            exportToPdf: jest.fn(),
            exportToExcel: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<DefensesService>(DefensesService);
    prismaService = module.get<PrismaService>(PrismaService);
    scheduleService = module.get<DefenseScheduleService>(
      DefenseScheduleService,
    );
    exportService = module.get<DefenseExportService>(DefenseExportService);
  });

  describe('create', () => {
    const createDto: CreateDefenseDto = {
      title: 'New Defense',
      description: 'Defense Description',
      startDate: '2024-06-15T09:00:00Z',
      endDate: '2024-06-15T17:00:00Z',
      location: 'Room 101',
      promotionId: 'promo-123',
    };

    it('should create a defense successfully', async () => {
      jest.spyOn(prismaService.promotion, 'findUnique').mockResolvedValue({
        id: 'promo-123',
        name: 'Test Promotion',
      } as any);
      jest
        .spyOn(prismaService.defense, 'create')
        .mockResolvedValue(mockDefense as any);

      const result = await service.create(createDto, mockUser);

      expect(result).toEqual(mockDefense);
      expect(prismaService.defense.create).toHaveBeenCalledWith({
        data: {
          title: createDto.title,
          description: createDto.description,
          startDate: new Date(createDto.startDate),
          endDate: new Date(createDto.endDate),
          location: createDto.location,
          status: DefenseStatus.DRAFT,
          userId: mockUser.id,
          promotionId: createDto.promotionId,
        },
        include: {
          sessions: { include: { group: true } },
          groups: { include: { members: true } },
        },
      });
    });

    it('should throw NotFoundException when promotion does not exist', async () => {
      jest.spyOn(prismaService.promotion, 'findUnique').mockResolvedValue(null);

      await expect(service.create(createDto, mockUser)).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  describe('findAll', () => {
    it('should return user defenses with filters', async () => {
      const mockDefenses = [mockDefense];
      jest
        .spyOn(prismaService.defense, 'findMany')
        .mockResolvedValue(mockDefenses as any);

      const result = await service.findAll(
        mockUser,
        DefenseStatus.DRAFT,
        'promo-123',
      );

      expect(result).toEqual(mockDefenses);
      expect(prismaService.defense.findMany).toHaveBeenCalledWith({
        where: {
          userId: mockUser.id,
          status: DefenseStatus.DRAFT,
          promotionId: 'promo-123',
        },
        include: {
          sessions: { include: { group: true } },
          groups: { include: { members: true } },
        },
        orderBy: { startDate: 'asc' },
      });
    });
  });

  describe('findOne', () => {
    it('should return defense when user owns it', async () => {
      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(mockDefense as any);

      const result = await service.findOne('defense-123', mockUser);

      expect(result).toEqual(mockDefense);
    });

    it('should throw NotFoundException when defense does not exist', async () => {
      jest.spyOn(prismaService.defense, 'findUnique').mockResolvedValue(null);

      await expect(service.findOne('defense-123', mockUser)).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw ForbiddenException when user does not own defense', async () => {
      const otherUserDefense = { ...mockDefense, userId: 'other-user' };
      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(otherUserDefense as any);

      await expect(service.findOne('defense-123', mockUser)).rejects.toThrow(
        ForbiddenException,
      );
    });
  });

  describe('update', () => {
    const updateDto: UpdateDefenseDto = {
      title: 'Updated Defense',
      description: 'Updated Description',
    };

    it('should update defense successfully', async () => {
      jest.spyOn(service, 'findOne').mockResolvedValue(mockDefense as any);
      const updatedDefense = { ...mockDefense, ...updateDto };
      jest
        .spyOn(prismaService.defense, 'update')
        .mockResolvedValue(updatedDefense as any);

      const result = await service.update('defense-123', updateDto, mockUser);

      expect(result).toEqual(updatedDefense);
      expect(prismaService.defense.update).toHaveBeenCalledWith({
        where: { id: 'defense-123' },
        data: updateDto,
        include: {
          sessions: { include: { group: true } },
          groups: { include: { members: true } },
        },
      });
    });
  });

  describe('remove', () => {
    it('should remove defense successfully', async () => {
      jest.spyOn(service, 'findOne').mockResolvedValue(mockDefense as any);
      jest
        .spyOn(prismaService.defense, 'delete')
        .mockResolvedValue(mockDefense as any);

      await service.remove('defense-123', mockUser);

      expect(prismaService.defense.delete).toHaveBeenCalledWith({
        where: { id: 'defense-123' },
      });
    });
  });

  describe('getAvailableProjects', () => {
    it('should return projects owned by user', async () => {
      jest
        .spyOn(prismaService.project, 'findMany')
        .mockResolvedValue([mockProject] as any);

      const result = await service.getAvailableProjects(mockUser);

      expect(result).toEqual([mockProject]);
      expect(prismaService.project.findMany).toHaveBeenCalledWith({
        where: { userId: mockUser.id },
        include: {
          groups: {
            include: { members: true },
          },
        },
      });
    });
  });

  describe('validateProjectOwnership', () => {
    it('should return true when user owns project', async () => {
      jest
        .spyOn(prismaService.project, 'findUnique')
        .mockResolvedValue(mockProject as any);

      const result = await service.validateProjectOwnership(
        'project-123',
        mockUser,
      );

      expect(result).toBe(true);
    });

    it('should return false when project does not exist', async () => {
      jest.spyOn(prismaService.project, 'findUnique').mockResolvedValue(null);

      const result = await service.validateProjectOwnership(
        'project-123',
        mockUser,
      );

      expect(result).toBe(false);
    });

    it('should return false when user does not own project', async () => {
      const otherUserProject = { ...mockProject, userId: 'other-user' };
      jest
        .spyOn(prismaService.project, 'findUnique')
        .mockResolvedValue(otherUserProject as any);

      const result = await service.validateProjectOwnership(
        'project-123',
        mockUser,
      );

      expect(result).toBe(false);
    });
  });
});
