import { Test, TestingModule } from '@nestjs/testing';
import { DefensesController } from '../defenses.controller';
import { DefensesService } from '../defenses.service';
import { DefenseScheduleService } from '../services/defense-schedule.service';
import { DefenseExportService } from '../services/defense-export.service';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { DefenseStatus } from '@prisma/client';
import { CreateDefenseDto } from '../dto/create-defense.dto';
import { UpdateDefenseDto } from '../dto/update-defense.dto';
import { CreateScheduleDto } from '../dto/create-schedule.dto';
import { Response } from 'express';

describe('DefensesController', () => {
  let controller: DefensesController;
  let defensesService: DefensesService;
  let scheduleService: DefenseScheduleService;
  let exportService: DefenseExportService;

  const mockUser = {
    id: 'user-123',
    email: 'teacher@example.com',
    role: 'TEACHER',
    firstname: 'John',
    lastname: 'Doe',
  };

  const mockDefense = {
    id: 'defense-123',
    title: 'Test Defense',
    description: 'Test Description',
    startDate: new Date('2024-06-15T09:00:00Z'),
    endDate: new Date('2024-06-15T17:00:00Z'),
    location: 'Room 101',
    status: DefenseStatus.DRAFT,
    userId: 'user-123',
    promotionId: 'promo-123',
    sessions: [],
    groups: [],
  };

  const mockSession = {
    id: 'session-1',
    startTime: new Date('2024-06-15T09:00:00Z'),
    endTime: new Date('2024-06-15T09:20:00Z'),
    location: 'Room 101',
    group: { id: 'group-1', name: 'Group 1', members: [] },
  };

  const mockResponse = {
    setHeader: jest.fn(),
    send: jest.fn(),
  } as unknown as Response;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DefensesController],
      providers: [
        {
          provide: DefensesService,
          useValue: {
            create: jest.fn(),
            findAll: jest.fn(),
            findOne: jest.fn(),
            update: jest.fn(),
            remove: jest.fn(),
            getAvailableProjects: jest.fn(),
            validateProjectOwnership: jest.fn(),
          },
        },
        {
          provide: DefenseScheduleService,
          useValue: {
            createSchedule: jest.fn(),
            insertBreak: jest.fn(),
            swapSessions: jest.fn(),
            reorderSessions: jest.fn(),
            removeBreak: jest.fn(),
            getSessionsByDefense: jest.fn(),
          },
        },
        {
          provide: DefenseExportService,
          useValue: {
            exportToPdf: jest.fn(),
            exportToExcel: jest.fn(),
            exportToICS: jest.fn(),
          },
        },
      ],
    })
      .overrideGuard(JwtAuthGuard)
      .useValue({ canActivate: jest.fn(() => true) })
      .compile();

    controller = module.get<DefensesController>(DefensesController);
    defensesService = module.get<DefensesService>(DefensesService);
    scheduleService = module.get<DefenseScheduleService>(
      DefenseScheduleService,
    );
    exportService = module.get<DefenseExportService>(DefenseExportService);
  });

  describe('create', () => {
    const createDto: CreateDefenseDto = {
      title: 'New Defense',
      description: 'Defense Description',
      startDate: '2024-06-15T09:00:00Z',
      endDate: '2024-06-15T17:00:00Z',
      location: 'Room 101',
      promotionId: 'promo-123',
    };

    it('should create a defense', async () => {
      jest
        .spyOn(defensesService, 'create')
        .mockResolvedValue(mockDefense as any);

      const result = await controller.create(createDto, mockUser);

      expect(result).toEqual(mockDefense);
      expect(defensesService.create).toHaveBeenCalledWith(createDto, mockUser);
    });
  });

  describe('findAll', () => {
    it('should return all defenses with filters', async () => {
      const mockDefenses = [mockDefense];
      jest
        .spyOn(defensesService, 'findAll')
        .mockResolvedValue(mockDefenses as any);

      const result = await controller.findAll(
        mockUser,
        DefenseStatus.DRAFT,
        'promo-123',
      );

      expect(result).toEqual(mockDefenses);
      expect(defensesService.findAll).toHaveBeenCalledWith(
        mockUser,
        DefenseStatus.DRAFT,
        'promo-123',
      );
    });

    it('should return all defenses without filters', async () => {
      const mockDefenses = [mockDefense];
      jest
        .spyOn(defensesService, 'findAll')
        .mockResolvedValue(mockDefenses as any);

      const result = await controller.findAll(mockUser);

      expect(result).toEqual(mockDefenses);
      expect(defensesService.findAll).toHaveBeenCalledWith(
        mockUser,
        undefined,
        undefined,
      );
    });
  });

  describe('findOne', () => {
    it('should return a defense by id', async () => {
      jest
        .spyOn(defensesService, 'findOne')
        .mockResolvedValue(mockDefense as any);

      const result = await controller.findOne('defense-123', mockUser);

      expect(result).toEqual(mockDefense);
      expect(defensesService.findOne).toHaveBeenCalledWith(
        'defense-123',
        mockUser,
      );
    });
  });

  describe('update', () => {
    const updateDto: UpdateDefenseDto = {
      title: 'Updated Defense',
      description: 'Updated Description',
    };

    it('should update a defense', async () => {
      const updatedDefense = { ...mockDefense, ...updateDto };
      jest
        .spyOn(defensesService, 'update')
        .mockResolvedValue(updatedDefense as any);

      const result = await controller.update(
        'defense-123',
        updateDto,
        mockUser,
      );

      expect(result).toEqual(updatedDefense);
      expect(defensesService.update).toHaveBeenCalledWith(
        'defense-123',
        updateDto,
        mockUser,
      );
    });
  });

  describe('remove', () => {
    it('should remove a defense', async () => {
      jest.spyOn(defensesService, 'remove').mockResolvedValue(undefined);

      await controller.remove('defense-123', mockUser);

      expect(defensesService.remove).toHaveBeenCalledWith(
        'defense-123',
        mockUser,
      );
    });
  });

  describe('getAvailableProjects', () => {
    it('should return available projects', async () => {
      const mockProjects = [{ id: 'project-1', name: 'Project 1' }];
      jest
        .spyOn(defensesService, 'getAvailableProjects')
        .mockResolvedValue(mockProjects as any);

      const result = await controller.getAvailableProjects(mockUser);

      expect(result).toEqual(mockProjects);
      expect(defensesService.getAvailableProjects).toHaveBeenCalledWith(
        mockUser,
      );
    });
  });

  describe('validateProjectOwnership', () => {
    it('should validate project ownership', async () => {
      jest
        .spyOn(defensesService, 'validateProjectOwnership')
        .mockResolvedValue(true);

      const result = await controller.validateProjectOwnership(
        'project-123',
        mockUser,
      );

      expect(result).toEqual({ isOwner: true });
      expect(defensesService.validateProjectOwnership).toHaveBeenCalledWith(
        'project-123',
        mockUser,
      );
    });
  });

  describe('Schedule endpoints', () => {
    const scheduleDto: CreateScheduleDto = {
      startDateTime: '2024-06-15T09:00:00Z',
      durationPerGroup: 20,
      breakBetweenGroups: 5,
    };

    describe('createSchedule', () => {
      it('should create a schedule', async () => {
        const mockSessions = [mockSession];
        jest
          .spyOn(scheduleService, 'createSchedule')
          .mockResolvedValue(mockSessions as any);

        const result = await controller.createSchedule(
          'defense-123',
          scheduleDto,
        );

        expect(result).toEqual(mockSessions);
        expect(scheduleService.createSchedule).toHaveBeenCalledWith(
          'defense-123',
          scheduleDto,
        );
      });
    });

    describe('getSessions', () => {
      it('should return defense sessions', async () => {
        const mockSessions = [mockSession];
        jest
          .spyOn(scheduleService, 'getSessionsByDefense')
          .mockResolvedValue(mockSessions as any);

        const result = await controller.getSessions('defense-123');

        expect(result).toEqual(mockSessions);
        expect(scheduleService.getSessionsByDefense).toHaveBeenCalledWith(
          'defense-123',
        );
      });
    });

    describe('insertBreak', () => {
      it('should insert a break', async () => {
        const breakDto = { afterPosition: 1, duration: 30, label: 'Lunch' };
        const mockSessions = [mockSession];
        jest
          .spyOn(scheduleService, 'insertBreak')
          .mockResolvedValue(mockSessions as any);

        const result = await controller.insertBreak('defense-123', breakDto);

        expect(result).toEqual(mockSessions);
        expect(scheduleService.insertBreak).toHaveBeenCalledWith(
          'defense-123',
          breakDto,
        );
      });
    });

    describe('swapSessions', () => {
      it('should swap sessions', async () => {
        const swapDto = { sessionId1: 'session-1', sessionId2: 'session-2' };
        const mockSessions = [mockSession];
        jest
          .spyOn(scheduleService, 'swapSessions')
          .mockResolvedValue(mockSessions as any);

        const result = await controller.swapSessions('defense-123', swapDto);

        expect(result).toEqual(mockSessions);
        expect(scheduleService.swapSessions).toHaveBeenCalledWith(
          'defense-123',
          swapDto,
        );
      });
    });

    describe('reorderSessions', () => {
      it('should reorder sessions', async () => {
        const reorderDto = { sessionIds: ['session-2', 'session-1'] };
        const mockSessions = [mockSession];
        jest
          .spyOn(scheduleService, 'reorderSessions')
          .mockResolvedValue(mockSessions as any);

        const result = await controller.reorderSessions(
          'defense-123',
          reorderDto,
        );

        expect(result).toEqual(mockSessions);
        expect(scheduleService.reorderSessions).toHaveBeenCalledWith(
          'defense-123',
          reorderDto,
        );
      });
    });

    describe('removeBreak', () => {
      it('should remove a break', async () => {
        const mockSessions = [mockSession];
        jest
          .spyOn(scheduleService, 'removeBreak')
          .mockResolvedValue(mockSessions as any);

        const result = await controller.removeBreak('defense-123', 'break-1');

        expect(result).toEqual(mockSessions);
        expect(scheduleService.removeBreak).toHaveBeenCalledWith(
          'defense-123',
          'break-1',
        );
      });
    });
  });

  describe('Export endpoints', () => {
    describe('exportToPdf', () => {
      it('should export to PDF', async () => {
        const mockPdfBuffer = Buffer.from('mock-pdf');
        jest
          .spyOn(exportService, 'exportToPdf')
          .mockResolvedValue(mockPdfBuffer);

        await controller.exportToPdf('defense-123', mockResponse);

        expect(exportService.exportToPdf).toHaveBeenCalledWith('defense-123');
        expect(mockResponse.setHeader).toHaveBeenCalledWith(
          'Content-Type',
          'application/pdf',
        );
        expect(mockResponse.setHeader).toHaveBeenCalledWith(
          'Content-Disposition',
          'attachment; filename="planning-defense-123.pdf"',
        );
        expect(mockResponse.send).toHaveBeenCalledWith(mockPdfBuffer);
      });
    });

    describe('exportToExcel', () => {
      it('should export to Excel', async () => {
        const mockExcelBuffer = Buffer.from('mock-excel');
        jest
          .spyOn(exportService, 'exportToExcel')
          .mockResolvedValue(mockExcelBuffer);

        await controller.exportToExcel('defense-123', mockResponse);

        expect(exportService.exportToExcel).toHaveBeenCalledWith('defense-123');
        expect(mockResponse.setHeader).toHaveBeenCalledWith(
          'Content-Type',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        );
        expect(mockResponse.setHeader).toHaveBeenCalledWith(
          'Content-Disposition',
          'attachment; filename="planning-defense-123.xlsx"',
        );
        expect(mockResponse.send).toHaveBeenCalledWith(mockExcelBuffer);
      });
    });

    describe('exportToICS', () => {
      it('should export to ICS', async () => {
        const mockIcsContent = 'BEGIN:VCALENDAR\nEND:VCALENDAR';
        jest
          .spyOn(exportService, 'exportToICS')
          .mockResolvedValue(mockIcsContent);

        await controller.exportToICS('defense-123', mockResponse);

        expect(exportService.exportToICS).toHaveBeenCalledWith('defense-123');
        expect(mockResponse.setHeader).toHaveBeenCalledWith(
          'Content-Type',
          'text/calendar',
        );
        expect(mockResponse.setHeader).toHaveBeenCalledWith(
          'Content-Disposition',
          'attachment; filename="planning-defense-123.ics"',
        );
        expect(mockResponse.send).toHaveBeenCalledWith(mockIcsContent);
      });
    });
  });
});
