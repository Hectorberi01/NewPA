import { Test, TestingModule } from '@nestjs/testing';
import { DefenseScheduleService } from '../services/defense-schedule.service';
import { PrismaService } from '../../prisma/prisma.service';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { CreateScheduleDto, TimeSlotDto } from '../dto/create-schedule.dto';
import { InsertBreakDto } from '../dto/insert-break.dto';
import { SwapSessionsDto } from '../dto/swap-sessions.dto';
import { ReorderSessionsDto } from '../dto/reorder-sessions.dto';

describe('DefenseScheduleService', () => {
  let service: DefenseScheduleService;
  let prismaService: PrismaService;

  const mockDefense = {
    id: 'defense-123',
    title: 'Test Defense',
    startDate: new Date('2024-06-15T09:00:00Z'),
    endDate: new Date('2024-06-15T17:00:00Z'),
    userId: 'user-123',
    sessions: [],
  };

  const mockGroups = [
    {
      id: 'group-1',
      name: 'Group 1',
      members: [{ id: 'student-1', firstname: 'Alice', lastname: 'Smith' }],
    },
    {
      id: 'group-2',
      name: 'Group 2',
      members: [{ id: 'student-2', firstname: 'Bob', lastname: 'Johnson' }],
    },
  ];

  const mockSession = {
    id: 'session-1',
    startTime: new Date('2024-06-15T09:00:00Z'),
    endTime: new Date('2024-06-15T09:20:00Z'),
    location: 'Room 101',
    defenseId: 'defense-123',
    groupId: 'group-1',
    order: 1,
    group: mockGroups[0],
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DefenseScheduleService,
        {
          provide: PrismaService,
          useValue: {
            defense: {
              findUnique: jest.fn(),
              update: jest.fn(),
            },
            defenseSession: {
              create: jest.fn(),
              findMany: jest.fn(),
              findUnique: jest.fn(),
              update: jest.fn(),
              delete: jest.fn(),
              createMany: jest.fn(),
              deleteMany: jest.fn(),
            },
            group: {
              findMany: jest.fn(),
            },
            $transaction: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<DefenseScheduleService>(DefenseScheduleService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  describe('createSchedule', () => {
    const createDto: CreateScheduleDto = {
      startDateTime: '2024-06-15T09:00:00Z',
      durationPerGroup: 20,
      breakBetweenGroups: 5,
      defaultLocation: 'Room 101',
    };

    it('should create schedule with duration mode', async () => {
      jest.spyOn(prismaService.defense, 'findUnique').mockResolvedValue({
        ...mockDefense,
        groups: mockGroups,
      } as any);
      jest
        .spyOn(prismaService.defenseSession, 'createMany')
        .mockResolvedValue({ count: 2 } as any);
      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue([mockSession] as any);

      const result = await service.createSchedule('defense-123', createDto);

      expect(result).toEqual([mockSession]);
      expect(prismaService.defenseSession.createMany).toHaveBeenCalledWith({
        data: expect.arrayContaining([
          expect.objectContaining({
            defenseId: 'defense-123',
            groupId: 'group-1',
            location: 'Room 101',
            order: 1,
          }),
        ]),
      });
    });

    it('should create schedule with manual time slots', async () => {
      const manualSlots: TimeSlotDto[] = [
        {
          startTime: '2024-06-15T09:00:00Z',
          endTime: '2024-06-15T09:20:00Z',
          groupId: 'group-1',
          location: 'Room 101',
        },
        {
          startTime: '2024-06-15T09:30:00Z',
          endTime: '2024-06-15T09:50:00Z',
          groupId: 'group-2',
          location: 'Room 102',
        },
      ];

      const dtoWithSlots = { ...createDto, timeSlots: manualSlots };
      jest
        .spyOn(prismaService.defense, 'findUnique')
        .mockResolvedValue(mockDefense as any);
      jest
        .spyOn(prismaService.defenseSession, 'createMany')
        .mockResolvedValue({ count: 2 } as any);
      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue([mockSession] as any);

      const result = await service.createSchedule('defense-123', dtoWithSlots);

      expect(result).toEqual([mockSession]);
      expect(prismaService.defenseSession.createMany).toHaveBeenCalledWith({
        data: expect.arrayContaining([
          expect.objectContaining({
            startTime: new Date('2024-06-15T09:00:00Z'),
            endTime: new Date('2024-06-15T09:20:00Z'),
            groupId: 'group-1',
            location: 'Room 101',
          }),
        ]),
      });
    });

    it('should throw NotFoundException when defense does not exist', async () => {
      jest.spyOn(prismaService.defense, 'findUnique').mockResolvedValue(null);

      await expect(
        service.createSchedule('defense-123', createDto),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw BadRequestException when no groups available', async () => {
      jest.spyOn(prismaService.defense, 'findUnique').mockResolvedValue({
        ...mockDefense,
        groups: [],
      } as any);

      await expect(
        service.createSchedule('defense-123', createDto),
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe('insertBreak', () => {
    const insertBreakDto: InsertBreakDto = {
      afterPosition: 1,
      duration: 30,
      label: 'Lunch Break',
    };

    it('should insert break successfully', async () => {
      const sessions = [
        { ...mockSession, order: 1 },
        { ...mockSession, id: 'session-2', order: 2 },
      ];

      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue(sessions as any);
      jest
        .spyOn(prismaService, '$transaction')
        .mockImplementation(async (callback) => {
          return await callback(prismaService);
        });
      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue(sessions as any);

      const result = await service.insertBreak('defense-123', insertBreakDto);

      expect(result).toEqual(sessions);
      expect(prismaService.$transaction).toHaveBeenCalled();
    });

    it('should throw NotFoundException when defense has no sessions', async () => {
      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue([]);

      await expect(
        service.insertBreak('defense-123', 1, { duration: 15, label: 'Break' }),
      ).rejects.toThrow(NotFoundException);
    });
  });

  describe('swapSessions', () => {
    const swapDto: SwapSessionsDto = {
      sessionId1: 'session-1',
      sessionId2: 'session-2',
    };

    it('should swap sessions successfully', async () => {
      const session1 = { ...mockSession, id: 'session-1', order: 1 };
      const session2 = { ...mockSession, id: 'session-2', order: 2 };

      jest
        .spyOn(prismaService.defenseSession, 'findUnique')
        .mockResolvedValueOnce(session1 as any)
        .mockResolvedValueOnce(session2 as any);

      jest
        .spyOn(prismaService, '$transaction')
        .mockImplementation(async (callback) => {
          return await callback(prismaService);
        });

      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue([session2, session1] as any);

      const result = await service.swapSessions('defense-123', swapDto);

      expect(result).toEqual([session2, session1]);
    });

    it('should throw NotFoundException when session does not exist', async () => {
      jest
        .spyOn(prismaService.defenseSession, 'findUnique')
        .mockResolvedValue(null);

      await expect(
        service.swapSessions(swapDto.sessionId1, swapDto.sessionId2),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw BadRequestException when sessions belong to different defenses', async () => {
      const session1 = { ...mockSession, defenseId: 'defense-123' };
      const session2 = { ...mockSession, defenseId: 'defense-456' };

      jest
        .spyOn(prismaService.defenseSession, 'findUnique')
        .mockResolvedValueOnce(session1 as any)
        .mockResolvedValueOnce(session2 as any);

      await expect(
        service.swapSessions(swapDto.sessionId1, swapDto.sessionId2),
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe('reorderSessions', () => {
    const reorderDto: ReorderSessionsDto = {
      sessionIds: ['session-2', 'session-1'],
      recalculateTimings: true,
    };

    it('should reorder sessions successfully', async () => {
      const sessions = [
        { ...mockSession, id: 'session-1', order: 1 },
        { ...mockSession, id: 'session-2', order: 2 },
      ];

      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue(sessions as any);
      jest
        .spyOn(prismaService, '$transaction')
        .mockImplementation(async (callback) => {
          return await callback(prismaService);
        });

      const result = await service.reorderSessions('defense-123', reorderDto.sessionIds);

      expect(result).toEqual(sessions);
      expect(prismaService.$transaction).toHaveBeenCalled();
    });

    it('should throw BadRequestException when session count mismatch', async () => {
      const sessions = [{ ...mockSession, id: 'session-1' }];
      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue(sessions as any);

      await expect(
        service.reorderSessions('defense-123', reorderDto.sessionIds),
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe('removeBreak', () => {
    it('should remove break session successfully', async () => {
      const breakSession = {
        ...mockSession,
        id: 'break-1',
        groupId: null,
        isBreak: true,
      };

      jest
        .spyOn(prismaService.defenseSession, 'findUnique')
        .mockResolvedValue(breakSession as any);
      jest
        .spyOn(prismaService, '$transaction')
        .mockImplementation(async (callback) => {
          return await callback(prismaService);
        });
      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue([mockSession] as any);

      const result = await service.removeBreak('defense-123', 'break-1');

      expect(result).toEqual([mockSession]);
    });

    it('should throw NotFoundException when break session does not exist', async () => {
      jest
        .spyOn(prismaService.defenseSession, 'findUnique')
        .mockResolvedValue(null);

      await expect(
        service.removeBreak('defense-123', 'break-1'),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw BadRequestException when trying to remove non-break session', async () => {
      jest.spyOn(prismaService.defenseSession, 'findUnique').mockResolvedValue({
        ...mockSession,
        groupId: 'group-1',
        isBreak: false,
      } as any);

      await expect(
        service.removeBreak('defense-123', 'session-1'),
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe('getSessionsByDefense', () => {
    it('should return sessions ordered by time', async () => {
      const sessions = [mockSession];
      jest
        .spyOn(prismaService.defenseSession, 'findMany')
        .mockResolvedValue(sessions as any);

      const result = await service.getSessionsByDefense('defense-123');

      expect(result).toEqual(sessions);
      expect(prismaService.defenseSession.findMany).toHaveBeenCalledWith({
        where: { defenseId: 'defense-123' },
        include: { group: { include: { members: true } } },
        orderBy: [{ order: 'asc' }, { startTime: 'asc' }],
      });
    });
  });

  describe('private helper methods', () => {
    describe('calculateScheduleTimes', () => {
      it('should skip weekends when configured', () => {
        const startDate = new Date('2024-06-14T09:00:00Z'); // Friday
        const durationPerGroup = 60;
        const breakBetweenGroups = 15;
        const groupCount = 5;
        const workingHoursStart = '09:00';
        const workingHoursEnd = '17:00';

        // Access private method via any cast for testing
        const result = (service as any).calculateScheduleTimes(
          startDate,
          durationPerGroup,
          breakBetweenGroups,
          groupCount,
          workingHoursStart,
          workingHoursEnd,
          true,
        );

        expect(result).toHaveLength(5);
        // Should not schedule on weekend (Saturday/Sunday)
        const hasWeekendSlots = result.some((slot) => {
          const day = slot.startTime.getDay();
          return day === 0 || day === 6; // Sunday or Saturday
        });
        expect(hasWeekendSlots).toBe(false);
      });
    });
  });
});
