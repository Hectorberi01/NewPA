export interface DefenseSlot {
  groupId: string;
  startTime: Date;
  endTime: Date;
  order: number;
  location?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  suggestions?: string[];
}

export interface ValidationError {
  type:
    | 'TIME_OVERLAP'
    | 'MISSING_GROUP'
    | 'INVALID_ORDER'
    | 'SCHEDULE_CONFLICT';
  message: string;
  sessionIds?: string[];
  groupIds?: string[];
}

export interface ValidationWarning {
  type: 'WEEKEND_SESSION' | 'OUTSIDE_HOURS' | 'LONG_BREAK';
  message: string;
  sessionIds?: string[];
}

export interface ScheduleConfig {
  durationPerGroup: number;
  breakBetweenGroups: number;
  workingHours?: { start: string; end: string };
  skipWeekends?: boolean;
}

export interface ProjectExportData {
  project: {
    name: string;
    teacher: string;
    promotion: string;
  };
  sessions: SessionExportData[];
  generatedAt: Date;
}

export interface SessionExportData {
  id: string;
  startTime: Date;
  endTime: Date;
  location?: string;
  order: number;
  group: {
    name: string;
    members: {
      firstname: string;
      lastname: string;
    }[];
  };
}

export interface AttendanceData {
  project: {
    name: string;
    promotion: string;
  };
  students: {
    firstname: string;
    lastname: string;
    groupName: string;
  }[];
  generatedAt: Date;
}

export interface ExportOptions {
  format?: 'simple' | 'detailed';
  landscape?: boolean;
  showLocation?: boolean;
  groupByDay?: boolean;
}

export interface PDFOptions {
  format: 'A4' | 'A3' | 'Letter';
  landscape?: boolean;
  margin: {
    top: string;
    bottom: string;
    left: string;
    right: string;
  };
}

export type ExportDocument =
  | 'schedule'
  | 'attendance-groups'
  | 'attendance-alphabetical';

// ============================================================================
// ENHANCED TYPE-SAFE INTERFACES FOR DEFENSE SESSIONS AND PROJECTS
// ============================================================================

// User data subset for defense sessions
export interface DefenseUser {
  firstname: string;
  lastname: string;
}

// Group member with user information
export interface DefenseGroupMember {
  id: string;
  groupId: string;
  userId: string;
  joinedAt: Date;
  user: DefenseUser;
}

// Group with members for defense sessions
export interface DefenseGroup {
  id: string;
  name: string;
  projectId: string;
  createdAt: Date;
  updatedAt: Date;
  members: DefenseGroupMember[];
}

// Defense session with full nested data
export interface DefenseSessionWithGroup {
  id: string;
  projectId: string;
  groupId: string;
  startTime: Date;
  endTime: Date;
  location: string | null;
  order: number;
  createdAt: Date;
  updatedAt: Date;
  group: DefenseGroup;
  // Additional properties for export compatibility
  label?: string;
}

// Simplified defense session (from Prisma without includes)
export interface DefenseSession {
  id: string;
  projectId: string;
  groupId: string;
  startTime: Date;
  endTime: Date;
  location: string | null;
  order: number;
  createdAt: Date;
  updatedAt: Date;
}

// Project with teacher and promotion data for exports
export interface ProjectWithTeacherPromotion {
  id: string;
  name: string;
  description: string | null;
  status: string;
  promotionId: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
  teacher: DefenseUser;
  promotion: {
    name: string;
  };
}

// Project with defense sessions for comprehensive data
export interface ProjectWithDefenseSessions {
  id: string;
  name: string;
  description: string | null;
  status: string;
  promotionId: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
  teacher?: DefenseUser;
  promotion?: {
    name: string;
  };
  defenseSessions: DefenseSessionWithGroup[];
  // Additional properties for export compatibility
  title?: string;
  startDate?: Date;
  endDate?: Date;
  location?: string;
}

// Project with groups for attendance data
export interface ProjectWithGroups {
  id: string;
  name: string;
  description: string | null;
  status: string;
  promotionId: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
  promotion: {
    name: string;
  };
  groups: DefenseGroup[];
}

// Schedule validation result with enhanced typing
export interface ScheduleValidationResult extends ValidationResult {
  totalDuration?: number;
  sessionCount?: number;
}

// Partial session for swap validation (only id, order, projectId)
export interface PartialDefenseSession {
  id: string;
  order: number;
  projectId: string;
}
