import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateScheduleDto } from './dto/create-schedule.dto';
import { UpdateSessionDto } from './dto/update-session.dto';
import { DefenseScheduleService } from './services/defense-schedule.service';
import { DefenseSession } from './interfaces/defense.interfaces';

@Injectable()
export class DefensesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scheduleService: DefenseScheduleService,
  ) {}

  async createSchedule(
    projectId: string,
    dto: CreateScheduleDto,
    teacherId: string,
  ) {
    // Valider que le projet existe et appartient à l'enseignant
    await this.validateProjectOwnership(projectId, teacherId);

    // Récupérer les groupes du projet
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        groups: {
          orderBy: { name: 'asc' },
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
      },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    if (project.groups.length === 0) {
      throw new BadRequestException('Aucun groupe trouvé pour ce projet');
    }

    // Supprimer l'ancien planning s'il existe
    await this.prisma.defenseSession.deleteMany({
      where: { projectId },
    });

    let sessions;

    if (dto.timeSlots && dto.timeSlots.length > 0) {
      // Mode créneaux manuels
      sessions = await this.scheduleService.createFromTimeSlots(
        projectId,
        dto.timeSlots,
        dto.defaultLocation,
      );
    } else {
      // Mode durée automatique
      const config = {
        durationPerGroup: dto.durationPerGroup || 20,
        breakBetweenGroups: dto.breakBetweenGroups || 5,
        workingHours:
          dto.workingHoursStart && dto.workingHoursEnd
            ? { start: dto.workingHoursStart, end: dto.workingHoursEnd }
            : undefined,
        skipWeekends: dto.skipWeekends ?? true,
      };

      sessions = await this.scheduleService.calculateSlots(
        new Date(dto.startDateTime),
        project.groups.map((g) => g.id),
        config,
        dto.defaultLocation,
      );
    }

    // Validation du planning généré
    const validation = await this.scheduleService.validateSchedule(sessions);

    return {
      sessions,
      totalDuration: this.calculateTotalDuration(sessions),
      conflictsDetected: !validation.isValid,
      validation: validation.isValid ? undefined : validation,
    };
  }

  async findByProject(projectId: string) {
    const sessions = await this.prisma.defenseSession.findMany({
      where: { projectId },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
      },
      orderBy: { order: 'asc' },
    });

    return sessions;
  }

  async findOne(sessionId: string) {
    const session = await this.prisma.defenseSession.findUnique({
      where: { id: sessionId },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
        project: { select: { name: true } },
      },
    });

    if (!session) {
      throw new NotFoundException('Session de soutenance non trouvée');
    }

    return session;
  }

  async updateSession(
    sessionId: string,
    dto: UpdateSessionDto,
    teacherId: string,
    projectId: string,
  ) {
    // Valider l'accès au projet
    await this.validateProjectOwnership(projectId, teacherId);

    const session = await this.prisma.defenseSession.findUnique({
      where: { id: sessionId },
      include: { project: true },
    });

    if (!session) {
      throw new NotFoundException('Session non trouvée');
    }

    if (session.projectId !== projectId) {
      throw new BadRequestException("Session n'appartient pas à ce projet");
    }

    // Valider les contraintes temporelles si changement d'horaire
    if (dto.startTime || dto.endTime) {
      const startTime = dto.startTime
        ? new Date(dto.startTime)
        : session.startTime;
      const endTime = dto.endTime ? new Date(dto.endTime) : session.endTime;

      if (startTime >= endTime) {
        throw new BadRequestException(
          "Heure de début doit être antérieure à l'heure de fin",
        );
      }

      // Vérifier les conflits avec autres sessions
      await this.checkTimeConflicts(sessionId, startTime, endTime, projectId);
    }

    const updatedSession = await this.prisma.defenseSession.update({
      where: { id: sessionId },
      data: {
        ...(dto.startTime && { startTime: new Date(dto.startTime) }),
        ...(dto.endTime && { endTime: new Date(dto.endTime) }),
        ...(dto.location !== undefined && { location: dto.location }),
        ...(dto.order && { order: dto.order }),
      },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } },
              },
            },
          },
        },
      },
    });

    return updatedSession;
  }

  async deleteSchedule(projectId: string, teacherId: string) {
    await this.validateProjectOwnership(projectId, teacherId);

    const deleteResult = await this.prisma.defenseSession.deleteMany({
      where: { projectId },
    });

    return {
      message: 'Planning supprimé avec succès',
      deletedCount: deleteResult.count,
    };
  }

  async validateProjectOwnership(projectId: string, teacherId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      select: { userId: true },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    if (project.userId !== teacherId) {
      throw new ForbiddenException('Accès non autorisé à ce projet');
    }
  }

  async getProjectInfo(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      select: { name: true },
    });

    if (!project) {
      throw new NotFoundException('Projet non trouvé');
    }

    return project;
  }

  private async checkTimeConflicts(
    sessionId: string,
    startTime: Date,
    endTime: Date,
    projectId: string,
  ) {
    const conflictingSessions = await this.prisma.defenseSession.findMany({
      where: {
        projectId,
        id: { not: sessionId },
        OR: [
          {
            AND: [
              { startTime: { lte: startTime } },
              { endTime: { gt: startTime } },
            ],
          },
          {
            AND: [
              { startTime: { lt: endTime } },
              { endTime: { gte: endTime } },
            ],
          },
          {
            AND: [
              { startTime: { gte: startTime } },
              { endTime: { lte: endTime } },
            ],
          },
        ],
      },
    });

    if (conflictingSessions.length > 0) {
      throw new BadRequestException('Conflit temporel avec une autre session');
    }
  }

  private calculateTotalDuration(sessions: DefenseSession[]): number {
    if (sessions.length === 0) return 0;

    const sortedSessions = sessions.sort((a, b) => a.order - b.order);
    const firstSession = sortedSessions[0];
    const lastSession = sortedSessions[sortedSessions.length - 1];

    return Math.round(
      (lastSession.endTime.getTime() - firstSession.startTime.getTime()) /
        (1000 * 60),
    );
  }

  /**
   * Récupère toutes les soutenances pour un étudiant
   */
  async findByStudent(studentId: string) {
    console.log(`[DEBUG] findByStudent defenses - studentId: ${studentId}`);
    
    // Vérifier que l'étudiant appartient à une promotion
    const studentPromotion = await this.prisma.studentPromotion.findFirst({
      where: { userId: studentId },
      include: { promotion: true },
    });

    if (!studentPromotion) {
      console.log(`[DEBUG] Aucune promotion trouvée pour l'étudiant ${studentId}`);
      throw new NotFoundException('Vous devez être assigné à une promotion pour voir les soutenances');
    }

    // Récupérer les groupes auxquels appartient l'étudiant
    const studentGroups = await this.prisma.groupMember.findMany({
      where: { userId: studentId },
      include: { group: true }
    });

    if (studentGroups.length === 0) {
      console.log(`[DEBUG] Aucun groupe trouvé pour l'étudiant ${studentId}`);
      return [];
    }

    const groupIds = studentGroups.map(sg => sg.group.id);

    // Récupérer toutes les sessions de soutenance pour les groupes de l'étudiant
    const sessions = await this.prisma.defenseSession.findMany({
      where: {
        groupId: { in: groupIds },
        project: {
          promotionId: studentPromotion.promotionId,
          status: 'VISIBLE'
        }
      },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { firstname: true, lastname: true } }
              }
            }
          }
        },
        project: {
          select: {
            id: true,
            name: true,
            description: true,
            teacher: { select: { firstname: true, lastname: true } }
          }
        }
      },
      orderBy: { startTime: 'asc' }
    });

    console.log(`[DEBUG] ${sessions.length} soutenances trouvées pour l'étudiant`);
    return sessions;
  }

  /**
   * Récupère une soutenance spécifique pour un étudiant avec vérifications d'accès
   */
  async findByIdForStudent(sessionId: string, studentId: string) {
    console.log(`[DEBUG] findByIdForStudent defense - sessionId: ${sessionId}, studentId: ${studentId}`);
    
    // Récupérer la session avec toutes les informations
    const session = await this.prisma.defenseSession.findUnique({
      where: { id: sessionId },
      include: {
        group: {
          include: {
            members: {
              include: {
                user: { select: { id: true, firstname: true, lastname: true, email: true } }
              }
            }
          }
        },
        project: {
          include: {
            teacher: { select: { firstname: true, lastname: true, email: true } },
            promotion: { select: { id: true, name: true } }
          }
        }
      }
    });

    if (!session) {
      console.log(`[DEBUG] Session de soutenance non trouvée: ${sessionId}`);
      throw new NotFoundException('La soutenance demandée n\'existe pas');
    }

    // Vérifier que l'étudiant fait partie du groupe concerné
    const isGroupMember = session.group.members.some(member => member.user.id === studentId);
    
    if (!isGroupMember) {
      console.log(`[DEBUG] L'étudiant ${studentId} ne fait pas partie du groupe ${session.group.id}`);
      throw new ForbiddenException('Vous n\'avez pas accès à cette soutenance car vous ne faites pas partie de ce groupe');
    }

    // Vérifier que le projet est visible
    if (session.project.status !== 'VISIBLE') {
      console.log(`[DEBUG] Projet non visible - statut: ${session.project.status}`);
      throw new ForbiddenException('Cette soutenance n\'est pas encore visible pour les étudiants');
    }

    console.log(`[DEBUG] Accès autorisé à la soutenance ${sessionId}`);
    return session;
  }
}
