import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Query,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiParam,
  ApiBody,
  ApiBearerAuth,
  ApiCreatedResponse,
  ApiOkResponse,
  ApiQuery,
} from '@nestjs/swagger';
import { DefensesService } from './defenses.service';
import { DefenseScheduleService } from './services/defense-schedule.service';
import { DefenseExportService } from './services/defense-export.service';
import { CreateScheduleDto } from './dto/create-schedule.dto';
import { ReorderSessionsDto } from './dto/reorder-sessions.dto';
import { SwapSessionsDto } from './dto/swap-sessions.dto';
import { InsertBreakDto } from './dto/insert-break.dto';
import { JWTAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TeacherGuard } from '../auth/guards/teacher.guard';
import { AuthenticatedRequest } from '../auth/types/auth.types';
import type { Response } from 'express';

@ApiTags('Defenses')
@Controller('defenses')
@UseGuards(JWTAuthGuard, TeacherGuard)
@ApiBearerAuth('JWT-auth')
export class DefensesController {
  constructor(
    private readonly defensesService: DefensesService,
    private readonly scheduleService: DefenseScheduleService,
    private readonly exportService: DefenseExportService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Récupérer toutes les défenses' })
  @ApiOkResponse({ description: 'Liste des défenses récupérée avec succès' })
  @ApiQuery({
    name: 'status',
    required: false,
    description: 'Filtrer par statut',
  })
  @ApiQuery({
    name: 'promotionId',
    required: false,
    description: 'Filtrer par promotion',
  })
  async findAll(
    @Req() req: AuthenticatedRequest,
    @Query('status') _status?: string,
    @Query('promotionId') _promotionId?: string,
  ) {
    // Utilise les méthodes existantes du service
    return await this.defensesService.findByProject(req.user.id);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Récupérer une défense par son ID' })
  @ApiParam({ name: 'id', description: 'ID de la défense' })
  @ApiOkResponse({ description: 'Défense récupérée avec succès' })
  async findOne(@Param('id') id: string) {
    return await this.defensesService.findOne(id);
  }

  // Schedule Management - utilisation de projectId
  @Post(':id/schedule')
  @ApiOperation({ summary: 'Générer un planning de soutenances' })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiBody({ type: CreateScheduleDto })
  @ApiCreatedResponse({ description: 'Planning créé avec succès' })
  async createSchedule(
    @Param('id') projectId: string,
    @Body() dto: CreateScheduleDto,
    @Req() req: AuthenticatedRequest,
  ) {
    return this.defensesService.createSchedule(projectId, dto, req.user.id);
  }

  @Get(':id/sessions')
  @ApiOperation({ summary: 'Lister les sessions de soutenance' })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiOkResponse({ description: 'Liste des sessions de soutenance' })
  async getSessions(@Param('id') projectId: string) {
    return this.defensesService.findByProject(projectId);
  }

  @Post(':id/sessions/reorder')
  @ApiOperation({ summary: "Réorganiser l'ordre des sessions" })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiBody({ type: ReorderSessionsDto })
  @ApiOkResponse({ description: 'Sessions réorganisées avec succès' })
  async reorderSessions(
    @Param('id') projectId: string,
    @Body() dto: ReorderSessionsDto,
    @Req() req: AuthenticatedRequest,
  ) {
    // Valider l'accès au projet d'abord
    await this.defensesService.validateProjectOwnership(projectId, req.user.id);
    return this.scheduleService.reorderSessions(projectId, dto.sessionIds);
  }

  @Post(':id/sessions/swap')
  @ApiOperation({ summary: 'Échanger deux sessions' })
  @ApiParam({ name: 'id', description: 'ID de la défense' })
  @ApiBody({ type: SwapSessionsDto })
  @ApiOkResponse({ description: 'Sessions échangées avec succès' })
  async swapSessions(
    @Param('id') defenseId: string,
    @Body() dto: SwapSessionsDto,
  ) {
    return this.scheduleService.swapSessions(dto.sessionId1, dto.sessionId2);
  }

  @Post(':id/breaks')
  @ApiOperation({ summary: 'Insérer une pause dans le planning' })
  @ApiParam({ name: 'id', description: 'ID de la défense' })
  @ApiBody({ type: InsertBreakDto })
  @ApiCreatedResponse({ description: 'Pause insérée avec succès' })
  async insertBreak(
    @Param('id') defenseId: string,
    @Body() dto: InsertBreakDto,
  ) {
    return this.scheduleService.insertBreak(defenseId, dto.afterPosition, {
      duration: dto.duration,
      label: dto.label,
    });
  }

  // Export Endpoints avec support des projectId
  @Get(':id/export/pdf')
  @ApiOperation({ summary: 'Exporter le planning en PDF' })
  @ApiParam({ name: 'id', description: 'ID du projet' })
  @ApiOkResponse({ description: 'Planning exporté en PDF' })
  @ApiQuery({
    name: 'type',
    required: false,
    description:
      "Type d'export (schedule, attendance-groups, attendance-alphabetical)",
  })
  async exportToPdf(
    @Param('id') projectId: string,
    @Query('type') type: string = 'schedule',
    @Res() res: Response,
  ) {
    let pdfBuffer: Buffer;
    let filename: string;

    switch (type) {
      case 'attendance-groups':
        pdfBuffer = await this.exportService.generateAttendanceSheetPDF(
          projectId,
          'groups',
        );
        filename = `emargement-groupes-${projectId}.pdf`;
        break;
      case 'attendance-alphabetical':
        pdfBuffer = await this.exportService.generateAttendanceSheetPDF(
          projectId,
          'alphabetical',
        );
        filename = `emargement-alphabetique-${projectId}.pdf`;
        break;
      default:
        pdfBuffer = await this.exportService.generateSchedulePDF(projectId);
        filename = `planning-soutenances-${projectId}.pdf`;
        break;
    }

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(pdfBuffer);
  }

  @Get(':id/export/excel')
  @ApiOperation({ summary: 'Exporter le planning en Excel' })
  @ApiParam({ name: 'id', description: 'ID de la défense' })
  @ApiOkResponse({ description: 'Planning exporté en Excel' })
  async exportToExcel(@Param('id') defenseId: string, @Res() res: Response) {
    const excelBuffer = await this.exportService.exportToExcel(defenseId);
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="planning-defense-${defenseId}.xlsx"`,
    );
    res.send(excelBuffer);
  }

  @Get(':id/export/ics')
  @ApiOperation({ summary: 'Exporter le planning en ICS (calendrier)' })
  @ApiParam({ name: 'id', description: 'ID de la défense' })
  @ApiOkResponse({ description: 'Planning exporté en ICS' })
  async exportToICS(@Param('id') defenseId: string, @Res() res: Response) {
    const icsContent = await this.exportService.exportToICS(defenseId);
    res.setHeader('Content-Type', 'text/calendar');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="planning-defense-${defenseId}.ics"`,
    );
    res.send(icsContent);
  }
}
