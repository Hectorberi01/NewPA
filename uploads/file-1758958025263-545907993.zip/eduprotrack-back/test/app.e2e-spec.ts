import { Test } from '@nestjs/testing';
import type { TestingModule } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';

describe('EduProTrack API (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    prisma = moduleFixture.get<PrismaService>(PrismaService);

    await app.init();
  });

  afterAll(async () => {
    await prisma.$disconnect();
    await app.close();
  });

  describe('Health Check', () => {
    it('/ (GET) should return health status', () => {
      return request(app.getHttpServer()).get('/').expect(200);
    });
  });

  describe('Authentication', () => {
    it('/auth/login (POST) should reject invalid credentials', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send({
          email: 'invalid@example.com',
          password: 'wrongpassword',
        })
        .expect(401);
    });

    it('/auth/login (POST) should reject missing credentials', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send({})
        .expect(400);
    });
  });

  describe('Students API', () => {
    it('/students (GET) should require authentication', () => {
      return request(app.getHttpServer()).get('/students').expect(401);
    });

    it('/students (POST) should require authentication', () => {
      return request(app.getHttpServer())
        .post('/students')
        .send({
          email: 'test@example.com',
          firstname: 'Test',
          lastname: 'User',
        })
        .expect(401);
    });
  });

  describe('Teachers API', () => {
    it('/teachers (GET) should require authentication', () => {
      return request(app.getHttpServer()).get('/teachers').expect(401);
    });

    it('/teachers/:id (GET) should require authentication', () => {
      return request(app.getHttpServer()).get('/teachers/1').expect(401);
    });
  });

  describe('Projects API', () => {
    it('/projects (GET) should require authentication', () => {
      return request(app.getHttpServer()).get('/projects').expect(401);
    });

    it('/projects (POST) should require authentication', () => {
      return request(app.getHttpServer())
        .post('/projects')
        .send({
          name: 'Test Project',
          description: 'Test Description',
        })
        .expect(401);
    });
  });

  describe('Groups API', () => {
    it('/groups (GET) should require authentication', () => {
      return request(app.getHttpServer()).get('/groups').expect(401);
    });

    it('/groups (POST) should require authentication', () => {
      return request(app.getHttpServer())
        .post('/groups')
        .send({
          name: 'Test Group',
          projectId: 'test-project-id',
        })
        .expect(401);
    });
  });

  describe('Deliverables API', () => {
    it('/deliverables (GET) should require authentication', () => {
      return request(app.getHttpServer()).get('/deliverables').expect(401);
    });

    it('/deliverables (POST) should require authentication', () => {
      return request(app.getHttpServer())
        .post('/deliverables')
        .send({
          name: 'Test Deliverable',
          description: 'Test Description',
          projectId: 'test-project-id',
        })
        .expect(401);
    });
  });

  describe('Reports API', () => {
    it('/reports (GET) should require authentication', () => {
      return request(app.getHttpServer()).get('/reports').expect(401);
    });

    it('/reports (POST) should require authentication', () => {
      return request(app.getHttpServer())
        .post('/reports')
        .send({
          title: 'Test Report',
          description: 'Test Description',
        })
        .expect(401);
    });
  });

  describe('Input Validation', () => {
    it('should reject malformed JSON', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send('invalid json')
        .set('Content-Type', 'application/json')
        .expect(400);
    });

    it('should handle large payloads appropriately', () => {
      const largePayload = {
        email: 'test@example.com',
        password: 'a'.repeat(10000), // Very long password
      };

      return request(app.getHttpServer())
        .post('/auth/login')
        .send(largePayload)
        .expect(401); // Should still process but reject invalid credentials
    });
  });

  describe('Content-Type Handling', () => {
    it('should handle missing Content-Type header', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send('email=test@example.com&password=test')
        .expect(400);
    });

    it('should handle incorrect Content-Type', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .set('Content-Type', 'text/plain')
        .send('some text')
        .expect(400);
    });
  });
});
