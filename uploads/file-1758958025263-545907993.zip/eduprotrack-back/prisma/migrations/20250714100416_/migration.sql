/*
  Warnings:

  - You are about to drop the column `penaltyPerHour` on the `Deliverable` table. All the data in the column will be lost.
  - You are about to alter the column `name` on the `Deliverable` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(100)`.
  - You are about to alter the column `description` on the `Deliverable` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(1000)`.
  - You are about to drop the column `lastLogin` on the `User` table. All the data in the column will be lost.
  - You are about to drop the column `hoursLate` on the `deliverable_submissions` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Deliverable" DROP COLUMN "penaltyPerHour",
ADD COLUMN     "latePenalty" DOUBLE PRECISION,
ADD COLUMN     "maxLateDays" INTEGER,
ALTER COLUMN "name" SET DATA TYPE VARCHAR(100),
ALTER COLUMN "description" SET DATA TYPE VARCHAR(1000),
ALTER COLUMN "deadline" SET DATA TYPE TIMESTAMPTZ;

-- AlterTable
ALTER TABLE "User" DROP COLUMN "lastLogin";

-- AlterTable
ALTER TABLE "deliverable_submissions" DROP COLUMN "hoursLate",
ADD COLUMN     "daysLate" INTEGER;

-- CreateIndex
CREATE INDEX "Deliverable_deadline_idx" ON "Deliverable"("deadline");
