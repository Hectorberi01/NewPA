/*
  Warnings:

  - A unique constraint covering the columns `[userId]` on the table `StudentPromotion` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "StudentPromotion_userId_promotionId_key";

-- CreateIndex
CREATE UNIQUE INDEX "StudentPromotion_userId_key" ON "StudentPromotion"("userId");
