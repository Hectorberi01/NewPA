/*
  Warnings:

  - You are about to drop the column `comments` on the `Evaluation` table. All the data in the column will be lost.
  - You are about to drop the column `groupId` on the `Evaluation` table. All the data in the column will be lost.
  - You are about to drop the column `isFinalized` on the `Evaluation` table. All the data in the column will be lost.
  - You are about to drop the column `createdById` on the `EvaluationGrid` table. All the data in the column will be lost.
  - You are about to drop the column `description` on the `EvaluationGrid` table. All the data in the column will be lost.
  - You are about to drop the column `comments` on the `EvaluationScore` table. All the data in the column will be lost.
  - You are about to drop the column `score` on the `EvaluationScore` table. All the data in the column will be lost.
  - You are about to drop the column `defenseWeight` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `deliverableWeight` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `hasDefense` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `hasDeliverable` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `hasReport` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `reportWeight` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `allowCode` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `allowImages` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `allowTables` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `content` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `deadline` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `dependsOn` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `isCompleted` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `isRequired` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `maxWords` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `minWords` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `reportId` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `template` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `wordCount` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the `Report` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `annotations` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `auto_save_status` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `comments` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `content_versions` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `section_locks` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[gridId,evaluatedEntityId]` on the table `Evaluation` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `evaluatedEntityId` to the `Evaluation` table without a default value. This is not possible if the table is not empty.
  - Added the required column `valueType` to the `EvaluationScore` table without a default value. This is not possible if the table is not empty.
  - Added the required column `projectReportId` to the `ReportSection` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "EvaluationStatus" AS ENUM ('DRAFT', 'FINALIZED', 'LOCKED');

-- CreateEnum
CREATE TYPE "ScoreValueType" AS ENUM ('NUMERIC', 'SCALE', 'BOOLEAN', 'TEXT');

-- DropForeignKey
ALTER TABLE "Evaluation" DROP CONSTRAINT "Evaluation_groupId_fkey";

-- DropForeignKey
ALTER TABLE "EvaluationGrid" DROP CONSTRAINT "EvaluationGrid_createdById_fkey";

-- DropForeignKey
ALTER TABLE "Report" DROP CONSTRAINT "Report_groupId_fkey";

-- DropForeignKey
ALTER TABLE "Report" DROP CONSTRAINT "Report_projectId_fkey";

-- DropForeignKey
ALTER TABLE "ReportSection" DROP CONSTRAINT "ReportSection_dependsOn_fkey";

-- DropForeignKey
ALTER TABLE "ReportSection" DROP CONSTRAINT "ReportSection_reportId_fkey";

-- DropForeignKey
ALTER TABLE "annotations" DROP CONSTRAINT "annotations_sectionId_fkey";

-- DropForeignKey
ALTER TABLE "annotations" DROP CONSTRAINT "annotations_teacherId_fkey";

-- DropForeignKey
ALTER TABLE "auto_save_status" DROP CONSTRAINT "auto_save_status_sectionId_fkey";

-- DropForeignKey
ALTER TABLE "auto_save_status" DROP CONSTRAINT "auto_save_status_userId_fkey";

-- DropForeignKey
ALTER TABLE "comments" DROP CONSTRAINT "comments_authorId_fkey";

-- DropForeignKey
ALTER TABLE "comments" DROP CONSTRAINT "comments_parentId_fkey";

-- DropForeignKey
ALTER TABLE "comments" DROP CONSTRAINT "comments_sectionId_fkey";

-- DropForeignKey
ALTER TABLE "content_versions" DROP CONSTRAINT "content_versions_authorId_fkey";

-- DropForeignKey
ALTER TABLE "content_versions" DROP CONSTRAINT "content_versions_sectionId_fkey";

-- DropForeignKey
ALTER TABLE "section_locks" DROP CONSTRAINT "section_locks_lockedBy_fkey";

-- DropForeignKey
ALTER TABLE "section_locks" DROP CONSTRAINT "section_locks_sectionId_fkey";

-- DropIndex
DROP INDEX "Evaluation_gridId_groupId_key";

-- DropIndex
DROP INDEX "ReportSection_deadline_idx";

-- AlterTable
ALTER TABLE "Deliverable" ADD COLUMN     "evaluationGridId" TEXT;

-- AlterTable
ALTER TABLE "Evaluation" DROP COLUMN "comments",
DROP COLUMN "groupId",
DROP COLUMN "isFinalized",
ADD COLUMN     "autoSaveEnabled" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "bonusScore" DOUBLE PRECISION DEFAULT 0,
ADD COLUMN     "calculatedScore" DOUBLE PRECISION,
ADD COLUMN     "entityType" TEXT NOT NULL DEFAULT 'GROUP',
ADD COLUMN     "evaluatedEntityId" TEXT NOT NULL,
ADD COLUMN     "finalizedAt" TIMESTAMP(3),
ADD COLUMN     "globalComments" TEXT,
ADD COLUMN     "isVisibleToStudents" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "lastAutoSaveAt" TIMESTAMP(3),
ADD COLUMN     "lastModifiedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "privateNotes" TEXT,
ADD COLUMN     "status" "EvaluationStatus" NOT NULL DEFAULT 'DRAFT',
ADD COLUMN     "totalScore" DOUBLE PRECISION;

-- AlterTable
ALTER TABLE "EvaluationGrid" DROP COLUMN "createdById",
DROP COLUMN "description";

-- AlterTable
ALTER TABLE "EvaluationScore" DROP COLUMN "comments",
DROP COLUMN "score",
ADD COLUMN     "booleanValue" BOOLEAN,
ADD COLUMN     "feedback" TEXT,
ADD COLUMN     "isBonus" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "normalizedScore" DOUBLE PRECISION,
ADD COLUMN     "numericValue" DOUBLE PRECISION,
ADD COLUMN     "scaleValue" TEXT,
ADD COLUMN     "textValue" TEXT,
ADD COLUMN     "valueType" "ScoreValueType" NOT NULL,
ADD COLUMN     "weight" DOUBLE PRECISION;

-- AlterTable
ALTER TABLE "Project" DROP COLUMN "defenseWeight",
DROP COLUMN "deliverableWeight",
DROP COLUMN "hasDefense",
DROP COLUMN "hasDeliverable",
DROP COLUMN "hasReport",
DROP COLUMN "reportWeight";

-- AlterTable
ALTER TABLE "ReportSection" DROP COLUMN "allowCode",
DROP COLUMN "allowImages",
DROP COLUMN "allowTables",
DROP COLUMN "content",
DROP COLUMN "deadline",
DROP COLUMN "dependsOn",
DROP COLUMN "isCompleted",
DROP COLUMN "isRequired",
DROP COLUMN "maxWords",
DROP COLUMN "minWords",
DROP COLUMN "reportId",
DROP COLUMN "template",
DROP COLUMN "wordCount",
ADD COLUMN     "projectReportId" TEXT NOT NULL,
ALTER COLUMN "title" SET DATA TYPE TEXT,
ALTER COLUMN "order" DROP DEFAULT,
ALTER COLUMN "description" SET DATA TYPE TEXT;

-- DropTable
DROP TABLE "Report";

-- DropTable
DROP TABLE "annotations";

-- DropTable
DROP TABLE "auto_save_status";

-- DropTable
DROP TABLE "comments";

-- DropTable
DROP TABLE "content_versions";

-- DropTable
DROP TABLE "section_locks";

-- DropEnum
DROP TYPE "AnnotationType";

-- DropEnum
DROP TYPE "CollaborationType";

-- DropEnum
DROP TYPE "ReportStatus";

-- DropEnum
DROP TYPE "SaveStatus";

-- CreateTable
CREATE TABLE "ProjectReport" (
    "id" TEXT NOT NULL,
    "projectId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "isEnabled" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ProjectReport_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GroupReportContent" (
    "id" TEXT NOT NULL,
    "projectReportId" TEXT NOT NULL,
    "sectionId" TEXT NOT NULL,
    "groupId" TEXT NOT NULL,
    "content" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'draft',
    "lastModifiedBy" TEXT,
    "lastModified" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "GroupReportContent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "evaluation_comments" (
    "id" TEXT NOT NULL,
    "evaluationId" TEXT NOT NULL,
    "criterionId" TEXT,
    "type" TEXT NOT NULL DEFAULT 'GENERAL',
    "content" TEXT NOT NULL,
    "isTemplate" BOOLEAN NOT NULL DEFAULT false,
    "templateName" TEXT,
    "order" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "evaluation_comments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ProjectReport_projectId_key" ON "ProjectReport"("projectId");

-- CreateIndex
CREATE UNIQUE INDEX "GroupReportContent_projectReportId_sectionId_groupId_key" ON "GroupReportContent"("projectReportId", "sectionId", "groupId");

-- CreateIndex
CREATE INDEX "evaluation_comments_evaluationId_idx" ON "evaluation_comments"("evaluationId");

-- CreateIndex
CREATE INDEX "evaluation_comments_criterionId_idx" ON "evaluation_comments"("criterionId");

-- CreateIndex
CREATE INDEX "Evaluation_status_idx" ON "Evaluation"("status");

-- CreateIndex
CREATE INDEX "Evaluation_evaluatorId_idx" ON "Evaluation"("evaluatorId");

-- CreateIndex
CREATE UNIQUE INDEX "Evaluation_gridId_evaluatedEntityId_key" ON "Evaluation"("gridId", "evaluatedEntityId");

-- CreateIndex
CREATE INDEX "EvaluationScore_criterionId_idx" ON "EvaluationScore"("criterionId");

-- AddForeignKey
ALTER TABLE "Deliverable" ADD CONSTRAINT "Deliverable_evaluationGridId_fkey" FOREIGN KEY ("evaluationGridId") REFERENCES "EvaluationGrid"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProjectReport" ADD CONSTRAINT "ProjectReport_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "Project"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReportSection" ADD CONSTRAINT "ReportSection_projectReportId_fkey" FOREIGN KEY ("projectReportId") REFERENCES "ProjectReport"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupReportContent" ADD CONSTRAINT "GroupReportContent_projectReportId_fkey" FOREIGN KEY ("projectReportId") REFERENCES "ProjectReport"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupReportContent" ADD CONSTRAINT "GroupReportContent_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "ReportSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupReportContent" ADD CONSTRAINT "GroupReportContent_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "Group"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupReportContent" ADD CONSTRAINT "GroupReportContent_lastModifiedBy_fkey" FOREIGN KEY ("lastModifiedBy") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Evaluation" ADD CONSTRAINT "Evaluation_evaluatedEntityId_fkey" FOREIGN KEY ("evaluatedEntityId") REFERENCES "Group"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evaluation_comments" ADD CONSTRAINT "evaluation_comments_evaluationId_fkey" FOREIGN KEY ("evaluationId") REFERENCES "Evaluation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evaluation_comments" ADD CONSTRAINT "evaluation_comments_criterionId_fkey" FOREIGN KEY ("criterionId") REFERENCES "EvaluationCriterion"("id") ON DELETE CASCADE ON UPDATE CASCADE;
