/*
  Warnings:

  - You are about to alter the column `title` on the `Report` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(200)`.
  - You are about to alter the column `title` on the `ReportSection` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(200)`.

*/
-- CreateEnum
CREATE TYPE "ReportStatus" AS ENUM ('DRAFT', 'PUBLISHED');

-- CreateEnum
CREATE TYPE "CollaborationType" AS ENUM ('INDIVIDUAL', 'GROUP');

-- DropForeignKey
ALTER TABLE "Report" DROP CONSTRAINT "Report_groupId_fkey";

-- AlterTable
ALTER TABLE "Report" ADD COLUMN     "allowModifications" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "collaborationType" "CollaborationType" NOT NULL DEFAULT 'INDIVIDUAL',
ADD COLUMN     "deadline" TIMESTAMPTZ,
ADD COLUMN     "description" VARCHAR(2000),
ADD COLUMN     "isPublished" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "status" "ReportStatus" NOT NULL DEFAULT 'DRAFT',
ALTER COLUMN "title" SET DATA TYPE VARCHAR(200),
ALTER COLUMN "groupId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "ReportSection" ADD COLUMN     "allowCode" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "allowImages" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "allowTables" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "deadline" TIMESTAMPTZ,
ADD COLUMN     "dependsOn" TEXT,
ADD COLUMN     "description" VARCHAR(1000),
ADD COLUMN     "isCompleted" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "isRequired" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "maxWords" INTEGER,
ADD COLUMN     "minWords" INTEGER,
ADD COLUMN     "template" TEXT,
ADD COLUMN     "wordCount" INTEGER NOT NULL DEFAULT 0,
ALTER COLUMN "title" SET DATA TYPE VARCHAR(200);

-- CreateIndex
CREATE INDEX "Report_deadline_idx" ON "Report"("deadline");

-- CreateIndex
CREATE INDEX "Report_status_idx" ON "Report"("status");

-- CreateIndex
CREATE INDEX "ReportSection_order_idx" ON "ReportSection"("order");

-- CreateIndex
CREATE INDEX "ReportSection_deadline_idx" ON "ReportSection"("deadline");

-- AddForeignKey
ALTER TABLE "Report" ADD CONSTRAINT "Report_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "Group"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReportSection" ADD CONSTRAINT "ReportSection_dependsOn_fkey" FOREIGN KEY ("dependsOn") REFERENCES "ReportSection"("id") ON DELETE SET NULL ON UPDATE CASCADE;
