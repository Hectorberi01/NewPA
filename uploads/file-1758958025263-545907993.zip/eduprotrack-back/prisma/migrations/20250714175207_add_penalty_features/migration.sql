-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "SubmissionStatus" ADD VALUE 'VALIDATION_FAILED';
ALTER TYPE "SubmissionStatus" ADD VALUE 'NOT_SUBMITTED';

-- AlterTable
ALTER TABLE "Deliverable" ADD COLUMN     "maxPenalty" DOUBLE PRECISION;

-- CreateTable
CREATE TABLE "penalty_adjustments" (
    "id" TEXT NOT NULL,
    "submissionId" TEXT NOT NULL,
    "adjustedById" TEXT NOT NULL,
    "originalPenalty" DOUBLE PRECISION NOT NULL,
    "newPenalty" DOUBLE PRECISION NOT NULL,
    "reason" TEXT NOT NULL,
    "adjustedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "penalty_adjustments_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "penalty_adjustments" ADD CONSTRAINT "penalty_adjustments_submissionId_fkey" FOREIGN KEY ("submissionId") REFERENCES "deliverable_submissions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "penalty_adjustments" ADD CONSTRAINT "penalty_adjustments_adjustedById_fkey" FOREIGN KEY ("adjustedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
