/*
  Warnings:

  - You are about to drop the column `createdById` on the `EvaluationGrid` table. All the data in the column will be lost.
  - You are about to drop the column `description` on the `EvaluationGrid` table. All the data in the column will be lost.
  - You are about to drop the column `defenseWeight` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `deliverableWeight` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `hasDefense` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `hasDeliverable` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `hasReport` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `reportWeight` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `allowCode` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `allowImages` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `allowTables` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `content` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `deadline` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `dependsOn` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `isCompleted` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `isRequired` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `maxWords` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `minWords` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `reportId` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `template` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the column `wordCount` on the `ReportSection` table. All the data in the column will be lost.
  - You are about to drop the `Report` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `annotations` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `auto_save_status` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `comments` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `content_versions` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `section_locks` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `projectReportId` to the `ReportSection` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "EvaluationGrid" DROP CONSTRAINT "EvaluationGrid_createdById_fkey";

-- DropForeignKey
ALTER TABLE "Report" DROP CONSTRAINT "Report_groupId_fkey";

-- DropForeignKey
ALTER TABLE "Report" DROP CONSTRAINT "Report_projectId_fkey";

-- DropForeignKey
ALTER TABLE "ReportSection" DROP CONSTRAINT "ReportSection_dependsOn_fkey";

-- DropForeignKey
ALTER TABLE "ReportSection" DROP CONSTRAINT "ReportSection_reportId_fkey";

-- DropForeignKey
ALTER TABLE "annotations" DROP CONSTRAINT "annotations_sectionId_fkey";

-- DropForeignKey
ALTER TABLE "annotations" DROP CONSTRAINT "annotations_teacherId_fkey";

-- DropForeignKey
ALTER TABLE "auto_save_status" DROP CONSTRAINT "auto_save_status_sectionId_fkey";

-- DropForeignKey
ALTER TABLE "auto_save_status" DROP CONSTRAINT "auto_save_status_userId_fkey";

-- DropForeignKey
ALTER TABLE "comments" DROP CONSTRAINT "comments_authorId_fkey";

-- DropForeignKey
ALTER TABLE "comments" DROP CONSTRAINT "comments_parentId_fkey";

-- DropForeignKey
ALTER TABLE "comments" DROP CONSTRAINT "comments_sectionId_fkey";

-- DropForeignKey
ALTER TABLE "content_versions" DROP CONSTRAINT "content_versions_authorId_fkey";

-- DropForeignKey
ALTER TABLE "content_versions" DROP CONSTRAINT "content_versions_sectionId_fkey";

-- DropForeignKey
ALTER TABLE "section_locks" DROP CONSTRAINT "section_locks_lockedBy_fkey";

-- DropForeignKey
ALTER TABLE "section_locks" DROP CONSTRAINT "section_locks_sectionId_fkey";

-- DropIndex
DROP INDEX "ReportSection_deadline_idx";

-- AlterTable
ALTER TABLE "Deliverable" ADD COLUMN     "evaluationGridId" TEXT;

-- AlterTable
ALTER TABLE "EvaluationGrid" DROP COLUMN "createdById",
DROP COLUMN "description";

-- AlterTable
ALTER TABLE "Project" DROP COLUMN "defenseWeight",
DROP COLUMN "deliverableWeight",
DROP COLUMN "hasDefense",
DROP COLUMN "hasDeliverable",
DROP COLUMN "hasReport",
DROP COLUMN "reportWeight";

-- AlterTable
ALTER TABLE "ReportSection" DROP COLUMN "allowCode",
DROP COLUMN "allowImages",
DROP COLUMN "allowTables",
DROP COLUMN "content",
DROP COLUMN "deadline",
DROP COLUMN "dependsOn",
DROP COLUMN "isCompleted",
DROP COLUMN "isRequired",
DROP COLUMN "maxWords",
DROP COLUMN "minWords",
DROP COLUMN "reportId",
DROP COLUMN "template",
DROP COLUMN "wordCount",
ADD COLUMN     "projectReportId" TEXT NOT NULL,
ALTER COLUMN "title" SET DATA TYPE TEXT,
ALTER COLUMN "order" DROP DEFAULT,
ALTER COLUMN "description" SET DATA TYPE TEXT;

-- DropTable
DROP TABLE "Report";

-- DropTable
DROP TABLE "annotations";

-- DropTable
DROP TABLE "auto_save_status";

-- DropTable
DROP TABLE "comments";

-- DropTable
DROP TABLE "content_versions";

-- DropTable
DROP TABLE "section_locks";

-- DropEnum
DROP TYPE "AnnotationType";

-- DropEnum
DROP TYPE "CollaborationType";

-- DropEnum
DROP TYPE "ReportStatus";

-- DropEnum
DROP TYPE "SaveStatus";

-- CreateTable
CREATE TABLE "ProjectReport" (
    "id" TEXT NOT NULL,
    "projectId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "isEnabled" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ProjectReport_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GroupReportContent" (
    "id" TEXT NOT NULL,
    "projectReportId" TEXT NOT NULL,
    "sectionId" TEXT NOT NULL,
    "groupId" TEXT NOT NULL,
    "content" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'draft',
    "lastModifiedBy" TEXT,
    "lastModified" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "GroupReportContent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ProjectReport_projectId_key" ON "ProjectReport"("projectId");

-- CreateIndex
CREATE UNIQUE INDEX "GroupReportContent_projectReportId_sectionId_groupId_key" ON "GroupReportContent"("projectReportId", "sectionId", "groupId");

-- AddForeignKey
ALTER TABLE "Deliverable" ADD CONSTRAINT "Deliverable_evaluationGridId_fkey" FOREIGN KEY ("evaluationGridId") REFERENCES "EvaluationGrid"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProjectReport" ADD CONSTRAINT "ProjectReport_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "Project"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReportSection" ADD CONSTRAINT "ReportSection_projectReportId_fkey" FOREIGN KEY ("projectReportId") REFERENCES "ProjectReport"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupReportContent" ADD CONSTRAINT "GroupReportContent_projectReportId_fkey" FOREIGN KEY ("projectReportId") REFERENCES "ProjectReport"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupReportContent" ADD CONSTRAINT "GroupReportContent_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "ReportSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupReportContent" ADD CONSTRAINT "GroupReportContent_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES "Group"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GroupReportContent" ADD CONSTRAINT "GroupReportContent_lastModifiedBy_fkey" FOREIGN KEY ("lastModifiedBy") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
