/*
  Warnings:

  - You are about to drop the column `comments` on the `Evaluation` table. All the data in the column will be lost.
  - You are about to drop the column `groupId` on the `Evaluation` table. All the data in the column will be lost.
  - You are about to drop the column `isFinalized` on the `Evaluation` table. All the data in the column will be lost.
  - You are about to drop the column `comments` on the `EvaluationScore` table. All the data in the column will be lost.
  - You are about to drop the column `score` on the `EvaluationScore` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[gridId,evaluatedEntityId]` on the table `Evaluation` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `evaluatedEntityId` to the `Evaluation` table without a default value. This is not possible if the table is not empty.
  - Added the required column `valueType` to the `EvaluationScore` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "EvaluationStatus" AS ENUM ('DRAFT', 'FINALIZED', 'LOCKED');

-- CreateEnum
CREATE TYPE "ScoreValueType" AS ENUM ('NUMERIC', 'SCALE', 'BOOLEAN', 'TEXT');

-- DropForeignKey
ALTER TABLE "Evaluation" DROP CONSTRAINT "Evaluation_groupId_fkey";

-- DropIndex
DROP INDEX "Evaluation_gridId_groupId_key";

-- AlterTable
ALTER TABLE "Evaluation" DROP COLUMN "comments",
DROP COLUMN "groupId",
DROP COLUMN "isFinalized",
ADD COLUMN     "autoSaveEnabled" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "bonusScore" DOUBLE PRECISION DEFAULT 0,
ADD COLUMN     "calculatedScore" DOUBLE PRECISION,
ADD COLUMN     "entityType" TEXT NOT NULL DEFAULT 'GROUP',
ADD COLUMN     "evaluatedEntityId" TEXT NOT NULL,
ADD COLUMN     "finalizedAt" TIMESTAMP(3),
ADD COLUMN     "globalComments" TEXT,
ADD COLUMN     "isVisibleToStudents" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "lastAutoSaveAt" TIMESTAMP(3),
ADD COLUMN     "lastModifiedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "privateNotes" TEXT,
ADD COLUMN     "status" "EvaluationStatus" NOT NULL DEFAULT 'DRAFT',
ADD COLUMN     "totalScore" DOUBLE PRECISION;

-- AlterTable
ALTER TABLE "EvaluationScore" DROP COLUMN "comments",
DROP COLUMN "score",
ADD COLUMN     "booleanValue" BOOLEAN,
ADD COLUMN     "feedback" TEXT,
ADD COLUMN     "isBonus" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "normalizedScore" DOUBLE PRECISION,
ADD COLUMN     "numericValue" DOUBLE PRECISION,
ADD COLUMN     "scaleValue" TEXT,
ADD COLUMN     "textValue" TEXT,
ADD COLUMN     "valueType" "ScoreValueType" NOT NULL,
ADD COLUMN     "weight" DOUBLE PRECISION;

-- CreateTable
CREATE TABLE "evaluation_comments" (
    "id" TEXT NOT NULL,
    "evaluationId" TEXT NOT NULL,
    "criterionId" TEXT,
    "type" TEXT NOT NULL DEFAULT 'GENERAL',
    "content" TEXT NOT NULL,
    "isTemplate" BOOLEAN NOT NULL DEFAULT false,
    "templateName" TEXT,
    "order" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "evaluation_comments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "evaluation_comments_evaluationId_idx" ON "evaluation_comments"("evaluationId");

-- CreateIndex
CREATE INDEX "evaluation_comments_criterionId_idx" ON "evaluation_comments"("criterionId");

-- CreateIndex
CREATE INDEX "Evaluation_status_idx" ON "Evaluation"("status");

-- CreateIndex
CREATE INDEX "Evaluation_evaluatorId_idx" ON "Evaluation"("evaluatorId");

-- CreateIndex
CREATE UNIQUE INDEX "Evaluation_gridId_evaluatedEntityId_key" ON "Evaluation"("gridId", "evaluatedEntityId");

-- CreateIndex
CREATE INDEX "EvaluationScore_criterionId_idx" ON "EvaluationScore"("criterionId");

-- AddForeignKey
ALTER TABLE "Evaluation" ADD CONSTRAINT "Evaluation_evaluatedEntityId_fkey" FOREIGN KEY ("evaluatedEntityId") REFERENCES "Group"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evaluation_comments" ADD CONSTRAINT "evaluation_comments_evaluationId_fkey" FOREIGN KEY ("evaluationId") REFERENCES "Evaluation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "evaluation_comments" ADD CONSTRAINT "evaluation_comments_criterionId_fkey" FOREIGN KEY ("criterionId") REFERENCES "EvaluationCriterion"("id") ON DELETE CASCADE ON UPDATE CASCADE;
