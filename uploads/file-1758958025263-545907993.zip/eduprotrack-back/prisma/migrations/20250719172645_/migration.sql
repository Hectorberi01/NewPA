/*
  Warnings:

  - A unique constraint covering the columns `[userId,promotionId]` on the table `StudentPromotion` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "StudentPromotion_userId_key";

-- CreateIndex
CREATE UNIQUE INDEX "StudentPromotion_userId_promotionId_key" ON "StudentPromotion"("userId", "promotionId");
