-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "hasDefense" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "hasDeliverable" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "hasReport" BOOLEAN NOT NULL DEFAULT false;
