-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "defenseWeight" DOUBLE PRECISION,
ADD COLUMN     "deliverableWeight" DOUBLE PRECISION,
ADD COLUMN     "reportWeight" DOUBLE PRECISION;
