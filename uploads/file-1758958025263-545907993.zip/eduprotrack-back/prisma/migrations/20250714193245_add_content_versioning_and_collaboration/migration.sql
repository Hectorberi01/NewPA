-- CreateEnum
CREATE TYPE "SaveStatus" AS ENUM ('SAVED', 'PENDING', 'ERROR');

-- CreateEnum
CREATE TYPE "AnnotationType" AS ENUM ('PRAISE', 'SUGGESTION', 'CORRECTION', 'PRIVATE_NOTE');

-- CreateTable
CREATE TABLE "content_versions" (
    "id" TEXT NOT NULL,
    "sectionId" TEXT NOT NULL,
    "version" INTEGER NOT NULL,
    "htmlContent" TEXT NOT NULL,
    "markdownContent" TEXT NOT NULL,
    "wordCount" INTEGER NOT NULL DEFAULT 0,
    "authorId" TEXT NOT NULL,
    "baseVersion" INTEGER,
    "changesSummary" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "content_versions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "section_locks" (
    "id" TEXT NOT NULL,
    "sectionId" TEXT NOT NULL,
    "lockedBy" TEXT NOT NULL,
    "lockedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "section_locks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "comments" (
    "id" TEXT NOT NULL,
    "sectionId" TEXT NOT NULL,
    "authorId" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "position" JSONB,
    "isResolved" BOOLEAN NOT NULL DEFAULT false,
    "parentId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "comments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "annotations" (
    "id" TEXT NOT NULL,
    "sectionId" TEXT NOT NULL,
    "teacherId" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "type" "AnnotationType" NOT NULL,
    "position" JSONB,
    "isPrivate" BOOLEAN NOT NULL DEFAULT false,
    "score" DOUBLE PRECISION,
    "maxScore" DOUBLE PRECISION,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "annotations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "auto_save_status" (
    "id" TEXT NOT NULL,
    "sectionId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "status" "SaveStatus" NOT NULL DEFAULT 'SAVED',
    "lastSaveAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastContent" TEXT,
    "pendingChanges" BOOLEAN NOT NULL DEFAULT false,
    "errorMessage" TEXT,
    "retryCount" INTEGER NOT NULL DEFAULT 0,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "auto_save_status_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "content_versions_sectionId_createdAt_idx" ON "content_versions"("sectionId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "content_versions_sectionId_version_key" ON "content_versions"("sectionId", "version");

-- CreateIndex
CREATE UNIQUE INDEX "section_locks_sectionId_key" ON "section_locks"("sectionId");

-- CreateIndex
CREATE INDEX "section_locks_expiresAt_idx" ON "section_locks"("expiresAt");

-- CreateIndex
CREATE INDEX "comments_sectionId_createdAt_idx" ON "comments"("sectionId", "createdAt");

-- CreateIndex
CREATE INDEX "annotations_sectionId_type_idx" ON "annotations"("sectionId", "type");

-- CreateIndex
CREATE INDEX "annotations_teacherId_createdAt_idx" ON "annotations"("teacherId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "auto_save_status_sectionId_key" ON "auto_save_status"("sectionId");

-- CreateIndex
CREATE INDEX "auto_save_status_status_updatedAt_idx" ON "auto_save_status"("status", "updatedAt");

-- AddForeignKey
ALTER TABLE "content_versions" ADD CONSTRAINT "content_versions_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "ReportSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "content_versions" ADD CONSTRAINT "content_versions_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "section_locks" ADD CONSTRAINT "section_locks_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "ReportSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "section_locks" ADD CONSTRAINT "section_locks_lockedBy_fkey" FOREIGN KEY ("lockedBy") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "comments" ADD CONSTRAINT "comments_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "ReportSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "comments" ADD CONSTRAINT "comments_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "comments" ADD CONSTRAINT "comments_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES "comments"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "annotations" ADD CONSTRAINT "annotations_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "ReportSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "annotations" ADD CONSTRAINT "annotations_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "auto_save_status" ADD CONSTRAINT "auto_save_status_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "ReportSection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "auto_save_status" ADD CONSTRAINT "auto_save_status_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
