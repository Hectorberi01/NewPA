import {
  PrismaClient,
  Role,
  ProjectStatus,
  GroupFormationMode,
  EvaluationType,
  CriterionScope,
  EvaluationStatus,
  ScoreValueType,
  DeliverableType,
  SubmissionStatus,
} from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Début du seeding...');

  // Nettoyer les données existantes
  await prisma.evaluationScore.deleteMany();
  await prisma.evaluationComment.deleteMany();
  await prisma.evaluation.deleteMany();
  await prisma.evaluationCriterion.deleteMany();
  await prisma.evaluationGrid.deleteMany();
  await prisma.deliverableSubmission.deleteMany();
  await prisma.deliverable.deleteMany();
  await prisma.groupReportContent.deleteMany();
  await prisma.reportSection.deleteMany();
  await prisma.projectReport.deleteMany();
  await prisma.groupMember.deleteMany();
  await prisma.group.deleteMany();
  await prisma.project.deleteMany();
  await prisma.studentPromotion.deleteMany();
  await prisma.teacherPromotion.deleteMany();
  await prisma.promotion.deleteMany();
  await prisma.user.deleteMany();

  console.log('🗑️ Données existantes supprimées');

  // Hash du mot de passe par défaut
  const defaultPassword = await bcrypt.hash('password123', 10);

  // 👨‍🏫 CRÉER DES ENSEIGNANTS
  const teachers = await Promise.all([
    prisma.user.create({
      data: {
        email: 'john.doe@school.com',
        firstname: 'John',
        lastname: 'Doe',
        role: Role.TEACHER,
        password: defaultPassword,
      },
    }),
    prisma.user.create({
      data: {
        email: 'jane.smith@school.com',
        firstname: 'Jane',
        lastname: 'Smith',
        role: Role.TEACHER,
        password: defaultPassword,
      },
    }),
    prisma.user.create({
      data: {
        email: 'pierre.martin@school.com',
        firstname: 'Pierre',
        lastname: 'Martin',
        role: Role.TEACHER,
        password: defaultPassword,
      },
    }),
  ]);

  console.log('👨‍🏫 3 enseignants créés');

  // 🎓 CRÉER DES PROMOTIONS
  const promotions = await Promise.all([
    prisma.promotion.create({
      data: {
        name: 'Master 2 Informatique 2024',
      },
    }),
    prisma.promotion.create({
      data: {
        name: 'Licence 3 Web Development 2024',
      },
    }),
    prisma.promotion.create({
      data: {
        name: 'Master 1 Data Science 2024',
      },
    }),
  ]);

  console.log('🎓 3 promotions créées');

  // 🔗 ASSOCIER ENSEIGNANTS AUX PROMOTIONS
  await Promise.all([
    // John Doe enseigne en Master 2 Info et Licence 3 Web
    prisma.teacherPromotion.create({
      data: { userId: teachers[0].id, promotionId: promotions[0].id },
    }),
    prisma.teacherPromotion.create({
      data: { userId: teachers[0].id, promotionId: promotions[1].id },
    }),
    // Pierre Martin enseigne en Master 1 Data Science
    prisma.teacherPromotion.create({
      data: { userId: teachers[0].id, promotionId: promotions[2].id },
    }),
  ]);

  console.log('🔗 Associations enseignants-promotions créées');

  // 🎓 CRÉER DES ÉTUDIANTS
  const studentsData = [
    // Master 2 Informatique (25 étudiants)
    {
      firstname: 'Alice',
      lastname: 'Johnson',
      email: 'alice.johnson@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Bob',
      lastname: 'Wilson',
      email: 'bob.wilson@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Charlie',
      lastname: 'Brown',
      email: 'charlie.brown@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Diana',
      lastname: 'Davis',
      email: 'diana.davis@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Eve',
      lastname: 'Miller',
      email: 'eve.miller@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Frank',
      lastname: 'Garcia',
      email: 'frank.garcia@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Grace',
      lastname: 'Rodriguez',
      email: 'grace.rodriguez@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Henry',
      lastname: 'Martinez',
      email: 'henry.martinez@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Ivy',
      lastname: 'Anderson',
      email: 'ivy.anderson@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Jack',
      lastname: 'Taylor',
      email: 'jack.taylor@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Kate',
      lastname: 'Thomas',
      email: 'kate.thomas@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Liam',
      lastname: 'Jackson',
      email: 'liam.jackson@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Mia',
      lastname: 'White',
      email: 'mia.white@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Noah',
      lastname: 'Harris',
      email: 'noah.harris@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Olivia',
      lastname: 'Clark',
      email: 'olivia.clark@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Peter',
      lastname: 'Lewis',
      email: 'peter.lewis@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Quinn',
      lastname: 'Lee',
      email: 'quinn.lee@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Ruby',
      lastname: 'Walker',
      email: 'ruby.walker@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Sam',
      lastname: 'Hall',
      email: 'sam.hall@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Tina',
      lastname: 'Allen',
      email: 'tina.allen@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Uma',
      lastname: 'Young',
      email: 'uma.young@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Victor',
      lastname: 'King',
      email: 'victor.king@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Wendy',
      lastname: 'Wright',
      email: 'wendy.wright@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Xavier',
      lastname: 'Lopez',
      email: 'xavier.lopez@student.com',
      promotionIndex: 0,
    },
    {
      firstname: 'Yara',
      lastname: 'Hill',
      email: 'yara.hill@student.com',
      promotionIndex: 0,
    },

    // Licence 3 Web (18 étudiants)
    {
      firstname: 'Antoine',
      lastname: 'Dubois',
      email: 'antoine.dubois@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Beatrice',
      lastname: 'Leroy',
      email: 'beatrice.leroy@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Cedric',
      lastname: 'Moreau',
      email: 'cedric.moreau@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Delphine',
      lastname: 'Simon',
      email: 'delphine.simon@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Etienne',
      lastname: 'Laurent',
      email: 'etienne.laurent@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Fabienne',
      lastname: 'Lefebvre',
      email: 'fabienne.lefebvre@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Guillaume',
      lastname: 'Roux',
      email: 'guillaume.roux@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Helene',
      lastname: 'Fournier',
      email: 'helene.fournier@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Igor',
      lastname: 'Girard',
      email: 'igor.girard@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Julie',
      lastname: 'Bonnet',
      email: 'julie.bonnet@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Kevin',
      lastname: 'Dupont',
      email: 'kevin.dupont@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Laure',
      lastname: 'Lambert',
      email: 'laure.lambert@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Marc',
      lastname: 'Fontaine',
      email: 'marc.fontaine@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Nathalie',
      lastname: 'Robin',
      email: 'nathalie.robin@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Olivier',
      lastname: 'Morel',
      email: 'olivier.morel@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Pauline',
      lastname: 'Muller',
      email: 'pauline.muller@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Quentin',
      lastname: 'Robert',
      email: 'quentin.robert@student.com',
      promotionIndex: 1,
    },
    {
      firstname: 'Rachel',
      lastname: 'Petit',
      email: 'rachel.petit@student.com',
      promotionIndex: 1,
    },

    // Master 1 Data Science (12 étudiants)
    {
      firstname: 'Alex',
      lastname: 'Chen',
      email: 'alex.chen@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Bella',
      lastname: 'Patel',
      email: 'bella.patel@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Carlos',
      lastname: 'Santos',
      email: 'carlos.santos@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Daria',
      lastname: 'Kowalski',
      email: 'daria.kowalski@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Emil',
      lastname: 'Andersson',
      email: 'emil.andersson@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Fatima',
      lastname: 'Al-Rashid',
      email: 'fatima.rashid@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Giorgio',
      lastname: 'Rossi',
      email: 'giorgio.rossi@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Hannah',
      lastname: 'Kim',
      email: 'hannah.kim@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Ivan',
      lastname: 'Petrov',
      email: 'ivan.petrov@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Jasmine',
      lastname: 'Singh',
      email: 'jasmine.singh@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Klaus',
      lastname: 'Mueller',
      email: 'klaus.mueller@student.com',
      promotionIndex: 2,
    },
    {
      firstname: 'Luna',
      lastname: 'Nakamura',
      email: 'luna.nakamura@student.com',
      promotionIndex: 2,
    },
  ];

  // Créer les étudiants
  interface StudentWithPromotion {
    id: string;
    email: string;
    firstname: string;
    lastname: string;
    role: Role;
    password: string;
    createdAt: Date;
    updatedAt: Date;
    promotionIndex: number;
  }

  const students: StudentWithPromotion[] = [];
  for (const studentData of studentsData) {
    const student = await prisma.user.create({
      data: {
        email: studentData.email,
        firstname: studentData.firstname,
        lastname: studentData.lastname,
        role: Role.STUDENT,
        password: defaultPassword,
      },
    });
    students.push({ ...student, promotionIndex: studentData.promotionIndex });
  }

  console.log(`🎓 ${students.length} étudiants créés`);

  // Associer étudiants aux promotions
  for (const student of students) {
    await prisma.studentPromotion.create({
      data: {
        userId: student.id,
        promotionId: promotions[student.promotionIndex].id,
      },
    });
  }

  console.log('🔗 Associations étudiants-promotions créées');

  // 📋 CRÉER DES PROJETS DE TEST (tous reliés à John Doe)
  const projects = await Promise.all([
    // Projet 1: Mode FREE - Master 2 Info (25 étudiants)
    prisma.project.create({
      data: {
        name: 'Projet Web App E-commerce',
        description:
          "Développement d'une application e-commerce complète avec React et Node.js",
        status: ProjectStatus.VISIBLE,
        userId: teachers[0].id, // John Doe
        promotionId: promotions[0].id, // Master 2 Info
        groupFormationMode: GroupFormationMode.FREE,
        minGroupSize: 3,
        maxGroupSize: 5,
        groupDeadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Dans 7 jours
      },
    }),

    // Projet 2: Mode MANUAL - Master 2 Info
    prisma.project.create({
      data: {
        name: 'Projet Machine Learning',
        description: "Développement d'un modèle de reconnaissance d'images",
        status: ProjectStatus.VISIBLE,
        userId: teachers[0].id, // John Doe
        promotionId: promotions[0].id, // Master 2 Info
        groupFormationMode: GroupFormationMode.MANUAL,
        minGroupSize: 2,
        maxGroupSize: 4,
      },
    }),

    // Projet 3: Mode FREE - Licence 3 Web (18 étudiants)
    prisma.project.create({
      data: {
        name: 'Site Web Portfolio',
        description: "Création d'un site portfolio responsive avec animations",
        status: ProjectStatus.VISIBLE,
        userId: teachers[0].id, // John Doe
        promotionId: promotions[1].id, // Licence 3 Web
        groupFormationMode: GroupFormationMode.FREE,
        minGroupSize: 2,
        maxGroupSize: 3,
        groupDeadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // Dans 3 jours
      },
    }),

    // Projet 4: Mode RANDOM - Master 1 Data Science
    prisma.project.create({
      data: {
        name: 'Analyse de Données Marketing',
        description: 'Analyse prédictive des comportements consommateurs',
        status: ProjectStatus.VISIBLE,
        userId: teachers[0].id, // John Doe
        promotionId: promotions[2].id, // Master 1 Data Science
        groupFormationMode: GroupFormationMode.RANDOM,
        minGroupSize: 3,
        maxGroupSize: 4,
      },
    }),

    // Projet 5: Mode FREE avec deadline passée (pour test auto-assignment)
    prisma.project.create({
      data: {
        name: 'Projet Mobile App',
        description: 'Application mobile de gestion de tâches',
        status: ProjectStatus.VISIBLE,
        userId: teachers[0].id, // John Doe
        promotionId: promotions[1].id, // Licence 3 Web
        groupFormationMode: GroupFormationMode.FREE,
        minGroupSize: 2,
        maxGroupSize: 3,
        groupDeadline: new Date(Date.now() - 24 * 60 * 60 * 1000), // Hier (deadline passée)
      },
    }),

    // Projet 6: PROJET PUBLIÉ avec mode MANUAL pour drag & drop
    prisma.project.create({
      data: {
        name: 'Projet DevOps & CI/CD',
        description: 'Mise en place d\'une chaîne DevOps complète avec Docker, Kubernetes et Jenkins',
        status: ProjectStatus.VISIBLE, // Projet publié
        userId: teachers[0].id, // John Doe
        promotionId: promotions[0].id, // Master 2 Info
        groupFormationMode: GroupFormationMode.MANUAL, // Pour drag & drop
        minGroupSize: 3,
        maxGroupSize: 4,
      },
    }),

    // Projet 7: PROJET PRÊT POUR SOUTENANCES
    prisma.project.create({
      data: {
        name: 'Projet Architecture Microservices',
        description: 'Conception et implémentation d\'une architecture microservices complète',
        status: ProjectStatus.VISIBLE,
        userId: teachers[0].id, // John Doe
        promotionId: promotions[0].id, // Master 2 Info
        groupFormationMode: GroupFormationMode.MANUAL,
        minGroupSize: 4,
        maxGroupSize: 5,
      },
    }),
  ]);

  console.log('📋 7 projets de test créés');

  // 👥 CRÉER QUELQUES GROUPES EXISTANTS

  // Groupes pour le projet ML (mode MANUAL)
  const mlProject = projects[1];
  const master2Students = students
    .filter((s) => s.promotionIndex === 0)
    .slice(0, 8);

  const mlGroups = await Promise.all([
    prisma.group.create({
      data: {
        name: 'Groupe Alpha',
        projectId: mlProject.id,
      },
    }),
    prisma.group.create({
      data: {
        name: 'Groupe Beta',
        projectId: mlProject.id,
      },
    }),
  ]);

  // Ajouter des membres aux groupes ML
  await Promise.all([
    // Groupe Alpha
    prisma.groupMember.create({
      data: { groupId: mlGroups[0].id, userId: master2Students[0].id },
    }),
    prisma.groupMember.create({
      data: { groupId: mlGroups[0].id, userId: master2Students[1].id },
    }),
    prisma.groupMember.create({
      data: { groupId: mlGroups[0].id, userId: master2Students[2].id },
    }),
    // Groupe Beta
    prisma.groupMember.create({
      data: { groupId: mlGroups[1].id, userId: master2Students[3].id },
    }),
    prisma.groupMember.create({
      data: { groupId: mlGroups[1].id, userId: master2Students[4].id },
    }),
  ]);

  // Créer groupes pour le projet Portfolio (mode FREE, VISIBLE)
  const portfolioProject = projects[2];
  const licence3Students = students.filter((s) => s.promotionIndex === 1);

  const portfolioGroups = await Promise.all([
    prisma.group.create({
      data: {
        name: 'Groupe React Masters',
        projectId: portfolioProject.id,
      },
    }),
    prisma.group.create({
      data: {
        name: 'Groupe Design Pros',
        projectId: portfolioProject.id,
      },
    }),
    prisma.group.create({
      data: {
        name: 'Groupe Full Stack',
        projectId: portfolioProject.id,
      },
    }),
  ]);

  // Ajouter des membres aux groupes Portfolio
  await Promise.all([
    // Groupe React Masters
    prisma.groupMember.create({
      data: {
        groupId: portfolioGroups[0].id,
        userId: licence3Students[0].id, // Antoine
      },
    }),
    prisma.groupMember.create({
      data: {
        groupId: portfolioGroups[0].id,
        userId: licence3Students[1].id, // Beatrice
      },
    }),
    // Groupe Design Pros
    prisma.groupMember.create({
      data: {
        groupId: portfolioGroups[1].id,
        userId: licence3Students[2].id, // Cedric
      },
    }),
    prisma.groupMember.create({
      data: {
        groupId: portfolioGroups[1].id,
        userId: licence3Students[3].id, // Delphine
      },
    }),
    // Groupe Full Stack
    prisma.groupMember.create({
      data: {
        groupId: portfolioGroups[2].id,
        userId: licence3Students[4].id, // Etienne
      },
    }),
    prisma.groupMember.create({
      data: {
        groupId: portfolioGroups[2].id,
        userId: licence3Students[5].id, // Fabienne
      },
    }),
  ]);

  // Créer groupe pour le projet Data Marketing
  const dataProject = projects[3];
  const dataStudents = students.filter((s) => s.promotionIndex === 2).slice(0, 6);

  const dataGroups = await Promise.all([
    prisma.group.create({
      data: {
        name: 'Groupe Data Analytics',
        projectId: dataProject.id,
      },
    }),
    prisma.group.create({
      data: {
        name: 'Groupe AI Insights',
        projectId: dataProject.id,
      },
    }),
  ]);

  // Ajouter des membres aux groupes Data
  await Promise.all([
    // Groupe Data Analytics
    prisma.groupMember.create({
      data: { groupId: dataGroups[0].id, userId: dataStudents[0].id }, // Alex
    }),
    prisma.groupMember.create({
      data: { groupId: dataGroups[0].id, userId: dataStudents[1].id }, // Bella
    }),
    prisma.groupMember.create({
      data: { groupId: dataGroups[0].id, userId: dataStudents[2].id }, // Carlos
    }),
    // Groupe AI Insights
    prisma.groupMember.create({
      data: { groupId: dataGroups[1].id, userId: dataStudents[3].id }, // Daria
    }),
    prisma.groupMember.create({
      data: { groupId: dataGroups[1].id, userId: dataStudents[4].id }, // Emil
    }),
    prisma.groupMember.create({
      data: { groupId: dataGroups[1].id, userId: dataStudents[5].id }, // Fatima
    }),
  ]);

  // 📝 PROJET DEVOPS (Projet 6) - Mode MANUAL pour drag & drop
  const devopsProject = projects[5];
  const master2StudentsForDevops = students
    .filter((s) => s.promotionIndex === 0)
    .slice(8, 20); // Prendre les étudiants 9-20

  // Créer des groupes vides et partiellement remplis pour tester le drag & drop
  const devopsGroups = await Promise.all([
    prisma.group.create({
      data: {
        name: 'Groupe DevOps Alpha',
        projectId: devopsProject.id,
      },
    }),
    prisma.group.create({
      data: {
        name: 'Groupe CI/CD Beta',
        projectId: devopsProject.id,
      },
    }),
    prisma.group.create({
      data: {
        name: 'Groupe Cloud Gamma',
        projectId: devopsProject.id,
      },
    }),
    prisma.group.create({
      data: {
        name: 'Groupe Monitoring Delta',
        projectId: devopsProject.id,
      },
    }),
  ]);

  // Ajouter seulement quelques membres pour tester le drag & drop
  await Promise.all([
    // Groupe DevOps Alpha - 2 membres (incomplet)
    prisma.groupMember.create({
      data: { groupId: devopsGroups[0].id, userId: master2StudentsForDevops[0].id }, // Ivy
    }),
    prisma.groupMember.create({
      data: { groupId: devopsGroups[0].id, userId: master2StudentsForDevops[1].id }, // Jack
    }),
    // Groupe CI/CD Beta - 1 membre (très incomplet)
    prisma.groupMember.create({
      data: { groupId: devopsGroups[1].id, userId: master2StudentsForDevops[2].id }, // Kate
    }),
    // Groupe Cloud Gamma - Complet (4 membres)
    prisma.groupMember.create({
      data: { groupId: devopsGroups[2].id, userId: master2StudentsForDevops[3].id }, // Liam
    }),
    prisma.groupMember.create({
      data: { groupId: devopsGroups[2].id, userId: master2StudentsForDevops[4].id }, // Mia
    }),
    prisma.groupMember.create({
      data: { groupId: devopsGroups[2].id, userId: master2StudentsForDevops[5].id }, // Noah
    }),
    prisma.groupMember.create({
      data: { groupId: devopsGroups[2].id, userId: master2StudentsForDevops[6].id }, // Olivia
    }),
    // Groupe Monitoring Delta - Vide (pour tester drag & drop)
  ]);

  // 🎯 PROJET MICROSERVICES (Projet 7) - Prêt pour soutenances
  const microservicesProject = projects[6];
  const master2StudentsForMicro = students
    .filter((s) => s.promotionIndex === 0)
    .slice(20, 25); // Derniers étudiants Master 2

  const microservicesGroups = await Promise.all([
    prisma.group.create({
      data: {
        name: 'Groupe Microservices Pro',
        projectId: microservicesProject.id,
      },
    }),
  ]);

  // Ajouter tous les membres (groupe complet pour soutenance)
  await Promise.all([
    prisma.groupMember.create({
      data: { groupId: microservicesGroups[0].id, userId: master2StudentsForMicro[0].id }, // Peter
    }),
    prisma.groupMember.create({
      data: { groupId: microservicesGroups[0].id, userId: master2StudentsForMicro[1].id }, // Quinn
    }),
    prisma.groupMember.create({
      data: { groupId: microservicesGroups[0].id, userId: master2StudentsForMicro[2].id }, // Ruby
    }),
    prisma.groupMember.create({
      data: { groupId: microservicesGroups[0].id, userId: master2StudentsForMicro[3].id }, // Sam
    }),
    prisma.groupMember.create({
      data: { groupId: microservicesGroups[0].id, userId: master2StudentsForMicro[4].id }, // Tina
    }),
  ]);

  console.log('👥 Groupes de test créés');

  // 📝 CRÉER DES GRILLES D'ÉVALUATION
  console.log('📝 Création des grilles d\'évaluation...');

  // Grille 1: Évaluation de livrable pour le projet Web E-commerce
  const deliverableGrid1 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Livrable - Application Web E-commerce',
      projectId: projects[0].id, // Projet Web E-commerce
      type: EvaluationType.DELIVERABLE,
      weight: 0.5, // 50% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille livrable Web E-commerce
  const deliverableCriteria1 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid1.id,
        name: 'Architecture et qualité du code',
        description: 'Structure du projet, respect des bonnes pratiques, lisibilité',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid1.id,
        name: 'Fonctionnalités e-commerce',
        description: 'Catalogue produits, panier, commandes, paiement',
        maxPoints: 20,
        weight: 35,
        scope: CriterionScope.GROUP,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid1.id,
        name: 'Interface et UX',
        description: 'Design, ergonomie, responsivité, accessibilité',
        maxPoints: 20,
        weight: 25,
        scope: CriterionScope.GROUP,
        order: 3,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid1.id,
        name: 'Tests et déploiement',
        description: 'Tests unitaires/intégration, documentation, déploiement',
        maxPoints: 20,
        weight: 10,
        scope: CriterionScope.GROUP,
        order: 4,
      },
    }),
  ]);

  // Grille 2: Évaluation de livrable pour le projet ML
  const deliverableGrid2 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Livrable - Machine Learning',
      projectId: projects[1].id, // Projet ML
      type: EvaluationType.DELIVERABLE,
      weight: 0.6, // 60% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille livrable ML
  const deliverableCriteria2 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid2.id,
        name: 'Préparation des données',
        description: 'Nettoyage, normalisation, augmentation des données',
        maxPoints: 20,
        weight: 25,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid2.id,
        name: 'Architecture du modèle',
        description: 'Choix du modèle, hyperparamètres, optimisation',
        maxPoints: 20,
        weight: 35,
        scope: CriterionScope.GROUP,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid2.id,
        name: 'Performances et validation',
        description: 'Métriques, validation croisée, comparaison modèles',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.GROUP,
        order: 3,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid2.id,
        name: 'Documentation technique',
        description: 'Code commenté, notebook explicatif, README',
        maxPoints: 20,
        weight: 10,
        scope: CriterionScope.GROUP,
        order: 4,
      },
    }),
  ]);

  // Grille 3: Évaluation de soutenance pour le projet ML
  const defenseGrid1 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Soutenance - Machine Learning',
      projectId: projects[1].id, // Projet ML
      type: EvaluationType.DEFENSE,
      weight: 0.4, // 40% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille soutenance ML
  const defenseCriteria1 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: defenseGrid1.id,
        name: 'Présentation orale',
        description: 'Clarté, structure, respect du temps, supports visuels',
        maxPoints: 20,
        weight: 40,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: defenseGrid1.id,
        name: 'Maîtrise technique individuelle',
        description: 'Compréhension des algorithmes, justification des choix',
        maxPoints: 20,
        weight: 35,
        scope: CriterionScope.INDIVIDUAL,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: defenseGrid1.id,
        name: 'Réponses aux questions',
        description: 'Pertinence, précision, capacité d\'adaptation',
        maxPoints: 20,
        weight: 25,
        scope: CriterionScope.INDIVIDUAL,
        order: 3,
      },
    }),
  ]);

  // Grille 4: Évaluation de rapport pour le projet Portfolio
  const reportGrid1 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Rapport - Portfolio Web',
      projectId: projects[2].id, // Projet Portfolio
      type: EvaluationType.REPORT,
      weight: 0.3, // 30% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille rapport Portfolio
  const reportCriteria1 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: reportGrid1.id,
        name: 'Structure et rédaction',
        description: 'Organisation, orthographe, syntaxe, présentation',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: reportGrid1.id,
        name: 'Analyse technique',
        description: 'Choix technologiques, architecture, performances',
        maxPoints: 20,
        weight: 40,
        scope: CriterionScope.GROUP,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: reportGrid1.id,
        name: 'Contribution individuelle',
        description: 'Participation personnelle, réflexion critique',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.INDIVIDUAL,
        order: 3,
      },
    }),
  ]);

  // Grille 5: Évaluation de livrable pour le projet Data Marketing
  const deliverableGrid3 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Livrable - Analyse Data Marketing',
      projectId: projects[3].id, // Projet Data Marketing
      type: EvaluationType.DELIVERABLE,
      weight: 0.7, // 70% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille livrable Data Marketing
  const deliverableCriteria3 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid3.id,
        name: 'Collecte et nettoyage des données',
        description: 'Sources de données, qualité, préparation',
        maxPoints: 20,
        weight: 25,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid3.id,
        name: 'Analyse exploratoire',
        description: 'Visualisations, insights, tendances identifiées',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.GROUP,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid3.id,
        name: 'Modèles prédictifs',
        description: 'Choix des modèles, validation, performances',
        maxPoints: 20,
        weight: 35,
        scope: CriterionScope.GROUP,
        order: 3,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid3.id,
        name: 'Recommandations business',
        description: 'Conclusions, plan d\'action, impact métier',
        maxPoints: 20,
        weight: 10,
        scope: CriterionScope.GROUP,
        order: 4,
      },
    }),
  ]);

  // Grille 6: Évaluation de livrable pour le projet DevOps
  const deliverableGrid4 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Livrable - DevOps & CI/CD',
      projectId: projects[5].id, // Projet DevOps
      type: EvaluationType.DELIVERABLE,
      weight: 0.6, // 60% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille livrable DevOps
  const deliverableCriteria4 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid4.id,
        name: 'Infrastructure et conteneurisation',
        description: 'Docker, Kubernetes, orchestration des services',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid4.id,
        name: 'Pipeline CI/CD',
        description: 'Jenkins, GitLab CI, automatisation des déploiements',
        maxPoints: 20,
        weight: 35,
        scope: CriterionScope.GROUP,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid4.id,
        name: 'Monitoring et observabilité',
        description: 'Métriques, logs, alertes, dashboard',
        maxPoints: 20,
        weight: 25,
        scope: CriterionScope.GROUP,
        order: 3,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid4.id,
        name: 'Sécurité et bonnes pratiques',
        description: 'Sécurisation du pipeline, gestion des secrets',
        maxPoints: 20,
        weight: 10,
        scope: CriterionScope.GROUP,
        order: 4,
      },
    }),
  ]);

  // Grille 7: Évaluation de rapport pour le projet DevOps
  const reportGrid2 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Rapport - DevOps Documentation',
      projectId: projects[5].id, // Projet DevOps
      type: EvaluationType.REPORT,
      weight: 0.4, // 40% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille rapport DevOps
  const reportCriteria2 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: reportGrid2.id,
        name: 'Documentation technique',
        description: 'Architecture, procédures, guides d\'installation',
        maxPoints: 20,
        weight: 40,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: reportGrid2.id,
        name: 'Analyse comparative',
        description: 'Comparaison des outils, justification des choix',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.GROUP,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: reportGrid2.id,
        name: 'Retour d\'expérience individuel',
        description: 'Apprentissages personnels, difficultés rencontrées',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.INDIVIDUAL,
        order: 3,
      },
    }),
  ]);

  // Grille 8: Évaluation de soutenance pour le projet Microservices
  const defenseGrid2 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Soutenance - Architecture Microservices',
      projectId: projects[6].id, // Projet Microservices
      type: EvaluationType.DEFENSE,
      weight: 0.5, // 50% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille soutenance Microservices
  const defenseCriteria2 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: defenseGrid2.id,
        name: 'Présentation de l\'architecture',
        description: 'Clarté des diagrammes, explication des patterns',
        maxPoints: 20,
        weight: 40,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: defenseGrid2.id,
        name: 'Démonstration technique',
        description: 'Fonctionnement des services, scalabilité',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.GROUP,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: defenseGrid2.id,
        name: 'Expertise individuelle',
        description: 'Maîtrise des concepts, capacité d\'adaptation',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.INDIVIDUAL,
        order: 3,
      },
    }),
  ]);

  // Grille 9: Évaluation de livrable pour le projet Microservices
  const deliverableGrid5 = await prisma.evaluationGrid.create({
    data: {
      name: 'Grille Livrable - Architecture Microservices',
      projectId: projects[6].id, // Projet Microservices
      type: EvaluationType.DELIVERABLE,
      weight: 0.5, // 50% de la note finale
      isTemplate: false,
    },
  });

  // Critères pour la grille livrable Microservices
  const deliverableCriteria5 = await Promise.all([
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid5.id,
        name: 'Conception de l\'architecture',
        description: 'Patterns microservices, découpage des services',
        maxPoints: 20,
        weight: 30,
        scope: CriterionScope.GROUP,
        order: 1,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid5.id,
        name: 'Implémentation des services',
        description: 'Qualité du code, API REST, communication inter-services',
        maxPoints: 20,
        weight: 35,
        scope: CriterionScope.GROUP,
        order: 2,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid5.id,
        name: 'Gestion des données',
        description: 'Base de données par service, cohérence des données',
        maxPoints: 20,
        weight: 25,
        scope: CriterionScope.GROUP,
        order: 3,
      },
    }),
    prisma.evaluationCriterion.create({
      data: {
        gridId: deliverableGrid5.id,
        name: 'Tests et déploiement',
        description: 'Tests d\'intégration, orchestration, scalabilité',
        maxPoints: 20,
        weight: 10,
        scope: CriterionScope.GROUP,
        order: 4,
      },
    }),
  ]);

  console.log('📝 Grilles d\'évaluation créées');

  // 📦 CRÉER DES LIVRABLES
  console.log('📦 Création des livrables...');

  const deliverables = await Promise.all([
    // Livrable 1: Projet Web E-commerce
    prisma.deliverable.create({
      data: {
        name: 'Application E-commerce v1.0',
        description: 'Version finale de l\'application e-commerce avec toutes les fonctionnalités',
        projectId: projects[0].id,
        type: DeliverableType.ARCHIVE,
        deadline: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000), // Dans 21 jours
        allowLateSubmission: true,
        latePenalty: 2.0, // 2 points par jour de retard
        maxLateDays: 7,
        maxPenalty: 14.0,
        maxFileSize: 100 * 1024 * 1024, // 100MB
        allowedExtensions: ['.zip', '.tar.gz'],
        requiredFiles: ['README.md', 'package.json', 'docker-compose.yml'],
        evaluationGridId: deliverableGrid1.id,
      },
    }),
    // Livrable 2: Projet ML - Code et modèle
    prisma.deliverable.create({
      data: {
        name: 'Modèle ML + Code source',
        description: 'Modèle entraîné, code source et notebook d\'analyse',
        projectId: projects[1].id,
        type: DeliverableType.GIT_LINK,
        deadline: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // Dans 14 jours
        allowLateSubmission: false,
        requiredFiles: ['model.pkl', 'train.py', 'analysis.ipynb', 'requirements.txt', 'README.md'],
        evaluationGridId: deliverableGrid2.id,
      },
    }),
    // Livrable 3: Projet Portfolio
    prisma.deliverable.create({
      data: {
        name: 'Site Portfolio Responsive',
        description: 'Site portfolio personnel avec animations et responsive design',
        projectId: projects[2].id,
        type: DeliverableType.GIT_LINK,
        deadline: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // Dans 10 jours
        allowLateSubmission: true,
        latePenalty: 1.5,
        maxLateDays: 5,
        requiredFiles: ['index.html', 'style.css', 'script.js', 'README.md'],
      },
    }),
    // Livrable 4: Projet Data Marketing
    prisma.deliverable.create({
      data: {
        name: 'Analyse Marketing Prédictive',
        description: 'Analyse complète avec modèles prédictifs et recommandations',
        projectId: projects[3].id,
        type: DeliverableType.ARCHIVE,
        deadline: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000), // Dans 18 jours
        allowLateSubmission: true,
        latePenalty: 1.0,
        maxLateDays: 3,
        maxFileSize: 200 * 1024 * 1024, // 200MB
        allowedExtensions: ['.zip'],
        requiredFiles: ['analysis.ipynb', 'data.csv', 'models/', 'report.pdf'],
        evaluationGridId: deliverableGrid3.id,
      },
    }),
    // Livrable 5: Projet DevOps - Infrastructure
    prisma.deliverable.create({
      data: {
        name: 'Infrastructure DevOps Complète',
        description: 'Chaîne DevOps avec CI/CD, monitoring et déploiement automatisé',
        projectId: projects[5].id, // Projet DevOps
        type: DeliverableType.GIT_LINK,
        deadline: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000), // Dans 25 jours
        allowLateSubmission: true,
        latePenalty: 2.5,
        maxLateDays: 5,
        requiredFiles: ['docker-compose.yml', 'Jenkinsfile', 'k8s/', 'monitoring/', 'README.md'],
        evaluationGridId: deliverableGrid4.id,
      },
    }),
    // Livrable 6: Projet Microservices - Architecture
    prisma.deliverable.create({
      data: {
        name: 'Architecture Microservices Complète',
        description: 'Ensemble de microservices avec API Gateway, service discovery et monitoring',
        projectId: projects[6].id, // Projet Microservices
        type: DeliverableType.GIT_LINK,
        deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // Dans 30 jours
        allowLateSubmission: false, // Pas de retard pour soutenance
        requiredFiles: ['docker-compose.yml', 'services/', 'api-gateway/', 'database/', 'docs/'],
        evaluationGridId: deliverableGrid5.id,
      },
    }),
  ]);

  console.log('📦 Livrables créés');

  // 📋 CRÉER DES RAPPORTS DE PROJET
  console.log('📋 Création des rapports de projet...');

  // Rapport pour le projet Portfolio
  const portfolioReport = await prisma.projectReport.create({
    data: {
      projectId: projects[2].id, // Projet Portfolio
      title: 'Rapport de Conception Portfolio',
      description: 'Rapport détaillé sur les choix de conception et l\'implémentation',
    },
  });

  // Sections du rapport Portfolio
  const portfolioSections = await Promise.all([
    prisma.reportSection.create({
      data: {
        projectReportId: portfolioReport.id,
        title: 'Introduction et Objectifs',
        description: 'Présentation du projet et des objectifs visés',
        order: 1,
      },
    }),
    prisma.reportSection.create({
      data: {
        projectReportId: portfolioReport.id,
        title: 'Choix Technologiques',
        description: 'Justification des technologies utilisées',
        order: 2,
      },
    }),
    prisma.reportSection.create({
      data: {
        projectReportId: portfolioReport.id,
        title: 'Conception et Architecture',
        description: 'Description de l\'architecture et du design',
        order: 3,
      },
    }),
    prisma.reportSection.create({
      data: {
        projectReportId: portfolioReport.id,
        title: 'Conclusion et Perspectives',
        description: 'Bilan du projet et améliorations futures',
        order: 4,
      },
    }),
  ]);

  // Contenu de rapport pour quelques groupes
  await Promise.all([
    // Groupe React Masters
    prisma.groupReportContent.create({
      data: {
        projectReportId: portfolioReport.id,
        sectionId: portfolioSections[0].id,
        groupId: portfolioGroups[0].id,
        content: '# Introduction\\n\\nNous avons choisi de créer un portfolio moderne axé sur React et les animations CSS avancées...',
        status: 'completed',
        lastModifiedBy: licence3Students[0].id,
      },
    }),
    prisma.groupReportContent.create({
      data: {
        projectReportId: portfolioReport.id,
        sectionId: portfolioSections[1].id,
        groupId: portfolioGroups[0].id,
        content: '# Technologies\\n\\n- **React 18** pour l\'interactivité\\n- **Framer Motion** pour les animations\\n- **Tailwind CSS** pour le styling...',
        status: 'completed',
        lastModifiedBy: licence3Students[1].id,
      },
    }),
  ]);

  console.log('📋 Rapports de projet créés');

  // 📝 RAPPORT POUR LE PROJET DEVOPS
  const devopsReport = await prisma.projectReport.create({
    data: {
      projectId: projects[5].id, // Projet DevOps
      title: 'Documentation DevOps & CI/CD',
      description: 'Guide complet de l\'infrastructure et des procédures DevOps',
    },
  });

  // Sections du rapport DevOps
  const devopsSections = await Promise.all([
    prisma.reportSection.create({
      data: {
        projectReportId: devopsReport.id,
        title: 'Architecture Infrastructure',
        description: 'Description de l\'architecture et des composants',
        order: 1,
      },
    }),
    prisma.reportSection.create({
      data: {
        projectReportId: devopsReport.id,
        title: 'Pipeline CI/CD',
        description: 'Documentation du pipeline d\'intégration continue',
        order: 2,
      },
    }),
    prisma.reportSection.create({
      data: {
        projectReportId: devopsReport.id,
        title: 'Monitoring et Alerting',
        description: 'Système de surveillance et d\'alertes',
        order: 3,
      },
    }),
    prisma.reportSection.create({
      data: {
        projectReportId: devopsReport.id,
        title: 'Procédures et Bonnes Pratiques',
        description: 'Guide des procédures et recommandations',
        order: 4,
      },
    }),
  ]);

  // Contenu pour quelques groupes DevOps
  await Promise.all([
    // Groupe DevOps Alpha
    prisma.groupReportContent.create({
      data: {
        projectReportId: devopsReport.id,
        sectionId: devopsSections[0].id,
        groupId: devopsGroups[0].id,
        content: '# Architecture Infrastructure\n\nNotre architecture s\'appuie sur une approche conteneurisée avec Docker et Kubernetes...\n\n## Composants principaux\n- **API Gateway**: NGINX Ingress\n- **Container Runtime**: Docker\n- **Orchestration**: Kubernetes',
        status: 'completed',
        lastModifiedBy: master2StudentsForDevops[0].id, // Ivy
      },
    }),
    prisma.groupReportContent.create({
      data: {
        projectReportId: devopsReport.id,
        sectionId: devopsSections[1].id,
        groupId: devopsGroups[2].id, // Groupe Cloud Gamma
        content: '# Pipeline CI/CD\n\nNotre pipeline Jenkins automatise entièrement le processus de déploiement...\n\n## Etapes du pipeline\n1. **Build**: Compilation et tests unitaires\n2. **Test**: Tests d\'intégration\n3. **Deploy**: Déploiement automatisé',
        status: 'completed',
        lastModifiedBy: master2StudentsForDevops[3].id, // Liam
      },
    }),
  ]);

  // 🎯 CRÉER DES SESSIONS DE DÉFENSE POUR LE PROJET MICROSERVICES
  console.log('🎯 Création des sessions de défense...');

  // Sessions de défense pour le projet Microservices (projet prêt pour soutenances)
  const defenseSessions = await Promise.all([
    // Session pour le Groupe Microservices Pro
    prisma.defenseSession.create({
      data: {
        projectId: projects[6].id, // Projet Microservices
        groupId: microservicesGroups[0].id, // Groupe Microservices Pro
        startTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000 + 9 * 60 * 60 * 1000), // Dans 5 jours à 9h
        endTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000 + 10 * 60 * 60 * 1000), // Dans 5 jours à 10h
        location: 'Salle de conférence A - Amphi 3',
        order: 1,
      },
    }),
    // Sessions vides pour d\'autres groupes (pour tester la planification)
    prisma.defenseSession.create({
      data: {
        projectId: projects[6].id,
        groupId: mlGroups[0].id, // Réutilisation pour test - Groupe Alpha ML
        startTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000 + 10 * 60 * 60 * 1000), // Dans 5 jours à 10h
        endTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000 + 11 * 60 * 60 * 1000), // Dans 5 jours à 11h
        location: 'Salle de conférence B - Amphi 2',
        order: 2,
      },
    }),
    prisma.defenseSession.create({
      data: {
        projectId: projects[6].id,
        groupId: mlGroups[1].id, // Réutilisation pour test - Groupe Beta ML
        startTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000 + 14 * 60 * 60 * 1000), // Dans 5 jours à 14h
        endTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000 + 15 * 60 * 60 * 1000), // Dans 5 jours à 15h
        location: 'Salle de conférence A - Amphi 3',
        order: 3,
      },
    }),
  ]);

  console.log('🎯 Sessions de défense créées');

  // 📋 CRÉER DES SOUMISSIONS AVEC DÉTECTION DE PLAGIAT
  console.log('📋 Création des soumissions avec détection plagiat...');

  // Soumissions pour le projet ML
  const mlSubmissions = await Promise.all([
    // Soumission Groupe Alpha - À l'heure
    prisma.deliverableSubmission.create({
      data: {
        deliverableId: deliverables[1].id, // Modèle ML
        groupId: mlGroups[0].id, // Groupe Alpha
        submittedById: master2Students[0].id, // Alice
        gitUrl: 'https://github.com/groupe-alpha/ml-recognition-project.git',
        status: SubmissionStatus.SUBMITTED,
        isLate: false,
        isValid: true,
        similarityScore: 12.5, // Faible similarité
        suspiciousGroups: [], // Pas de plagiat détecté
        plagiarismChecked: true,
      },
    }),
    // Soumission Groupe Beta - En retard mais détection plagiat
    prisma.deliverableSubmission.create({
      data: {
        deliverableId: deliverables[1].id, // Modèle ML
        groupId: mlGroups[1].id, // Groupe Beta
        submittedById: master2Students[3].id, // Diana
        gitUrl: 'https://github.com/groupe-beta/ml-image-classifier.git',
        status: SubmissionStatus.LATE,
        isLate: true,
        daysLate: 2,
        penaltyApplied: 4.0, // 2 points par jour
        isValid: true,
        validationErrors: [],
        similarityScore: 78.3, // Forte similarité !
        suspiciousGroups: [mlGroups[0].id], // Similaire au Groupe Alpha
        plagiarismChecked: true,
      },
    }),
  ]);

  // Soumissions pour le projet Portfolio
  const portfolioSubmissions = await Promise.all([
    // Soumission Groupe React Masters
    prisma.deliverableSubmission.create({
      data: {
        deliverableId: deliverables[2].id, // Site Portfolio
        groupId: portfolioGroups[0].id,
        submittedById: licence3Students[0].id, // Antoine
        gitUrl: 'https://github.com/react-masters/awesome-portfolio.git',
        status: SubmissionStatus.SUBMITTED,
        isLate: false,
        isValid: true,
        similarityScore: 15.8,
        suspiciousGroups: [],
        plagiarismChecked: true,
      },
    }),
    // Soumission Groupe Design Pros - Avec problème de validation
    prisma.deliverableSubmission.create({
      data: {
        deliverableId: deliverables[2].id,
        groupId: portfolioGroups[1].id,
        submittedById: licence3Students[2].id, // Cedric
        gitUrl: 'https://github.com/design-pros/creative-portfolio.git',
        status: SubmissionStatus.VALIDATION_FAILED,
        isLate: false,
        isValid: false,
        validationErrors: ['Fichier README.md manquant', 'Structure des dossiers incorrecte'],
        similarityScore: 8.9,
        suspiciousGroups: [],
        plagiarismChecked: true,
      },
    }),
  ]);

  // Soumissions pour le projet Data Marketing
  const dataSubmissions = await Promise.all([
    // Soumission Groupe Data Analytics - Excellente
    prisma.deliverableSubmission.create({
      data: {
        deliverableId: deliverables[3].id,
        groupId: dataGroups[0].id,
        submittedById: dataStudents[0].id, // Alex
        fileUrl: '/uploads/data-analytics-analysis.zip',
        fileName: 'marketing-analysis-v2.zip',
        fileSize: 45 * 1024 * 1024, // 45MB
        status: SubmissionStatus.SUBMITTED,
        isLate: false,
        isValid: true,
        similarityScore: 6.2, // Très original
        suspiciousGroups: [],
        plagiarismChecked: true,
      },
    }),
  ]);

  console.log('📋 Soumissions avec détection plagiat créées');

  // 🎯 CRÉER DES ÉVALUATIONS AVEC NOTES
  console.log('🎯 Création des évaluations avec notes...');

  // Évaluation FINALISÉE pour le Groupe Alpha (ML)
  const evaluationAlpha = await prisma.evaluation.create({
    data: {
      gridId: defenseGrid1.id,
      evaluatedEntityId: mlGroups[0].id, // Groupe Alpha
      entityType: 'GROUP',
      evaluatorId: teachers[0].id, // John Doe
      status: EvaluationStatus.FINALIZED,
      globalComments: 'Excellente présentation avec une maîtrise technique remarquable. L\'équipe a su expliquer clairement les choix d\'architecture et répondre avec précision aux questions techniques avancées.',
      privateNotes: 'Groupe très bien organisé. Alice et Charlie excellent niveau technique, Bob progresse bien.',
      isVisibleToStudents: true,
      finalizedAt: new Date(),
    },
  });

  // Scores détaillés pour l'évaluation Alpha
  const alphaScores = await Promise.all([
    // Présentation orale (GROUP)
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlpha.id,
        criterionId: defenseCriteria1[0].id,
        valueType: ScoreValueType.NUMERIC,
        numericValue: 18,
        normalizedScore: 90, // (18/20) * 100
        weight: 40,
        feedback: 'Présentation très claire, bien structurée avec d\'excellents supports visuels. Respect parfait du timing.',
      },
    }),
    // Maîtrise technique Alice (INDIVIDUAL)
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlpha.id,
        criterionId: defenseCriteria1[1].id,
        userId: master2Students[0].id, // Alice
        valueType: ScoreValueType.NUMERIC,
        numericValue: 19,
        normalizedScore: 95,
        weight: 35,
        feedback: 'Maîtrise exceptionnelle des concepts ML. Excellente justification des choix d\'hyperparamètres.',
      },
    }),
    // Maîtrise technique Bob (INDIVIDUAL)
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlpha.id,
        criterionId: defenseCriteria1[1].id,
        userId: master2Students[1].id, // Bob
        valueType: ScoreValueType.NUMERIC,
        numericValue: 16,
        normalizedScore: 80,
        weight: 35,
        feedback: 'Bonne compréhension générale, quelques hésitations sur les détails d\'implémentation.',
      },
    }),
    // Maîtrise technique Charlie (INDIVIDUAL)
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlpha.id,
        criterionId: defenseCriteria1[1].id,
        userId: master2Students[2].id, // Charlie
        valueType: ScoreValueType.NUMERIC,
        numericValue: 19,
        normalizedScore: 95,
        weight: 35,
        feedback: 'Excellente maîtrise technique, capable d\'expliquer les algorithmes en détail.',
      },
    }),
    // Réponses aux questions Alice (INDIVIDUAL)
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlpha.id,
        criterionId: defenseCriteria1[2].id,
        userId: master2Students[0].id, // Alice
        valueType: ScoreValueType.NUMERIC,
        numericValue: 17,
        normalizedScore: 85,
        weight: 25,
        feedback: 'Réponses très pertinentes et bien argumentées.',
      },
    }),
    // Réponses aux questions Bob (INDIVIDUAL)
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlpha.id,
        criterionId: defenseCriteria1[2].id,
        userId: master2Students[1].id, // Bob
        valueType: ScoreValueType.NUMERIC,
        numericValue: 15,
        normalizedScore: 75,
        weight: 25,
        feedback: 'Quelques difficultés sur les questions techniques pointues, mais effort d\'adaptation.',
      },
    }),
    // Réponses aux questions Charlie (INDIVIDUAL)
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlpha.id,
        criterionId: defenseCriteria1[2].id,
        userId: master2Students[2].id, // Charlie
        valueType: ScoreValueType.NUMERIC,
        numericValue: 18,
        normalizedScore: 90,
        weight: 25,
        feedback: 'Excellentes réponses, très précises et techniques.',
      },
    }),
  ]);

  // Calculer le score total pour l'évaluation Alpha
  const alphaTotalScore = (
    (18/20 * 40) + // Présentation
    ((19+16+19)/3/20 * 35) + // Maîtrise technique (moyenne des 3)
    ((17+15+18)/3/20 * 25)   // Réponses (moyenne des 3)
  );

  await prisma.evaluation.update({
    where: { id: evaluationAlpha.id },
    data: {
      calculatedScore: alphaTotalScore,
      totalScore: alphaTotalScore,
    },
  });

  // Évaluation du livrable pour le Groupe Alpha (ML)
  const evaluationAlphaLivrable = await prisma.evaluation.create({
    data: {
      gridId: deliverableGrid2.id,
      evaluatedEntityId: mlGroups[0].id, // Groupe Alpha
      entityType: 'GROUP',
      evaluatorId: teachers[0].id, // John Doe
      status: EvaluationStatus.FINALIZED,
      globalComments: 'Travail de très haute qualité. Le modèle présente d\'excellentes performances et le code est exemplaire.',
      isVisibleToStudents: true,
      finalizedAt: new Date(),
    },
  });

  // Scores pour le livrable Alpha
  await Promise.all([
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlphaLivrable.id,
        criterionId: deliverableCriteria2[0].id, // Préparation données
        valueType: ScoreValueType.NUMERIC,
        numericValue: 19,
        normalizedScore: 95,
        weight: 25,
        feedback: 'Excellent travail de nettoyage et d\'augmentation des données.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlphaLivrable.id,
        criterionId: deliverableCriteria2[1].id, // Architecture modèle
        valueType: ScoreValueType.NUMERIC,
        numericValue: 18,
        normalizedScore: 90,
        weight: 35,
        feedback: 'Architecture bien pensée, bonne optimisation des hyperparamètres.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlphaLivrable.id,
        criterionId: deliverableCriteria2[2].id, // Performances
        valueType: ScoreValueType.NUMERIC,
        numericValue: 20,
        normalizedScore: 100,
        weight: 30,
        feedback: 'Performances exceptionnelles, validation croisée rigoureuse.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationAlphaLivrable.id,
        criterionId: deliverableCriteria2[3].id, // Documentation
        valueType: ScoreValueType.NUMERIC,
        numericValue: 17,
        normalizedScore: 85,
        weight: 10,
        feedback: 'Documentation complète et claire.',
      },
    }),
  ]);

  // Évaluation DRAFT pour le Groupe Beta (ML)
  const evaluationBeta = await prisma.evaluation.create({
    data: {
      gridId: defenseGrid1.id,
      evaluatedEntityId: mlGroups[1].id, // Groupe Beta
      entityType: 'GROUP',
      evaluatorId: teachers[0].id, // John Doe
      status: EvaluationStatus.DRAFT,
      globalComments: 'Évaluation en cours de finalisation...',
      privateNotes: 'Présentation correcte mais manque de profondeur technique. Attention au plagiat détecté.',
      isVisibleToStudents: false,
    },
  });

  // Scores partiels pour Beta
  await Promise.all([
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationBeta.id,
        criterionId: defenseCriteria1[0].id,
        valueType: ScoreValueType.NUMERIC,
        numericValue: 14,
        normalizedScore: 70,
        weight: 40,
        feedback: 'Présentation correcte mais manque de structure et de clarté.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationBeta.id,
        criterionId: defenseCriteria1[1].id,
        userId: master2Students[3].id, // Diana
        valueType: ScoreValueType.NUMERIC,
        numericValue: 13,
        normalizedScore: 65,
        weight: 35,
        feedback: 'Compréhension de base mais difficultés à expliquer les choix techniques.',
      },
    }),
  ]);

  // Évaluation pour le Groupe React Masters (Portfolio)
  const evaluationPortfolio1 = await prisma.evaluation.create({
    data: {
      gridId: reportGrid1.id,
      evaluatedEntityId: portfolioGroups[0].id, // Groupe React Masters
      entityType: 'GROUP',
      evaluatorId: teachers[0].id, // John Doe
      status: EvaluationStatus.FINALIZED,
      globalComments: 'Rapport bien structuré avec une excellente analyse technique. La réflexion sur les choix technologiques est pertinente.',
      isVisibleToStudents: true,
      finalizedAt: new Date(),
    },
  });

  // Scores pour le rapport Portfolio
  await Promise.all([
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationPortfolio1.id,
        criterionId: reportCriteria1[0].id, // Structure et rédaction
        valueType: ScoreValueType.NUMERIC,
        numericValue: 17,
        normalizedScore: 85,
        weight: 30,
        feedback: 'Rapport bien organisé, style clair et professionnel.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationPortfolio1.id,
        criterionId: reportCriteria1[1].id, // Analyse technique
        valueType: ScoreValueType.NUMERIC,
        numericValue: 18,
        normalizedScore: 90,
        weight: 40,
        feedback: 'Excellente justification des choix technologiques.',
      },
    }),
    // Contributions individuelles
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationPortfolio1.id,
        criterionId: reportCriteria1[2].id, // Contribution Antoine
        userId: licence3Students[0].id,
        valueType: ScoreValueType.NUMERIC,
        numericValue: 16,
        normalizedScore: 80,
        weight: 30,
        feedback: 'Bonne contribution, analyse pertinente des performances.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationPortfolio1.id,
        criterionId: reportCriteria1[2].id, // Contribution Beatrice
        userId: licence3Students[1].id,
        valueType: ScoreValueType.NUMERIC,
        numericValue: 18,
        normalizedScore: 90,
        weight: 30,
        feedback: 'Excellente analyse du design et de l\'UX.',
      },
    }),
  ]);

  // Évaluation pour le Groupe Data Analytics
  const evaluationData1 = await prisma.evaluation.create({
    data: {
      gridId: deliverableGrid3.id,
      evaluatedEntityId: dataGroups[0].id, // Groupe Data Analytics
      entityType: 'GROUP',
      evaluatorId: teachers[0].id, // John Doe
      status: EvaluationStatus.FINALIZED,
      globalComments: 'Analyse marketing de très haut niveau. Modèles prédictifs performants et recommandations business très pertinentes.',
      isVisibleToStudents: true,
      finalizedAt: new Date(),
    },
  });

  // Scores pour l'analyse Data Marketing
  await Promise.all([
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationData1.id,
        criterionId: deliverableCriteria3[0].id, // Collecte données
        valueType: ScoreValueType.NUMERIC,
        numericValue: 18,
        normalizedScore: 90,
        weight: 25,
        feedback: 'Très bon travail de collecte et nettoyage des données.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationData1.id,
        criterionId: deliverableCriteria3[1].id, // Analyse exploratoire
        valueType: ScoreValueType.NUMERIC,
        numericValue: 19,
        normalizedScore: 95,
        weight: 30,
        feedback: 'Visualisations excellentes, insights très pertinents.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationData1.id,
        criterionId: deliverableCriteria3[2].id, // Modèles prédictifs
        valueType: ScoreValueType.NUMERIC,
        numericValue: 20,
        normalizedScore: 100,
        weight: 35,
        feedback: 'Modèles très performants, validation rigoureuse.',
      },
    }),
    prisma.evaluationScore.create({
      data: {
        evaluationId: evaluationData1.id,
        criterionId: deliverableCriteria3[3].id, // Recommandations business
        valueType: ScoreValueType.NUMERIC,
        numericValue: 17,
        normalizedScore: 85,
        weight: 10,
        feedback: 'Recommandations concrètes et applicables.',
      },
    }),
  ]);

  console.log('🎯 Évaluations avec notes créées');

  // 📊 AFFICHER LE RÉSUMÉ
  console.log('\n🎉 SEEDING TERMINÉ !');
  console.log('\n📊 RÉSUMÉ DES DONNÉES CRÉÉES:');
  console.log(`👨‍🏫 Enseignants: ${teachers.length}`);
  console.log(`🎓 Promotions: ${promotions.length}`);
  console.log(`📋 Projets: ${projects.length} (tous reliés à John Doe)`);
  console.log(`🎓 Étudiants: ${students.length}`);
  console.log('   • Master 2 Info: 25 étudiants');
  console.log('   • Licence 3 Web: 18 étudiants');
  console.log('   • Master 1 Data: 12 étudiants');
  console.log(`📝 Grilles d'évaluation: 9 (toutes à critères pondérés)`);
  console.log(`🎯 Critères d'évaluation: 30+ total`);
  console.log(`📦 Livrables: ${deliverables.length}`);
  console.log(`📋 Évaluations: 6 (5 finalisées, 1 en cours)`);
  console.log(`📋 Soumissions: 5 (avec détection plagiat)`);
  console.log(`👥 Groupes: 12 total (différentes configurations)`);
  console.log(`📄 Rapports de projet: 2 avec sections et contenu`);
  console.log(`🎯 Sessions de défense: ${defenseSessions.length} programmées`);

  console.log('\n🔑 COMPTES DE TEST:');
  console.log('👨‍🏫 ENSEIGNANTS:');
  console.log('   • john.doe@school.com / password123 (PROFESSEUR PRINCIPAL)');
  console.log('   • jane.smith@school.com / password123');
  console.log('   • pierre.martin@school.com / password123');
  console.log('\n🎓 ÉTUDIANTS (exemples):');
  console.log('   • alice.johnson@student.com / password123 (Master 2, Groupe Alpha)');
  console.log('   • antoine.dubois@student.com / password123 (Licence 3, React Masters)');
  console.log('   • alex.chen@student.com / password123 (Master 1, Data Analytics)');

  console.log('\n📋 PROJETS DE TEST (John Doe):');
  console.log('1. 🛒 Projet Web App E-commerce (Master 2) - Mode FREE - VISIBLE');
  console.log('   • Grille livrable avec 4 critères (Architecture, Fonctionnalités, UI, Tests)');
  console.log('   • Livrable: Application E-commerce v1.0 (Archive, deadline +21j)');
  console.log('2. 🤖 Projet Machine Learning (Master 2) - Mode MANUAL - VISIBLE');
  console.log('   • Grille livrable + soutenance avec critères GROUP/INDIVIDUAL');
  console.log('   • Livrable: Modèle ML + Code (Git, deadline +14j)');
  console.log('   • Évaluations: Groupe Alpha (excellentes notes), Groupe Beta (plagiat détecté)');
  console.log('   • Soumissions avec détection plagiat (78.3% similarité Beta vs Alpha)');
  console.log('3. 🎨 Site Web Portfolio (Licence 3) - Mode FREE - VISIBLE');
  console.log('   • Grille rapport avec critères GROUP/INDIVIDUAL');
  console.log('   • Rapport de projet avec sections et contenu');
  console.log('   • Évaluations: React Masters (notes finalisées)');
  console.log('4. 📈 Analyse Marketing (Master 1) - Mode RANDOM - VISIBLE');
  console.log('   • Grille livrable data science avec 4 critères');
  console.log('   • Évaluations: Data Analytics (excellentes performances)');
  console.log('5. 📱 Projet Mobile App (Licence 3) - Mode FREE - VISIBLE');

  console.log('\n🎯 NOUVELLES FONCTIONNALITÉS AJOUTÉES:');
  console.log('🔸 Projet DevOps avec mode MANUAL pour drag & drop');
  console.log('🔸 Groupes vides, incomplets et complets pour tester interface');
  console.log('🔸 Projet Microservices prêt pour soutenances');
  console.log('🔸 Sessions de défense programmées avec créneaux');
  console.log('🔸 9 grilles d\'évaluation complètes avec pondérations');
  console.log('🔸 6 livrables avec deadlines réalistes');
  console.log('🔸 2 rapports de projet avec sections et contenu');
  
  console.log('\n🎓 SPÉCIAL DRAG & DROP (Projet DevOps):');
  console.log('• Groupe DevOps Alpha: 2/4 membres (incomplet)');
  console.log('• Groupe CI/CD Beta: 1/4 membres (très incomplet)');
  console.log('• Groupe Cloud Gamma: 4/4 membres (complet)');
  console.log('• Groupe Monitoring Delta: 0/4 membres (vide)');
  console.log('• Étudiants non assignés disponibles pour drag & drop');
  
  console.log('\n🎯 SPÉCIAL SOUTENANCES (Projet Microservices):');
  console.log('• Groupe Microservices Pro: 5/5 membres (prêt)');
  console.log('• Session de défense: Dans 5 jours à 9h-10h, Amphi 3');
  console.log('• 2 sessions supplémentaires programmées pour tests');
  console.log('• Grilles soutenance + livrable prêtes');

  console.log('\n📱 POUR L\'APP MOBILE:');
  console.log('• Projet ML: Groupe Alpha (évaluation complète), Groupe Beta (en cours)');
  console.log('• Notes réalistes: 13-20/20 selon les critères');
  console.log('• Commentaires pédagogiques détaillés');
  console.log('• Cas de plagiat pour tester les alertes');

  console.log('\n💡 PROCHAINES ÉTAPES:');
  console.log('   - Démarrer l\'API: npm run start:dev');
  console.log('   - Extraire les IDs: node scripts/get-test-ids.js');
  console.log('   - Tester drag & drop avec Projet DevOps');
  console.log('   - Tester planification soutenances avec Projet Microservices');
  console.log('   - Explorer avec Prisma Studio: npx prisma studio');

  console.log('\n🎆 PRÊT POUR TOUS LES TESTS ! (7 projets complets)');
}

main()
  .catch((e) => {
    console.error('❌ Erreur lors du seeding:', e);
    process.exit(1);
  })
  .finally(() => {
    void prisma.$disconnect();
  });
