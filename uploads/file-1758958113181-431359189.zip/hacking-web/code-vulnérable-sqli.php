<?php
session_start();

// Protection contre le session fixation attack
session_regenerate_id(true);

// Vérification de la session
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('Location: /index.php');
    exit();
}

// Génération du token CSRF si inexistant
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = false;
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérification du token CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Invalid CSRF token.");
    }

    // Validation et nettoyage de l'entrée utilisateur
    if (!isset($_POST['username']) || empty(trim($_POST['username']))) {
        $error = true;
    } else {
        $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    }

    if (!$error) {
        include('includes/db_connect.php');

        // Vérification que la connexion à la base de données est établie
        if (!$db) {
            error_log("Database connection failed: " . pg_last_error());
            die("Database error.");
        }

        // Utilisation de requêtes préparées pour éviter l'injection SQL
        $query = "SELECT id FROM users WHERE username = $1";
        $result = pg_query_params($db, $query, array($username));

        if (!$result) {
            error_log("Database query error: " . pg_last_error($db));
            die("An error occurred.");
        }

        if (pg_num_rows($result) === 1) {
            $success = true;
        } else {
            $error = true;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Username</title>
    <link rel="stylesheet" href="style/style.css">
</head>

<body>
    <?php include('includes/header.php'); ?>
    <div id="content">
        <form class="center_form" action="forgotusername.php" method="POST">
            <h1>Forgot Username:</h1>
            
            <input type="text" name="username" placeholder="Username" required><br><br>
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
            <input type="submit" value="Send Reset Token">

            <?php if ($error) : ?>
                <span style="color:blue">If the username exists, you will receive an email.</span>
            <?php elseif ($success) : ?>
                <span style="color:blue">If the username exists, you will receive an email.</span>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>