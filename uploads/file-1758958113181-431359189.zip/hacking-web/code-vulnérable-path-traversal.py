from flask import Flask, request, render_template_string, send_file, abort, escape
import os

app = Flask(__name__)

IMAGE_DIR = os.path.abspath("./images")
ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp"}
print(f"Chemin du répertoire d'images sécurisé : {IMAGE_DIR}")

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure File Viewer</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; color: #333; margin: 0; padding: 20px; }
        h1 { color: #444; }
        form { margin: 20px 0; }
        input[type="text"] { padding: 8px; width: 300px; border: 1px solid #ccc; border-radius: 4px; }
        button { padding: 8px 12px; background-color: #007BFF; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background-color: #0056b3; }
        .result, .error { margin-top: 20px; padding: 10px; border: 1px solid #ccc; background-color: #fff; word-wrap: break-word; }
        .error { color: red; }
        img { max-width: 100%; height: auto; display: block; margin-top: 20px; }
    </style>
</head>
<body>
    <h1>Secure File Viewer</h1>
    <p>Entrez le nom d'un fichier image :</p>
    <form method="GET" action="/read_file">
        <input type="text" name="file" placeholder="Exemple: image.png" />
        <button type="submit">Afficher</button>
    </form>
    {% if image %}
    <div class="result">
        <h3>Image :</h3>
        <img src="{{ image }}" alt="Image non trouvée"/>
    </div>
    {% elif error %}
    <div class="error">
        <h3>Erreur :</h3>
        <p>{{ error }}</p>
    </div>
    {% endif %}
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/read_file', methods=['GET'])
def read_file():
    file_name = request.args.get('file')
    if not file_name:
        return render_template_string(HTML_TEMPLATE, error="Veuillez fournir un nom de fichier.")

    try:
        # Sécurisation du chemin du fichier
        file_path = os.path.join(IMAGE_DIR, os.path.basename(file_name))

        # Vérification si le fichier est bien dans le dossier IMAGE_DIR
        if not file_path.startswith(IMAGE_DIR):
            return render_template_string(HTML_TEMPLATE, error="Accès interdit.")

        # Vérification de l'existence du fichier et de son extension
        if not os.path.exists(file_path) or not os.path.isfile(file_path):
            return render_template_string(HTML_TEMPLATE, error="Fichier non trouvé.")
        
        file_ext = os.path.splitext(file_path)[1].lower()
        if file_ext not in ALLOWED_EXTENSIONS:
            return render_template_string(HTML_TEMPLATE, error="Format de fichier non autorisé.")

        # Retourner l'image
        return render_template_string(HTML_TEMPLATE, image=f"/images/{os.path.basename(file_path)}")

    except Exception as e:
        return render_template_string(HTML_TEMPLATE, error=f"Erreur du serveur.")

@app.route('/images/<filename>')
def serve_image(filename):
    # Empêcher l'accès aux fichiers cachés (ex: .htaccess)
    if filename.startswith('.'):
        abort(403)

    file_path = os.path.join(IMAGE_DIR, filename)
    
    if not file_path.startswith(IMAGE_DIR) or not os.path.exists(file_path):
        abort(404)

    return send_file(file_path)

if __name__ == '__main__':
    if not os.path.exists(IMAGE_DIR):
        os.makedirs(IMAGE_DIR)
    app.run(debug=False, host='0.0.0.0')