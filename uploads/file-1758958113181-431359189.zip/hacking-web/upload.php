<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadDir = 'uploads/';

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        die("Erreur lors de l'upload.");
    }

    if ($_FILES['file']['size'] > 2 * 1024 * 1024) {
        die("Fichier trop volumineux (max 2 Mo).");
    }

    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt'];
    $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf', 'text/plain'];

    $fileInfo = pathinfo($_FILES['file']['name']);
    $fileExtension = strtolower($fileInfo['extension']);
    $fileMimeType = mime_content_type($_FILES['file']['tmp_name']);

    if (!in_array($fileExtension, $allowedExtensions) || !in_array($fileMimeType, $allowedMimeTypes)) {
        die("Type de fichier non autorisé.");
    }

    $safeFileName = time() . '_' . bin2hex(random_bytes(8)) . '.' . $fileExtension;
    $uploadFile = $uploadDir . $safeFileName;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
        echo "Fichier uploadé avec succès : <a href=\"$uploadFile\">$safeFileName</a>";
    } else {
        echo "Échec de l'upload.";
    }
}
?>